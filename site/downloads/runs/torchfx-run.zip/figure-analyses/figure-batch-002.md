# 图片批次 2

## 图片 1：Figure 8. Normalized inference runtime (lower is better) with torch.fx-based TensorRT lowering

![Figure 8. Normalized inference runtime (lower is better) with torch.fx-based TensorRT lowering](../assets/imgs/img_in_chart_box_637_1047_1054_1289.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 6.4 节"Device and Runtime Export/Compilation"中 torch.fx 支持 TensorRT 下沉这一效果类主张——即 torch.fx 提供的程序表示能否被下游编译工具链（TensorRT）使用，并带来可预测的运行时加速。图表角色为**实验结论**（同时隐含**方法流水线**验证：torch.fx 提取的 ahead-of-time 表示是否可被实际编译栈消费）。`[正文支持]`
   - **图表角色**：实验结论。
   - **上文呼应**：第 6.4 节"设备下沉"主张——正文陈述"TensorRT provides a predictable 3.7x runtime speed-up ... for ResNet50 and a 1.54x speed-up for LearningToPaint"（页码：10），对应主张地图"TensorRT 下沉带来 ResNet50 3.7x、LearningToPaint 1.54x 加速"。

2. **图像类型与布局**：柱状图（bar chart），单一坐标系内两组分类（ResNet50、LearningToPaint），每组各两根柱子（蓝色、橙色），每根柱子顶部带误差棒。`[图像直接可见]`

3. **如何阅读**：纵轴为 Normalized Runtime（0–1.2），横轴为两个模型分组；据图注（正文图 8 图例）蓝色=Normalized PyTorch Runtime，橙色=Normalized TensorRT Runtime，图注明确"lower is better"。应比较同一分组内蓝橙两柱的高度差异及误差棒范围。

4. **直接可见的结论**：ResNet50 组：蓝柱≈1.0（误差棒很小），橙柱明显更低，约0.27，误差棒同样很小；LearningToPaint 组：蓝柱≈1.0，橙柱约0.65，误差棒略大于 ResNet50 橙柱但仍较小。两组橙柱均显著低于对应蓝柱，且 ResNet50 的降幅比 LearningToPaint 更大。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为效果类主张提供直接视觉证据——torch.fx 支撑的 TensorRT 下沉相较原生 PyTorch 基线降低了推理运行时，且两个模型的降幅一致方向（TensorRT 更快），与正文"3.7x"（ResNet50）和"1.54x"（LearningToPaint）的倍数陈述在方向上吻合：ResNet50 橙柱目视约为蓝柱的 1/3.7≈0.27，LearningToPaint 橙柱目视约为 1/1.54≈0.65，与图中读出的柱高比例基本一致。`[基于视觉的谨慎推断]` 此证据支持"torch.fx 提供的程序表示可被 ahead-of-time 编译栈（TensorRT）有效利用"这一机制/效果主张，说明 torch.fx 的捕获-变换流水线在设备下沉场景中是可行的（对应模块五"源码到源码代码生成"及符号追踪捕获机制的下游价值）。误差棒较小（尤其 ResNet50）支持正文"predictable"（可预测）这一措辞。该图不能证明的：不能说明该加速对其他模型/硬件的泛化性，也不能说明具体的 30 trials 统计分布细节（图中仅呈现均值±误差棒，无法看出具体标准差数值或分布形态）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的设置——ResNet50 与 LearningToPaint 两个模型，在 NVIDIA Tesla V100-SXM2 16GB GPU（CUDA 11.0）上、经实验性 torch.fx-to-TensorRT 下沉系统、30 次试验（30 trials）下的归一化运行时对比（页码：10）。真实缺口：图中误差棒的具体数值（标准差）无法从像素精确读出，只能定性比较相对大小；若需精确核验需参照附录 D 数值表（PyTorch RN50: 0.2443±0.00119, TensorRT RN50: 0.0662±0.00022；PyTorch LearningToPaint: 0.0068±0.0003, TensorRT LearningToPaint: 0.0044±0.0001，页码：14）。
