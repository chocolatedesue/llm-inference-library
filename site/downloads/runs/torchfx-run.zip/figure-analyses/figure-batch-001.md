# 图片批次 1

## 图片 1：Figure 7. Normalized inference runtime (lower is better) with torch.fx-based Convolution/Batch-Norm fusion.

![Figure 7. Normalized inference runtime (lower is better) with torch.fx-based Convolution/Batch-Norm fusion.](../assets/imgs/img_in_chart_box_637_1020_1059_1268.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：效果类主张。该图验证 6.2.2 节 Conv-BatchNorm 融合优化在 GPU 与两种 CPU 线程配置下带来的推理延迟降低效果，同时是"GraphModule 同时操纵代码与权重简化融合类变换"这一机制主张（模块三）的实践验证场景之一。`[正文支持]`
   - **图表角色**：实验结论（组内蓝/橙柱构成融合前后的对照，兼具对比基线性质）。
   - **上文呼应**：第 6.2.2 节 Conv-BN 融合延迟降低主张（GPU~6%/CPU 默认线程~40%/CPU 无线程~18%）；模块三 GraphModule 技术优势论证。

2. **图像类型与布局**：分组柱状图，横轴分三组（GPU / CPU, Threaded / CPU, Unthreaded），每组两根柱（蓝=未融合基线、橙=融合后），柱顶带误差棒。

3. **如何阅读**：纵轴为 Normalized Runtime（0–1.2，图注"lower is better"），横轴为三种硬件/线程配置；图例（依据同页图注文字）蓝色=Normalized Runtime Unfused，橙色=Normalized Runtime Fused；应比较同组内蓝橙柱高度差，即该配置下融合带来的相对延迟降低比例；误差棒表示测量方差。

4. **直接可见的结论**`[图像直接可见]`：
   - GPU 组：蓝柱=1.0，橙柱≈0.94，两柱误差棒都很短，降幅约 6%。
   - CPU, Threaded 组：蓝柱=1.0，橙柱≈0.71–0.72，橙柱误差棒明显更宽（约 0.62–0.80），降幅目测约 28%–30%。
   - CPU, Unthreaded 组：蓝柱=1.0，橙柱≈0.84–0.85，误差棒中等，降幅目测约 15%–16%。

5. **它验证的论点与方法设计含义**：属效果类主张。图像方向上支持"融合在三种配置下均降低延迟，且 CPU 默认多线程配置降幅最大、GPU 降幅最小"这一定性结论 `[正文支持]`。但具体数值上，图中 CPU, Threaded 组的可见降幅（约 28%–30%）明显低于正文陈述的"40%"，而与附录 C 原始运行时反推的约 28.9% 更吻合；GPU 组约 6% 与正文一致；CPU, Unthreaded 组约 15%–16% 与附录反推的约 15.1% 吻合，但略低于正文"18%"。这为主张地图中已记录的"融合延迟降低百分比正文与附录反推值不一致"提供了独立的视觉交叉验证 `[基于视觉的谨慎推断]`。该图不能证明这一数值差异的具体原因（是否统计口径不同、测量批次不同等），也不能推广到其他模型/硬件上融合效果的普适性。

6. **适用范围与证据缺口**：本图覆盖论文 6.2.2 节报告的 ResNet50 模型，在 NVIDIA Tesla V100-SXM2 GPU 与 Intel Xeon Gold 6138 CPU（默认多线程 / OMP_NUM_THREADS=1 两种配置）下的融合前后归一化运行时对比。真实缺口：CPU, Threaded 组的图像可见降幅（约 28%–30%）与正文文字陈述的"40%"存在明显不一致，且该差异无法仅凭本图或附录 C 数值表完全消解（附录反推值更接近图像读数而非正文数字），构成正文/图题与视觉观察之间的冲突，应标记为缺口。

---

## 图片 2：Figure 6. Normalized inference runtime (lower is better) for torch.fx-based quantization.

![Figure 6. Normalized inference runtime (lower is better) for torch.fx-based quantization.](../assets/imgs/img_in_chart_box_122_630_564_908.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：效果类主张。该图验证 6.2.1 节 torch.fx 支持的量化变换对 DeepRecommender 模型推理运行时的提升效果（正文陈述"up to a 3.3x runtime performance improvement"），并作为 GraphModule 同时修改代码与权重这一机制（模块三）的实践验证场景之一。`[正文支持]`
   - **图表角色**：实验结论。
   - **上文呼应**：第 6.2.1 节量化性能提升主张；附录 B 数值表交叉验证。

2. **图像类型与布局**：分组柱状图，横轴按 Batch Size 分四组（1 / 16 / 64 / 128），每组两根柱（蓝=未量化基线、橙=量化后），柱顶带误差棒。

3. **如何阅读**：纵轴为 Normalized Runtime（0–1.2，图注"lower is better"），横轴为 Batch Size；图例蓝色=Normalized Unquantized Runtime，橙色=Normalized Quantized Runtime；应比较同组内蓝橙柱高度比，即量化后相对未量化基线的运行时比例，比值越小代表加速倍数越高。

4. **直接可见的结论**`[图像直接可见]`：
   - Batch=1：蓝柱=1.0，橙柱≈0.28–0.29，误差棒很短。
   - Batch=16：蓝柱=1.0，橙柱≈0.32，误差棒略宽于 batch=1。
   - Batch=64：蓝柱=1.0，橙柱≈0.64–0.65，误差棒明显更宽。
   - Batch=128：蓝柱=1.0，橙柱≈0.80，误差棒也较宽。
   - 整体趋势：随 batch size 增大，橙柱（量化后运行时）相对蓝柱基线逐渐升高，即量化带来的相对降幅逐渐减小。

5. **它验证的论点与方法设计含义**：属效果类主张。图像在 batch=1 处的降幅最大（橙柱约为基线的 28%–29%，对应加速约 3.4×–3.5×），方向上支持正文"up to 3.3x"的表述，且与附录 B 数据反推的约 3.5×（batch=1）更为吻合，略高于正文陈述的 3.3x，为主张地图中已记录的"3.3x 与附录反推值存在出入"这一数值缺口提供了视觉侧的交叉验证 `[基于视觉的谨慎推断]`。此外，图像清楚显示"量化带来的相对加速随 batch size 增大而单调递减"这一趋势（batch=1 降幅约 71% → batch=128 降幅约 20%），这是文字"up to 3.3x"未明确展开、但图可补充的适用边界信息：量化的收益在大 batch 场景下显著变小 `[基于视觉的谨慎推断，正文未讨论此趋势背后的机制，不应臆测吞吐/带宽瓶颈等原因]`。该图不能证明量化在其他模型架构或硬件上的普适性，也不能解释加速倍数随 batch 衰减的具体原因。

6. **适用范围与证据缺口**：本图覆盖论文 6.2.1 节报告的 DeepRecommender 模型，在 Intel Xeon Gold 6138 CPU 上使用 FBGEMM 量化算子、batch size 为 1/16/64/128 的场景。真实缺口：附录 B 数值表中还包含 batch size=256 的一行数据，但本图横轴只可见 1、16、64、128 四组，未见对应 256 的柱子，无法从当前图像判断该批次是否被裁剪掉或原图本就未绘制此组——标记为图像可见范围与附录数值表覆盖范围不一致的缺口。
