#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[TORCH.FX: PRACTICAL PROGRAM CAPTURE AND TRANSFORMATION FOR DEEP LEARNING IN PYTHON]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[James K Reed, Zachary DeVito, Horace He, Ansley Ussery, Jason Ansel]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[PyTorch] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[程序捕获] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[程序变换] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[中间表示] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[符号追踪]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-28]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

现代深度学习框架提供了嵌入在 Python 中的命令式、即时执行（eager execution）编程接口，以带来高效的开发体验。然而，深度学习从业者有时需要捕获并变换程序结构，以用于性能优化、可视化、分析和硬件集成。我们研究了深度学习领域中用于程序捕获与变换的不同设计方案。通过针对典型的深度学习使用场景（而非长尾场景）进行设计，可以构建出更简单的程序捕获与变换框架。我们将这一原则应用于 torch.fx------一个完全用 Python 编写、专为提升机器学习从业者开发效率而优化的 PyTorch 程序捕获与变换库。我们通过案例研究展示了 torch.fx 如何支持此前在 PyTorch 生态系统中难以实现的工作流。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [TORCH.FX: PRACTICAL PROGRAM CAPTURE AND TRANSFORMATION FOR DEEP LEARNING IN PYTHON],
    [作者], [James K Reed, Zachary DeVito, Horace He, Ansley Ussery, Jason Ansel],
    [发表场所 / 年份], [文中未说明],
    [研究领域], [深度学习系统],
    [关键词], [PyTorch, 程序捕获, 程序变换, 中间表示, 符号追踪],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（5 个）]：`torch.fx` · `PyTorch` · `符号追踪` · `程序中间表示` · `深度学习编译`
]

论文提出 torch.fx，一个纯 Python 实现的 PyTorch 程序捕获与变换库，主张\"只为典型深度学习模型（无数据依赖控制流的算子 DAG）设计而非为长尾场景设计\"，可以在牺牲部分通用性的前提下大幅简化程序捕获、中间表示（IR）与变换编写的复杂度，实验显示其捕获的 IR 操作数（445）远少于 TorchScript（2614）`[作者明确陈述]`，并在量化、算子融合、TensorRT 下沉等案例中获得可观的运行时收益 `[实验支持]`。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- #strong[覆盖页码]：正文第 1--10 页及附录 B/C/D 数值表（第 14 页），另含第 9、10 页共 3 张柱状图的图像证据。
- #strong[明显缺失/损坏]：发表场所与年份 OCR 未能识别，写\"文中未说明\"；论文未给出符号追踪失败率、变换代码行数对比、别名分析屏障的具体量化数据。
- #strong[关键限制]：正文陈述的融合延迟降低百分比（GPU\~6%/CPU 默认线程\~40%/CPU 无线程\~18%）与附录 C 原始数据反推值（约 5.8%/28.9%/15.1%）及图 7 视觉读数（约 6%/28%--30%/15%--16%）存在明显出入，量化\"3.3x\"与附录 B 反推值（约 3.5x，batch=1）也不完全一致 `[实验支持]`；这是本报告需要如实保留而非\"修正\"的信息缺口。
- 本节区分：论文事实（页码可核）与背景知识（无页码，明确标注）。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

PyTorch 采用\"eager execution\"（即时执行，类比：像逐行执行的脚本，写一行跑一行，而不是先画好完整流程图再执行）编程模型，便于调试，但性能优化、量化、硬件下沉等变换需要\"看到\"程序整体结构（IR）`[作者明确陈述]`。这类能力之所以重要，是因为深度学习从业者在生产环境中经常需要把训练好的模型转换为更快、更省资源或能在特定硬件上运行的形式，而 eager 模式本身不产出可供分析的结构化表示。

难点在于：已有能提供结构捕获的系统（如 TorchScript）为了忠实建模完整 Python 语义（可变状态、控制流、复杂数据类型），必须引入词法-语法-编译器全栈与别名分析，导致实现复杂、IR 体积庞大、变换编写困难 `[作者明确陈述]`。成功标准是：在不牺牲开发生产力、不脱离 Python 生态的前提下，让典型模型的结构能被简单地捕获和变换。

#strong[本文的 story]：旧路线（TorchScript）在\"必须支持全部 Python 语言特性\"这一设计前提上付出了过高代价------控制流与别名分析让 IR 变得又大又难用；本文的核心转折是承认\"大多数深度学习模型结构上是平坦的算子 DAG\"这一经验事实，主动放弃对长尾程序（依赖输入值的控制流）的支持，从而换取捕获机制、IR 和变换编写的极简化。

== 4. 旧方法为何不够
<4-旧方法为何不够>

- #strong[图模式框架（TensorFlow/Caffe/Theano）]：原本解决\"提供可被变换的显式图 IR\"问题；限制是用户须脱离 Python 进入 DSL/运行时，调试体验差（无法用 pdb）`[作者明确陈述]`；对应本文用符号追踪+源码级代码生成保持在 Python 生态内，但该批判缺乏直接对比实验 `[无法从当前 OCR 内容确认]`。
- #strong[jit.trace]：原本无侵入地记录一次真实执行；限制是对输入形状产生特化，张量元数据可能逃逸进 Python 控制流，导致对其他形状失效 `[作者明确陈述]`；对应模块一\"符号追踪\"用抽象 Proxy 代替真实值执行，回应实验为 6.1 节 IR 计数对比（间接涉及，非专门验证）。
- #strong[TorchScript（jit.script）]：原本用完整语言工具链支持结构化控制流、可编译期报错；限制是实现复杂、仍不支持完整 Python、捕获的 IR 极\"丰富\"（含标量运算、控制流、别名语义），导致变换编写与维护成本高，操作数达 2614 `[作者明确陈述]`；对应本文 6 指令 DAG-only IR，回应实验为 6.1 节算子计数对比（2614 vs 445）与量化案例中\"生产力提升一个数量级\"的质性陈述 `[作者明确陈述]`。
- #strong[DyNet/LazyTensor]：原本每次调用即时追踪以避免特化失效；限制是重复捕获带来额外开销（LazyTensor 用缓存缓解，仍是补丁）`[作者明确陈述]`；对应本文一次性（ahead-of-time）符号追踪，但缺乏直接开销对比实验 `[无法从当前 OCR 内容确认]`。
- #strong[JAX jit]：原本用纯函数式约束减少不必要重新捕获；限制是执行行为难推理（print/pdb 只在重新追踪时执行）、重新特化造成不可预测的性能\"气泡\" `[作者明确陈述]`；对应本文\"不做特化决策、交由具体变换决定\"（5.3 节），无直接对比实验。
- #strong[TorchScript 别名分析]：原本支持视图别名/原地修改语义下的变换合法性；限制是所有算子须标注别名信息，成本高，未标注调用被保守视为全局内存修改，形成优化屏障 `[作者明确陈述]`；对应本文直接将变异操作定义为未定义行为（5.6 节），但论文未把融合/量化收益显式归因于此设计 `[无法从当前 OCR 内容确认]`。
- #strong[JAX 函数式状态管理]：原本把状态追踪移出框架，模型变为纯函数；限制是需要同时修改状态与代码的变换（如 BatchNorm 折叠）因二者分离而更复杂 `[作者明确陈述]`；对应模块三 GraphModule，回应实验为 6.2.2 节融合案例。
- #strong[含控制流的丰富 IR]：原本更\"忠实\"地表达复杂工作负载；限制是分析须做不动点数据流分析，作者称变换作者常引入 bug，循环携带形状无法满足有限性，只能得到欠约束\"dynamic\"结果 `[作者明确陈述]`；对应本文无控制流 IR 设计，但\"常引入 bug\"缺乏量化支撑 `[无法从当前 OCR 内容确认]`。

== 5. 核心洞见与假设
<5-核心洞见与假设>

`[作者明确陈述]`：可以把\"忠实建模 Python 语义\"这一需求与\"支持量化/融合等变换所需的高层 DAG 结构\"这一需求解耦------变换通常只需在高层 DAG 层面操作，具体实现细节可隐藏在 Convolution、BatchNorm 等高层模块内部，因此捕获机制和 IR 都只需聚焦高层 DAG，不必支持完整 Python。

为落地此洞见所需的实现组件包括：可配置 Tracer、`fx.passes.shape_prop`、`fx.graph_drawer`。三条设计假设（）：①优先让典型模型的捕获/变换简单，即使牺牲对所有程序的支持；②使用 ML 从业者已熟悉的工具（Python 数据结构、公开算子）；③让捕获过程高度可配置，供用户自行应对长尾场景。这些假设的隐含前提是 PyTorch 用户主要是倾向留在 Python 生态、编译器背景较弱的 ML 从业者 `[作者明确陈述]`------若目标用户群体转向需要重度自定义控制流的场景（如带 beam search 的整体解码器），该前提可能不成立 `[基于文中逻辑的推断]`。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入函数或 `nn.Module` → 符号追踪生成 `Graph` → 与模块参数打包为 `GraphModule` → 变换（可重复追踪-变换循环）→ 源码级代码生成还原为可执行/可调试 Python 代码。

+ #strong[符号追踪（4.1 节）]：动机是不依赖真实输入张量、不脱离 Python 即可捕获算子结构 `[作者明确陈述]`；用 Proxy（\"代言人\"占位对象）替代真实张量，经 `__torch_function__` 协议拦截算子分发并记录子模块调用，输出 `Graph`；技术优势是避免特定输入值特化，且可通过 `is_leaf_module`、`create_proxy` 定制追踪粒度 `[作者明确陈述]`；追踪成功率等定量数据 `文中未说明`。
+ #strong[6 指令 DAG-only IR（4.2 节）]：动机是让静态分析只需正向传递函数，避免不动点分析 `[作者明确陈述]`；用 `placeholder/call_function/call_module/call_method/get_attr/output` 六种 opcode 表示 Node，数据依赖通过 args/kwargs 引用表达；技术优势是与张量操作近似一一对应，省去别名标注负担 `[作者明确陈述]`。
+ #strong[GraphModule（4.2 节/5.6 节）]：动机是解决状态与代码分离导致联合修改（如 BatchNorm 折叠）复杂的问题 `[作者明确陈述]`；`call_module` 调 forward、`get_attr` 取参数，参数管理留在 nn.Module 层级、无状态逻辑放在功能性 Graph 中；技术优势是可同时操纵代码与参数，简化融合/量化实现 `[基于文中逻辑的推断，推理依据：4.2 节陈述该能力->6.2.1/6.2.2 案例正是同时修改代码与权重的变换]`。
+ #strong[可配置 Tracer（5.2 节）]：动机是为长尾场景提供逃生舱而不内置进核心系统；`is_leaf_module`/`create_proxy` 可覆写；覆盖多少长尾模型 `文中未说明`。
+ #strong[源码到源码代码生成（4.3 节/5.4 节）]：动机是让变换结果仍是可读、可调试、可再输入捕获流程的 Python 代码；输出可再次被 `symbolic_trace`（如图 3 所示的嵌套追踪流程），也可送入 TorchScript 编译或 `DistributedDataParallel`；独立于具体变换的代码生成开销 `文中未说明`。
+ #strong[无控制流/无别名可变语义（5.5、5.6 节）]：与模块二、三共同支撑简单 IR，代价是无法表示依赖输入值的控制流，子图组合方式留给使用者自行处理 `[作者明确陈述]`。

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制]：DAG-only IR 省去不动点分析 → #strong[收益]：变换只需处理正向传递，降低编写门槛与出 bug 风险 → #strong[条件]：仅当模型确实不含数据依赖控制流 `[基于文中逻辑的推断]`。
- #strong[机制]：不做别名分析、把变异定义为未定义行为 → #strong[收益]：省去标注成本、消除保守优化屏障 → #strong[条件]：使用者需保证追踪期不产生非法原地修改 `[基于文中逻辑的推断]`。
- #strong[机制]：GraphModule 把参数与功能图绑定 → #strong[收益]：联合修改代码与权重的变换（融合、量化）实现更简单 → #strong[条件]：变换确实需要同时触及两者 `[基于文中逻辑的推断]`。
- #strong[机制]：源码级代码生成保持 Python 可读性 → #strong[收益]：可复用 pdb 调试、可再次追踪、可接入下游编译栈（TorchScript/TensorRT）→ #strong[条件]：生成代码需与原语义等价，正确性依赖下游变换自证 `[基于文中逻辑的推断]`。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- IR 是否更简单？→ 对比 jit.script/jit.trace 的算子计数 → 计数更少支持\"简单\"这一效果主张，但不直接证明\"变换更易编写\" `[实验支持]`。
- 量化/融合/QPS 调度/TensorRT 下沉是否带来性能收益？→ 各自的运行时对比实验 → 倍数/百分比读数支持效果主张，但均缺乏第三方复现 `[实验支持]`。
- 融合是否数值正确（鲁棒性）？→ rtol/atol 容差比较 → 通过与否支持正确性主张，但无具体误差分布 `[作者明确陈述]`。
- 符号追踪/GraphModule 的适用范围？→ 论文承认无法处理数据依赖控制流 → 说明适用边界，非效果证据 `[作者明确陈述]`。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 量化案例：DeepRecommender 模型，Intel Xeon Gold 6138 CPU，FBGEMM 量化算子，batch size 1/16/64/128（附录 B 还含 256，但图未见）`[作者明确陈述]`。
- 融合案例：ResNet50，NVIDIA Tesla V100-SXM2 GPU 与 Intel Xeon Gold 6138 CPU（默认多线程/OMP\_NUM\_THREADS=1 两种配置）`[作者明确陈述]`。
- TensorRT 下沉案例：ResNet50、LearningToPaint，NVIDIA Tesla V100-SXM2 16GB GPU（CUDA 11.0），30 trials `[作者明确陈述]`。
- QPS 调度案例：大规模分布式训练任务，具体规模、调用数量、方差 `文中未说明`。
- 重复次数/统计方式：TensorRT 案例给出 30 trials 与标准差；量化、融合案例的重复次数与统计方式 `文中未说明`（仅附录给出 stdev）。
- 基线与超参数：量化/融合以未变换的 PyTorch 原生实现为基线；具体超参数 `文中未说明`。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：IR 算子/节点计数；测量捕获出的操作个数；无明确优劣声明，论文以\"更少=更简单\"为叙事方向。

  - #strong[定义与公式]：无可核验公式，为直接计数结果：jit.script=2614，jit.trace=860，torch.fx=445。#strong[来源层级]：无可核验公式。
  - #strong[实验用途]：回答\"torch.fx 是否降低 IR 复杂度\"，比较对象为 jit.script、jit.trace。
  - #strong[读数与边界]：445 远少于 2614/860 `[作者明确陈述]`；不能证明\"变换更易编写/维护\"，缺乏代码行数或 bug 率对比。

- #strong[指标与方向]：量化推理速度提升倍数；越高越好。

  - #strong[定义与公式]：正文直接陈述\"up to a 3.3x\"，无计算式；#strong[来源层级]：推导关系（非原文公式）\#mi(\"\\frac{\\text{Runtime}#emph[{Unquantized}}{\\text{Runtime}]{Quantized}}\")，推理依据：附录 B 给出两者运行时 -\> 相除得到倍数 -\> batch=1 时约 3.5x，与正文\"3.3x\"不完全一致 `[基于文中逻辑的推断]`。
  - #strong[实验用途]：量化效果主张，与浮点基线比较。
  - #strong[读数与边界]：图像读数在 batch=1 处降幅最大（约 3.4--3.5×），随 batch 增大收益递减（batch=128 降幅约 20%）`[基于视觉的谨慎推断]`；不能证明其他模型/硬件的普适性。

- #strong[指标与方向]：量化各阶段耗时（preparation/calibration/conversion）；越低越好。

  - #strong[定义与公式]：直接报告 44 ms / 590 ms / 3.8 s，无公式编号。
  - #strong[实验用途]：说明量化转换本身开销规模。
  - #strong[读数与边界]：仅说明开销远小于推理侧收益的时间尺度；无重复次数说明 `文中未说明`。

- #strong[指标与方向]：Conv-BN 融合延迟降低百分比；越高（降低越多）越好。

  - #strong[定义与公式]：#strong[来源层级]：推导关系（非原文公式）\#mi(\"\\frac{\\text{Runtime}#emph[{unfused}-\\text{Runtime}]{fused}}{\\text{Runtime}\_{unfused}}\")，推理依据：附录 C 给出各配置 Unfused/Fused 运行时 -\> 按此比例可得降低百分比 `[基于文中逻辑的推断]`；核验结果 GPU≈5.8%（正文\~6%，吻合），CPU 默认线程≈28.9%（正文\"40%\"，不符），CPU 无线程≈15.1%（正文\"18%\"，有出入）。
  - #strong[实验用途]：融合优化效果主张。
  - #strong[读数与边界]：三组数值存在不同程度不吻合，论文未说明测量批次是否一致，不能强行调和 `[实验支持，但数值有出入]`。

- #strong[指标与方向]：融合数值正确性判据；误差需低于阈值。

  - #strong[定义与公式]：#strong[来源层级]：原文公式（阈值判据）\#mi(\"|\\text{fused}-\\text{unfused}| \\le \\text{atol} + \\text{rtol}\\times|\\text{unfused}|\")，rtol=1e-05，atol=1e-08 为原文明确给出的数值，完整不等式写法/公式编号文中未给出。
  - #strong[实验用途]：验证融合变换数值正确性（鲁棒性证据）。
  - #strong[读数与边界]：仅说明\"confirmed\"通过，未给出最大误差观测值或通过率 `[作者明确陈述]`。

- #strong[指标与方向]：融合变换本身运行耗时；越低越好。

  - #strong[定义与公式]：直接报告 81 ms，无公式编号。
  - #strong[实验用途]：说明变换开销远小于其带来的推理加速。
  - #strong[读数与边界]：仅单点数值，无对比或重复次数说明 `文中未说明`。

- #strong[指标与方向]：程序调度 QPS 提升；越高越好。

  - #strong[定义与公式]：无可核验公式，仅文字\"up to 9%\"。
  - #strong[实验用途]：重叠远程调用与本地计算的调度优化效果主张。
  - #strong[读数与边界]：无附录数值表或图表支撑，具体测量条件 `文中未说明`。

- #strong[指标与方向]：TensorRT 下沉推理加速倍数；越高越好。

  - #strong[定义与公式]：#strong[来源层级]：推导关系（非原文公式）\#mi(\"\\text{加速倍数}=\\text{Runtime}#emph[{PyTorch}/\\text{Runtime}]{TensorRT}\")，推理依据：附录 D 给出两者运行时 -\> 相除 `[基于文中逻辑的推断]`；核验结果 ResNet50≈3.69（正文\"3.7x\"吻合），LearningToPaint≈1.545（正文\"1.54x\"吻合）。
  - #strong[实验用途]：设备下沉/编译效果主张。
  - #strong[读数与边界]：一致性良好，误差棒较小支持\"predictable\"措辞 `[实验支持]`；不能说明其他模型/硬件的泛化性。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [jit.trace], [形状特化，元数据逃逸致其他形状失效], [符号追踪], [IR 计数间接涉及；形状泛化性专项对比`文中未说明`],
    [jit.script (TorchScript)], [实现复杂，IR 丰富致维护成本高], [6 指令 DAG-only IR], [6.1 节算子计数（2614 vs 445）；生产力提升仅质性陈述],
    [DyNet/LazyTensor], [每次调用重复捕获，开销大], [AoT 符号追踪], [无直接开销对比实验`文中未说明`],
    [JAX jit], [重新特化不可预测，print/pdb 行为难推理], [无特化决策的 AoT 捕获], [无直接对比实验`文中未说明`],
    [TorchScript 别名分析], [标注成本高，形成优化屏障], [不做别名分析，未定义行为], [未显式归因量化的优化收益案例`文中未说明`],
    [JAX+Haiku/Flax 函数式状态], [状态代码分离致联合变换复杂], [GraphModule], [6.2.2 融合案例，但无直接工作量对比`文中未说明`],
  )]
  , kind: table
  )

- 比较结果仅说明当前论文实验设置内谁表现更好，不能证明对方方法在所有场景失效。

#strong[主张与证据强度]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [IR 更简单（445 vs 2614/860 算子）], [6.1 节文本数值], [`[作者明确陈述]`，计数确凿；\"更易维护\"缺乏量化对照],
    [量化最高 3.3x 提升], [正文+附录 B+图 6], [`[实验支持]`，但与附录反推约 3.5x（batch=1）存在出入，且收益随 batch 增大递减],
    [融合降低延迟 6%/40%/18%], [正文+附录 C+图 7], [`[实验支持]`，CPU 默认线程组数值与附录/图像反推不吻合（约 28%--30% vs 40%）],
    [融合数值正确], [rtol/atol 判据], [`[作者明确陈述]`，但无误差分布/通过率细节],
    [调度 QPS 提升最高 9%], [正文陈述], [`[作者明确陈述]`，无附录数据支撑，测量条件`文中未说明`],
    [TensorRT 加速 3.7x/1.54x], [正文+附录 D+图 8], [`[实验支持]`，附录反推值与正文吻合，证据较完整],
  )]
  , kind: table
  )

- 上述比较提升均以论文自身原生 PyTorch 实现为基线，绝对/相对口径见各指标条目；无第三方复现数据。
- 融合与量化的数值出入是本报告发现的具体证据缺口，不应被当作已被完全证实的精确数字看待。
- 缺失消融：论文未对\"去掉某个 IR opcode/去掉 GraphModule 绑定\"做系统消融，属证据状态而非补造。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_122_630_564_908.jpg", width: 100%)
    #emph[Figure 6. Normalized inference runtime (lower is better) for torch.fx-based quantization.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：量化最高 3.3x 提升]
    - #strong[图组结论]：batch=1 降幅约 71%（约 3.4--3.5×），batch=128 降幅收窄至约 20%，收益随 batch 增大递减。

- #strong[论证关系]：batch=1 读数与附录 B 反推值（约 3.5×）更吻合，为正文\"3.3x\"提供交叉验证但存在数值出入。

- #strong[适用范围]：附录含 batch=256 数据但图未见对应柱子；不能证明其他模型架构/硬件的普适性。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_637_1020_1059_1268.jpg", width: 100%)
    #emph[Figure 7. Normalized inference runtime (lower is better) with torch.fx-based Convolution/Batch-Norm fusion.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：融合延迟降低 6%/40%/18%]
    - #strong[图组结论]：GPU 组降幅约 6%，CPU 默认线程组约 28%--30%，CPU 无线程组约 15%--16%。

- #strong[论证关系]：三组均支持融合降低延迟，但 CPU 默认线程组图像读数与正文\"40%\"不符，更接近附录反推约 28.9%。

- #strong[适用范围]：无法判定数值出入具体原因，不能推广到其他模型/硬件。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_637_1047_1054_1289.jpg", width: 100%)
    #emph[Figure 8. Normalized inference runtime (lower is better) with torch.fx-based TensorRT lowering]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：TensorRT 加速 3.7x/1.54x]
    - #strong[图组结论]：ResNet50 组降幅目视约为 1/3.7，LearningToPaint 组约为 1/1.54，误差棒均较小。

- #strong[论证关系]：方向与附录 D 数值吻合，误差棒小支持\"predictable\"措辞。

- #strong[适用范围]：不能说明其他模型/硬件的泛化性，误差棒精确标准差需参照附录 D。
  ],
)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：如何在不脱离 Python、不牺牲开发生产力的前提下为深度学习模型提供可用于变换的结构化表示？
  - 旧方法限制：TorchScript 全量语言建模导致 IR 庞大（2614 操作）、变换编写难；图模式框架脱离 Python 生态；追踪类方法（jit.trace/DyNet/JAX jit）存在特化失效或重复捕获开销。
    - 核心洞见/假设：解耦\"忠实建模 Python 语义\"与\"支持变换所需的高层 DAG 结构\"，只服务典型无控制流模型。
      - 方法模块：符号追踪 + 6 指令 DAG-only IR + GraphModule + 可配置 Tracer + 源码级代码生成。
        - 可验证预测：捕获的 IR 操作数应显著少于 TorchScript；联合修改代码与权重的变换（融合、量化）应更易实现。
          - 指标与实验：IR 算子计数对比（6.1 节）；量化/融合/TensorRT 下沉运行时对比（6.2--6.4 节）。
            - 图表证据：图 6（量化）、图 7（融合）、图 8（TensorRT）柱状图。
              - 结论与适用边界：IR 简化证据确凿（445 vs 2614）；性能收益方向一致但部分具体数值（融合 40%、量化 3.3x）与图/附录反推值存在出入，未被当前证据完全消解；无控制流支持仍是明确适用边界，长尾场景需变换作者自行处理。

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- #strong[贡献]：符号追踪捕获机制、6 指令 DAG-only IR、GraphModule（功能图+有状态模块绑定）、源码到源码代码生成 `[作者明确陈述]`。
- #strong[证据充分的结论]：torch.fx 捕获的 IR 操作数显著少于 TorchScript（445 vs 2614）`[实验支持]`；TensorRT 下沉带来可预测的运行时加速（附录数据与正文吻合）`[实验支持]`。
- #strong[尚属推断的意义]：GraphModule 简化联合代码/权重变换的机制性优势，是基于设计动机与案例呼应的推断，而非直接的对照实验 `[基于文中逻辑的推断]`。
- #strong[适用条件]：仅适用于无数据依赖控制流的\"basic block\"模型（MLP、CNN、DLRM 类推荐模型、去循环的 Transformer 编码器等）`[作者明确陈述]`。
- #strong[局限]：融合/量化的具体数值与附录反推值存在未解释的出入；多数\"旧方法批判\"缺乏直接定量对比实验；案例均来自 Facebook/Meta 内部生态，缺乏第三方复现 `[作者明确陈述]`。
- #strong[下一步验证]：需要变换代码行数/开发时长的系统性对比、符号追踪失败率统计、以及澄清融合/量化数值出入的测量协议。

#strong[审稿式风险检查]：

- 贡献新意：核心设计原则（为典型场景简化而非通用）有明确论证与对比数据支撑，当前证据未显示该风险。
- 写作/可复现性：案例研究细节（如具体超参数、QPS 实验条件）多处\"文中未说明\"，存在可复现性风险。
- 效果大小：融合/量化百分比与附录反推值不一致，效果量的精确性存在风险；TensorRT 数据一致性良好，该项风险较低。
- 实验覆盖：缺乏与 jit.trace/DyNet/JAX jit/别名分析屏障的直接定量对比，覆盖度不完整，存在风险。
- 方法设计：无控制流支持是作者主动承认的设计取舍而非未被发现的缺陷，当前证据未显示该项为风险。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：Eager execution（即时执行）------代码写一行执行一行的编程模型。

  - #strong[第一性原理角色]：连接\"开发便利性\"与\"缺乏结构化表示\"这一因果链的起点；`[背景知识]`。
  - #strong[本文位置]：论文批判的基础执行模型，是引出捕获需求的根源。

- #strong[术语]：符号追踪（Symbolic Tracing）------用占位对象（Proxy）代替真实值运行程序以记录操作序列。

  - #strong[第一性原理角色]：受\"不依赖具体输入值\"这一约束，连接\"程序执行\"与\"结构记录\"两个基本量。
  - #strong[本文位置]：torch.fx 捕获机制的核心，模块一。

- #strong[术语]：Proxy（代言人对象）------鸭子类型的占位符，记录别人对它做了什么操作而不真正计算。

  - #strong[第一性原理角色]：作为张量的替身，使追踪不受具体形状/数值约束。
  - #strong[本文位置]：符号追踪实现细节。

- #strong[术语]：DAG-only IR（无环图中间表示）------仅六种 opcode 构成、不含控制流的程序表示。

  - #strong[第一性原理角色]：受\"分析必须终止且无需不动点迭代\"这一数学约束驱动，连接\"程序结构\"与\"静态分析可行性\"。
  - #strong[本文位置]：模块二核心设计。

- #strong[术语]：GraphModule------把功能性 Graph 与 nn.Module 的有状态参数绑定的对象。

  - #strong[第一性原理角色]：连接\"无状态计算逻辑\"与\"有状态参数\"两个基本量，使二者可被同一变换联合修改。
  - #strong[本文位置]：模块三，支撑融合/量化案例。

- #strong[术语]：别名（Aliasing）/可变状态（Mutability）------两个变量名可能指向同一份可被原地修改的数据。

  - #strong[第一性原理角色]：受内存共享约束，是编译器判断变换合法性时的复杂度来源；`[背景知识]`。
  - #strong[本文位置]：论文明确不做别名分析，将变异定义为未定义行为。

- #strong[术语]：不动点数据流分析（Fix-point Dataflow Analysis）------含循环/分支时需反复迭代直至稳定的分析方法。

  - #strong[第一性原理角色]：受\"格的单调性与有限性\"数学约束支配，是控制流分析复杂度的根源；`[背景知识]`。
  - #strong[本文位置]：论文用以论证为何避免支持控制流。

- #strong[术语]：算子融合（Operator Fusion）------把多步计算合并为一步执行。

  - #strong[第一性原理角色]：连接\"减少中间内存读写\"与\"降低运行时延迟\"这两个物理量；`[背景知识]`。
  - #strong[本文位置]：6.2.2 节案例研究对象。

- #strong[术语]：量化（Quantization）------用更少位数表示数值以降低内存与计算开销。

  - #strong[第一性原理角色]：在\"数值精度\"与\"计算/存储资源消耗\"之间做权衡；`[背景知识]`。
  - #strong[本文位置]：6.2.1 节案例研究对象。

=== 12.2 学习路径
<122-学习路径>
+ #strong[张量与算子]（基本对象）：理解深度学习计算的最小单位是张量和对其的算子调用，这是理解\"程序即算子序列\"的前提。
+ #strong[有向无环图（约束）]：理解\"数据只能向前流动、无回路\"这一结构约束，才能理解为何 torch.fx 选择只支持 DAG。
+ #strong[追踪与符号执行（机制）]：理解\"用假值跑一遍程序记录操作\"这一机制，才能理解符号追踪如何捕获结构而不依赖具体输入。
+ #strong[静态分析复杂度（机制/约束）]：理解为何含控制流的程序分析需要不动点迭代，才能理解 torch.fx 舍弃控制流带来的简化收益。
+ #strong[运行时性能指标（指标/系统行为）]：理解\"归一化运行时\"\"加速倍数\"等衡量方式，才能读懂量化、融合、下沉实验的效果证据。
