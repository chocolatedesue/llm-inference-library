# 图片批次 3

## 图片 1：Figure 6. (a) Sweet spot of the token budget in chunk-prefill. The decode uses a fixed batch size of 32, with each request having a reused context length of 1K tokens. (b) Latencies with varied reused context of the fused prefill chunk in chunk-prefill. The token budget is fixed at 512, and the reused context length of decode phase is the same as in (a).

![Figure 6. (a) Sweet spot of the token budget in chunk-prefill. The decode uses a fixed batch size of 32, with each request having a reused context length of 1K tokens. (b) Latencies with varied reused context of the fused prefill chunk in chunk-prefill. The token budget is fixed at 512, and the reused context length of decode phase is the same as in (a).](../figure-groups/page-0004-e505d9117a7a.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图（Figure 6(a)(b)，位于§2.3.2/页码5）用于量化"旧方法的限制"中 chunked-prefill 的核心矛盾——token 预算既要"大"以打满 GPU、又要"小"以满足 TBT SLO，二者结构性冲突；同时揭示复用上下文过长时该方法失效的具体机制。**图表角色**：问题严重性（对基线方法结构性缺陷的量化刻画）。**上文呼应**：对应"旧方法的限制"第2类（Chunked-prefill）及"主张地图"中"chunked-prefill 存在 SLO合规 vs 高利用率两难"一条 [正文支持]。

2. **图像类型与布局**：两个并列折线图（panel）。Panel 1（a）：x 轴为 Token budget（对数刻度，128/512/2048…），y 轴为 Latency(ms)（100–500）；两条曲线——"70B"（蓝色 ×marker，实测）与"Linear scale"（红色虚线，理论线性参考），并有文字标注箭头指向"Saturation (4K, 505ms)"。Panel 2（b）：x 轴为 Reused context(K)（对数刻度，1/4/16/64…），y 轴为 Latency(ms)（约100–300+）；两条曲线——"Decode BS=8"（蓝色）与"Decode BS=64"（橙色）。

3. **如何阅读**：Panel(a) 应比较实测曲线相对线性参考线的偏离程度，找出偏离开始加剧的拐点及饱和点数值；Panel(b) 应比较两条不同 decode batch size 曲线随 reused context 增长的走势是否一致，判断影响延迟的主因是 batch size 还是 reused length。

4. **直接可见的结论**：Panel(a) 中实测曲线在较小 token budget 区间与线性参考线接近重合，但约从中段开始明显向上偏离线性，并在标注的 4K 处达到约 500ms 附近的延迟峰值 [图像直接可见]。Panel(b) 中两条曲线在 reused context 较小时（约数K以内）都保持较低且平稳的延迟水平，此后随 reused context 增大均显著上升，到最大取值处 BS=64 曲线明显高于 BS=8 曲线，但两条曲线整体上升趋势/形状相似 [图像直接可见]。

5. **它验证的论点与方法设计含义**：属于必要性类证据，证明 chunked-prefill 的两难是架构性、不可通过调参规避的问题 [正文支持]。Panel(a) 为正文"70B 模型在 8×A100 打满 GPU 需 4K 预算、对应延迟 505ms，远超 100ms SLO"提供图形层面的直接支撑，量化展示了"打满利用率"所需预算与"满足 SLO"所允许预算之间的数量级差距。Panel(b) 证明 TBT 随复用上下文增长而显著恶化，且该恶化趋势在不同 decode batch size 下都存在（两曲线形态相近），说明问题根源在于复用上下文长度本身而非 batch size 配置，因而无法通过调整 batch size 规避——这直接构成 MuxWise 提出"以空间复用取代同流水线内时间融合"的动机来源。该图无法证明的是：MuxWise 自身在同等设置下的对照表现（图中不含 MuxWise 数据，仅刻画 chunked-prefill 基线自身特性）。

6. **适用范围与证据缺口**：本证据覆盖 Llama3-70B 部署于 8×A100 GPU 的设置；Panel(a) 中 decode batch size 固定为32、reused context 固定1K；Panel(b) 中 token budget 固定512、对比 decode batch size 8 与 64 [正文支持，页码5]。真实缺口：除标注的 (4K, 505ms) 拐点外，曲线上其余具体数值点仅能视觉估读而非精确读出，图像分辨率不足以确认精确刻度值。

---

## 图片 2：Figure 7. An ideal solution: prefill-decode multiplexing.

![Figure 7. An ideal solution: prefill-decode multiplexing.](../assets/imgs/img_in_image_box_215_143_550_301.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：本图（Figure 7，页码5）是§2.4引出新范式时给出的概念性示意图，用于说明作者提出的"理想方案"——intra-GPU PD multiplexing——在机制上如何区别于Figure 4展示的三种旧方法（分离式、动态分离式、chunked-prefill的时间交替执行）。**图表角色**：方法流水线（机制类）。**上文呼应**：对应"核心洞见与假设"——让prefill与decode在同一GPU内部、同一时刻通过划分计算单元"空间上并行"执行 [正文支持]。

2. **图像类型与布局**：调度时序示意图，风格与Figure 4类似。左侧4行，每行前方带有堆叠圆盘状图标；右侧沿时间轴（Time，从左到右）排列一系列色块，色块分蓝色（图例标注为"Prefill"）与绿色（图例标注为"Decode iteration"）两类；部分色块标注批次编号（b1、b2、b1&2等）；顶部标注各批次时长（b1:1T、b2:2T、b3:1.2T）及最右侧 b1' 对应 0.5T；图上还有竖直箭头标注为"TTFT of batch"。

3. **如何阅读**：横轴为时间进程；纵向4行代表并行的资源单元；每个色块颜色表示该时刻该资源正执行prefill还是decode，块上文字表示归属批次；顶部箭头表示各批次从到达到首个色块出现之间的TTFT。应重点比较同一时间列内是否有蓝、绿色块并存于不同行（体现空间并行），以及色块序列是否连续无空隙（体现"无气泡"）。

4. **直接可见的结论**：在多个时间列中可见蓝色块与绿色块同时分布于不同行（如中段区域"b1 b1 / b2 b1 / b1&2"等多行并列的色块组合），表明prefill与decode在同一时刻分别占据不同资源行执行 [图像直接可见]。色块序列沿时间轴排列基本连续，未见明显空白间隙 [图像直接可见]。图右侧b1'对应的时长标注（0.5T）明显短于左侧b1（1T）、b2（2T）[图像直接可见]。图例明确区分蓝色=Prefill、绿色=Decode iteration [图像直接可见]。

5. **它验证的论点与方法设计含义**：属于机制类证据，用于示意"prefill 和 decode 动态共享GPU内计算资源（SM）"这一核心范式，与正文"prefill and decode dynamically share the compute resources (SMs) within each GPU...By reserving sufficient SMs to satisfy decode SLOs and assigning the remaining SMs to prefill"直接呼应 [正文支持]。图中不同批次prefill/decode色块在同一时刻分处不同行，示意性支撑"空间并行使两阶段互不阻塞独立执行"的设计假设；b1'相对更短的时长标注示意性地体现该范式对TTFT的潜在改善预期。需注意：本图是提出范式时的抽象概念示意图，并非真实系统实测数据（区别于后续Figure 14/15等实验图），图中数值（1T/2T/1.2T/0.5T）为相对时间示意单位而非实测延迟读数，不能作为效果量化证据，也不能证明MuxWise实际实现中的真实气泡水平或延迟表现——这些由§4实验部分的图表给出。

6. **适用范围与证据缺口**：本图覆盖范围是§2.4提出新范式时构造的一个抽象调度示例场景（4行资源、b1/b2/b3/b1'四批次），用于定性阐释与Figure 4三种旧方法的机制差异 [正文支持，页码5]。真实缺口：图中左侧堆叠圆盘状图标的具体含义（代表GPU数量、SM分区数或其他资源单位）在图像本身及全文OCR图注中均未说明；部分色块内标注文字（如"b1&2"的合并逻辑细节、各行具体对应的资源量）因图像分辨率较低难以完全辨认，仅可确认批次编号的大致归属。
