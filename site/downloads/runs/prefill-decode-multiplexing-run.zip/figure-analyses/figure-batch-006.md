# 图片批次 6

## 图片 1：Figure 12. The dispatching policy of MuxWise.

![Figure 12. The dispatching policy of MuxWise.](../assets/imgs/img_in_image_box_638_145_1117_316.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图对应 §3.4.2 Dispatching policy，是 SLO 感知调度器模块的**方法流水线**图解，用于说明"如何在无气泡引擎与抗争用估计器的基础上，逐时刻做出 SM 划分与请求调度决策"这一具体机制，而非展示性能数据。它呼应报告"方法推理树 - 模块三：SLO-aware Dispatcher"中关于"每个 prefill batch 完成、每次 decode 迭代结束时重新决策"及"允许短请求抢占长请求但不允许递归抢占"的设计描述。[正文支持]
   - **图表角色**：方法流水线。
   - **上文呼应**：第 9 页 §3.4.2；对应"论文 Story 与贡献边界"中的核心贡献 2（PD 多路复用范式的具体调度设计）。

2. **图像类型与布局**：示意图/时间轴流程图，分上下两行（Request Status / GPU Status），横轴为 Time，纵向以虚线框划分三个连续时间段。每个时间段内，Request Status 行列出正在处理的 prefill 请求（带 bs、len 标注）与当前 decode 批次（带 bs 标注）；GPU Status 行对应展示"PLs in Pn"（该请求的 prefill layers）与"Decode(bs=…)"两个色块及其占比百分比。段与段之间用文字标注触发事件（"P₀ finishes"、"P₂ preempts P₁"）。[图像直接可见]

3. **如何阅读**：从左到右按时间推进阅读三个分段；每段内对比 Request Status（谁在被处理）与 GPU Status（对应的 SM 划分比例），三段共同展示同一调度过程随事件演化的资源分配变化。[图像直接可见]

4. **直接可见的结论**：
   - 第一段：请求 P1(bs=1,len=2048) 与 P0(bs=4,len=512) 的 prefill 同时进行，decode(bs=16) 并行执行；GPU 划分为 PLs 40% / Decode 60%。
   - "P0 finishes" 后进入第二段：仅剩 P1(bs=1,len=2048) 的 prefill 继续，decode 批次扩大为 bs=20；GPU 划分变为 PLs 20% / Decode 80%。
   - "P2 preempts P1" 后进入第三段：新请求 P2(bs=2,len=256) 抢占 P1，Request Status 中 P2 排在 P1 之上，decode(bs=20) 不变；GPU 划分变为 PLs 30% / Decode 70%。
   [图像直接可见]

5. **它验证的论点与方法设计含义**：该图属于**机制**类证据，直接可视化正文所述"the dispatcher allocates a best-fit number of SMs (60%) to decode and assigns the remaining [40%] to prefill"这一分配规则（与第一段 40%/60% 划分一致），并具体展示了"decode SLO 优先、prefill 尽力而为"的调度优先级（Decode 色块随 batch 增大而占比提升，从 60%→80%→70%），以及"允许短请求抢占长请求"的调度能力（P2 抢占 P1）。这支持了报告"方法推理树-模块三"中关于调度器分配逻辑与抢占机制的设计描述，读者可据此理解 GPU 划分比例是随 decode batch 组成动态重算的，而非固定配置。该图仅说明调度机制本身，**不能**证明该机制带来的实际 goodput/SLO 提升幅度——量化提升需依赖端到端实验（如图 14）。[正文支持]

6. **适用范围与证据缺口**：本图为一个抽象示意案例（P0/P1/P2 三个请求的假设时间线），用于说明调度逻辑，并非某次具体实验的实测时序数据；正文与图注均未说明这些数值（bs、len、百分比）来自哪个具体模型/硬件配置的真实运行记录，还是纯示意值 [文中未说明，无法从当前 OCR 内容确认该图数值是否为真实实验采样]。无其他额外证据缺口。

---

## 图片 2：Figure 14. 99%-ile TTFT and TBT for Llama-8B and Llama-70B on real-world Conversation and Tool&Agent workloads. Chunked represents chunked-prefill in SGLang. Values marked with * are too large; we clip their corresponding bars, so the bar height only decodes their relative size.

![Figure 14. 99%-ile TTFT and TBT for Llama-8B and Llama-70B on real-world Conversation and Tool&Agent workloads. Chunked represents chunked-prefill in SGLang. Values marked with * are too large; we clip their corresponding bars, so the bar height only decodes their relative size.](../figure-groups/page-0010-6b732e393447.png)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：本图为 Figure 14，属于**实验结论**（效果类证据），对应 §4.2.1 End-to-end Performance，用于验证核心主张——MuxWise 在真实世界工作负载（Conversation、Tool&Agent）下、不同模型规模（Llama-8B/70B）上，相对四个基线（chunked-prefill、NanoFlow、LoongServe、SGLang-PD）在 99%-ile TTFT 与 TBT 上的端到端优势，是摘要"平均 2.20×（最高 3.06×）goodput 提升"这一总览主张在延迟维度上的具体实验支撑之一。[正文支持]
   - **图表角色**：实验结论 / 对比基线。
   - **上文呼应**：第 10 页 §4.2.1；对应"实验、指标与文字可确认的结论"中"真实负载端到端评测（Figure 14）"一条。

2. **图像类型与布局**：多子图分组柱状图。可见五组柱状图容器，按标注分别为 Panel1（对应子图 (a) Llama 8B-Conversation，含 TTFT 与 TBT 两个并列柱状图）、Panel2（一个 TTFT 柱状图，图例部分显示"LoongServe"）、Panel3（一个 TBT 柱状图，图例部分显示"SGLang-PD"）、Panel4（对应子图 (c) Llama 70B-Conversation，TTFT+TBT）、Panel5（对应子图 (d) Llama 70B-Tool&Agent，TTFT+TBT）。每组柱状图内均为 5 根柱子，按斜线/纯色区分不同方法（深色斜纹=MuxWise，浅灰斜纹=Chunked，青色斜纹=NanoFlow，另两种为橙色、粉色斜纹，分别对应 LoongServe、SGLang-PD，依据 Panel2/Panel3 局部图例文字与全文基线清单推断）。部分柱子顶部数值带 `*` 并配一道折断/裁切标记线。[图像直接可见]

3. **如何阅读**：每个子图纵轴为 99%-ile TTFT（秒）或 99%-ile TBT（毫秒），横向 5 根柱子按同一方法顺序排列（MuxWise、Chunked、NanoFlow、LoongServe、SGLang-PD，依据数值排列位置与全文基线介绍顺序推断），柱顶标注具体数值；带 `*` 的柱子经裁剪缩短显示，柱高只反映相对大小，不代表真实数值（图注已说明）。应横向比较同一子图内 MuxWise 与各基线的柱高/数值差异，纵向比较四个 workload/模型组合下的一致性。[图像直接可见]

4. **直接可见的结论**：
   - (a) Llama 8B-Conversation：TTFT 五柱依次约为 2.8、11.1、24.7、14.3、4.5（秒）；TBT 依次约为 19.3、63.7、65.1、29.5、15.6（毫秒）。MuxWise 在 TTFT 和 TBT 上均为五者中数值最低（或并列最低）。[图像直接可见]
   - Panel2（TTFT，含 LoongServe 图例）五柱约为 1.5、8.3、9.2、16.0、2.3；Panel3（TBT，含 SGLang-PD 图例）五柱约为 22.5、54.0、50.8、31.5、18.8。两图均为第一柱（推断为 MuxWise）数值最低。[基于视觉的谨慎推断，因图例被裁切不完整]
   - (c) Llama 70B-Conversation：TTFT 五柱约 17.9、50.0、112*、60.4、32.2；TBT 五柱约 54.8、132、309*、89.9、40.6。第三柱（NanoFlow，依据文字位置与图注中"NanoFlow in Figure 14-(c)"的不稳定性描述对应）带 `*` 及折断标记，数值远高于其余四柱。MuxWise 一栏在两个指标上均为最低。[图像直接可见]
   - (d) Llama 70B-Tool&Agent：TTFT 五柱约 8.2、16.4、24.4、144*、4.1；TBT 五柱约 51.9、84.9、(数值被遮挡)、184*、41.7。第四柱（对应 LoongServe，依据图注"LoongServe in Figure 14-(d)"的不稳定性描述）带 `*` 及折断标记，远高于其余柱子。MuxWise 一栏同样为两个指标中最低或接近最低（TTFT 最低为最后一柱 4.1，略低于 MuxWise 的 8.2）。[图像直接可见]

5. **它验证的论点与方法设计含义**：该组图属于**效果**类证据，直接支撑正文所述"MuxWise achieves average 99%-ile TTFT speedups of 3.57×、5.98×、4.65×、1.66× over chunked-prefill、NanoFlow、LoongServe、SGLang-PD"这一量化主张——从各子图 MuxWise 柱值普遍低于其余四种方法可见其一致性。图中带 `*` 折断柱（NanoFlow 在 (c)、LoongServe 在 (d)）直接可视化正文"某些基线在评测中进入不稳定状态、达到峰值吞吐后表现异常"的说明，解释了为何这两处基线数值被裁剪且论文声称"排除不稳定结果后"计算平均加速比——即摘要级别的加速比数字并非对全部原始柱值取平均，而是有选择性地排除了这些异常点，读者据此应理解该加速比统计口径的边界。同时，图中 MuxWise 在 TBT 上并非绝对最优（例如 SGLang-PD 在 (a)(c)(d) 部分子图中 TBT 低于或接近 MuxWise），这与正文"SGLang-PD achieves shorter TBT than MuxWise, as it statically reserves more compute resources for the decode instance"的说明一致，说明该图同时用于**对比基线**——明确 MuxWise 相对静态分离方案（SGLang-PD）的权衡边界（TTFT 更优但 TBT 未必绝对最优）。该图不能单独证明 goodput（需满足 SLO 前提下的峰值吞吐）提升倍数，goodput 的 2.6×–5.2× 等数字来自另一独立实验（Figure 15），此图仅提供延迟分布证据。[正文支持]

6. **适用范围与证据缺口**：本组证据覆盖论文报告的 Llama-8B 与 Llama-70B 两种模型规模、Conversation 与 Tool&Agent 两类真实世界多轮负载、共四个 workload 组合的端到端 TTFT/TBT 99 分位延迟对比。真实缺口：(1) Panel2、Panel3 因图像裁剪缺少完整的子图编号标签（无法在图像本身确认其确切对应 (b) Llama 8B-Tool&Agent，只能依据数值位置、图注列出的四组合顺序及正文行文推断）；(2) Panel2/Panel3 的图例仅各自显示一个方法名（LoongServe、SGLang-PD），其余四种方法的图例文字在该裁剪区域不可见，柱子与方法的对应关系依赖与 Panel1 柱形/顺序的一致性假设，无法在图像内独立确认；(3) (d) 子图 TBT 图中第三柱（推断为 NanoFlow）顶部数值因折断标记与相邻柱重叠而无法清晰读出具体数字。
