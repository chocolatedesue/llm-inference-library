# 图片批次 2

## 图片 1：Figure 2. Main architecture of most LLMs.

![Figure 2. Main architecture of most LLMs.](../assets/imgs/img_in_image_box_191_145_504_237.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Figure 2（第 3 页），是背景性架构示意图，证据类型为**机制**。它不直接验证某个实验主张，而是为后文的机制设计提供结构基础：说明"典型 LLM 由多个相同的 transformer 层堆叠而成，每层含 Attention 与 FFN 子模块，Attention 需要读取/写入 KV 缓存"。该结构事实被 §3.2.3 用来论证"layer-wise execution incurs negligible overhead, since LLMs are inherently structured as multiple transformer layers"（页码：6），也是 Table 2（Attention/FFN 分开计算复杂度，页码：7）建模方式的依据。`[正文支持]`
   - **图表角色**：方法流水线（为无气泡多路复用引擎的"按层切分 prefill"设计提供结构性前提）。
   - **上文呼应**：第 2.1 节"Architecture of LLMs"背景说明；间接支撑第 3.2 节 Bubble-less Multiplex Engine 的层级化切分设计与第 3.3 节 Table 2 的 Attention/FFN 分类建模。

2. **图像类型与布局**：示意图（方框流程图），单一面板。虚线大框标注"Transformer block × N"，框内从左到右依次为输入节点 X → Attention 模块（橙色方框）→ 节点 Y → FFN 模块（蓝色方框）→ 输出节点 Z。Attention 模块上下各有一组红色虚线箭头，分别标注"Reused KV cache"（向内，指入 Attention）与"New KV cache"（向外，指出 Attention）。

3. **如何阅读**：从左到右为单个 transformer 层内部的数据流顺序；外层虚线框及"× N"标记表示该结构重复 N 次以构成完整模型。需要关注的是：KV 缓存的读/写箭头只挂在 Attention 子模块上，FFN 子模块不涉及 KV 缓存交互。

4. **直接可见的结论**：图中显示单个 transformer 层由 Attention 和 FFN 两个子模块顺序组成，且该层结构以"× N"方式整体重复；KV 缓存的复用（读取历史）与新增（写入当前）交互仅发生在 Attention 子模块处，FFN 子模块不与 KV 缓存交互。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图提供的是**机制**性背景知识：LLM 天然由多个结构相同的 transformer 层堆叠而成，且每层的 KV 缓存交互集中在 Attention 部分。这一结构事实是论文提出"按层切分 prefill（PLs）"这一设计选择的物理基础——正文明确指出该切分开销可忽略正是因为"LLM 天然由多层组成"（页码：7）。同时也解释了 Table 2 为何把 Prefill/Decode 的计算复杂度按 Attention 与 FFN 分列（页码：7）：因为二者对 KV 缓存的依赖方式不同（Attention 需读写缓存，FFN 不需要），从而计算量随 reused/new token 长度的增长规律不同。该图**不能**证明层级切分带来的实际开销大小（那是 §4.5 的运行时开销实验，非本图内容），也不能证明气泡消除的效果（那是 Figure 9/19 的内容）。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本图覆盖的是论文对"大多数 LLM"（Most LLMs）的通用架构抽象，不针对具体模型规模或具体硬件。无额外证据缺口。

---

## 图片 2：Figure 4. Processing four LLM request batches on 4 GPUs using (a) Splitwise, (b) LoongServe (c) chunked-prefill. All methods satisfy the TBT SLO (T per decode iteration). Specifically, arrives at 0T, at 1T, at 3T, and at 5T. denotes a subsequent request batch that reuses the KV cache of . Inefficient TTFTs are marked in red for each method. KV cache management is shown only for the two disaggregated methods, as they require migration or recomputation. In (a) and (b), solid black arrows represent migration, while dashed red arrows with cross markers denote recomputation. In (a), the KV cache column with a red indicates the active batch. In (c), the red arrow denotes KV cache reads from earlier chunks.

![Figure 4. Processing four LLM request batches on 4 GPUs using (a) Splitwise, (b) LoongServe (c) chunked-prefill. All methods satisfy the TBT SLO (T per decode iteration). Specifically, arrives at 0T, at 1T, at 3T, and at 5T. denotes a subsequent request batch that reuses the KV cache of . Inefficient TTFTs are marked in red for each method. KV cache management is shown only for the two disaggregated methods, as they require migration or recomputation. In (a) and (b), solid black arrows represent migration, while dashed red arrows with cross markers denote recomputation. In (a), the KV cache column with a red indicates the active batch. In (c), the red arrow denotes KV cache reads from earlier chunks.](../figure-groups/page-0004-afd626dd9342.png)

*来源：OCR 第 4 页。*

### 解读

该图片实际包含两组独立编号的图：Panel 1 对应 **Figure 4**（(a) Splitwise、(b) LoongServe、(c) Chunked-prefill 三种方法在 4 GPU 上处理请求批次的时序示意），Panel 2 对应 **Figure 5**（KV 缓存池容量对命中率的影响曲线）。二者在页面上邻近排布但是各自独立编号、独立图注，对应论文论证链条中的不同环节：Figure 4 是**机制**层面的图解式批判，Figure 5 是**效果**层面的量化实验。以下按两个 panel 分别作答，但作为同一图片组一并给出组内关系说明：Figure 4 先用示意图揭示分离式部署"资源耦合"导致的两类问题（空闲与重算），Figure 5 紧接着用本文自测的量化实验证实其中"共享内存池被压缩导致命中率下降"这一分支论点，二者共同支撑第 2.3.1 节对 Splitwise/LoongServe 的批判。

1. **论文角色与验证问题**：
   - **Panel 1（Figure 4）**：证据类型为**机制**+**对比基线**。作者需要说明现有两类分离式方法（Splitwise 静态分离、LoongServe 动态分离）以及 chunked-prefill 在同一场景（4 GPU 处理 b1/b2/b3/b1' 四个批次）下各自的资源占用/KV缓存处理方式，具体验证的问题是：静态分离为何产生 GPU 闲置（限制 A）、动态分离为何在跨请求复用场景下被迫重算（限制 C）。`[正文支持]`
   - **Panel 2（Figure 5）**：证据类型为**效果**。验证"分离式部署因缓存池减半而降低命中率、进而损害 goodput"这一机制主张的量化结果，对应正文"experimental results in Figure 5 show that this reduced capacity sharply lowers the KV cache hit rate in multi-turn workloads"（页码：4）。`[正文支持]`
   - **图表角色**：Panel 1 = 对比基线；Panel 2 = 实验结论。
   - **上文呼应**：均对应第 2.3.1 节"Disaggregated Serving"的限制论证（Splitwise 限制 A/B、LoongServe 限制 C，页码：2, 4）。

2. **图像类型与布局**：
   - Panel 1：示意性时序图（甘特图风格），共三个子图 (a)(b)(c)。顶部有统一图例：Prefill（深蓝色块）、Decode iteration（浅蓝/青色块）、KV in cache pool（网格纹理块）、Idle resource of each GPU（斜线阴影块）、TTFT of batch（带箭头虚线）。(a)(b) 各有 4 行代表 4 块 GPU，横轴为时间，图中标注 b1、b2、b3、b1' 等批次色块及对应时间点（0T/1T/3T/5T）；(b) 中另有红色虚线箭头标注"recompute"。(c) 展示 chunked-prefill 单一执行流中交替/融合的色块。
   - Panel 2：折线/散点图，横轴"Size of KV cache pool (tokens)"（对数刻度），纵轴"Cache hit rate"（0–0.6）。两条曲线：蓝色"×"标记为 Tool&Agent，橙色"○"标记为 Conversation。

3. **如何阅读**：
   - Panel 1：按行（GPU 编号）、按列（时间轴）比较不同方法下各 GPU 在同一时间段的占用状态（Prefill/Decode/空闲/KV缓存），红色 TTFT 虚线标出各批次首 token 产出时刻，用以比较"响应延迟"与"资源利用"的权衡；(a)(b) 的 KV cache 列显示是否需要跨 GPU 迁移（黑色实箭头）或重算（红色虚线叉标箭头）。
   - Panel 2：横轴为 KV 缓存池容量（对数尺度），纵轴为命中率；比较两条工作负载曲线在同一池容量下的命中率高低，以及各自趋于平稳（饱和）所需的最小容量。

4. **直接可见的结论**：
   - Panel 1：(a) Splitwise 中，专用于 decode 的两行 GPU 在 prefill 阶段呈现斜线阴影（空闲），且 KV 缓存列显示两个实例分别维护缓存（未见共享）；(b) LoongServe 中，GPU 分配行数从 prefill 时段的 4 行收缩为 decode 时段的 2 行，且 b1' 复用 b1 缓存处出现红色虚线"recompute"标注；(c) chunked-prefill 中同一时间轴上色块连续交替、未见明显空闲阴影块。`[图像直接可见]`
   - Panel 2：Tool&Agent 曲线在小池容量时命中率约 0.35，随容量增大逐步升至约 0.53–0.55 并趋于平坦；Conversation 曲线在小池容量时命中率接近 0（约 0.05），随容量增大持续爬升至约 0.35–0.4，在图中所示的最大容量处仍未明显趋平。两条曲线在整个横轴范围内 Conversation 均低于 Tool&Agent。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - Panel 1 是**机制**层面的图解证据：(a) 的空闲阴影直接对应正文"Splitwise does not adapt to serving dynamics...leads to resource underutilization"（限制 A，页码：2）；(b) 的"recompute"标注直接对应"LoongServe...cannot support the cross-request KV cache reuse, incurring significant recomputation overhead"（限制 C，页码：2, 4）。(c) chunked-prefill 无空闲阴影则呼应正文"it avoids disaggregation, it also prevents goodput loss from a reduced KV cache pool"（页码：2）——即 chunked-prefill 相对分离式方法不存在这类空闲/重算问题，但该图本身不展示 chunked-prefill 的 token 预算两难（那是 Figure 6 的内容）。此图为**示意性说明**而非实测基准，用于建立"资源耦合导致空闲或重算"这一必要性论证，而非量化对比三种方法的具体延迟数字。`[正文支持]`
   - Panel 2 是**效果**层面的量化证据：命中率随缓存池增大而提升，且提升幅度和饱和点因工作负载而异，直接支撑"缓存池容量越小、命中率越低"的机制主张，从而解释为何分离式部署（缓存池减半）会降低命中率、增加不必要重算、降低 goodput（页码：2, 4）。这是论文**自测**的量化实验，与正文引用文献[45]的"36.6%→4.2%"这一外部数字是两个不同来源的证据（该引用数字并非来自本图）。此图不能证明分离式部署具体减半后对应图中横轴上的哪一个精确点，因此不能反推出"减半导致命中率从X降到Y"的具体数值——正文也未做此映射。`[正文支持]`

6. **适用范围与证据缺口**：
   - Panel 1：覆盖的是论文构造的示意性场景——4 块 GPU、四个批次 b1/b2/b3/b1'，用于概念性论证，而非某个具体 workload 的实测时序。无额外证据缺口。
   - Panel 2：覆盖 Tool&Agent 与 Conversation 两个多轮工作负载（Table 1 定义）、LRU 淘汰策略、70B 模型场景。图注声明"achieving the optimal hit rate requires 3.3 TB of memory"，但该 3.3TB 对应的具体横轴刻度点（tokens 换算）在图中未标注/不可辨认，构成图像裁剪/坐标未标注导致的真实缺口：读者无法直接从当前坐标轴（tokens 对数刻度）上定位该 3.3TB 对应的确切点。
