# 图片批次 1

## 图片 1：Figure 1. A typical workflow in LLM serving systems: User1 sends two consecutive requests, with the second reusing the context from the first. User2 sends 1 request.

![Figure 1. A typical workflow in LLM serving systems: User1 sends two consecutive requests, with the second reusing the context from the first. User2 sends 1 request.](../assets/imgs/img_in_image_box_128_146_560_233.jpg)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Introduction 中根问题的提出（"Since prefill and decode interleave in an LLM serving system, SLO violations may arise... A long prefill can thus delay decode, potentially violating its SLO"，页码：2）。它不是效果对比，而是**问题严重性**类证据：用一个具体的多用户请求时间线，直观呈现"inflight batching 使长 prefill 挤占正在进行的 decode，从而造成 TBT 超标"这一根问题，并同时引入"跨轮次 KV 缓存复用"这一后续设计（共享显存池）依赖的现象。`[正文支持]`
   - **图表角色**：问题严重性
   - **上文呼应**：对应"根问题与重要性"一节（第 25 行陈述：长 prefill 挤占 decode 导致 TBT 超标）以及正文第 2 页对 Figure 1 的文字说明。

2. **图像类型与布局**：示意性时间线图（非数据曲线），横轴为 Timeline。分两行，分别代表 User1、User2 两个用户各自发出的请求（req1/req1' 与 req2）。每行由若干矩形色块拼接而成：蓝色 "P" 块代表 prefill 阶段，橙色 "D" 块（多个连续）代表 decode 迭代序列。图中标注了 TTFT（跨在 P 块上方的括号）、TBT（跨在相邻 D 块间的括号，其中一处被标记为红色 "✗ TBT"，表示违反）、以及两个带圈数字标注：❶"Stall for inflight batching"（位于 User1 行的 D 序列与下一个 P 块之间）、❷"Reusing KV cache from previous request"（伴随 "KV" 标签的箭头，指向后续 P 块）。

3. **如何阅读**：沿时间轴从左到右阅读每行的色块顺序（P→D→D→D→...）；TTFT 方括号标示从请求发出到首 token 产出所需时间（对应 P 块跨度）；TBT 方括号标示相邻两个 decode 输出之间的间隔（对应 D 块间距），红色 "✗ TBT" 表示该处 TBT 超出正常间隔；❶❷ 圈码是作者对关键事件的显式标注，需结合图注与正文对应机制名称理解，图像本身未给出数值坐标。

4. **直接可见的结论**：
   - User1 先发出 req1（P 块 + 三个 D 块，含正常 TTFT/TBT 标注），随后其后续请求（req1' 对应的第二个 P 块）插入到 decode 序列中间，导致相邻 D 块之间出现一段被标红的 "✗ TBT" 区间，且该区间紧邻 ❶"Stall for inflight batching" 标注 `[图像直接可见]`。
   - 第二个 P 块下方有 "KV" 箭头与 ❷"Reusing KV cache from previous request" 标注，箭头方向指向该 P 块，表示其复用了此前生成的 KV 缓存 `[图像直接可见]`。
   - User2 行同样呈现 req2 的 "P + D D D" 结构，并带有独立的 "KV" 标注 `[图像直接可见]`；User2 的 P/D 块与 User1 的时间线是否严格对齐、两用户请求是否被合并进同一 decode batch，图像本身未给出可辨认的对齐刻度或连线证据 `[基于视觉的谨慎推断，无法进一步确认]`。

5. **它验证的论点与方法设计含义**：该图是**机制类**证据，直接支持文中陈述"inflight batching stalls the ongoing decode phase to prefill new requests"以及"a long prefill can thus delay decode, potentially violating its SLO"（页码：2）——图中红色 "✗ TBT" 与 ❶ 标注正是这一因果链条的可视化呈现：长 prefill 插入导致 decode 迭代间隔（TBT）超标 `[正文支持]`。同时 ❷ 标注呼应正文"LLM serving systems reuse intermediate results (i.e., the KV cache) both within and across requests through a KV cache pool"（页码：2），为后文批判"分离式部署因独立缓存池降低命中率"埋下需求伏笔 `[正文支持]`。该图**不能**证明具体的 TBT 超标幅度或量化影响——它是概念性动机图，不含可读取的数值坐标，因此不能替代 §2.3 或 §4 中的量化实验结论。

6. **适用范围与证据缺口**：本图为示意性场景图，用于说明现有 inflight batching 系统中的典型交互模式（两个用户、两条请求流），并非某一具体硬件/模型/工作负载下的实测时间线。无额外证据缺口。

---

## 图片 2：Figure 3. Required compute and memory for processing different phases under SLO constraints with varied reused context lengths. For prefill (a), the batch size is fixed at 1, the new context length is set to 2K, and TTFT is set to 400ms. For decode (b), the batch size is fixed at 32, and TBT is set to 100ms. These settings are commonly seen in online serving.

![Figure 3. Required compute and memory for processing different phases under SLO constraints with varied reused context lengths. For prefill (a), the batch size is fixed at 1, the new context length is set to 2K, and TTFT is set to 400ms. For decode (b), the batch size is fixed at 32, and TBT is set to 100ms. These settings are commonly seen in online serving.](../assets/imgs/img_in_chart_box_645_147_1105_331.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本图对应 §2.2 Characterization under SLO constraint 一节的核心实验（页码：3），用于验证"支撑核心洞见的前置观察"——prefill 与 decode 阶段对复用上下文长度的计算/显存需求敏感度不同，从而论证需要"运行时"而非"静态"的计算资源划分，以及应将 KV 缓存放在同一显存空间内共享。这是**机制类**证据（用量化关系解释为何需要动态资源分区+共享显存这一设计）。`[正文支持]`
   - **图表角色**：机制
   - **上文呼应**：对应"核心洞见与假设"一节中的"支撑该洞见的前置观察"（第 49-51 行）以及正文 §2.2（页码：3）。

2. **图像类型与布局**：双 Panel 折线图，(a) "Prefill phase"、(b) "Decode phase"。每个 Panel 均为双 Y 轴曲线图：左 Y 轴为 "GPU number"（对应 Compute，三角形标记的折线），右 Y 轴为 "KV cache size (GB)"（对应 Memory，叉形标记的折线），X 轴分别为 "Reused length (K)"（(a)，范围约 0–100K）和 "Reused length of decode batch (K)"（(b)，范围约 0–250K）。两条曲线（Compute、Memory）在图例中以三角形/叉形区分。

3. **如何阅读**：横轴表示复用（reused）上下文长度（单位 K token），随 X 轴右移代表复用长度增加；两条纵轴分别对应两条曲线的量级（GPU 数 vs KV 缓存 GB），需分别对照左右轴读取 Compute 与 Memory 曲线的数值；比较的核心是同一 Panel 内 Compute 曲线随复用长度增长的斜率/趋势，以及 (a)(b) 两个 Panel 之间 Compute 曲线斜率的差异。

4. **直接可见的结论**：
   - (a) Prefill phase：Compute（GPU number）曲线随复用长度增加而持续上升，从接近 0 升至约 8（在约 100K 处），呈现明显正相关趋势；Memory（KV cache size）曲线也随复用长度近似线性上升，至约 40GB `[图像直接可见]`。
   - (b) Decode phase：Compute（GPU number）曲线在整个 0–250K 复用长度范围内基本维持在低位（约 1–2），几乎不随复用长度增长而明显上升；Memory 曲线则随复用长度持续近似线性上升，至约 80GB（右轴对应约 100 附近刻度）`[图像直接可见]`。
   - 对比 (a)(b) 两图，Prefill 的 Compute 曲线斜率明显大于 Decode 的 Compute 曲线斜率，而两者的 Memory 曲线都呈现随复用长度增长的持续上升趋势 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图直接支持正文陈述"As shown in Figure 3-(a), prefill phase requires increasingly more compute resources to meet SLO targets as the reused length grows. In contrast, the compute demand of the decode phase shows less sensitivity"（页码：3），以及"Figure 3-(b) shows that the KV cache required by both the prefill and decode easily reaches tens or even hundreds of gigabytes...It is preferable to keep the KV cache in the same memory space"（页码：3）`[正文支持]`。这是一条**机制类**证据链：prefill 计算需求对复用长度高度敏感、decode 相对不敏感 → 二者的资源需求"错配"，必须支持运行时动态划分计算资源（而非如 Splitwise 般静态固定）→ 同时两阶段的显存（KV 缓存）需求都很大且持续增长，宜共享同一显存空间以便跨阶段/跨请求复用 → 直接构成 MuxWise "compute 与 memory 解耦管理"设计动机的量化基础。该图**不能**证明 MuxWise 方案本身的实际效果（吞吐、SLO 达标率等），仅提供设计动机层面的资源需求特征证据。

6. **适用范围与证据缺口**：本图实验设置已在图注中明确：Llama-70B 部署于 8×A100 GPU（张量并行），(a) 固定 batch size=1、新增上下文长度 2K、TTFT SLO=400ms；(b) 固定 batch size=32、TBT SLO=100ms（页码：3）。结论范围限定于该模型规模、该硬件配置、该批大小和该 SLO 目标下的观测。无额外证据缺口（Y 轴具体数值刻度精读、GPU 数换算比例等细节可从图像直接读取，无遮挡或冲突）。
