# 图片批次 4

## 图片 1：Figure 8. Architecture overview of MuxWise.

![Figure 8. Architecture overview of MuxWise.](../assets/imgs/img_in_image_box_636_146_1116_415.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：该图是 MuxWise 系统的整体架构总览图，用于说明作者提出的"三模块协同设计"如何落地对应第 5 页正文中的核心洞见（"GPU 内空间复用"）与两大新挑战（C-1 气泡、C-2 争用）。证据类型为**方法流水线**：它不是实验数据，而是把 §3.1-§3.4 描述的模块分工与数据流关系可视化。`[正文支持]`
   - **图表角色**：方法流水线。
   - **上文呼应**：对应第 5 页 §3.1 Architecture Overview，"MuxWISE comprises (1) a bubble-less multiplex engine, (2) a contention-tolerant estimator, and (3) an SLO-aware dispatcher"，以及 §3.3/§3.4 对估计器与调度器的说明。

2. **图像类型与布局**：示意图（系统架构框图），整体标题"MuxWise"。内含三个矩形分区：左上"§3.3 Contention-tolerant estimator"（内嵌"Solo-run predictor"与"Contention guard"两个子框，上方共同指向一个"One-time offline profiling"框）；左下"§3.4 SLO-aware dispatcher"（内嵌"Multiplexing plan"框，列出 P：X SMs / Y Blocks，D：Z SMs）；右侧"§3.2 Bubble-less multiplex engine"（含"Compute"纵轴、"Time"横轴的时间线示意，显示"Request"箭头进入后产生 PLs 蓝色块与多个 D 绿色块交替排列，并有图例"Partition（点划线）""Inflight batch（箭头）""Sync（虚线）"）。三个分区之间以红色文字标注的箭头连接：估计器→调度器标"Latency"，争用防护→估计器标"Update"，调度器→引擎标"Plan"。

3. **如何阅读**：按信息流方向阅读——顶部"One-time offline profiling"离线画像先训练出估计器的两个子模块；估计器通过"Latency"箭头把最坏情况延迟估计传给调度器；调度器生成的"Multiplexing plan"（P/D 的 SM 与块数分配）通过"Plan"箭头传给引擎执行；引擎在运行期间产生的执行数据通过"Update"箭头反哺争用防护模块。右侧时间线子图应按"Compute（纵轴，SM 占用）× Time（横轴）"读取，PLs 与 D 色块的水平排布表示两阶段在同一时间轴上占据不同计算资源并行执行。

4. **直接可见的结论**：三个模块以框图形式分区展示，且用红字箭头明确标注了三条数据流方向（Latency、Update、Plan），形成"离线画像→估计→计划→执行→运行时更新"的闭环；右侧引擎子图显示 PLs（prefill layers）块与 D（decode）块在同一时间轴上并列出现而非先后串行，且有专门图例区分"Partition/Inflight batch/Sync"三种线型。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于**机制**类证据，直接对应"论文 Story 主线"中"三模块配套解决气泡与争用两个新问题"的设计声明——估计器（对应 C-2 争用管理）与引擎（对应 C-1 气泡消除）通过调度器串联成一个闭环系统，且引擎子图中 PLs/D 并列排布的画法与正文"prefill and decode are executed on different streaming multiprocessors (SMs) within the GPUs"的核心机制描述一致。它支持读者理解三模块的**接口关系**（估计器输出喂给调度器决策、调度器输出喂给引擎执行、引擎运行时数据反哺估计器），但**不能**证明该架构在真实负载下确实降低了气泡或提升了 goodput——这些效果类主张需由 Figure 14-20 等实验图表验证，本图仅提供架构层面的机制说明。`[正文支持]`

6. **适用范围与证据缺口**：本图是概念性架构示意图，覆盖论文声称的三模块整体设计关系，不对应具体硬件、模型或负载设置。无额外证据缺口。

---

## 图片 2：Figure 10. Bubble-less coordination using layer-wise scheduling for the prefill phase and graph-level scheduling for the decode phase. PLs is the short for prefill layers.

![Figure 10. Bubble-less coordination using layer-wise scheduling for the prefill phase and graph-level scheduling for the decode phase. PLs is the short for prefill layers.](../assets/imgs/img_in_image_box_639_143_1109_293.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：该图展示 MuxWise 提出的"层级化 prefill 切分 + 基于事件轮询的同步"（layer-wise execution + query-based synchronization）如何消除 Figure 9 中列出的三类朴素调度气泡/SLO 违规问题。证据类型为**方法流水线**（机制层面的解决方案示意），验证的具体问题是：无气泡多路复用引擎的调度设计是否能同时满足"快速启动 decode""满足长短请求各自 SLO""decode 全部结束时不留计算空洞"三项目标。`[正文支持]`
   - **图表角色**：方法流水线。
   - **上文呼应**：对应第 6 页 §3.2.3 Bubble-less Coordination，"we propose layer-wise execution for prefill and query-based synchronization"，是对 Figure 9（朴素调度产生的三类气泡）的直接解法示意。

2. **图像类型与布局**：时间线示意图，纵轴"Compute"、横轴"Time"。顶部图例区分四种符号：短请求图标（波浪+问号）、长请求图标（波浪+问号，较大）、"Inflight batch"（点划线箭头 ---）、"Sync"（虚线 --）。主体从左到右依次展示：左侧一组循环箭头标注"Fast kernel launch"（打钩），下方紧跟多个 D 色块连续排列；中段出现短请求图标后接一个较窄 PLs 蓝色块，随后是"Meet both SLOs"（打钩）标注下并列两个 PLs 块（一窄一宽）与一个更宽的 PLs 块，下方对应多个 D 色块；右侧末端标注"No bubbles when all reqs end decoding"（打钩），对应右下角 D 色块与省略号"…"表示后续持续排列。

3. **如何阅读**：横轴为时间推进方向，纵轴表示 GPU 计算资源（Compute/SM）的占用；蓝色 PLs 块与绿色/浅色 D 块在同一时间轴上前后紧邻排布，块的宽度大致对应该阶段占用时长；三处打钩标注（Fast kernel launch / Meet both SLOs / No bubbles when all reqs end decoding）应逐一对照 Figure 9 中的三类气泡问题位置（左、中、右上）来理解其对应的修复点；短/长请求图标标出请求到达时刻及其长度差异。

4. **直接可见的结论**：图中 PLs 块与 D 块交替排布紧密、之间未见明显空白间隙，三处关键节点均带有打钩标注，表明设计意图上消除了对应位置的气泡；短请求对应的窄 PLs 块出现在长请求宽 PLs 块之前/之间，暗示了按层调度带来的抢占/交织能力；右侧 D 块连续排列且注明"无气泡"。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于**机制**类证据，直接对应模块一（Bubble-less Multiplex Engine）动机小节中列出的三类气泡/SLO 违规（prefill 启动延迟阻塞 decode、decode 提前结束但 prefill 不可抢占、长请求排队致短请求违约），图中三处打钩标注分别对应这三类问题的解决方案：层级化切分使 PLs 粒度接近单次 decode 迭代从而"快速启动"、短请求的 PLs 可插入/抢占长请求的 PLs 从而"同时满足两者 SLO"、query-based synchronization 使最后一层 prefill 完成后立即合并进 decode batch 从而在"所有请求结束解码时不留气泡"。这属于**机制设计说明**而非量化效果证明——图中未标出具体延迟数值，其量化效果（如"层级调度关闭后延迟增加约10ms""关闭 query-based synchronization 后 TBT 恶化314ms/672ms"）需依赖 §4.4.2 消融实验（Figure 19）而非本图。`[正文支持]`

6. **适用范围与证据缺口**：本图为示意性时间线，用于解释调度机制原理，不代表某一具体模型/硬件/负载下的真实测得时间线，图中也未标注具体时间刻度或数值。无额外证据缺口。
