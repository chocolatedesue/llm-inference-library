# 图片批次 5

## 图片 1：Figure 9. Bubbles and SLO violation of naive intra-process multiplexing. represents the kernel launch order.

![Figure 9. Bubbles and SLO violation of naive intra-process multiplexing. represents the kernel launch order.](../assets/imgs/img_in_image_box_112_145_581_307.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文 §3.2.2"Inefficiencies from Naive Integration"，其证据类型为**问题严重性**（同时也部分构成方法流水线的动机铺垫）。作者需要证明：在 GPU 内空间复用范式下，若采用"先 launch decode、再 launch prefill"的朴素调度策略，仍会产生三类具体的气泡/SLO 违规问题，从而为后续"无气泡多路复用引擎"（layer-wise execution + query-based synchronization）的必要性提供依据。[正文支持]
   - **图表角色**：问题严重性
   - **上文呼应**：对应正文 3.2.2 节"this naive approach still introduces two types of GPU bubbles and can also lead to SLO violations"，图注明确为"Figure 9. Bubbles and SLO violation of naive intra-process multiplexing"。

2. **图像类型与布局**：示意图（时间轴调度图），非曲线图或表格。纵轴标注"Compute"，横轴为"Time"。图中用椭圆虚线圈出两条并行的计算轨道，上方轨道标"P"（Prefill），下方轨道标"D"（Decode）。顶部图例定义：`?`短请求（虚线问号，蓝色）、`?`长请求（虚线问号，红色）、`↓`Inflight batch、`- - -` Sync、`▨` Partition/Bubble（斜线填充色块）。图中标注三个带圈数字的红色文字标签：❶ "Bubbles due to slow kernel launch"，❷ "All reqs end decoding, leaving unutilized bubbles"，❸ "SLO violation of short req."，分别用红色箭头指向图中对应的时间段区域。

3. **如何阅读**：需按左中右三段时间轴顺序读图，对照顶部图例区分"短请求/长请求/inflight batch 触发同步/分区(气泡)"四类标记；重点关注 D 轨道（decode）上出现斜线填充色块（气泡）的位置，以及 P 轨道上长请求（红色问号）与短请求（蓝色问号）的排队/执行顺序。三个标注序号分别对应图中三段不同的时间区间，需逐一定位斜线气泡块或请求排队情况。

4. **直接可见的结论**：
   - 左侧区域（❶附近）：D 轨道上的 decode 迭代之间出现斜线填充的气泡色块，与旁边"Bubbles due to slow kernel launch"标注对应位置吻合 [图像直接可见]。
   - 中间区域（❷附近）：D 轨道末尾也出现斜线气泡块，且旁边有向下箭头指向该区域并标注"All reqs end decoding, leaving unutilized bubbles" [图像直接可见]。
   - 右侧区域（❸附近）：P 轨道上出现一个较长的红色问号（长请求）占据一段时间，其后方标注 "SLO violation of short req." 并有花括号/箭头指示一段时间跨度 [图像直接可见]。
   - 三段区域在图中确实是时间上先后排列、彼此分隔的独立片段（图中有竖虚线/间隔分隔）[图像直接可见]。
   - 图中未给出具体数值刻度（无 ms 数字标注），气泡宽度、请求时长仅为示意性比例，无法读出精确大小 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图是一个**问题严重性/机制**类证据，用于说明朴素的 PD 多路复用调度会产生三类具体缺陷，直接对应正文列出的"两类气泡+一类 SLO 违规"：(1) prefill 启动延迟超过单次 decode 迭代耗时导致下一次 decode 无法及时启动而产生气泡（❶，正文："a bubble appears between two decode iterations because the serving system must return newly generated tokens after each iteration"）；(2) decode batch 全部提前结束但已启动的 prefill 因 GPU 不可抢占而无法回收资源产生气泡（❷，正文："all requests in a decode batch may finish token generation while a concurrent prefill phase has already been launched...cannot be interrupted to reclaim compute resources"）；(3) 短请求因排队等待长 prefill 而可能错过自身 SLO（❸，正文："a short request may suffer long queuing delays while waiting for the prefill of an ultra-long request")。这三点共同构成了模块一"Bubble-less Multiplex Engine"（layer-wise execution + query-based synchronization）的设计动机：图像本身只是示意性地展示问题现象，并不包含量化实验数据，量化验证由后续消融实验（Figure 19，禁用相关机制后 TTFT/TBT 恶化的数字）提供。[正文支持]

6. **适用范围与证据缺口**：本图覆盖的是"朴素调度策略"（非 MuxWise 最终设计）在概念/示意层面的问题展示，用于铺垫动机，而非对 MuxWise 本身的实测评估。图中不含坐标数值、具体延迟数字或具体请求参数，均为示意性构图；由于这是概念示意图而非数据图，正文也未声称其包含可量化的实验数据，因此这不构成"图像裁剪遮挡"式的缺口。无额外证据缺口。

---

## 图片 2：Figure 11. Slowdowns in decode due to contention with different multiplexing configurations of prefill and decode across models and GPUs.

![Figure 11. Slowdowns in decode due to contention with different multiplexing configurations of prefill and decode across models and GPUs.](../assets/imgs/img_in_chart_box_107_146_586_318.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文 §3.3.1"Contention Analysis"，证据类型为**机制**（同时服务于"必要性"论证）。作者需要证明：在 PD 空间复用下，显存带宽等未被 GreenContext 管理的资源会引发不可预测的争用减速，且该减速幅度"因硬件、模型而异、难以预测"，从而论证"抗争用延迟估计器"（solo-run predictor + contention guard）存在的必要性。[正文支持]
   - **图表角色**：机制
   - **上文呼应**：对应正文 3.3.1 节"we extensively profile prefill and decode under multiplexing using Llama-8B and Llama-70B...contention-induced slowdown ranges from nearly zero to about 30%...The high variation across hardware partitions indicates the inherent unpredictability of contention slowdown"，图注为"Figure 11. Slowdowns in decode due to contention with different multiplexing configurations of prefill and decode across models and GPUs"。

2. **图像类型与布局**：箱线图（box plot），横向排列 4 个子面板，分别标题为 "A100 Llama-8B"（蓝色）、"A100 Llama-70B"（橙色）、"H100 Llama-8B"（绿色）、"H100 Llama-70B"（红色）。纵轴统一为"Slowdown"，刻度 0%–50%；横轴为"The Number of SM for Decode"，各子图刻度不同（A100 两图为 12/28/44/60/76；H100 两图为 20/36/52/68/84/100）。每个 x 刻度下有一个箱线图，箱体含中位线、上下四分位框、须线（whisker）及若干离群点。

3. **如何阅读**：需按四个子面板分别对比，横轴表示分配给 decode 的 SM 数量（其余分给 prefill），纵轴为该配置下 decode 因争用产生的减速百分比；应比较同一子面板内不同 SM 数下箱体中位数/分布高低的变化趋势，以及跨子面板（不同模型/GPU组合）之间整体减速水平和分布形状的差异。

4. **直接可见的结论**：
   - 四个子面板中，decode 减速幅度均在约 0%–30% 区间内波动，多数箱体上须可达约 20%–30%，个别离群点略超此范围 [图像直接可见]。
   - A100 两个子面板（Llama-8B、Llama-70B）的箱体中位数普遍低于约 10%-15%，整体波动幅度相对较小 [图像直接可见]。
   - H100 两个子面板（Llama-8B、Llama-70B）的箱体中位数和分布范围普遍高于 A100 对应子面板，尤其 H100 Llama-8B 在较低 SM 数（如 20、36）时中位数接近 15%-20% [图像直接可见]。
   - 在同一子面板内，随着分配给 decode 的 SM 数增加，箱体中位数及分布范围未表现出单调递减或递增的一致规律，各 SM 配置下的减速中位数相对接近，箱体重叠较多 [图像直接可见]。
   - Llama-8B 与 Llama-70B 在同一 GPU 类型下的箱线图形状/离散程度存在相似的整体波动模式（如均呈现中等分散的箱体与少量高值离群点）[基于视觉的谨慎推断]。

5. **它验证的论点与方法设计含义**：该图是**机制**类证据，直接支撑正文"contention-induced slowdown ranges from nearly zero to about 30%...inherent unpredictability of contention slowdown"的陈述：图中箱体分布分散、且减速幅度不随 SM 分配呈现简单规律，印证了"精确预测争用不可行，只能通过离线画像给出最坏情况上界"这一设计前提，从而支撑模块二 Contention-tolerant Estimator 中 "contention guard 提供最大减速因子而非精确预测" 的设计选择（正文 8 页所述 A100 最大 20%、H100 最大 30% 的减速上界数值即来自与此类似的画像数据）。该图仅覆盖 decode 侧的减速数据（正文明确说明"results for prefill are similar but omitted due to space constraints"），因此不能用于验证 prefill 侧的争用规律，也不能直接证明 contention guard 参数选择的最优性——那需要依赖后续调度器设计与端到端实验（Figure 14-17）。[正文支持]

6. **适用范围与证据缺口**：本图覆盖的实验范围为 Llama-8B 与 Llama-70B 两个模型、A100 与 H100 两种 8 卡服务器、且仅展示 decode 侧的减速数据（图注与正文均只提及 decode）；prefill 侧的争用画像结果正文声明"similar but omitted"，未在本图或其他已分析图中给出。图中各面板具体箱体中位数/离群点数值因像素分辨率限制无法精确读出（仅可判断大致区间），此为图像本身分辨率导致的真实缺口；此外，本图未标注具体是何种 workload（reused/new context 长度等）对应哪个箱体，正文提及 profiling 覆盖"prefill 总长度 1,024–128K、decode reused 长度 1,024–1,024K"的范围，但图中同一 SM 配置下的箱体具体聚合了哪些子配置，正文与图注均未进一步拆分说明。
