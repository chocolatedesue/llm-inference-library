# 论文解构报告

### 论文元数据

| 字段 | 内容 |
|---|---|
| 标题 | Towards High-Goodput LLM Serving with Prefill-decode Multiplexing |
| 作者 | Yukang Chen, Weihao Cui, Han Zhao, Ziyi Xu, Xiaoze Fan, Xusheng Chen, Yangjie Zhou, Shixuan Sun, Bingsheng He, Quan Chen |
| 发表场所 / 年份 | ASPLOS '26（第31届ACM架构支持编程语言与操作系统国际会议，第2卷）/ 2026 |
| 研究领域 | 计算机系统（LLM 服务系统） |
| 关键词 | LLM Serving, PD-Multiplexing, Goodput, GPU调度, SLO |

### 资源链接

- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：https://doi.org/10.1145/3779212.3790236
- 代码 / 数据集：文中未说明

> **标签（5个）**：`LLM推理服务` · `Prefill-Decode多路复用` · `GPU调度` · `SLO保障` · `Goodput优化`

## 1. 一句话总览

论文提出 MuxWise，一种让 prefill（预填充，处理输入生成首token）与 decode（解码，逐token生成）在同一块 GPU 内部、同一时刻分别占用不同计算单元并行执行的新范式，配合无气泡多路复用引擎、抗争用估计器、SLO感知调度器三个模块，在满足延迟 SLO 前提下将有效吞吐（goodput）平均提升 2.20 倍、最高 3.06 倍 [作者明确陈述][页码：1]。

## 2. 阅读范围与证据状态

- OCR 覆盖论文正文第 1–15 页的文本证据分析与 6 组图表证据分析（共 12 张图片，另有 6 张因超出上限未做视觉分析），可核实内容包括方法设计、消融数据、比较工作表与主张证据表 [页码：全文]。
- 明显缺失：Goodput/TTFT/TBT 的精确计算公式、统计聚合口径（是否多次运行平均、置信区间）文中未说明[页码：9]；代码/数据集链接文中未说明。
- 6 张未分析图片可能包含额外实验细节，本报告不对其做视觉层面判断，相关结论只依据已分析的图组与文本。

## 3. 根问题：论文究竟要解决什么

- **问题定义**：LLM 在线服务需同时满足两条独立延迟 SLO——prefill 阶段的首token时间（TTFT，如<500ms）与 decode 阶段的逐token间隔（TBT，如<100ms）[作者明确陈述][页码：2]。由于 prefill 与 decode 在同一请求流中交替出现，长 prefill 会挤占正在进行的 decode 迭代，造成 TBT 超标[作者明确陈述][页码：2]。
- **为何重要**：真实工作负载（单轮聊天、长文档、长链推理、多轮对话/工具调用）在输入/输出/复用（reused，跨轮共享上文）长度上差异巨大（Conversation 复用长度可达0–120K token）[作者明确陈述][页码：3，Table 1]，任何静态资源分配都难兼顾吞吐与SLO。
- **难点来源**：token 是基本工作单元，prefill 计算量随（新增+复用）token数增长、decode 显存访问量随复用长度增长（Table 2，页码：7）；若两阶段共享同一批资源却按同一批次串行调度，一方资源需求波动即传导为另一方排队延迟，最终表现为 SLO 违约与 goodput 下降 [基于文中逻辑的推断，页码：2-3]。
- **本文 story**：旧路线（分离式部署、分块预填充）都把 compute 与 memory 管理绑定在一起、且让两阶段在时间上交替，这一结构性设计导致资源闲置或"SLO合规vs高利用率"两难；本文的转折在于把两阶段从"时间交替"改为"空间并行"，从而在同一 GPU 内解耦资源分配。

## 4. 旧方法为何不够

- **Splitwise（静态分离式）**：目标是把 prefill/decode 分离到独立实例分别保 SLO；前提是负载可预先划分。失效条件：GPU 划分在实例初始化时固定，负载波动时产生闲置[作者明确陈述][页码：2]；各实例独立缓存池使总容量缩水，命中率下降（引用文献数据 36.6%→4.2%）[作者明确陈述，引用[45]][页码：2]。对应本文模块：共享显存池设计；对应实验：Figure 5 自测命中率曲线、§4端到端对比。
- **LoongServe（动态分离式）**：在 Splitwise 基础上按序列长度/阶段动态调整 GPU 分配。前提是可以随时释放原 GPU 缓存；失效条件：为避免缓存重复而立即释放，导致跨请求（多轮）KV复用失效，必须重算[作者明确陈述][页码：2, 4]。对应本文模块：PD multiplexing 的共享显存设计；对应实验：Figure 4(b) 示意分析、Table 4 端到端对比。
- **Chunked-prefill（如SARATHI-Serve）**：把prefill切块与decode迭代融合，靠token预算上限保SLO。前提是可找到兼顾利用率与延迟的预算值；失效条件：70B模型在8×A100打满GPU需4K预算，是100ms TBT SLO所允许256预算的8倍[作者明确陈述][页码：2]；复用上下文越长，TBT越差[作者明确陈述][页码：2, 5]。对应本文模块：无气泡多路复用引擎（空间复用替代时间融合）；对应实验：Figure 6(a)(b) 预算/复用长度扫描。
- **NanoFlow**：算子级GPU内多路复用，目标是宽松SLO下近最优吞吐；严格SLO（≤100ms）要求预算降至256时不再计算受限，且70B模型因反复加载权重开销被放大 [作者明确陈述][页码：9]。对应模块：PD multiplexing使模型权重仅prefill阶段加载一次；对应实验：Table 3/4、Figure 14(c)(d)。
- **SGLang-PD**：静态分离但支持跨阶段缓存共享；波动负载下decode实例仍会闲置，OpenThoughts/LooGLE场景下表现明显更差[作者明确陈述][页码：10, 12]。对应模块：动态计算重配置能力；对应实验：§4.2.1、§4.3端到端对比。
- DistServe、Dynamo 仅有排除性文字说明，未作为主要基线，原始动机与限制无法从当前OCR内容确认[页码：9]。

## 5. 核心洞见与假设

- **核心洞见**：与其让prefill、decode在同一流水线中"时间交替"（无论跨实例还是同GPU前后执行），不如让二者在同一GPU内部、同一时刻通过划分SM（流式多处理器）"空间并行"执行，同时共享同一块显存 [作者明确陈述][页码：2, 5]。
- **实现组件（非独立贡献）**：GreenContext空间划分（来自已有文献）、层级化prefill切分、query-based synchronization、离线画像预测器与contention guard[页码：6-8]。
- **支撑前提**（[实验支持]，页码：3）：prefill计算需求对复用长度高度敏感、decode相对不敏感（Figure 3a/b）；两阶段KV缓存量可达数十至数百GB，宜共享显存空间。
- **前提可能失效处**：该范式依赖硬件支持进程内低开销空间划分（如GreenContext），不支持该特性的硬件不适用[作者明确陈述][页码：13-14]。
- 由此产生两个新挑战：C-1 朴素调度产生GPU气泡；C-2 空间复用引入不可预测的显存带宽争用 [作者明确陈述][页码：5]。

## 6. 方法：从洞见到可执行系统

总览：请求进入后，估计器基于离线画像给出最坏情况延迟预测→调度器据此决定SM划分与请求调度顺序→引擎按层级化方式执行prefill并与decode并行→运行时数据反哺争用防护模块，形成闭环 [作者明确陈述][页码：5-9]。

1. **Bubble-less Multiplex Engine（无气泡多路复用引擎）**：动机是朴素调度会因prefill启动耗时（数十ms）远超单次decode迭代（<0.5ms）产生气泡、GPU不可抢占导致资源无法回收、长请求排队使短请求违约（页码：6）。做法：把prefill按transformer层切分为"prefill layers（PLs）"，以接近decode迭代的粒度交替启动，配合事件轮询同步在最后一层完成时立即合并进decode batch（页码：6-7）。优势：层级切分开销可忽略，因LLM天然由多层组成（页码：7）；带来抢占短请求优先的能力。
2. **Contention-tolerant Estimator（抗争用估计器）**：动机是GreenContext无法管理显存带宽争用、GPU不暴露实时带宽监控接口（页码：7）。输入为复用/新增/输出长度、batch size、SM分区；过程分solo-run predictor（拟合$T_{Prefill}$、$T_{Decode}$线性模型，Eq.1/Eq.2，页码：8）与contention guard（离线网格画像给出最坏减速因子，页码：7-8）。输出为最坏情况延迟预测，用于保证SLO上界而非追求精度。
3. **SLO-aware Dispatcher（SLO感知调度器）**：动机是需据估计结果实际分配SM并选调度对象（页码：8）。每次decode迭代结束时重新决策，优先保decode SLO，用$N_{PL} = \lceil (T_d \times N_T) / T_P \rceil$（页码：9）计算应启动的prefill层数，剩余SM给prefill；允许短请求抢占长请求但不允许递归抢占（页码：9）。

## 7. 为什么它可能有效

- 层级化切分使prefill粒度接近decode迭代，从而快速让出资源、减少气泡 [基于文中逻辑的推断，页码：6-7]，需要的前提是LLM确实由多层构成（普遍成立）。
- 共享显存空间保留KV缓存池的完整效率，前提是硬件显存容量足够容纳prefill+decode合并后的缓存需求 [基于文中逻辑的推断，页码：3]。
- 空间并行使两阶段互不阻塞独立执行，从而理论上避免"SLO合规vs高利用率"两难，前提是SM划分能被低开销动态调整（依赖GreenContext）[基于文中逻辑的推断，页码：5]。
- worst-case延迟估计保证SLO上界，前提是离线画像覆盖范围包含线上实际出现的资源配置组合，论文未证明该覆盖的完备性 [基于文中逻辑的推断，页码：7-8]。

## 8. 实验与指标：证据是否支撑主张

### 8.1 实验问题与判定标准

- 效果问题：MuxWise是否在真实/合成负载下相对四个基线提升TTFT/TBT/goodput？对应Figure 14-17端到端对比[实验支持]。
- 必要性问题：chunked-prefill的token预算两难是否架构性不可规避？对应Figure 6扫描实验[实验支持]。
- 机制/必要性问题：无气泡引擎的层级调度与同步机制是否必要？对应§4.4.2消融（页码：13）[实验支持]。
- 鲁棒性问题：抢占机制是否带来提升？对应Figure 20，仅有量化的"开启抢占"对比，未提供"关闭抢占仍有提升"的量化数据[作者明确陈述，但未见量化数据][页码：9]。
- 适用范围问题：MoE大模型（Qwen3-235B）上是否同样有效？仅与chunked-prefill单一基线对比，范围窄于其他实验[作者明确陈述][页码：11]。

### 8.2 数据、任务、对比与运行设置

- 负载来源：ShareGPT（单轮聊天）、LooGLE（长文档）、OpenThoughts（长链推理）、Conversation/Tool&agent（多轮，Table 1定义）[作者明确陈述][页码：3]。
- 模型/硬件：Llama-8B/70B（A100/H100）、Qwen3-235B（H200），均用张量并行部署[作者明确陈述][页码：10-11]。
- 基线：chunked-prefill(SARATHI-Serve)、NanoFlow、LoongServe、SGLang-PD，另有自建对比WindServe、Tropical、Semi-PD、Bullet（页码：14）。
- 请求到达：Poisson process模拟[作者明确陈述][页码：413之前的术语说明]。
- 重复次数/统计方式：文中未说明。
- SLO目标：Llama-8B设50ms TBT，Llama-70B设100ms TBT[作者明确陈述][页码：9]。

### 8.3 指标字典与对应公式

- **指标与方向**：TTFT，测量prefill耗时，单位ms/s，越低越好。
  **定义与公式**：来源层级为无可核验公式；文中仅文字定义为"产生首token的耗时"[页码：2]。
  **实验用途**：SLO达标判据，对比MuxWise与四基线（页码：10-12）。
  **读数与边界**：具体倍数见8.4；不能证明goodput绝对值。

- **指标与方向**：TBT，测量decode单token间隔，单位ms，越低越好，是全文核心SLO指标。
  **定义与公式**：来源层级无可核验公式；文字定义为"每token延迟"，并与TPOT（平均指标）对比强调其为"逐token"口径[页码：2, 9]。
  **实验用途**：主SLO判据，Llama-8B设50ms、Llama-70B设100ms[页码：9]。
  **读数与边界**：不能反映平均表现掩盖的尾部延迟以外信息。

- **指标与方向**：Goodput（有效吞吐），单位文中未说明（推断token/s或req/s），越高越好。
  **定义与公式**：来源层级为推导关系（非原文公式）[基于文中逻辑的推断：推理依据——作者陈述"under the constraint of meeting the 99%-ile SLO guarantees"+报告吞吐倍数→goodput=SLO达标条件下的吞吐→用于全文倍数对比][页码：1, 9, 11]，非原文Eq.。
  **实验用途**：摘要2.20×/3.06×结论来源。
  **读数与边界**：分母口径为"同一实验设置下基线对应数值"[作者明确陈述]，但聚合方式（多次运行平均/置信区间）文中未说明。

- **指标与方向**：$T_{Prefill}$、$T_{Decode}$，估计器内部延迟预测量。
  **定义与公式**：来源层级为原文公式。$T_{Prefill}=\theta_{1}\cdot\sum_{i}^{bs}n_{i}^{2}+\theta_{2}\cdot\sum_{i}^{bs}n_{i}\cdot r_{i}+\theta_{3}\cdot\sum_{i}^{bs}n_{i}+\theta_{4}$（Eq.1，页码：8）；$T_{Decode}=\theta_{1}\cdot\sum_{i}^{bs}r_{i}+\theta_{2}\cdot bs+\theta_{3}$（Eq.2，页码：8），$bs$为批大小，$n_i$/$r_i$为第i请求新增/复用token数。
  **实验用途**：支撑solo-run predictor精度主张（最大偏差prefill 8.16%、decode 8.84%）[作者明确陈述][页码：8]。

- **指标与方向**：气泡率，CUDA stream空闲时间占比，越低越好（论文认为不直接等价于goodput损失）。
  **定义与公式**：作者文字定义"the proportion of all such bubbles in the compute stream"[页码：13]。
  **读数与边界**：MuxWise气泡率7.7%高于chunked-prefill的4.5%，但作者称不影响goodput，该因果解释未见独立对照实验量化 [基于文中逻辑的推断，页码：13]。

### 8.4 主结果、消融与证据边界

**比较工作与被批判限制的呼应**

| 比较对象 | 核心限制/失效条件 | 本文对应模块 | 直接实验与仍未验证边界 |
|---|---|---|---|
| Splitwise | 静态分配致闲置；缓存池减半降命中率 | 共享显存池+动态引擎 | Figure 5命中率实验；§4端到端对比；36.6%→4.2%数字来自外部文献非本文自测 |
| LoongServe | 释放缓存致跨请求复用失效、需重算 | PD multiplexing共享显存 | Figure 4(b)示意、Table 4对比；未给出重算量化占比 |
| Chunked-prefill | token预算大小两难，复用越长TBT越差 | 无气泡多路复用引擎 | Figure 6扫描实验，证据较充分 |
| NanoFlow | 严格SLO下非计算受限、70B权重反复加载开销大 | PD multiplexing权重仅加载一次 | Table 3/4、Figure 14(c)(d) |
| SGLang-PD | 静态分配波动负载下闲置 | 动态计算重配置 | §4.2.1、§4.3对比；TBT上SGLang-PD有时优于MuxWise（页码：10） |

- 端到端TTFT加速比（Figure 14，页码：10）：相对chunked-prefill/NanoFlow/LoongServe/SGLang-PD分别3.57×、5.98×、4.65×、1.66×（排除不稳定结果后）[实验支持]。
- SLO达标下goodput（Figure 15，页码：11）：Llama-8B为2.6×/5.2×/2.0×/1.3×；Llama-70B为3.06×/2.62×/1.62×（对chunked-prefill/LoongServe/SGLang-PD，无NanoFlow数据）[实验支持]。
- 消融——无气泡引擎（页码：13）：禁用层级调度使TTFT增约10ms；进一步禁用同步机制使TBT恶化314ms（8B）/672ms（70B）[实验支持]。
- 消融——抢占调度（页码：13）：99%-ile TTFT per token加速1.96×[实验支持]；关闭抢占仍有提升的说法未给出量化数据[无法从当前OCR内容确认]。
- Qwen3-235B（MoE）场景仅与chunked-prefill对比，LoongServe/分离式方案因不支持MoE被排除[作者明确陈述该限制][页码：11]。

## 9. 图表解读与论证关系

### 图片原件与标题

#### 原始图片 1：Figure 1. A typical workflow in LLM serving systems: User1 sends two consecutive requests, with the second reusing the context from the first. User2 sends 1 request.

![Figure 1. A typical workflow in LLM serving systems: User1 sends two consecutive requests, with the second reusing the context from the first. User2 sends 1 request.](assets/imgs/img_in_image_box_128_146_560_233.jpg)

*来源：OCR 第 2 页。*

---

#### 原始图片 2：Figure 3. Required compute and memory for processing different phases under SLO constraints with varied reused context lengths. For prefill (a), the batch size is fixed at 1, the new context length is set to 2K, and TTFT is set to 400ms. For decode (b), the batch size is fixed at 32, and TBT is set to 100ms. These settings are commonly seen in online serving.

![Figure 3. Required compute and memory for processing different phases under SLO constraints with varied reused context lengths. For prefill (a), the batch size is fixed at 1, the new context length is set to 2K, and TTFT is set to 400ms. For decode (b), the batch size is fixed at 32, and TBT is set to 100ms. These settings are commonly seen in online serving.](assets/imgs/img_in_chart_box_645_147_1105_331.jpg)

*来源：OCR 第 3 页。*

---

#### 原始图片 3：Figure 2. Main architecture of most LLMs.

![Figure 2. Main architecture of most LLMs.](assets/imgs/img_in_image_box_191_145_504_237.jpg)

*来源：OCR 第 3 页。*

---

#### 原始图片 4：Figure 4. Processing four LLM request batches on 4 GPUs using (a) Splitwise, (b) LoongServe (c) chunked-prefill. All methods satisfy the TBT SLO (T per decode iteration). Specifically, arrives at 0T, at 1T, at 3T, and at 5T. denotes a subsequent request batch that reuses the KV cache of . Inefficient TTFTs are marked in red for each method. KV cache management is shown only for the two disaggregated methods, as they require migration or recomputation. In (a) and (b), solid black arrows represent migration, while dashed red arrows with cross markers denote recomputation. In (a), the KV cache column with a red indicates the active batch. In (c), the red arrow denotes KV cache reads from earlier chunks.

![Figure 4. Processing four LLM request batches on 4 GPUs using (a) Splitwise, (b) LoongServe (c) chunked-prefill. All methods satisfy the TBT SLO (T per decode iteration). Specifically, arrives at 0T, at 1T, at 3T, and at 5T. denotes a subsequent request batch that reuses the KV cache of . Inefficient TTFTs are marked in red for each method. KV cache management is shown only for the two disaggregated methods, as they require migration or recomputation. In (a) and (b), solid black arrows represent migration, while dashed red arrows with cross markers denote recomputation. In (a), the KV cache column with a red indicates the active batch. In (c), the red arrow denotes KV cache reads from earlier chunks.](figure-groups/page-0004-afd626dd9342.png)

*来源：OCR 第 4 页。*

---

#### 原始图片 5：Figure 6. (a) Sweet spot of the token budget in chunk-prefill. The decode uses a fixed batch size of 32, with each request having a reused context length of 1K tokens. (b) Latencies with varied reused context of the fused prefill chunk in chunk-prefill. The token budget is fixed at 512, and the reused context length of decode phase is the same as in (a).

![Figure 6. (a) Sweet spot of the token budget in chunk-prefill. The decode uses a fixed batch size of 32, with each request having a reused context length of 1K tokens. (b) Latencies with varied reused context of the fused prefill chunk in chunk-prefill. The token budget is fixed at 512, and the reused context length of decode phase is the same as in (a).](figure-groups/page-0004-e505d9117a7a.png)

*来源：OCR 第 4 页。*

---

#### 原始图片 6：Figure 7. An ideal solution: prefill-decode multiplexing.

![Figure 7. An ideal solution: prefill-decode multiplexing.](assets/imgs/img_in_image_box_215_143_550_301.jpg)

*来源：OCR 第 5 页。*

---

#### 原始图片 7：Figure 8. Architecture overview of MuxWise.

![Figure 8. Architecture overview of MuxWise.](assets/imgs/img_in_image_box_636_146_1116_415.jpg)

*来源：OCR 第 5 页。*

---

#### 原始图片 8：Figure 10. Bubble-less coordination using layer-wise scheduling for the prefill phase and graph-level scheduling for the decode phase. PLs is the short for prefill layers.

![Figure 10. Bubble-less coordination using layer-wise scheduling for the prefill phase and graph-level scheduling for the decode phase. PLs is the short for prefill layers.](assets/imgs/img_in_image_box_639_143_1109_293.jpg)

*来源：OCR 第 6 页。*

---

#### 原始图片 9：Figure 9. Bubbles and SLO violation of naive intra-process multiplexing. represents the kernel launch order.

![Figure 9. Bubbles and SLO violation of naive intra-process multiplexing. represents the kernel launch order.](assets/imgs/img_in_image_box_112_145_581_307.jpg)

*来源：OCR 第 6 页。*

---

#### 原始图片 10：Figure 11. Slowdowns in decode due to contention with different multiplexing configurations of prefill and decode across models and GPUs.

![Figure 11. Slowdowns in decode due to contention with different multiplexing configurations of prefill and decode across models and GPUs.](assets/imgs/img_in_chart_box_107_146_586_318.jpg)

*来源：OCR 第 7 页。*

---

#### 原始图片 11：Figure 12. The dispatching policy of MuxWise.

![Figure 12. The dispatching policy of MuxWise.](assets/imgs/img_in_image_box_638_145_1117_316.jpg)

*来源：OCR 第 8 页。*

---

#### 原始图片 12：Figure 14. 99%-ile TTFT and TBT for Llama-8B and Llama-70B on real-world Conversation and Tool&Agent workloads. Chunked represents chunked-prefill in SGLang. Values marked with * are too large; we clip their corresponding bars, so the bar height only decodes their relative size.

![Figure 14. 99%-ile TTFT and TBT for Llama-8B and Llama-70B on real-world Conversation and Tool&Agent workloads. Chunked represents chunked-prefill in SGLang. Values marked with * are too large; we clip their corresponding bars, so the bar height only decodes their relative size.](figure-groups/page-0010-6b732e393447.png)

*来源：OCR 第 10 页。*

### 图1：问题动机时间线（第2页）

- **图组结论**：示意图显示长prefill插入decode序列导致相邻decode间隔标红"✗ TBT"，即实测根问题现象的可视化 [页码：2]。
- **论证关系**：该证据→支撑根问题"长prefill挤占decode致TBT超标"→与Figure 3的量化资源需求分析互补，共同引出核心洞见。
- **适用范围**：为概念性示意图，非具体硬件/负载下的实测数据。

### 图2：Prefill/Decode资源需求特征（Figure 3，第3页）

- **图组结论**：Prefill计算需求随复用长度显著上升（约0至8 GPU），Decode计算需求基本不敏感（维持1-2 GPU），两阶段显存需求都持续增长[页码：3]。
- **论证关系**：该证据→直接支撑"需运行时动态划分计算资源、共享显存"的核心洞见→与Figure 1的问题现象图互补，构成设计动机的定量基础。
- **适用范围**：结论限定于Llama-70B、8×A100、特定batch size与SLO设置下的观测。

### 图/表：分离式部署机制批判与缓存命中率（Figure 4/5，第3-4页）

- **图组结论**：Splitwise示意图显示decode专用GPU在prefill阶段闲置；LoongServe示意图显示跨请求复用时出现"recompute"；Figure 5显示缓存池越小命中率越低（Conversation负载在小池容量时命中率仅约0.05）[页码：4]。
- **论证关系**：Figure 4机制类示意→支撑"资源耦合导致闲置或重算"的必要性论证；Figure 5效果类实验→支撑"缓存池减半降低命中率"这一具体量化分支，二者互补但来自不同来源（Figure5为自测，引用[45]的36.6%→4.2%为外部数字）。
- **适用范围**：Figure 5覆盖Tool&Agent/Conversation两个负载、LRU策略、70B模型；图注提到最优命中率需3.3TB内存，但对应横轴刻度未标注，构成证据缺口。

### 图/表：Chunked-prefill两难量化（Figure 6，第4-5页）

- **图组结论**：token预算达4K时延迟达约505ms（远超100ms SLO）；不同decode batch size下TBT均随复用长度增长而显著恶化[页码：5]。
- **论证关系**：该证据→证明chunked-prefill两难是架构性、不可通过调参规避的问题→直接构成MuxWise提出空间复用范式的动机来源。
- **适用范围**：仅覆盖Llama3-70B/8×A100设置，不含MuxWise自身对照数据。

### 图/表：新范式概念示意与系统架构（Figure 7、架构图，第5-6页）

- **图组结论**：示意prefill与decode色块同时分布于不同资源行（空间并行），系统架构图展示估计器→调度器→引擎→争用防护的数据流闭环[页码：5-6]。
- **论证关系**：机制类证据→说明核心洞见如何映射为三模块协同设计→需配合Figure 14-20的端到端实验才能验证实际效果。
- **适用范围**：均为抽象示意图，数值为相对时间单位，非实测数据。

### 图/表：无气泡引擎问题与解法（Figure 9及其解法示意，第5-6页）

- **图组结论**：朴素调度产生三类气泡/SLO违规（启动延迟致气泡、请求提前结束致资源无法回收、短请求排队违约）；解法示意图显示层级化调度+同步机制消除对应问题[页码：6]。
- **论证关系**：问题严重性证据→论证无气泡引擎设计的必要性→量化验证依赖§4.4.2消融实验（TTFT增约10ms、TBT恶化314/672ms）。
- **适用范围**：示意性构图，无具体数值刻度。

### 图/表：争用画像箱线图（Figure 11，第7页）

- **图组结论**：四种模型/GPU组合下decode争用减速在0%-30%区间波动，且不随SM分配呈单调规律[页码：7]。
- **论证关系**：机制证据→支撑"争用不可预测、只能给最坏情况上界"的设计前提→支撑contention guard设计选择。
- **适用范围**：仅覆盖decode侧，prefill侧"similar but omitted"未给出图表；各面板对应workload细分未说明。

### 图/表：调度器决策示意与端到端结果（调度示意图、Figure 14，第8-10页）

- **图组结论**：调度示意图显示SM划分随decode batch变化动态重算（40%/60%→20%/80%→30%/70%）并展示抢占；Figure 14显示MuxWise在四类负载组合下TTFT/TBT普遍优于四基线，但SGLang-PD在部分TBT上更优[页码：8-10]。
- **论证关系**：调度示意为机制证据，支撑调度器设计描述；Figure 14为效果证据，直接支撑摘要级加速比结论，并揭示MuxWise相对SGLang-PD的TBT权衡边界。
- **适用范围**：调度示意为假设案例，未说明是否来自真实运行记录[文中未说明]；Figure 14中部分柱子因裁剪/图例不完整存在读数缺口。

## 10. 完整因果推理树

- 根问题：LLM服务需同时满足prefill/decode两条独立SLO，二者交替执行致资源冲突[页码：2]
  - 旧方法限制：分离式部署资源耦合致闲置/重算；分块预填充存在预算两难[页码：2]
    - 核心洞见/假设：以GPU内空间并行替代时间交替，解耦compute与memory管理[页码：2, 5]
      - 方法模块：无气泡多路复用引擎（层级化prefill切分+事件同步）[页码：6-7]
        - 可验证预测：层级调度可低开销消除气泡且不损害goodput
          - 指标与实验：§4.4.2消融（TTFT/TBT变化量）[实验支持][页码：13]
            - 图表证据：Figure 9问题示意+解法示意[页码：6]
              - 结论与适用边界：气泡率轻微上升（7.7%vs4.5%）但作者称不影响goodput，该因果未被独立量化实验证明[基于文中逻辑的推断][页码：13]
      - 方法模块：抗争用估计器（solo-run predictor+contention guard）[页码：7-8]
        - 可验证预测：预测误差可控、争用减速有上界
          - 指标与实验：预测误差数字（8.16%/8.84%）、Figure 11争用画像[实验支持][页码：7-8]
            - 图表证据：Figure 11箱线图[页码：7]
              - 结论与适用边界：仅覆盖decode侧、离线画像覆盖范围外的线上争用是否超界未被验证[基于文中逻辑的推断][页码：8]
      - 方法模块：SLO感知调度器（分层启动量+抢占）[页码：8-9]
        - 可验证预测：抢占机制提升尾部TTFT
          - 指标与实验：Figure 20抢占消融（1.96×提升）[实验支持][页码：13]
            - 图表证据：调度示意图[页码：8]
              - 结论与适用边界：关闭抢占仍有提升的说法未被量化验证[未被当前证据直接验证][页码：9]
    - 整体效果验证：端到端TTFT/TBT/goodput提升
      - 指标与实验：Figure 14-17端到端对比[实验支持][页码：10-12]
        - 图表证据：Figure 14柱状图[页码：10]
          - 结论与适用边界：结论限定于已测试的模型/硬件/负载组合，Qwen-235B场景仅单一基线对比[作者明确陈述][页码：11]

## 11. 结论、贡献与边界

- **贡献总结**：提炼高goodput LLM服务关键需求；提出PD多路复用新范式及三模块设计；在多样负载下评估并证明优于现有方案 [作者明确陈述][页码：3]。
- **证据充分的结论**：真实负载/合成负载下MuxWise相对四基线的TTFT/goodput提升有直接实验数字支撑（§4.2-4.3）[实验支持]。
- **尚属推断的意义**：goodput指标本身为推导关系而非原文公式，"气泡率略升不影响goodput"这一因果解释缺乏独立对照实验[基于文中逻辑的推断]。
- **适用条件**：仅在SLO严格的在线服务场景占优；需硬件支持进程内低开销空间划分（如GreenContext）[作者明确陈述][页码：13-14]。
- **局限**：多数消融实验仅用Llama-70B（"其他模型结果相似"未给量化数据）[作者明确陈述][页码：12]；contention guard的画像更新运维成本文中未说明。
- **审稿式风险检查**：
  - 贡献新意：GreenContext等底层技术非本文首创，本文贡献在于系统整合与调度设计，论文自身已区分[作者明确陈述][页码：6]，当前证据未显示过度夸大风险。
  - 写作/可复现性：代码/数据集链接文中未说明，复现存在障碍，属当前证据暴露的风险。
  - 效果大小：主要提升数字来自论文自报的排除"不稳定结果"后的平均值，统计口径（是否多次运行、置信区间）文中未说明，构成一定风险。
  - 实验覆盖：MoE模型场景仅对比单一基线，覆盖面较窄，属当前证据暴露的风险[作者明确陈述该限制]。
  - 方法设计：worst-case估计依赖离线画像覆盖率，在线场景是否超出画像范围未见实验验证，当前证据未显示该风险已发生，但也未排除。

## 12. 术语与第一性原理学习路径

### 12.1 核心术语

- **术语**：SLO（服务等级目标）。**第一性原理角色**：连接"用户体验要求"与"系统资源分配"两个基本量的约束条件。**本文位置**：TTFT/TBT两条SLO是全文优化目标[页码：2, 9]。
- **术语**：KV缓存。**第一性原理角色**：受显存容量约束，是connect"历史token计算结果"与"当前生成token"的因果媒介，避免重复计算。**本文位置**：共享显存设计的核心对象[页码：2-4]。
- **术语**：SM（流式多处理器）。**第一性原理角色**：GPU计算资源的最小可分配单元，受总数量物理约束。**本文位置**：调度器分配对象、GreenContext划分单位[页码：5-9]。
- **术语**：GreenContext。**第一性原理角色**：连接"进程内多流"与"低开销SM划分"两个量的机制。**本文位置**：本文实现空间复用的底层技术基础[页码：6]。
- **术语**：Goodput。**第一性原理角色**：受SLO约束限定的吞吐量，是"原始吞吐"与"SLO合规率"两个量的耦合结果。**本文位置**：全文核心评测指标[页码：1, 9, 11]。
- **术语**：Token budget（token预算）。**第一性原理角色**：受GPU算力约束与TBT SLO约束双重限制的资源分配参数。**本文位置**：chunked-prefill两难的核心变量[页码：2, 5]。
- **术语**：MoE（混合专家模型）。**第一性原理角色**：受"总参数量"与"激活参数量"分离约束的架构，降低计算成本。**本文位置**：Qwen3-235B适用范围验证场景[页码：11]。

### 12.2 学习路径

1. 先理解token与KV缓存这两个基本对象——它们是LLM推理的最小计算/存储单元，是理解prefill/decode差异的前提。
2. 再理解SM与显存这两类GPU资源约束——任何调度设计都受限于"有限SM数"与"有限显存容量"这两条硬约束。
3. 然后理解prefill计算密集、decode显存带宽密集这一机制性差异——它解释了为何两阶段需要不同的资源分配策略。
4. 最后理解TTFT/TBT/Goodput这类可观测指标——它们是判断调度设计是否成功的最终标尺，理解了它们才能读懂论文的实验图表。

---

*本报告由 paper-pipeline 生成 · prompt `v11` · backend `cli_agent` · model `claude-sonnet-5` · 2026-07-26T11:24:00*
