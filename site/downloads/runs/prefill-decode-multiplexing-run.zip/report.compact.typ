#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[Towards High-Goodput LLM Serving with Prefill-decode Multiplexing]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yukang Chen, Weihao Cui, Han Zhao, Ziyi Xu, Xiaoze Fan, Xusheng Chen, Yangjie Zhou, Shixuan Sun, Bingsheng He, Quan Chen]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[ASPLOS '26 (31st ACM International Conference on Architectural Support for Programming Languages and Operating Systems, Volume 2) · 2026]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM Serving] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[PD-Multiplexing] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Goodput] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU调度] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[SLO]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[DOI：https://doi.org/10.1145/3779212.3790236]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

大语言模型（LLM）服务需要同时满足预填充（prefill）和解码（decode）阶段严格的服务级别目标（SLO）。现有方案中，一些将两个阶段分离部署，可能导致资源闲置或计算冗余；另一些将预填充阶段切分为多个块并与解码迭代融合，造成SLO合规性与高利用率之间的两难困境。为解决这些问题，高效的服务系统应能动态调整计算资源分配、将计算与内存管理解耦，并使预填充与解码独立执行。我们提出了MuxWise，一个采用全新范式------GPU内预填充-解码复用（intra-GPU prefill-decode multiplexing）------的LLM服务框架。为充分发挥该范式的优势，MuxWise集成了无气泡复用引擎、抗争用估计器和SLO感知调度器。评估结果表明，在满足SLO保证的前提下，MUXWISE相较于现有最先进方案将峰值吞吐量平均提升了2.20倍（最高达3.06倍）。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [Towards High-Goodput LLM Serving with Prefill-decode Multiplexing],
    [作者], [Yukang Chen, Weihao Cui, Han Zhao, Ziyi Xu, Xiaoze Fan, Xusheng Chen, Yangjie Zhou, Shixuan Sun, Bingsheng He, Quan Chen],
    [发表场所 / 年份], [ASPLOS \'26（第31届ACM架构支持编程语言与操作系统国际会议，第2卷）/ 2026],
    [研究领域], [计算机系统（LLM 服务系统）],
    [关键词], [LLM Serving, PD-Multiplexing, Goodput, GPU调度, SLO],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：#link("https://doi.org/10.1145/3779212.3790236")
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（5个）]：`LLM推理服务` · `Prefill-Decode多路复用` · `GPU调度` · `SLO保障` · `Goodput优化`
]

论文提出 MuxWise，一种让 prefill（预填充，处理输入生成首token）与 decode（解码，逐token生成）在同一块 GPU 内部、同一时刻分别占用不同计算单元并行执行的新范式，配合无气泡多路复用引擎、抗争用估计器、SLO感知调度器三个模块，在满足延迟 SLO 前提下将有效吞吐（goodput）平均提升 2.20 倍、最高 3.06 倍 \[作者明确陈述\]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- OCR 覆盖论文正文第 1--15 页的文本证据分析与 6 组图表证据分析（共 12 张图片，另有 6 张因超出上限未做视觉分析），可核实内容包括方法设计、消融数据、比较工作表与主张证据表。
- 明显缺失：Goodput/TTFT/TBT 的精确计算公式、统计聚合口径（是否多次运行平均、置信区间）文中未说明；代码/数据集链接文中未说明。
- 6 张未分析图片可能包含额外实验细节，本报告不对其做视觉层面判断，相关结论只依据已分析的图组与文本。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

- #strong[问题定义]：LLM 在线服务需同时满足两条独立延迟 SLO------prefill 阶段的首token时间（TTFT，如\<500ms）与 decode 阶段的逐token间隔（TBT，如\<100ms）\[作者明确陈述\]。由于 prefill 与 decode 在同一请求流中交替出现，长 prefill 会挤占正在进行的 decode 迭代，造成 TBT 超标\[作者明确陈述\]。
- #strong[为何重要]：真实工作负载（单轮聊天、长文档、长链推理、多轮对话/工具调用）在输入/输出/复用（reused，跨轮共享上文）长度上差异巨大（Conversation 复用长度可达0--120K token）\[作者明确陈述\]，任何静态资源分配都难兼顾吞吐与SLO。
- #strong[难点来源]：token 是基本工作单元，prefill 计算量随（新增+复用）token数增长、decode 显存访问量随复用长度增长；若两阶段共享同一批资源却按同一批次串行调度，一方资源需求波动即传导为另一方排队延迟，最终表现为 SLO 违约与 goodput 下降 \[基于文中逻辑的推断\]。
- #strong[本文 story]：旧路线（分离式部署、分块预填充）都把 compute 与 memory 管理绑定在一起、且让两阶段在时间上交替，这一结构性设计导致资源闲置或\"SLO合规vs高利用率\"两难；本文的转折在于把两阶段从\"时间交替\"改为\"空间并行\"，从而在同一 GPU 内解耦资源分配。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：具体主张]
  #image("assets/imgs/img_in_image_box_128_146_560_233.jpg", width: 100%)
  #emph[Figure 1. A typical workflow in LLM serving systems: User1 sends two consecutive requests, with the second reusing the context from the first. User2 sends 1 request.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：长 prefill 插入 decode 序列导致相邻 decode 间隔标红违反 TBT SLO，直观呈现根问题现象。

- #strong[论证关系]：作为直观问题证据，支撑根问题中长 prefill 挤占 decode 导致 TBT 超标的论点，与定量分析互补。

- #strong[适用范围]：为概念性工作流示意图，而非特定硬件或工作负载下的实测数据。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：具体主张]
  #image("assets/imgs/img_in_chart_box_645_147_1105_331.jpg", width: 100%)
  #emph[Figure 3. Required compute and memory for processing different phases under SLO constraints with varied reused context lengths. For prefill (a), the batch size is fixed at 1, the new context length is set to 2K, and TTFT is set to 400ms. For decode (b), the batch size is fixed at 32, and TBT is set to 100ms. These settings are commonly seen in online serving.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Prefill 计算需求随复用长度显著上升，Decode 计算需求不敏感，而两阶段显存需求均持续增长。

- #strong[论证关系]：定量揭示 prefill 与 decode 算力需求错配，支撑需要动态划分计算资源并共享显存的核心洞见。

- #strong[适用范围]：限定于 Llama-70B、8×A100、特定批大小与 SLO 设置下的测量结果。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：具体主张]
  #image("figure-groups/page-0004-e505d9117a7a.png", width: 100%)
  #emph[Figure 6. (a) Sweet spot of the token budget in chunk-prefill. The decode uses a fixed batch size of 32, with each request having a reused context length of 1K tokens. (b) Latencies with varied reused context of the fused prefill chunk in chunk-prefill. The token budget is fixed at 512, and the reused context length of decode phase is the same as in (a).]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：token 预算达 4K 时延迟超 500ms 远超 SLO，且 TBT 随复用长度增长显著恶化。

- #strong[论证关系]：证明分块预填充的利用率与延迟两难是结构性的，构成空间复用范式的核心动机。

- #strong[适用范围]：仅覆盖 Llama3-70B 与 8×A100 配置，不含 MuxWise 对照数据。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：具体主张]
  #image("assets/imgs/img_in_image_box_112_145_581_307.jpg", width: 100%)
  #emph[Figure 9. Bubbles and SLO violation of naive intra-process multiplexing. represents the kernel launch order.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：朴素 GPU 内多路复用会引入启动开销气泡、资源无法回收气泡及短请求 SLO 违约。

- #strong[论证关系]：揭示朴素空间复用缺陷，论证无气泡多路复用引擎层级调度与事件同步的必要性。

- #strong[适用范围]：为朴素调度缺陷的示意图，无具体数值刻度。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

#critique-card(
  [Splitwise（静态分离式）],
  [目标是把 prefill/decode 分离到独立实例分别保 SLO；前提是负载可预先划分。],
  [GPU 划分在实例初始化时固定，负载波动时产生闲置\[作者明确陈述\]；各实例独立缓存池使总容量缩水，命中率下降（引用文献数据 36.6%→4.2%）\[作者明确陈述，引用\[45\]\]。],
  [共享显存池设计],
  [Figure 5 自测命中率曲线、§4端到端对比],
)

#critique-card(
  [LoongServe（动态分离式）],
  [在 Splitwise 基础上按序列长度/阶段动态调整 GPU 分配。前提是可以随时释放原 GPU 缓存。],
  [为避免缓存重复而立即释放，导致跨请求（多轮）KV复用失效，必须重算\[作者明确陈述\]。],
  [PD multiplexing 的共享显存设计],
  [Figure 4(b) 示意分析、Table 4 端到端对比],
)

#critique-card(
  [Chunked-prefill（如SARATHI-Serve）],
  [把prefill切块与decode迭代融合，靠token预算上限保SLO。前提是可找到兼顾利用率与延迟的预算值。],
  [70B模型在8×A100打满GPU需4K预算，是100ms TBT SLO所允许256预算的8倍\[作者明确陈述\]；复用上下文越长，TBT越差\[作者明确陈述\]。],
  [无气泡多路复用引擎（空间复用替代时间融合）],
  [Figure 6(a)(b) 预算/复用长度扫描],
)

#critique-card(
  [NanoFlow],
  [算子级GPU内多路复用，目标是宽松SLO下近最优吞吐。],
  [严格SLO（≤100ms）要求预算降至256时不再计算受限，且70B模型因反复加载权重开销被放大 \[作者明确陈述\]。],
  [PD multiplexing使模型权重仅prefill阶段加载一次],
  [Table 3/4、Figure 14(c)(d)],
)

#critique-card(
  [SGLang-PD],
  [静态分离但支持跨阶段缓存共享。],
  [波动负载下decode实例仍会闲置，OpenThoughts/LooGLE场景下表现明显更差\[作者明确陈述\]。],
  [动态计算重配置能力],
  [§4.2.1、§4.3端到端对比],
)

#critique-card(
  [DistServe、Dynamo],
  [],
  [仅有排除性文字说明，未作为主要基线，原始动机与限制无法从当前OCR内容确认。],
  [文中未作为主要基线对比],
  [],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

- #strong[核心洞见]：与其让prefill、decode在同一流水线中\"时间交替\"（无论跨实例还是同GPU前后执行），不如让二者在同一GPU内部、同一时刻通过划分SM（流式多处理器）\"空间并行\"执行，同时共享同一块显存 \[作者明确陈述\]。
- #strong[实现组件（非独立贡献）]：GreenContext空间划分（来自已有文献）、层级化prefill切分、query-based synchronization、离线画像预测器与contention guard。
- #strong[支撑前提]（\[实验支持\]）：prefill计算需求对复用长度高度敏感、decode相对不敏感（Figure 3a/b）；两阶段KV缓存量可达数十至数百GB，宜共享显存空间。
- #strong[前提可能失效处]：该范式依赖硬件支持进程内低开销空间划分（如GreenContext），不支持该特性的硬件不适用\[作者明确陈述\]。
- 由此产生两个新挑战：C-1 朴素调度产生GPU气泡；C-2 空间复用引入不可预测的显存带宽争用 \[作者明确陈述\]。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：请求进入后，估计器基于离线画像给出最坏情况延迟预测→调度器据此决定SM划分与请求调度顺序→引擎按层级化方式执行prefill并与decode并行→运行时数据反哺争用防护模块，形成闭环 \[作者明确陈述\]。

+ #strong[Bubble-less Multiplex Engine（无气泡多路复用引擎）]：动机是朴素调度会因prefill启动耗时（数十ms）远超单次decode迭代（\<0.5ms）产生气泡、GPU不可抢占导致资源无法回收、长请求排队使短请求违约。做法：把prefill按transformer层切分为\"prefill layers（PLs）\"，以接近decode迭代的粒度交替启动，配合事件轮询同步在最后一层完成时立即合并进decode batch。优势：层级切分开销可忽略，因LLM天然由多层组成；带来抢占短请求优先的能力。
+ #strong[Contention-tolerant Estimator（抗争用估计器）]：动机是GreenContext无法管理显存带宽争用、GPU不暴露实时带宽监控接口。输入为复用/新增/输出长度、batch size、SM分区；过程分solo-run predictor（拟合$T_(P r e f i l l)$、$T_(D e c o d e)$线性模型，Eq.1/Eq.2）与contention guard（离线网格画像给出最坏减速因子）。输出为最坏情况延迟预测，用于保证SLO上界而非追求精度。
+ #strong[SLO-aware Dispatcher（SLO感知调度器）]：动机是需据估计结果实际分配SM并选调度对象。每次decode迭代结束时重新决策，优先保decode SLO，用$N_(P L) = ceil.l\(T_d times N_T\)\/T_P ceil.r$计算应启动的prefill层数，剩余SM给prefill；允许短请求抢占长请求但不允许递归抢占。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/imgs/img_in_image_box_191_145_504_237.jpg", width: 100%)
  #emph[Figure 2. Main architecture of most LLMs.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：LLM 由多个相同 transformer 层堆叠而成，KV 缓存交互仅发生在 Attention 子模块。

- #strong[论证关系]：为无气泡引擎的按层切分 prefill 设计提供结构前提，证明层级切分开销极低。

- #strong[适用范围]：主流 Transformer 架构 LLM 的通用结构抽象。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/imgs/img_in_image_box_215_143_550_301.jpg", width: 100%)
  #emph[Figure 7. An ideal solution: prefill-decode multiplexing.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Prefill 与 Decode 色块在同一时刻分布于不同资源行，实现 GPU 内空间并行执行。

- #strong[论证关系]：直观展示 PD 空间多路复用范式，说明两阶段解耦与计算资源动态共享机制。

- #strong[适用范围]：新范式概念示意图，图中数值为相对时间单位。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/imgs/img_in_image_box_636_146_1116_415.jpg", width: 100%)
  #emph[Figure 8. Architecture overview of MuxWise.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示抗争用估计器、SLO 感知调度器与无气泡多路复用引擎三模块闭环协同关系。

- #strong[论证关系]：说明系统整体架构与数据流向，展示三模块如何协作解决气泡与争用挑战。

- #strong[适用范围]：MuxWise 系统整体架构框图。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/imgs/img_in_image_box_639_143_1109_293.jpg", width: 100%)
  #emph[Figure 10. Bubble-less coordination using layer-wise scheduling for the prefill phase and graph-level scheduling for the decode phase. PLs is the short for prefill layers.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：通过层级化 prefill 切分与基于事件轮询的同步机制，实现无气泡的跨阶段协调。

- #strong[论证关系]：展示无气泡引擎如何消除启动延迟、资源不可回收及短请求排队三类气泡。

- #strong[适用范围]：无气泡协调机制的时序示意图。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/imgs/img_in_image_box_638_145_1117_316.jpg", width: 100%)
  #emph[Figure 12. The dispatching policy of MuxWise.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：SM 划分比例随 decode 批次组成动态重算，且展示短请求抢占长请求调度过程。

- #strong[论证关系]：直观呈现 SLO 感知调度器的分配逻辑与抢占机制，支撑调度策略实现细节。

- #strong[适用范围]：调度策略流程图解，非实测运行记录。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 层级化切分使prefill粒度接近decode迭代，从而快速让出资源、减少气泡 \[基于文中逻辑的推断\]，需要的前提是LLM确实由多层构成（普遍成立）。
- 共享显存空间保留KV缓存池的完整效率，前提是硬件显存容量足够容纳prefill+decode合并后的缓存需求 \[基于文中逻辑的推断\]。
- 空间并行使两阶段互不阻塞独立执行，从而理论上避免\"SLO合规vs高利用率\"两难，前提是SM划分能被低开销动态调整（依赖GreenContext）\[基于文中逻辑的推断\]。
- worst-case延迟估计保证SLO上界，前提是离线画像覆盖范围包含线上实际出现的资源配置组合，论文未证明该覆盖的完备性 \[基于文中逻辑的推断\]。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果问题：MuxWise是否在真实/合成负载下相对四个基线提升TTFT/TBT/goodput？对应Figure 14-17端到端对比\[实验支持\]。
- 必要性问题：chunked-prefill的token预算两难是否架构性不可规避？对应Figure 6扫描实验\[实验支持\]。
- 机制/必要性问题：无气泡引擎的层级调度与同步机制是否必要？对应§4.4.2消融\[实验支持\]。
- 鲁棒性问题：抢占机制是否带来提升？对应Figure 20，仅有量化的\"开启抢占\"对比，未提供\"关闭抢占仍有提升\"的量化数据\[作者明确陈述，但未见量化数据\]。
- 适用范围问题：MoE大模型（Qwen3-235B）上是否同样有效？仅与chunked-prefill单一基线对比，范围窄于其他实验\[作者明确陈述\]。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 负载来源：ShareGPT（单轮聊天）、LooGLE（长文档）、OpenThoughts（长链推理）、Conversation/Tool&agent（多轮，Table 1定义）\[作者明确陈述\]。
- 模型/硬件：Llama-8B/70B（A100/H100）、Qwen3-235B（H200），均用张量并行部署\[作者明确陈述\]。
- 基线：chunked-prefill(SARATHI-Serve)、NanoFlow、LoongServe、SGLang-PD，另有自建对比WindServe、Tropical、Semi-PD、Bullet。
- 请求到达：Poisson process模拟\[作者明确陈述\]。
- 重复次数/统计方式：文中未说明。
- SLO目标：Llama-8B设50ms TBT，Llama-70B设100ms TBT\[作者明确陈述\]。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：TTFT，测量prefill耗时，单位ms/s，越低越好。 #strong[定义与公式]：来源层级为无可核验公式；文中仅文字定义为\"产生首token的耗时\"。 #strong[实验用途]：SLO达标判据，对比MuxWise与四基线。 #strong[读数与边界]：具体倍数见8.4；不能证明goodput绝对值。

- #strong[指标与方向]：TBT，测量decode单token间隔，单位ms，越低越好，是全文核心SLO指标。 #strong[定义与公式]：来源层级无可核验公式；文字定义为\"每token延迟\"，并与TPOT（平均指标）对比强调其为\"逐token\"口径。 #strong[实验用途]：主SLO判据，Llama-8B设50ms、Llama-70B设100ms。 #strong[读数与边界]：不能反映平均表现掩盖的尾部延迟以外信息。

- #strong[指标与方向]：Goodput（有效吞吐），单位文中未说明（推断token/s或req/s），越高越好。 #strong[定义与公式]：来源层级为推导关系（非原文公式）\[基于文中逻辑的推断：推理依据------作者陈述\"under the constraint of meeting the 99%-ile SLO guarantees\"+报告吞吐倍数→goodput=SLO达标条件下的吞吐→用于全文倍数对比\]，非原文Eq.。 #strong[实验用途]：摘要2.20×/3.06×结论来源。 #strong[读数与边界]：分母口径为\"同一实验设置下基线对应数值\"\[作者明确陈述\]，但聚合方式（多次运行平均/置信区间）文中未说明。

- #strong[指标与方向]：$T_(P r e f i l l)$、$T_(D e c o d e)$，估计器内部延迟预测量。 #strong[定义与公式]：来源层级为原文公式。$T_(P r e f i l l) = theta_1 dot.op sum_i^(b s) n_i^2 + theta_2 dot.op sum_i^(b s) n_i dot.op r_i + theta_3 dot.op sum_i^(b s) n_i + theta_4$（Eq.1）；$T_(D e c o d e) = theta_1 dot.op sum_i^(b s) r_i + theta_2 dot.op b s + theta_3$（Eq.2），$b s$为批大小，$n_i$/$r_i$为第i请求新增/复用token数。 #strong[实验用途]：支撑solo-run predictor精度主张（最大偏差prefill 8.16%、decode 8.84%）\[作者明确陈述\]。

- #strong[指标与方向]：气泡率，CUDA stream空闲时间占比，越低越好（论文认为不直接等价于goodput损失）。 #strong[定义与公式]：作者文字定义\"the proportion of all such bubbles in the compute stream\"。 #strong[读数与边界]：MuxWise气泡率7.7%高于chunked-prefill的4.5%，但作者称不影响goodput，该因果解释未见独立对照实验量化 \[基于文中逻辑的推断\]。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较对象], [核心限制/失效条件], [本文对应模块], [直接实验与仍未验证边界],),
    table.hline(),
    [Splitwise], [静态分配致闲置；缓存池减半降命中率], [共享显存池+动态引擎], [Figure 5命中率实验；§4端到端对比；36.6%→4.2%数字来自外部文献非本文自测],
    [LoongServe], [释放缓存致跨请求复用失效、需重算], [PD multiplexing共享显存], [Figure 4(b)示意、Table 4对比；未给出重算量化占比],
    [Chunked-prefill], [token预算大小两难，复用越长TBT越差], [无气泡多路复用引擎], [Figure 6扫描实验，证据较充分],
    [NanoFlow], [严格SLO下非计算受限、70B权重反复加载开销大], [PD multiplexing权重仅加载一次], [Table 3/4、Figure 14(c)(d)],
    [SGLang-PD], [静态分配波动负载下闲置], [动态计算重配置], [§4.2.1、§4.3对比；TBT上SGLang-PD有时优于MuxWise],
  )]
  , kind: table
  )

- 端到端TTFT加速比（Figure 14）：相对chunked-prefill/NanoFlow/LoongServe/SGLang-PD分别3.57×、5.98×、4.65×、1.66×（排除不稳定结果后）\[实验支持\]。
- SLO达标下goodput（Figure 15）：Llama-8B为2.6×/5.2×/2.0×/1.3×；Llama-70B为3.06×/2.62×/1.62×（对chunked-prefill/LoongServe/SGLang-PD，无NanoFlow数据）\[实验支持\]。
- 消融------无气泡引擎：禁用层级调度使TTFT增约10ms；进一步禁用同步机制使TBT恶化314ms（8B）/672ms（70B）\[实验支持\]。
- 消融------抢占调度：99%-ile TTFT per token加速1.96×\[实验支持\]；关闭抢占仍有提升的说法未给出量化数据\[无法从当前OCR内容确认\]。
- Qwen3-235B（MoE）场景仅与chunked-prefill对比，LoongServe/分离式方案因不支持MoE被排除\[作者明确陈述该限制\]。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0004-afd626dd9342.png", width: 100%)
    #emph[Figure 4. Processing four LLM request batches on 4 GPUs using (a) Splitwise, (b) LoongServe (c) chunked-prefill. All methods satisfy the TBT SLO (T per decode iteration). Specifically, arrives at 0T, at 1T, at 3T, and at 5T. denotes a subsequent request batch that reuses the KV cache of . Inefficient TTFTs are marked in red for each method. KV cache management is shown only for the two disaggregated methods, as they require migration or recomputation. In (a) and (b), solid black arrows represent migration, while dashed red arrows with cross markers denote recomputation. In (a), the KV cache column with a red indicates the active batch. In (c), the red arrow denotes KV cache reads from earlier chunks.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
    - #strong[图组结论]：Splitwise 存在 decode 实例闲置，LoongServe 跨请求复用产生重算，Figure 5 显示池越小命中率越低。

- #strong[论证关系]：支撑分离式部署资源耦合致闲置与重算的批判，自测命中率实验补充容量缩水危害。

- #strong[适用范围]：示意图覆盖 4 卡 4 批次场景；命中率实验覆盖 Tool&Agent 与 Conversation 负载。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_107_146_586_318.jpg", width: 100%)
    #emph[Figure 11. Slowdowns in decode due to contention with different multiplexing configurations of prefill and decode across models and GPUs.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
    - #strong[图组结论]：不同模型与 GPU 下 decode 因争用减速在 0%--30% 波动，且不随 SM 分配呈现单调规律。

- #strong[论证关系]：证实显存带宽争用具有不可预测性，支撑抗争用估计器给出最坏情况减速上界的设计选择。

- #strong[适用范围]：覆盖 Llama-8B/70B 与 A100/H100，仅展示 decode 侧减速数据。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0010-6b732e393447.png", width: 100%)
    #emph[Figure 14. 99%-ile TTFT and TBT for Llama-8B and Llama-70B on real-world Conversation and Tool&Agent workloads. Chunked represents chunked-prefill in SGLang. Values marked with \* are too large; we clip their corresponding bars, so the bar height only decodes their relative size.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
    - #strong[图组结论]：MuxWise 在多类真实负载下 99%-ile TTFT/TBT 普遍优于四基线，部分场景 SGLang-PD 的 TBT 更优。

- #strong[论证关系]：直接支撑端到端延迟优势主张，同时揭示与静态分离方案（SGLang-PD）在 TBT 上的权衡边界。

- #strong[适用范围]：覆盖 Llama-8B/70B 及 Conversation、Tool&Agent 负载。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1. Diverse patterns of typical LLM tasks. Minimum, mean, and maximum values for each metric are reported.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
  - #strong[图组结论]：不同 LLM 任务在输入、输出及复用上下文长度上呈现出巨大的模式差异。

- #strong[论证关系]：量化真实工作负载的多样性与波动性，论证静态资源分配无法兼顾吞吐与 SLO 的根问题。

- #strong[适用范围]：统计涵盖 Single-turn, Long-doc, Reasoning, Multi-turn 等典型在线服务负载。
  #v(5pt)
  #image("table-groups/page-0003-568fcf9321e4.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2. Compute analysis for prefill and decode phases.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
  - #strong[图组结论]：给出 Prefill 与 Decode 阶段在 Attention 与 FFN 模块上的理论计算复杂度表达式。

- #strong[论证关系]：为抗争用估计器中的 solo-run predictor 线性模型拟合提供理论计算复杂度建模依据。

- #strong[适用范围]：适用于标准 Transformer 架构模型的 Prefill 与 Decode 计算量分析。
  #v(5pt)
  #image("table-groups/page-0007-bdef7e9f39b9.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
  - #strong[图组结论]：补充展示 Llama-70B 在 Conversation 负载下各基线与 MuxWise 的吞吐与资源利用率等细节指标。

- #strong[论证关系]：与 Figure 14 延迟数据互补，全面支撑 MuxWise 综合性能优越性的主张。

- #strong[适用范围]：限定于 Llama-70B 在 Conversation 工作负载下的评估。
  #v(5pt)
  #image("table-groups/page-0010-2f595b9c124f.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 4.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
  - #strong[图组结论]：补充展示 Llama-70B 在 Tool&Agent 负载下各基线与 MuxWise 的吞吐与 SLO 达标情况等数据。

- #strong[论证关系]：为 Tool&Agent 多轮工具调用场景下的端到端性能优势提供多维证据支撑。

- #strong[适用范围]：限定于 Llama-70B 在 Tool&Agent 工作负载下的评估。
  #v(5pt)
  #image("table-groups/page-0011-cdbc163cf3dc.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 5. Token throughput and GPU utilization for Llama8B and Llama-70B on Tool&Agent workload under Goodput.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 9 节：具体主张]
  - #strong[图组结论]：展示 SLO 约束（Goodput）下 Llama-8B/70B 在 Tool&Agent 上的 token 吞吐量与 GPU 利用率。

- #strong[论证关系]：直接支撑论文关于 MuxWise 能在保 SLO 前提下显著提升有效吞吐与 GPU 利用率的主张。

- #strong[适用范围]：覆盖 Llama-8B 与 Llama-70B 在 Tool&Agent 负载下的 Goodput 评测。
  #v(5pt)
  #image("table-groups/page-0011-f4ccaf86cdc9.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：LLM服务需同时满足prefill/decode两条独立SLO，二者交替执行致资源冲突
  - 旧方法限制：分离式部署资源耦合致闲置/重算；分块预填充存在预算两难
    - 核心洞见/假设：以GPU内空间并行替代时间交替，解耦compute与memory管理
      - 方法模块：无气泡多路复用引擎（层级化prefill切分+事件同步）
        - 可验证预测：层级调度可低开销消除气泡且不损害goodput
          - 指标与实验：§4.4.2消融（TTFT/TBT变化量）\[实验支持\]
            - 图表证据：Figure 9问题示意+解法示意
              - 结论与适用边界：气泡率轻微上升（7.7%vs4.5%）但作者称不影响goodput，该因果未被独立量化实验证明\[基于文中逻辑的推断\]
      - 方法模块：抗争用估计器（solo-run predictor+contention guard）
        - 可验证预测：预测误差可控、争用减速有上界
          - 指标与实验：预测误差数字（8.16%/8.84%）、Figure 11争用画像\[实验支持\]
            - 图表证据：Figure 11箱线图
              - 结论与适用边界：仅覆盖decode侧、离线画像覆盖范围外的线上争用是否超界未被验证\[基于文中逻辑的推断\]
      - 方法模块：SLO感知调度器（分层启动量+抢占）
        - 可验证预测：抢占机制提升尾部TTFT
          - 指标与实验：Figure 20抢占消融（1.96×提升）\[实验支持\]
            - 图表证据：调度示意图
              - 结论与适用边界：关闭抢占仍有提升的说法未被量化验证\[未被当前证据直接验证\]
    - 整体效果验证：端到端TTFT/TBT/goodput提升
      - 指标与实验：Figure 14-17端到端对比\[实验支持\]
        - 图表证据：Figure 14柱状图
          - 结论与适用边界：结论限定于已测试的模型/硬件/负载组合，Qwen-235B场景仅单一基线对比\[作者明确陈述\]

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- #strong[贡献总结]：提炼高goodput LLM服务关键需求；提出PD多路复用新范式及三模块设计；在多样负载下评估并证明优于现有方案 \[作者明确陈述\]。
- #strong[证据充分的结论]：真实负载/合成负载下MuxWise相对四基线的TTFT/goodput提升有直接实验数字支撑（§4.2-4.3）\[实验支持\]。
- #strong[尚属推断的意义]：goodput指标本身为推导关系而非原文公式，\"气泡率略升不影响goodput\"这一因果解释缺乏独立对照实验\[基于文中逻辑的推断\]。
- #strong[适用条件]：仅在SLO严格的在线服务场景占优；需硬件支持进程内低开销空间划分（如GreenContext）\[作者明确陈述\]。
- #strong[局限]：多数消融实验仅用Llama-70B（\"其他模型结果相似\"未给量化数据）\[作者明确陈述\]；contention guard的画像更新运维成本文中未说明。
- #strong[审稿式风险检查]：
  - 贡献新意：GreenContext等底层技术非本文首创，本文贡献在于系统整合与调度设计，论文自身已区分\[作者明确陈述\]，当前证据未显示过度夸大风险。
  - 写作/可复现性：代码/数据集链接文中未说明，复现存在障碍，属当前证据暴露的风险。
  - 效果大小：主要提升数字来自论文自报的排除\"不稳定结果\"后的平均值，统计口径（是否多次运行、置信区间）文中未说明，构成一定风险。
  - 实验覆盖：MoE模型场景仅对比单一基线，覆盖面较窄，属当前证据暴露的风险\[作者明确陈述该限制\]。
  - 方法设计：worst-case估计依赖离线画像覆盖率，在线场景是否超出画像范围未见实验验证，当前证据未显示该风险已发生，但也未排除。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：SLO（服务等级目标）。#strong[第一性原理角色]：连接\"用户体验要求\"与\"系统资源分配\"两个基本量的约束条件。#strong[本文位置]：TTFT/TBT两条SLO是全文优化目标。
- #strong[术语]：KV缓存。#strong[第一性原理角色]：受显存容量约束，是connect\"历史token计算结果\"与\"当前生成token\"的因果媒介，避免重复计算。#strong[本文位置]：共享显存设计的核心对象。
- #strong[术语]：SM（流式多处理器）。#strong[第一性原理角色]：GPU计算资源的最小可分配单元，受总数量物理约束。#strong[本文位置]：调度器分配对象、GreenContext划分单位。
- #strong[术语]：GreenContext。#strong[第一性原理角色]：连接\"进程内多流\"与\"低开销SM划分\"两个量的机制。#strong[本文位置]：本文实现空间复用的底层技术基础。
- #strong[术语]：Goodput。#strong[第一性原理角色]：受SLO约束限定的吞吐量，是\"原始吞吐\"与\"SLO合规率\"两个量的耦合结果。#strong[本文位置]：全文核心评测指标。
- #strong[术语]：Token budget（token预算）。#strong[第一性原理角色]：受GPU算力约束与TBT SLO约束双重限制的资源分配参数。#strong[本文位置]：chunked-prefill两难的核心变量。
- #strong[术语]：MoE（混合专家模型）。#strong[第一性原理角色]：受\"总参数量\"与\"激活参数量\"分离约束的架构，降低计算成本。#strong[本文位置]：Qwen3-235B适用范围验证场景。

=== 12.2 学习路径
<122-学习路径>
+ 先理解token与KV缓存这两个基本对象------它们是LLM推理的最小计算/存储单元，是理解prefill/decode差异的前提。
+ 再理解SM与显存这两类GPU资源约束------任何调度设计都受限于\"有限SM数\"与\"有限显存容量\"这两条硬约束。
+ 然后理解prefill计算密集、decode显存带宽密集这一机制性差异------它解释了为何两阶段需要不同的资源分配策略。
+ 最后理解TTFT/TBT/Goodput这类可观测指标------它们是判断调度设计是否成功的最终标尺，理解了它们才能读懂论文的实验图表。
