#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[GPEmu: A GPU Emulator for Faster and Cheaper Prototyping and Evaluation of Deep Learning System Research]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Meng Wang, Gus Waldspurger, Naufal Ananda, Yuyang Huang, Kemas Wiharja, John Bent, Swaminathan Sundararaman, Vijay Chidambaram, Haryadi S. Gunawi]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[PVLDB · 2025]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU仿真] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[深度学习系统] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[分布式训练] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU调度] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[数据加载优化]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[DOI：https://doi.org/10.14778/3725688.3725716]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[代码：https://github.com/mengwanguc/gpenu]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

深度学习（DL）系统研究常常受限于GPU可用性有限和成本高昂的问题。本文提出GPEmu，一种无需使用真实GPU即可实现更快、更廉价地对深度学习系统研究进行原型设计和评估的GPU仿真器。GPEmu具备四项创新特性：时间仿真、内存仿真、分布式系统支持和共享支持。我们支持超过30种深度学习模型和6种GPU型号，是迄今为止规模最大的支持。我们通过成功复现九篇近期论文的主要实验结果，并轻松原型化三种新的微优化，展示了GPEmu的能力。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [GPEmu: A GPU Emulator for Faster and Cheaper Prototyping and Evaluation of Deep Learning System Research],
    [作者], [Meng Wang, Gus Waldspurger, Naufal Ananda, Yuyang Huang, Kemas Wiharja, John Bent, Swaminathan Sundararaman, Vijay Chidambaram, Haryadi S. Gunawi],
    [发表场所 / 年份], [PVLDB, 2025],
    [研究领域], [系统与深度学习],
    [关键词], [GPU仿真, 深度学习系统, 分布式训练, GPU调度, 数据加载优化],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：#link("https://doi.org/10.14778/3725688.3725716")
- 代码 / 数据集：#link("https://github.com/mengwanguc/gpenu")

#quote(block: true)[
#strong[标签（4 个）]：`GPU仿真` · `深度学习系统研究` · `Profile-and-Replay` · `分布式训练与调度`
]

GPEmu 用离线性能画像（profiling）加睡眠等待（sleep）的方式在纯 CPU 机器上\"伪造\"GPU 的计算、传输、预处理耗时与显存占用，从而让研究者无需真实 GPU 即可复现和原型化 GPU 之上层面（数据加载、调度、共享）的系统研究\*\*\[作者明确陈述\]#strong[；其复现了九篇已发表论文的实验模式，但精确误差量化和多数分布式场景下的\"真实 GPU vs 仿真\"三方对照较为有限]\[实验支持\]\*\*。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- OCR 覆盖论文正文第 1--14 页的文本，以及第 3、4、7、8、9、10 页共 6 组图片批次（每组 2 张，另有 3 张图片超出分析上限未做视觉分析）。
- 文中未出现任何编号公式（无\"Eq.X\"），指标定义多为自然语言描述，需在第 8.3 节中标注推导关系而非原文公式。
- 部分图表坐标刻度因图像分辨率受限无法精确读数，但正文已给出对应精确数字的场景不构成额外缺口；本报告严格区分论文事实与背景知识（背景知识仅用于术语解释）。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

深度学习系统研究------聚焦数据加载、预处理、调度等\"GPU 之上\"层面的问题------常因真实 GPU 稀缺且昂贵而受阻\*\*\[作者明确陈述\]#strong[。这一价值在于：Chameleon 研究云仅提供 4 台 V100 且需提前数周预约，CloudBank 每 6 个月仅 5000 美元预算、按 Synergy 论文配置仅 51 小时耗尽，商业云还存在高峰期数十小时不可用、扩容需数周等问题]\[作者明确陈述\]\*\*。

难点在于：研究者本想验证的是调度/加载算法的行为，却被迫先获取昂贵硬件才能做实验------类似于想研究高速公路收费站排队优化，却被迫先买一辆跑车。作者指出的可解决性前提是：对这类研究而言，重要的不是 GPU 计算结果的正确性，而是其\"性能表现\"（耗时、显存占用）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]，这构成全文成立的第一性原理假设。

#strong[本文的 story]：既有仿真工具只覆盖了\"性能足迹\"的一小部分（多数仅做计算时间），导致部分维度缺失时误差可达 20% 或更高\*\*\[作者明确陈述\]\*\*；GPEmu 用全维度 profile-and-replay 填补这一缺口，把可行性建立在\"耗时/显存分配模式高度重复、可预测\"这一经验观察上。

== 4. 旧方法为何不够
<4-旧方法为何不够>

#critique-card(
  [Silod \[83\]],
  [原本用便宜的 K80 集群模拟在昂贵 V100 上 profile 得到的计算时间，服务于 GPU 集群调度研究；其前提是仍需在真实 V100 上做一次 profile],
  [未摆脱硬件依赖，且仅支持 8 模型/1 GPU 型号/无批大小配置\*\*\[作者明确陈述\]#strong[。技术根源上，DNN 训练一个 batch 依次经过读样本→预处理→数据传输→前向→反向五步]\[作者明确陈述\]#strong[，仿真器若只覆盖部分步骤，遗漏部分会使总耗时系统性偏差，实测偏差可达 20% 或更多]\[作者明确陈述\]\*\*。],
  [GPEmu 用全离线 profile+sleep（完全不需真实 GPU）、扩展到 36 模型/6 GPU/256 批大小的时间仿真模块回应],
  [Table 1 的功能对照与 \#DL/\#GPU/\#BS 数值是对应检验证据。],
)

#critique-card(
  [MLPerf Storage \[23\]、DLCache \[49\]],
  [均为主机侧仿真器，仅做计算时间仿真；前提是"计算时间是唯一需要仿真的维度"],
  [缺数据传输、预处理、显存、锁页内存、分布式、共享，因此"无法评估 Synergy 和 Allox 论文"（因缺多任务调度功能 DJ）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]],
  [GPEmu 用显存仿真、分布式系统支持、GPU 共享支持模块回应],
  [Table 1 功能列对比 + Table 3 的联合判断是检验实验。],
)

#critique-card(
  [GPU 架构模拟器（GPGPU-Sim 等） \[35,53,51,72\]],
  [模拟 GPU 内部执行细节（显存、时钟周期），前提是聚焦单卡内部行为],
  [不支持端到端全栈实验（无法串联存储、CPU、主机内存、网络层）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]],
  [GPEmu 以全栈仿真定位回应],
  [文中未提供直接对比实验，无法从当前 OCR 内容确认具体检验图表。],
)

#critique-card(
  [算子级延迟建模（Once-for-all、ProxylessNAS 等） \[36,37\]],
  [作者承认其更具可扩展性],
  [可靠性不及暴力 profile 在捕捉"GPU 型号与模型组件间不可预测交互"上的表现\*\*\[作者明确陈述\]\*\*],
  [GPEmu 用全维度 profile-and-replay 画像与采样回放回应],
  [文中未给出两法误差对比实验，无法从当前 OCR 内容确认。],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见]\*\*\[作者明确陈述\]\*\*：对\"GPU 之上\"层系统研究而言，重要的是 GPU 的性能表现而非计算结果的正确性，这使统计画像+睡眠回放可以完全绕开真实 GPU 硬件。

其成立依赖三条经验前提，均为#strong[实现该洞见所需的支撑观察]而非洞见本身：(1) 同一（模型、GPU、batch size）配置下计算耗时高度一致、可重复，除最初 1-2 个 batch 外\*\*\[作者明确陈述\]#strong[#strong[\[实验支持\]#strong[（Figure 1a）；(2) 计算耗时与 batch size 的关系并非总是线性------计算密集模型（如 ResNet101）呈稳定线性，计算轻量模型（如 AlexNet）呈分段线性，需更密集采样]\[作者明确陈述\]]]\[实验支持\]#strong[（Figure 1b）；(3) 显存分配-释放模式在每 batch 内重复，且与 batch size 强线性相关、与 GPU 型号无关，可从少量 profile 外推]\[作者明确陈述\]\*\*\*\*\[实验支持\]\*\*（Figure 3）。

#strong[假设边界]\*\*\[作者明确陈述\]\*\*：不适用于需要评估准确率等依赖真实计算结果的场景，也不适用于依赖训练中动态数值（梯度、参数、embedding 热度）做决策的优化------这两条直接划定了核心洞见的适用边界，而非事后发现的局限。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入为模型类型、batch size、GPU 型号等 config；系统先离线 profile 各维度性能数据存入数据库，在线阶段用查表+sleep 替代真实 GPU 相关步骤，输出与真实 GPU 运行模式一致的仿真时延和显存占用\*\*\[作者明确陈述\]\*\*。

+ #strong[时间仿真]：动机是五步骤中任一步缺失仿真都致总耗时失真\*\*\[作者明确陈述\]#strong[。过程为离线 profile 计算/传输/预处理耗时（排除初始化异常），在线用 `sleep(T)` 替代，`emuForward(config)` 查表取 T，支持同步/异步两种模式]\[作者明确陈述\]#strong[。技术优势建立在耗时低方差可重复之上；对计算密集模型用线性外推节省 profile 成本，对轻量模型用密集采样覆盖非线性区段]\[作者明确陈述\]\*\*。
+ #strong[显存仿真]：动机是显存容量决定任务可行性，也是 GPU 共享仿真的基础\*\*\[作者明确陈述\]#strong[。区分计算峰值、模型持久化占用、预处理显存三类，前两者线性外推、预处理需 profile 到稳定后的最大值]\[作者明确陈述\]#strong[。锁页内存子模块用 `mlock()` 模拟 CUDA\"分配后不释放\"策略，避免主循环 GC 停顿，Figure 3c 显示未仿真时慢约 20%、仿真后与真实 GPU 接近]\[实验支持\]\*\*。
+ #strong[分布式系统支持]：动机是真实研究常涉及多 GPU/多节点/多任务调度\*\*\[作者明确陈述\]#strong[。DataParallel 按 GPU 拆分 batch 并单独 profile 通信开销；DDP 因梯度归约与反向重叠、精确算子级仿真复杂，改为 profile \"batch 级别\"总耗时并插入 `barrier()` 同步；多节点基于最多 4 节点数据复用，未精确建模网络通信成本，尤其大规模场景]\[作者明确陈述\]#strong[；多任务调度支持自定义调度器与 Kubernetes（emuGPU 资源类型+设备插件）]\[作者明确陈述\]\*\*。
+ #strong[GPU 共享仿真]：动机是 DL 任务常需分时共享 GPU\*\*\[作者明确陈述\]#strong[。单机场景由基于 RabbitMQ 的 sharing manager 依次处理仿真请求、显存超限则拒绝；Kubernetes 场景为每个 emuGPU 建多副本文件供多容器共享]\[作者明确陈述\]\*\*。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：时间仿真]
  #image("figure-groups/page-0003-f3c0d0bce81b.png", width: 100%)
  #emph[Figure 1: Compute time\'s pattern (\$2.1.1). The figures show that (a) compute time is consistent within the same setup, (b) compute time doesn\'t always linearly correlate with batch size.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：同一配置下前反向计算耗时呈阶跃跳变且低方差，轻量模型耗时随批大小呈分段线性。

- #strong[论证关系]：支撑时间仿真模块离线 profile 和睡眠回放机制，以及对轻量模型实施密集采样的必要性。

- #strong[适用范围]：覆盖 ResNet50 与 AlexNet 两模型在 V100/P100 GPU 上的计算耗时。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：时间仿真]
  #image("figure-groups/page-0003-ea2cf7ceefd7.png", width: 100%)
  #emph[Figure 2: (a) Amount of data transfer time (\\2.1.3).]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：轻量模型传输时间可达计算耗时的 20%，预处理耗时分布因操作类型不同呈现显著变异性。

- #strong[论证关系]：支撑时间仿真必须将传输与预处理独立建模，论证全维度耗时仿真的必要性。

- #strong[适用范围]：覆盖 ResNet50/AlexNet 模型及 FFCV/DALI 预处理操作。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 计算耗时低方差可重复→profile-and-replay 才能长期复用同一份画像数据，而不必每次重新实测\*\*\[基于文中逻辑的推断\]\*\*，前提是模型/GPU/batch size 组合保持稳定。
- 显存分配模式逐 batch 重复→少量样本外推即可覆盖未测配置\*\*\[基于文中逻辑的推断\]\*\*，条件是工作负载在少数 batch 内即\"收敛\"到稳定模式。
- 锁页内存模拟 CUDA 的\"不释放\"策略→避免主循环触发 Python GC 停顿→耗时更贴近真实 GPU\*\*\[作者明确陈述\]\*\*\*\*\[实验支持\]\*\*，此点有直接实验支撑而非纯推断。
- DDP 场景以 batch 级别整体耗时替代算子级重叠建模→在对梯度通信不敏感的评测中有效，但通信高度敏感场景的误差边界未知\*\*\[基于文中逻辑的推断\]\*\*。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果证据：GPEmu 复现的九篇论文实验模式是否与原论文/真实 GPU 一致（对应 Figure 4-12）。
- 机制证据：计算耗时/显存分配是否确实高度一致可重复（Figure 1、3a/3b）。
- 必要性证据：锁页内存仿真是否消除额外 20% 耗时（Figure 3c）。
- 适用范围证据：多节点通信仿真简化在何种场景下仍有效（文中未给出量化误差边界）。
- 单一性能表（如 Figure 4c）只能证明特定模型/配置下的模式一致，不能代表全部主张。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 复现对象：DataStall、tf.data service、FastFlow、FFCV、LADL、Synergy、Allox、Salus、Muri 九篇论文\*\*\[作者明确陈述\]\*\*。
- 硬件：涉及 V100、P100、RTX-6000 等 GPU 型号（不同案例各异）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；FFCV 案例为单节点 RTX-6000；LADL 为 4 节点集群、限速 3Gbps；Synergy 为 4 节点集群/每节点 24 CPU/100GB DRAM/8 仿真 GPU/40 任务；Salus 为单机 3 个 ResNet50 任务共享 1 块仿真 P100\*\*\[作者明确陈述\]\*\*。
- 重复次数、统计方式：文中未说明。
- 实现规模：Table 2a 显示实现共 3031 行代码\*\*\[作者明确陈述\]\*\*。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Fetch stall percentage，测量训练总时间中等待数据获取的占比，单位 %，越低越好。 #strong[定义与公式]：作者文字定义\"time spent waiting for data fetching divided by total training time\"；来源层级为#strong[推导关系（非原文公式）\*\*\*\*\[基于文中逻辑的推断\]]，分子为等待数据获取时间，分母为总训练时间。 #strong[实验用途]：复现 DataStall 论文的核心实验问题（Figure 4a）。 #strong[读数与边界]：AlexNet 因计算轻量而 fetch stall 占比最高，VGG11 因计算重而占比最低\*\*\[作者明确陈述\]\*\*；该指标不能证明绝对数值精度，仅证明跨来源排序模式一致。

- #strong[指标与方向]：训练速度（images/sec），越高越好。 #strong[定义与公式]：无可核验公式，仅报告结果数值。 #strong[实验用途]：Figure 4c 比较不同模型的 CPU/GPU 需求。 #strong[读数与边界]：AlexNet 需约 24 核方能饱和，ResNet50 仅需约 3 核\*\*\[作者明确陈述\]\*\*；无法确认该关系在其余模型上的普适性。

- #strong[指标与方向]：JCT（任务完成时间），越低越好。 #strong[定义与公式]：无可核验公式，仅提及\"average JCT\"与\"95th percentile JCT\"，具体统计口径文中未说明。 #strong[实验用途]：Synergy/Allox 复现实验（Figure 10）。 #strong[读数与边界]：Synergy 相对 Proportional 基线降低平均 JCT 22%、95 分位 25%；Allox 相对 DRFF 降低平均 JCT 42%#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；未说明置信区间或重复次数。

- #strong[指标与方向]：归一化 Epoch 时间，越低越好。 #strong[定义与公式]：作者明确说明\"y-axis is normalized to the maximum training time per configuration\"，为#strong[推导关系]，分母是同一配置下的最大训练时间。 #strong[实验用途]：FFCV 等数据加载对比实验（Figure 7）。 #strong[读数与边界]：FFCV 相对 ImageFolder 降低约 80%（文中数值）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；仅在该三种加载器/该 GPU 配置下成立。

- #strong[指标与方向]：加速比/Speedup，越高越好。 #strong[定义与公式]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]，未显式给出分子分母，仅从\"归一化训练时间对比\"上下文推断为基线耗时/优化后耗时。 #strong[实验用途]：CoorDL、LADL、Synergy、Allox 等复现实验的效果论证。 #strong[读数与边界]：CoorDL 在 65% 缓存、1 节点达 3x、2 节点达 6x 加速\*\*\[作者明确陈述\]\*\*；40% 缓存场景具体倍数文中未说明。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [Silod], [仍需真实 GPU；规模小（8模型/1GPU）], [时间仿真（全离线）], [Table 1 对照；跨其余型号未逐一验证],
    [MLPerf/DLCache], [仅计算时间仿真，无 DJ 功能], [显存/分布式/共享仿真], [Table 1+3；具体误差量级文中未说明],
    [GPU 架构模拟器], [不支持端到端全栈], [全栈仿真定位], [无对比实验，无法从当前 OCR 内容确认],
  )]
  , kind: table
  )

- #strong[说明]：比较结果仅说明本论文实验设置内谁表现更好，不能证明对方方法在所有场景失效。

#strong[主张 → 证据 → 边界]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据], [证据强度与边界],),
    table.hline(),
    [忽略部分仿真维度致误差 20%+], [Figure 3c（仅锁页内存子项）], [无全维度消融实验，文中未说明],
    [计算耗时同配置下高度一致], [Figure 1a（仅 ResNet50/V100）], [未覆盖其余 35 模型/6 GPU 组合],
    [GPEmu 复现结果与原论文/真实 GPU 吻合], [Figure 4-12 多组三方/两方对照], [多数分布式案例（Synergy、Allox、Salus、Muri）缺真实 GPU 独立对照],
    [三个微优化提升 I/O 性能], [Figure 13-15], [SFF/异步批读取仅在仿真环境评估，未与真实硬件对照],
  )]
  , kind: table
  )

- FFCV（Figure 7）是少数同时给出\"原论文/真实 GPU/GPEmu\"三方对照的案例，DALI 分组中原论文柱与真实GPU/仿真柱存在差距，成因文中未说明。
- Salus、Muri 的 GPEmu 结果仅与原论文数据对比，未见真实 GPU 独立对照曲线\*\*\[作者明确陈述\]\*\*。
- 多节点 DDP 通信仿真简化\"对梯度通信不敏感的评测有效\"，但敏感场景下失准的具体量级文中未说明。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0004-ae4593485538.png", width: 100%)
    #emph[Figure 3: Memory emulation (\$2.2). The figures show (a) the GPU memory consumption of propagation and (b) GPU-driven preprocessing, as well as (c) the impact of emulating pinned memory.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：显存仿真]
    - #strong[图组结论]：显存占用呈周期性重复分配模式；加入锁页内存仿真后耗时与真实 GPU 接近（329s vs 330s），未加入偏慢约 21%。

- #strong[论证关系]：验证显存外推假设，并作为锁页内存仿真消除 GC 停顿与额外耗时的消融证据。

- #strong[适用范围]：覆盖 PyTorch 环境下 AlexNet 模型的显存与锁页内存仿真。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0007-b7d5ecfeff81.png", width: 100%)
    #emph[Figure 4: Data stall analysis with GPEMU ( 3.1).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：DataStall 复现]
    - #strong[图组结论]：Fetch stall 占比、缓存比例及 CPU 核数对吞吐量的影响在三方对照中呈现跨来源一致的定性排序。

- #strong[论证关系]：证明 GPEmu 在不依赖真实 GPU 的情况下能可靠复现 DataStall 论文的整体实验模式。

- #strong[适用范围]：适用于特定模型与硬件配置下的 DataStall 定性趋势复现。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_114_408_581_570.jpg", width: 100%)
    #emph[Figure 6: FastFlow\'s \[73\] benefits with GPEMU ( 3.2).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：FastFlow 复现]
    - #strong[图组结论]：FastFlow 在各 CPU 配比下耗时均低于基线，GPEmu 仿真柱与真实 GPU 柱高度接近。

- #strong[论证关系]：支撑 GPEmu 在解耦预处理架构下评估分布式数据并行优化的保真度。

- #strong[适用范围]：覆盖 Transformer ASR 工作负载在不同 CPU 配比下的性能复现。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_112_183_536_350.jpg", width: 100%)
    #emph[Figure 5: TF-DS \[34\] training speedup with GPEMU (\$3.2).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：tf.data service 复现]
    - #strong[图组结论]：TF-DS 训练加速比随 worker 数增加先快速上升后趋于平缓，GPEmu 曲线与真实 GPU 高度吻合。

- #strong[论证关系]：证明时间仿真与分布式模块能准确捕捉预处理解耦场景下的吞吐量饱和拐点。

- #strong[适用范围]：适用于 GAN 模型在 CUB-200 数据集及分布式 worker 设置。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_138_623_552_758.jpg", width: 100%)
    #emph[Figure 7: FFCV\'s \[55\] benefits shown with GPEMU ( 3.3).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：FFCV 复现]
    - #strong[图组结论]：FFCV 相对默认加载器降低约 80% 训练耗时，GPEmu 柱与真实 GPU 柱在三种加载器下均高度一致。

- #strong[论证关系]：作为直接三方对照证据，强力支撑 GPEmu 仿真结果与真实 GPU 耗时一致的核心主张。

- #strong[适用范围]：适用于单节点 RTX-6000 环境下的数据加载器性能评估。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_171_375_526_494.jpg", width: 100%)
    #emph[Figure 9: LADL\'s \[80\] benefits shown with GPEMU ( 3.4).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：LADL 复现]
    - #strong[图组结论]：LADL 偏好本地采样策略的耗时优势随节点数增加而增大，4 节点时相对 Regular 优势最明显。

- #strong[论证关系]：证明 GPEmu 分布式模块能评估带宽受限条件下的本地缓存采样优化效果。

- #strong[适用范围]：适用于 4 节点限速 3Gbps 网络条件下的分布式缓存复现。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_646_177_1106_373.jpg", width: 100%)
    #emph[Figure 10: (a) Synergy \[60\] and (b) Allox\'s \[54\] JCT reduction with GPEMU.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：Synergy 与 Allox 复现]
    - #strong[图组结论]：Synergy 与 Allox 在 GPEmu 仿真下的 JCT 降低趋势与原论文数据高度接近。

- #strong[论证关系]：直接证明 GPEmu 具备多任务集群调度（DJ）仿真能力，填补旧仿真器的功能空白。

- #strong[适用范围]：适用于 4 节点集群多任务调度场景下的 JCT 优化复现。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_104_181_586_318.jpg", width: 100%)
    #emph[Figure 8: CoorDL\'s benefits with GPEMU (\$3.4).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：CoorDL 复现]
    - #strong[图组结论]：CoorDL 加速比随节点数增加而显著提升（65% 缓存下 2 节点达 6x），GPEmu 柱与原论文柱接近。

- #strong[论证关系]：证明分布式系统支持模块能有效复现分区缓存组合覆盖数据集带来的扩缩收益。

- #strong[适用范围]：适用于多节点分布式训练场景下的分区缓存效果评估。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0010-394b51fe6fd7.png", width: 100%)
    #emph[Figure 12: Muri\'s benefits shown using GPEMU (\$3.6).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：Muri 复现]
    - #strong[图组结论]：Muri-S 调度相比 SRTF 能更快清空任务队列并降低 normalized makespan，与原论文一致。

- #strong[论证关系]：证明 GPU 共享仿真模块能有效保留多资源瓶颈调度算法之间的相对优劣关系。

- #strong[适用范围]：适用于单机 10 个仿真训练任务的多资源调度评测。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_160_175_533_309.jpg", width: 100%)
    #emph[Figure 11: Salus\'s \[81\] GPU sharing with GPEMU (\$3.6).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：Salus 复现]
    - #strong[图组结论]：多任务共享 GPU 时吞吐量被按比例压低，任务结束后吞吐量呈阶梯式恢复。

- #strong[论证关系]：验证单机 GPU 共享仿真模块能准确再现细粒度时间片共享下的资源竞争与恢复模式。

- #strong[适用范围]：适用于单机 3 个 ResNet50 任务共享 P100 GPU 的场景。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1: Features and configurations supported by prior GPU emulators and GPEMU ( 2).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：旧方法为何不够]
  - #strong[图组结论]：GPEmu 支持全维度仿真（时间/显存/分布式/共享），覆盖 36 模型/6 GPU/256 批大小配置，全面优于此前仿真器。

- #strong[论证关系]：支撑本文对比旧方法限制的主张，证明 GPEmu 在功能扩展与配置覆盖上的完整性与优越性。

- #strong[适用范围]：适用于旧有 GPU 仿真器与 GPEmu 的功能及支持配置对比。
  #v(5pt)
  #image("table-groups/page-0002-2b434a50be4e.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2: Implementation efforts ( ).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法：从洞见到可执行系统]
  - #strong[图组结论]：GPEmu 系统实现共 3031 行代码，同时展示了复现既有论文及实现微优化的代码工作量。

- #strong[论证关系]：证明 GPEmu 系统实现的轻量性与可复现性，支撑从原型到可执行系统的工程可行性。

- #strong[适用范围]：适用于 GPEmu 自身及复现工作的代码量评估。
  #v(5pt)
  #image("table-groups/page-0006-a057b54d85fa.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3: GPEMU features for paper reproductions ( ).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标：证据是否支撑主张]
  - #strong[图组结论]：展示 GPEmu 各项功能特性在复现 9 篇已发表论文实验中的具体使用情况。

- #strong[论证关系]：证明 GPEmu 的多维仿真特性在复现多种复杂 DL 系统研究中的实操必要性与实用价值。

- #strong[适用范围]：适用于评估 GPEmu 功能与论文复现需求之间的对应映射。
  #v(5pt)
  #image("table-groups/page-0007-421eba19fafc.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：DL 系统研究因 GPU 稀缺昂贵而受阻，且部分研究只需 GPU 性能足迹而非计算结果
  - 旧方法限制：Silod 仍需真实 GPU；MLPerf/DLCache 仅仿真计算时间，缺 DJ 等功能；架构模拟器不支持端到端全栈
  - 核心洞见/假设：GPU 性能表现（非计算结果）可用统计画像+睡眠回放模拟，前提是耗时/显存分配模式高度重复可预测
    - 方法模块：时间仿真（计算/传输/预处理）
      - 可验证预测：仿真耗时应与真实 GPU 耗时模式一致
        - 指标与实验：Fetch stall percentage、训练速度（Figure 4）
          - 图表证据：Figure 4 三方对照
            - 结论与适用边界：模式一致，绝对数值有差异，未验证跨全部模型
    - 方法模块：显存仿真（含锁页内存）
      - 可验证预测：加入锁页内存仿真后耗时应接近真实 GPU
        - 指标与实验：Epoch time 对比（Figure 3c）
          - 图表证据：Figure 3c 三柱对照
            - 结论与适用边界：约 21% 偏差被消除，仅验证 AlexNet
    - 方法模块：分布式系统支持
      - 可验证预测：多 GPU/节点/集群调度场景下仿真效果应与原论文一致
        - 指标与实验：JCT、Speedup（Figure 5、9、10）
          - 图表证据：tf.data service、LADL、Synergy/Allox 复现图
            - 结论与适用边界：模式一致，通信高度敏感/超大规模场景未被当前证据直接验证
    - 方法模块：GPU 共享仿真
      - 可验证预测：分时共享下吞吐量/makespan 变化模式应与原论文一致
        - 指标与实验：Normalized Makespan、吞吐量曲线（Figure 11、12）
          - 图表证据：Muri、Salus 复现图
            - 结论与适用边界：模式一致，但缺真实 GPU 独立对照，数值精度未被当前证据直接验证

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：时间仿真、显存仿真（含锁页内存）、分布式系统支持、GPU 共享仿真四项，均有明确挑战定位与机制/实验支撑\*\*\[作者明确陈述\]\*\*。

#strong[证据充分的结论]：锁页内存仿真消除约 20% 额外耗时（AlexNet 场景，Figure 3c）；GPEmu 在九篇论文复现中呈现跨来源一致的模式（Figure 4-12）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。

#strong[尚属推断的意义]：多数分布式/共享场景（Synergy、Allox、Salus、Muri）的\"仿真与真实 GPU 数值吻合\"缺图内独立对照，其吻合性目前主要是文字断言而非图像证据\*\*\[基于文中逻辑的推断\]\*\*。

#strong[适用条件与局限]：面向 DL 训练（非推理）工作负载的\"GPU 之上\"系统研究；不适用于评估准确率或依赖训练动态数值决策的优化\*\*\[作者明确陈述\]#strong[；DDP 重叠通信、超 4 节点通信仿真、层级 profile、FSDP/模型并行、GPU 空间共享、LLM 支持均为未来工作]\[作者明确陈述\]\*\*。

#strong[审稿式风险检查]：

- 贡献新意：四模块组合的规模（36模型/6GPU/256批大小）有 Table 1 数值支持，当前证据未显示新意风险。
- 写作/可复现性：代码仓库已提供，但数据集划分、部分基线超参数文中未说明，存在轻微可复现性风险。
- 效果大小：多数效果量级（20%、22%、42% 等）有具体数字支撑，但全维度消融实验缺失，\"20%或更高\"这一整体必要性主张的量化边界未被专门验证。
- 实验覆盖：机制证据（Figure 1、3）仅覆盖 1-2 个模型-GPU 组合，未逐一验证 35 模型/6 GPU 组合下同等成立；此为当前证据显示的覆盖缺口。
- 方法设计：多节点通信仿真简化对通信高度敏感场景的误差边界未知，作者已自陈为未来工作，非隐藏风险。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：GPU 仿真器（emulator），不使用真实 GPU 硬件、用统计模型重现其时间/内存行为的软件系统。 #strong[第一性原理角色]：连接\"研究者需求（性能足迹数据）\"与\"硬件可得性（真实 GPU 稀缺）\"两个基本量，约束是仿真精度必须逼近真实硬件行为。 #strong[本文位置]：GPEmu 的整体定位\*\*\[作者明确陈述\]\*\*。

- #strong[术语]：Profile-and-replay（画像-回放），先离线记录真实运行的耗时/资源数据，再在线查表回放。 #strong[第一性原理角色]：受\"耗时低方差可重复\"这一经验约束支撑，是时间/显存仿真的基本机制。 #strong[本文位置]：时间与显存仿真模块的核心策略\*\*\[作者明确陈述\]\*\*。

- #strong[术语]：锁页内存（pinned memory），操作系统不会换出到磁盘的固定地址内存区域。 #strong[第一性原理角色]：受操作系统内存管理约束，连接\"CUDA 数据传输前的暂存需求\"与\"GC 停顿\"两个因果环节。 #strong[本文位置]：解释仿真时间偏差来源及其修复\*\*\[作者明确陈述\]\*\*。

- #strong[术语]：DataParallel/DDP，多 GPU 训练的两种并行方式。 #strong[第一性原理角色]：受\"梯度同步是否与计算重叠\"这一因果约束区分，DDP 重叠通信与计算提高效率。 #strong[本文位置]：分布式系统支持模块 profile 策略的设计依据\*\*\[作者明确陈述\]\*\*。

- #strong[术语]：Fetch stall（数据获取阻塞），训练中 GPU 等待数据获取的时间。 #strong[第一性原理角色]：连接\"数据管道吞吐\"与\"GPU 空闲时间\"两个基本量，受 I/O 带宽约束。 #strong[本文位置]：DataStall 复现实验的核心指标\*\*\[作者明确陈述\]\*\*。

- #strong[术语]：JCT（任务完成时间），单个调度任务从提交到完成的耗时。 #strong[第一性原理角色]：连接\"调度策略\"与\"资源竞争\"两个基本量，是调度算法优劣的直接观测量。 #strong[本文位置]：Synergy/Allox 复现实验指标\*\*\[作者明确陈述\]\*\*。

- #strong[术语]：GPU 共享/时间片共享，多任务轮流占用同一 GPU。 #strong[第一性原理角色]：受\"单 GPU 同一时刻仅能服务一个计算流\"这一物理约束，连接\"任务数\"与\"单任务吞吐量\"。 #strong[本文位置]：GPU 共享仿真模块与 Salus/Muri 复现实验\*\*\[作者明确陈述\]\*\*。

=== 12.2 学习路径
<122-学习路径>
+ #strong[DNN 训练的基本步骤]（读样本→预处理→传输→前向→反向）：理解为何仿真器必须覆盖多个环节才能不失真，这是全文批判旧方法的基础。
+ #strong[GPU 显存与计算资源约束]：理解为何\"性能表现\"（耗时、显存）而非计算结果是可仿真对象，是核心洞见成立的前提。
+ #strong[Profiling 与统计建模]：理解\"实测一次、多次复用\"为何可行，是所有仿真模块的共同机制。
+ #strong[分布式训练（DP/DDP）与集群调度]：理解多 GPU/多节点/多任务场景下仿真为何需要\"batch 级别\"简化，是理解方法局限的关键。
+ #strong[GPU 共享/时间片调度]：理解多任务竞争同一 GPU 时的吞吐量变化模式，是理解 Salus/Muri 复现实验的前提。
