#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(size: 9.4pt)
#set par(justify: true, leading: 0.72em, spacing: 0.72em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#show heading.where(level: 1): it => block(above: 1.4em, below: 0.9em)[
  #text(size: 17pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]
  #v(-6pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => block(above: 1.6em, below: 0.7em, inset: (x: 9pt, y: 5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))[#text(size: 12.5pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => block(above: 1.1em, below: 0.4em)[#text(size: 10.6pt, weight: "bold", fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => block(above: 0.9em, below: 0.3em)[#text(size: 9.8pt, weight: "bold", fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(size: 12pt, weight: "bold", tracking: 3pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(6pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(size: 22pt, weight: "bold")[GPEmu: A GPU Emulator for Faster and Cheaper Prototyping and Evaluation of Deep Learning System Research]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Meng Wang, Gus Waldspurger, Naufal Ananda, Yuyang Huang, Kemas Wiharja, John Bent, Swaminathan Sundararaman, Vijay Chidambaram, Haryadi S. Gunawi]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[PVLDB · 2025]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU仿真] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[深度学习系统] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[分布式训练] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU调度] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[数据加载优化]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[DOI：https://doi.org/10.14778/3725688.3725716]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[代码：https://github.com/mengwanguc/gpenu]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-26]
]
#pagebreak(weak: true)

#set page(numbering: "1")
#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

深度学习（DL）系统研究常常受限于GPU可用性有限和成本高昂的问题。本文提出GPEmu，一种无需使用真实GPU即可实现更快、更廉价地对深度学习系统研究进行原型设计和评估的GPU仿真器。GPEmu具备四项创新特性：时间仿真、内存仿真、分布式系统支持和共享支持。我们支持超过30种深度学习模型和6种GPU型号，是迄今为止规模最大的支持。我们通过成功复现九篇近期论文的主要实验结果，并轻松原型化三种新的微优化，展示了GPEmu的能力。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#align(center)[#table(
  columns: 2,
  align: (col, row) => (auto,auto,).at(col),
  inset: 6pt,
  [字段], [内容],
  [标题],
  [GPEmu: A GPU Emulator for Faster and Cheaper Prototyping and Evaluation of Deep Learning System Research],
  [作者],
  [Meng Wang, Gus Waldspurger, Naufal Ananda, Yuyang Huang, Kemas Wiharja, John Bent, Swaminathan Sundararaman, Vijay Chidambaram, Haryadi S. Gunawi],
  [发表场所 / 年份],
  [PVLDB, 2025],
  [研究领域],
  [系统与深度学习],
  [关键词],
  [GPU仿真, 深度学习系统, 分布式训练, GPU调度, 数据加载优化],
)
]

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：#link("https://doi.org/10.14778/3725688.3725716")
- 代码 / 数据集：#link("https://github.com/mengwanguc/gpenu")

#blockquote[
#strong[标签（4 个）]：`GPU仿真` · `深度学习系统研究` · `Profile-and-Replay` · `分布式训练与调度`
]

GPEmu 用离线性能画像（profiling）加睡眠等待（sleep）的方式在纯 CPU 机器上\"伪造\"GPU 的计算、传输、预处理耗时与显存占用，从而让研究者无需真实 GPU 即可复现和原型化 GPU 之上层面（数据加载、调度、共享）的系统研究\[作者明确陈述\]\[页码：1\]；其复现了九篇已发表论文的实验模式，但精确误差量化和多数分布式场景下的\"真实 GPU vs 仿真\"三方对照较为有限\[实验支持\]\[页码：6-10\]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- OCR 覆盖论文正文第 1–14 页的文本，以及第 3、4、7、8、9、10 页共 6 组图片批次（每组 2 张，另有 3 张图片超出分析上限未做视觉分析）\[页码：3-10\]。
- 文中未出现任何编号公式（无\"Eq.X\"），指标定义多为自然语言描述，需在第 8.3 节中标注推导关系而非原文公式。
- 部分图表坐标刻度因图像分辨率受限无法精确读数，但正文已给出对应精确数字的场景不构成额外缺口；本报告严格区分论文事实与背景知识（背景知识仅用于术语解释）。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

深度学习系统研究——聚焦数据加载、预处理、调度等\"GPU 之上\"层面的问题——常因真实 GPU 稀缺且昂贵而受阻\[作者明确陈述\]\[页码：1\]。这一价值在于：Chameleon 研究云仅提供 4 台 V100 且需提前数周预约，CloudBank 每 6 个月仅 5000 美元预算、按 Synergy 论文配置仅 51 小时耗尽，商业云还存在高峰期数十小时不可用、扩容需数周等问题\[作者明确陈述\]\[页码：1\]。

难点在于：研究者本想验证的是调度/加载算法的行为，却被迫先获取昂贵硬件才能做实验——类似于想研究高速公路收费站排队优化，却被迫先买一辆跑车。作者指出的可解决性前提是：对这类研究而言，重要的不是 GPU 计算结果的正确性，而是其\"性能表现\"（耗时、显存占用）\[作者明确陈述\]\[页码：1\]，这构成全文成立的第一性原理假设。

#strong[本文的 story]：既有仿真工具只覆盖了\"性能足迹\"的一小部分（多数仅做计算时间），导致部分维度缺失时误差可达 20% 或更高\[作者明确陈述\]\[页码：2\]；GPEmu 用全维度 profile-and-replay 填补这一缺口，把可行性建立在\"耗时/显存分配模式高度重复、可预测\"这一经验观察上。

== 4. 旧方法为何不够
<4-旧方法为何不够>

- #strong[Silod]\[83\]：原本用便宜的 K80 集群模拟在昂贵 V100 上 profile 得到的计算时间，服务于 GPU 集群调度研究；其前提是仍需在真实 V100 上做一次 profile，未摆脱硬件依赖，且仅支持 8 模型/1 GPU 型号/无批大小配置\[作者明确陈述\]\[页码：2\]。GPEmu 用全离线 profile+sleep（完全不需真实 GPU）、扩展到 36 模型/6 GPU/256 批大小的时间仿真模块回应，Table 1 的功能对照与 \#DL/\#GPU/\#BS 数值是对应检验证据。
- #strong[MLPerf Storage]\[23\]、#strong[DLCache]\[49\]：均为主机侧仿真器，仅做计算时间仿真；前提是\"计算时间是唯一需要仿真的维度\"，缺数据传输、预处理、显存、锁页内存、分布式、共享，因此\"无法评估 Synergy 和 Allox 论文\"（因缺多任务调度功能 DJ）\[作者明确陈述\]\[页码：7\]。GPEmu 用显存仿真、分布式系统支持、GPU 共享支持模块回应，Table 1 功能列对比 + Table 3 的联合判断是检验实验。
- #strong[GPU 架构模拟器]（GPGPU-Sim 等）\[35,53,51,72\]：模拟 GPU 内部执行细节（显存、时钟周期），前提是聚焦单卡内部行为；限制是不支持端到端全栈实验（无法串联存储、CPU、主机内存、网络层）\[作者明确陈述\]\[页码：14\]。GPEmu 以全栈仿真定位回应，但文中未提供直接对比实验，此对应关系为叙述性论证——#strong[无法从当前 OCR 内容确认]具体检验图表。
- #strong[算子级延迟建模]（Once-for-all、ProxylessNAS 等）\[36,37\]：作者承认其更具可扩展性，但认为可靠性不及暴力 profile 在捕捉\"GPU 型号与模型组件间不可预测交互\"上的表现\[作者明确陈述\]\[页码：14\]；文中未给出两法误差对比实验——#strong[无法从当前 OCR 内容确认]。

技术根源上，DNN 训练一个 batch 依次经过读样本→预处理→数据传输→前向→反向五步\[作者明确陈述\]\[页码：3\]，仿真器若只覆盖部分步骤，遗漏部分会使总耗时系统性偏差，实测偏差可达 20% 或更多\[作者明确陈述\]\[页码：2\]。

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见]\[作者明确陈述\]\[页码：1\]：对\"GPU 之上\"层系统研究而言，重要的是 GPU 的性能表现而非计算结果的正确性，这使统计画像+睡眠回放可以完全绕开真实 GPU 硬件。

其成立依赖三条经验前提，均为#strong[实现该洞见所需的支撑观察]而非洞见本身：(1) 同一（模型、GPU、batch size）配置下计算耗时高度一致、可重复，除最初 1-2 个 batch 外\[作者明确陈述\]\[实验支持\]\[页码：3\]（Figure 1a）；(2) 计算耗时与 batch size 的关系并非总是线性——计算密集模型（如 ResNet101）呈稳定线性，计算轻量模型（如 AlexNet）呈分段线性，需更密集采样\[作者明确陈述\]\[实验支持\]\[页码：3\]（Figure 1b）；(3) 显存分配-释放模式在每 batch 内重复，且与 batch size 强线性相关、与 GPU 型号无关，可从少量 profile 外推\[作者明确陈述\]\[实验支持\]\[页码：4\]。

#strong[假设边界]\[作者明确陈述\]\[页码：11\]：不适用于需要评估准确率等依赖真实计算结果的场景，也不适用于依赖训练中动态数值（梯度、参数、embedding 热度）做决策的优化——这两条直接划定了核心洞见的适用边界，而非事后发现的局限。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入为模型类型、batch size、GPU 型号等 config；系统先离线 profile 各维度性能数据存入数据库，在线阶段用查表+sleep 替代真实 GPU 相关步骤，输出与真实 GPU 运行模式一致的仿真时延和显存占用\[作者明确陈述\]\[页码：3-4\]。

+ #strong[时间仿真]：动机是五步骤中任一步缺失仿真都致总耗时失真\[作者明确陈述\]\[页码：3\]。过程为离线 profile 计算/传输/预处理耗时（排除初始化异常），在线用 `sleep(T)` 替代，`emuForward(config)` 查表取 T，支持同步/异步两种模式\[作者明确陈述\]\[页码：3\]。技术优势建立在耗时低方差可重复之上；对计算密集模型用线性外推节省 profile 成本，对轻量模型用密集采样覆盖非线性区段\[作者明确陈述\]\[页码：3\]。
+ #strong[显存仿真]：动机是显存容量决定任务可行性，也是 GPU 共享仿真的基础\[作者明确陈述\]\[页码：4\]。区分计算峰值、模型持久化占用、预处理显存三类，前两者线性外推、预处理需 profile 到稳定后的最大值\[作者明确陈述\]\[页码：4\]。锁页内存子模块用 `mlock()` 模拟 CUDA\"分配后不释放\"策略，避免主循环 GC 停顿，Figure 3c 显示未仿真时慢约 20%、仿真后与真实 GPU 接近\[实验支持\]\[页码：4\]。
+ #strong[分布式系统支持]：动机是真实研究常涉及多 GPU/多节点/多任务调度\[作者明确陈述\]\[页码：4\]。DataParallel 按 GPU 拆分 batch 并单独 profile 通信开销；DDP 因梯度归约与反向重叠、精确算子级仿真复杂，改为 profile \"batch 级别\"总耗时并插入 `barrier()` 同步；多节点基于最多 4 节点数据复用，未精确建模网络通信成本，尤其大规模场景\[作者明确陈述\]\[页码：5\]；多任务调度支持自定义调度器与 Kubernetes（emuGPU 资源类型+设备插件）\[作者明确陈述\]\[页码：5\]。
+ #strong[GPU 共享仿真]：动机是 DL 任务常需分时共享 GPU\[作者明确陈述\]\[页码：5\]。单机场景由基于 RabbitMQ 的 sharing manager 依次处理仿真请求、显存超限则拒绝；Kubernetes 场景为每个 emuGPU 建多副本文件供多容器共享\[作者明确陈述\]\[页码：5-6\]。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：时间仿真模块的profile-and-replay与外推策略设计依据]
  #image("figure-groups/page-0003-f3c0d0bce81b.png", width: 100%)
  #emph[Figure 1: Compute time\'s pattern (\$2.1.1). The figures show that (a) compute time is consistent within the same setup, (b) compute time doesn\'t always linearly correlate with batch size.] \
来源：OCR 第 3 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：同配置下前向/反向耗时CDF近阶跃、高度一致；AlexNet耗时随batch size呈分段线性而非直线

- #strong[论证关系]：支撑“耗时可一次profile多次复用”的核心洞见，并解释轻量模型需密集采样而非线性外推

- #strong[适用范围]：仅覆盖ResNet50-V100与AlexNet-P100两组配置，未覆盖其余35模型/6GPU组合
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：时间仿真为何需分建传输与预处理耗时]
  #image("figure-groups/page-0003-ea2cf7ceefd7.png", width: 100%)
  #emph[Figure 2: (a) Amount of data transfer time (\\2.1.3).] \
来源：OCR 第 3 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：ResNet50传输耗时可忽略，AlexNet达计算15-20%；预处理耗时FFCV稳定、DALI波动大

- #strong[论证关系]：支撑仿真须显式建模传输与预处理耗时，而非仅计算时间

- #strong[适用范围]：仅覆盖ResNet50/AlexNet与FFCV/DALI两种预处理操作
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：显存仿真与锁页内存子模块设计依据]
  #image("figure-groups/page-0004-ae4593485538.png", width: 100%)
  #emph[Figure 3: Memory emulation (\$2.2). The figures show (a) the GPU memory consumption of propagation and (b) GPU-driven preprocessing, as well as (c) the impact of emulating pinned memory.] \
来源：OCR 第 4 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：显存分配-释放呈周期性重复、可外推模式；加入锁页内存仿真后epoch时间(329s)接近真实GPU(330s)，未加入时(400s)偏慢约21%

- #strong[论证关系]：机制面支撑显存外推设计，消融面直接验证“锁页内存消除约20%额外耗时”这一必要性主张

- #strong[适用范围]：仅验证AlexNet/PyTorch环境，未证明其余模型同等有效
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 计算耗时低方差可重复→profile-and-replay 才能长期复用同一份画像数据，而不必每次重新实测\[基于文中逻辑的推断\]，前提是模型/GPU/batch size 组合保持稳定。
- 显存分配模式逐 batch 重复→少量样本外推即可覆盖未测配置\[基于文中逻辑的推断\]，条件是工作负载在少数 batch 内即\"收敛\"到稳定模式。
- 锁页内存模拟 CUDA 的\"不释放\"策略→避免主循环触发 Python GC 停顿→耗时更贴近真实 GPU\[作者明确陈述\]\[实验支持\]\[页码：4\]，此点有直接实验支撑而非纯推断。
- DDP 场景以 batch 级别整体耗时替代算子级重叠建模→在对梯度通信不敏感的评测中有效，但通信高度敏感场景的误差边界未知\[基于文中逻辑的推断\]\[页码：5\]。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果证据：GPEmu 复现的九篇论文实验模式是否与原论文/真实 GPU 一致（对应 Figure 4-12）。
- 机制证据：计算耗时/显存分配是否确实高度一致可重复（Figure 1、3a/3b）。
- 必要性证据：锁页内存仿真是否消除额外 20% 耗时（Figure 3c）。
- 适用范围证据：多节点通信仿真简化在何种场景下仍有效（文中未给出量化误差边界）。
- 单一性能表（如 Figure 4c）只能证明特定模型/配置下的模式一致，不能代表全部主张。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 复现对象：DataStall、tf.data service、FastFlow、FFCV、LADL、Synergy、Allox、Salus、Muri 九篇论文\[作者明确陈述\]\[页码：6-10\]。
- 硬件：涉及 V100、P100、RTX-6000 等 GPU 型号（不同案例各异）\[作者明确陈述\]\[页码：3,8\]；FFCV 案例为单节点 RTX-6000；LADL 为 4 节点集群、限速 3Gbps；Synergy 为 4 节点集群/每节点 24 CPU/100GB DRAM/8 仿真 GPU/40 任务；Salus 为单机 3 个 ResNet50 任务共享 1 块仿真 P100\[作者明确陈述\]\[页码：8-10\]。
- 重复次数、统计方式：文中未说明。
- 实现规模：Table 2a 显示实现共 3031 行代码\[作者明确陈述\]\[页码：6\]。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Fetch stall percentage，测量训练总时间中等待数据获取的占比，单位 %，越低越好。 #strong[定义与公式]：作者文字定义\"time spent waiting for data fetching divided by total training time\"；来源层级为#strong[推导关系（非原文公式）]\[基于文中逻辑的推断\]\[页码：6\]，分子为等待数据获取时间，分母为总训练时间。 #strong[实验用途]：复现 DataStall 论文的核心实验问题（Figure 4a）。 #strong[读数与边界]：AlexNet 因计算轻量而 fetch stall 占比最高，VGG11 因计算重而占比最低\[作者明确陈述\]\[页码：7\]；该指标不能证明绝对数值精度，仅证明跨来源排序模式一致。

- #strong[指标与方向]：训练速度（images/sec），越高越好。 #strong[定义与公式]：无可核验公式，仅报告结果数值\[页码：6\]。 #strong[实验用途]：Figure 4c 比较不同模型的 CPU/GPU 需求。 #strong[读数与边界]：AlexNet 需约 24 核方能饱和，ResNet50 仅需约 3 核\[作者明确陈述\]\[页码：7\]；无法确认该关系在其余模型上的普适性。

- #strong[指标与方向]：JCT（任务完成时间），越低越好。 #strong[定义与公式]：无可核验公式，仅提及\"average JCT\"与\"95th percentile JCT\"，具体统计口径文中未说明\[页码：9\]。 #strong[实验用途]：Synergy/Allox 复现实验（Figure 10）。 #strong[读数与边界]：Synergy 相对 Proportional 基线降低平均 JCT 22%、95 分位 25%；Allox 相对 DRFF 降低平均 JCT 42%\[作者明确陈述\]\[页码：9\]；未说明置信区间或重复次数。

- #strong[指标与方向]：归一化 Epoch 时间，越低越好。 #strong[定义与公式]：作者明确说明\"y-axis is normalized to the maximum training time per configuration\"，为#strong[推导关系]\[页码：8\]，分母是同一配置下的最大训练时间。 #strong[实验用途]：FFCV 等数据加载对比实验（Figure 7）。 #strong[读数与边界]：FFCV 相对 ImageFolder 降低约 80%（文中数值）\[作者明确陈述\]\[页码：8\]；仅在该三种加载器/该 GPU 配置下成立。

- #strong[指标与方向]：加速比/Speedup，越高越好。 #strong[定义与公式]：#strong[\[基于文中逻辑的推断\]]，未显式给出分子分母，仅从\"归一化训练时间对比\"上下文推断为基线耗时/优化后耗时\[页码：8-9\]。 #strong[实验用途]：CoorDL、LADL、Synergy、Allox 等复现实验的效果论证。 #strong[读数与边界]：CoorDL 在 65% 缓存、1 节点达 3x、2 节点达 6x 加速\[作者明确陈述\]\[页码：8\]；40% 缓存场景具体倍数文中未说明。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#align(center)[#table(
  columns: 4,
  align: (col, row) => (auto,auto,auto,auto,).at(col),
  inset: 6pt,
  [比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],
  [Silod],
  [仍需真实 GPU；规模小（8模型/1GPU）],
  [时间仿真（全离线）],
  [Table 1 对照；跨其余型号未逐一验证],
  [MLPerf/DLCache],
  [仅计算时间仿真，无 DJ 功能],
  [显存/分布式/共享仿真],
  [Table 1+3；具体误差量级文中未说明],
  [GPU 架构模拟器],
  [不支持端到端全栈],
  [全栈仿真定位],
  [无对比实验，无法从当前 OCR 内容确认],
)
]

- #strong[说明]：比较结果仅说明本论文实验设置内谁表现更好，不能证明对方方法在所有场景失效。

#strong[主张 → 证据 → 边界]

#align(center)[#table(
  columns: 3,
  align: (col, row) => (auto,auto,auto,).at(col),
  inset: 6pt,
  [主张], [直接证据], [证据强度与边界],
  [忽略部分仿真维度致误差 20%+],
  [Figure 3c（仅锁页内存子项）],
  [无全维度消融实验，文中未说明],
  [计算耗时同配置下高度一致],
  [Figure 1a（仅 ResNet50/V100）],
  [未覆盖其余 35 模型/6 GPU 组合],
  [GPEmu 复现结果与原论文/真实 GPU 吻合],
  [Figure 4-12 多组三方/两方对照],
  [多数分布式案例（Synergy、Allox、Salus、Muri）缺真实 GPU 独立对照],
  [三个微优化提升 I/O 性能],
  [Figure 13-15],
  [SFF/异步批读取仅在仿真环境评估，未与真实硬件对照],
)
]

- FFCV（Figure 7）是少数同时给出\"原论文/真实 GPU/GPEmu\"三方对照的案例，DALI 分组中原论文柱与真实GPU/仿真柱存在差距，成因文中未说明\[页码：8\]。
- Salus、Muri 的 GPEmu 结果仅与原论文数据对比，未见真实 GPU 独立对照曲线\[作者明确陈述\]\[页码：9-10\]。
- 多节点 DDP 通信仿真简化\"对梯度通信不敏感的评测有效\"，但敏感场景下失准的具体量级文中未说明\[页码：5\]。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1: Features and configurations supported by prior GPU emulators and GPEMU ( 2).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第4节：Silod/MLPerf/DLCache/架构模拟器的功能局限对比]
  - #strong[图组结论]：GPEmu是唯一同时支持TC/TT/TP/MC/MP/DG/DN/DJ/SS全部特征的仿真器，且配置规模(36模型/6GPU/256批大小)远超Silod(8模型/1GPU)

- #strong[论证关系]：为“旧方法功能残缺、GPEmu填补全维度空白”提供逐项功能核验证据

- #strong[适用范围]：仅证明功能清单覆盖广度，不代表各功能仿真精度
  #v(5pt)
  #image("table-groups/page-0002-2b434a50be4e.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2: Implementation efforts ( ).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：GPEmu实现规模与九篇论文复现工作量]
  - #strong[图组结论]：GPEmu核心实现共3031行代码；右表显示各论文复现与微优化的代码量均属轻量级增量

- #strong[论证关系]：为“GPEmu工程可行、复现成本低”提供规模量化支撑

- #strong[适用范围]：仅反映代码行数规模，不代表实现难度或复现精度
  #v(5pt)
  #image("table-groups/page-0006-a057b54d85fa.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0007-b7d5ecfeff81.png", width: 100%)
    #emph[Figure 4: Data stall analysis with GPEMU ( 3.1).] \
来源：OCR 第 7 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Fetch stall占比、缓存比例与CPU核数三项指标复现]
    - #strong[图组结论]：fetch stall占比、缓存-耗时关系、CPU核数-吞吐关系三方面均呈跨来源(原论文/真实GPU/GPEmu)一致排序与形态

- #strong[论证关系]：验证策略是模式一致而非数值精确复制，支撑“GPEmu复现结果模式与原论文/真实GPU一致”

- #strong[适用范围]：仅证明定性趋势可靠，不能单独证明绝对数值精度
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3: GPEMU features for paper reproductions ( ).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第4节：MLPerf/DLCache因缺DJ等功能无法评估Synergy/Allox论文]
  - #strong[图组结论]：GPEmu在九篇论文复现所需特征上均标记支持，与Table1功能列表一致对应

- #strong[论证关系]：直接反驳旧仿真器“因功能缺失无法评估”的局限，证明功能覆盖是复现可行的前提

- #strong[适用范围]：仅证明功能存在，不代表每项复现的数值保真度
  #v(5pt)
  #image("table-groups/page-0007-421eba19fafc.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_112_183_536_350.jpg", width: 100%)
    #emph[Figure 5: TF-DS \[34\] training speedup with GPEMU (\$3.2).] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：tf.data service加速比随worker数变化的复现]
    - #strong[图组结论]：三子图Speedup曲线均呈“快速上升后饱和”模式，GPU与GPEmu饱和值(约16-17x)高度接近，原论文因匿名化配置不同(约12-13x)

- #strong[论证关系]：支撑分布式支持模块捕捉饱和拐点的准确性，验证仿真与真实GPU吻合

- #strong[适用范围]：仅覆盖GAN模型/CUB-200数据集/8×V100配置，饱和点具体worker数无法逐点核实
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_114_408_581_570.jpg", width: 100%)
    #emph[Figure 6: FastFlow\'s \[73\] benefits with GPEMU ( 3.2).] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：FastFlow预处理解耦相对TF-NO/TF-DS的收益复现]
    - #strong[图组结论]：TF+FF柱在各CPU配比下均最低；GPU与GPEmu面板模式高度相似，原论文因模型匿名化采用不同CPU配比

- #strong[论证关系]：支撑“FastFlow持续优于基线”效果主张及时间仿真/分布式模块在解耦场景下的准确性

- #strong[适用范围]：仅覆盖Transformer ASR工作负载，未证明其余35模型配置下同等准确
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_138_623_552_758.jpg", width: 100%)
    #emph[Figure 7: FFCV\'s \[55\] benefits shown with GPEMU ( 3.3).] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：FFCV相对ImageFolder的加载优化效果与仿真精度]
    - #strong[图组结论]：FFCV分组三柱均为最低且彼此接近；GPEmu柱与真实GPU柱在三种加载器下均高度接近

- #strong[论证关系]：是少数直接给出真实GPU独立对照柱的案例，直接支撑“GPEmu结果与真实GPU一致”核心假设

- #strong[适用范围]：仅证明该模型/数据集/RTX-6000配置下吻合，DALI组差距成因文中未说明
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_104_181_586_318.jpg", width: 100%)
    #emph[Figure 8: CoorDL\'s benefits with GPEMU (\$3.4).] \
来源：OCR 第 9 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：CoorDL分区缓存加速随节点数扩展的复现]
    - #strong[图组结论]：65%缓存下1节点3x、2节点6x加速；CoorDL\_GPEmu柱与CoorDL\_Paper柱高度接近且随节点数上升

- #strong[论证关系]：支撑分布式缓存组合覆盖数据集的效果主张及仿真保真度

- #strong[适用范围]：40%缓存场景各节点数具体倍数无法从当前OCR内容确认
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_171_375_526_494.jpg", width: 100%)
    #emph[Figure 9: LADL\'s \[80\] benefits shown with GPEMU ( 3.4).] \
来源：OCR 第 9 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：LADL偏好本地缓存在带宽受限场景下的效果]
    - #strong[图组结论]：4节点时LADL相对Regular耗时优势最大，节点数越多差距越扩大

- #strong[论证关系]：支撑分布式模块可评估缓存优化，但图内无真实GPU或原论文对照柱，吻合性仅由文字断言支撑

- #strong[适用范围]：仅复现到4节点规模，原论文用16-128节点展示可扩展性，规模缩减为作者自陈
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_646_177_1106_373.jpg", width: 100%)
    #emph[Figure 10: (a) Synergy \[60\] and (b) Allox\'s \[54\] JCT reduction with GPEMU.] \
来源：OCR 第 9 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Synergy/Allox调度算法降低JCT的复现]
    - #strong[图组结论]：Synergy曲线与Allox柱状图均显示GPEmu复现值与原论文高度接近，调度降低JCT方向一致

- #strong[论证关系]：直接反驳MLPerf/DLCache因缺DJ功能无法评估此类论文的局限

- #strong[适用范围]：仅4节点/40任务规模，未证明通信高度敏感或超大规模集群下的保真度
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_160_175_533_309.jpg", width: 100%)
    #emph[Figure 11: Salus\'s \[81\] GPU sharing with GPEMU (\$3.6).] \
来源：OCR 第 10 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：GPU时间片共享下吞吐量变化模式复现]
    - #strong[图组结论]：三任务吞吐量呈“共享期间被压低、任务退出后逐级恢复”的阶梯模式

- #strong[论证关系]：支撑GPU共享仿真模块复现时间片调度定性模式，但缺真实GPU独立对照曲线

- #strong[适用范围]：仅证明模式一致性，不能作为数值吻合的直接证据
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0010-394b51fe6fd7.png", width: 100%)
    #emph[Figure 12: Muri\'s benefits shown using GPEMU (\$3.6).] \
来源：OCR 第 10 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：多资源调度算法对队列长度与makespan影响的复现]
    - #strong[图组结论]：Muri-S比SRTF更快清空队列；两策略下Paper柱与GPEmu柱高度接近

- #strong[论证关系]：支撑GPU共享仿真模块保留调度算法相对优劣关系，但未附真实GPU独立对照柱

- #strong[适用范围]：仅验证模式一致性，不能证明数值精度与真实GPU完全吻合
  ],
)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：DL 系统研究因 GPU 稀缺昂贵而受阻，且部分研究只需 GPU 性能足迹而非计算结果
  - 旧方法限制：Silod 仍需真实 GPU；MLPerf/DLCache 仅仿真计算时间，缺 DJ 等功能；架构模拟器不支持端到端全栈
  - 核心洞见/假设：GPU 性能表现（非计算结果）可用统计画像+睡眠回放模拟，前提是耗时/显存分配模式高度重复可预测
    - 方法模块：时间仿真（计算/传输/预处理）
      - 可验证预测：仿真耗时应与真实 GPU 耗时模式一致
        - 指标与实验：Fetch stall percentage、训练速度（Figure 4）
          - 图表证据：Figure 4 三方对照
            - 结论与适用边界：模式一致，绝对数值有差异，未验证跨全部模型
    - 方法模块：显存仿真（含锁页内存）
      - 可验证预测：加入锁页内存仿真后耗时应接近真实 GPU
        - 指标与实验：Epoch time 对比（Figure 3c）
          - 图表证据：Figure 3c 三柱对照
            - 结论与适用边界：约 21% 偏差被消除，仅验证 AlexNet
    - 方法模块：分布式系统支持
      - 可验证预测：多 GPU/节点/集群调度场景下仿真效果应与原论文一致
        - 指标与实验：JCT、Speedup（Figure 5、9、10）
          - 图表证据：tf.data service、LADL、Synergy/Allox 复现图
            - 结论与适用边界：模式一致，通信高度敏感/超大规模场景未被当前证据直接验证
    - 方法模块：GPU 共享仿真
      - 可验证预测：分时共享下吞吐量/makespan 变化模式应与原论文一致
        - 指标与实验：Normalized Makespan、吞吐量曲线（Figure 11、12）
          - 图表证据：Muri、Salus 复现图
            - 结论与适用边界：模式一致，但缺真实 GPU 独立对照，数值精度未被当前证据直接验证

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：时间仿真、显存仿真（含锁页内存）、分布式系统支持、GPU 共享仿真四项，均有明确挑战定位与机制/实验支撑\[作者明确陈述\]\[页码：3-6\]。

#strong[证据充分的结论]：锁页内存仿真消除约 20% 额外耗时（AlexNet 场景，Figure 3c）；GPEmu 在九篇论文复现中呈现跨来源一致的模式（Figure 4-12）\[实验支持\]。

#strong[尚属推断的意义]：多数分布式/共享场景（Synergy、Allox、Salus、Muri）的\"仿真与真实 GPU 数值吻合\"缺图内独立对照，其吻合性目前主要是文字断言而非图像证据\[基于文中逻辑的推断\]。

#strong[适用条件与局限]：面向 DL 训练（非推理）工作负载的\"GPU 之上\"系统研究；不适用于评估准确率或依赖训练动态数值决策的优化\[作者明确陈述\]\[页码：11\]；DDP 重叠通信、超 4 节点通信仿真、层级 profile、FSDP/模型并行、GPU 空间共享、LLM 支持均为未来工作\[作者明确陈述\]\[页码：11\]。

#strong[审稿式风险检查]：

- 贡献新意：四模块组合的规模（36模型/6GPU/256批大小）有 Table 1 数值支持，当前证据未显示新意风险。
- 写作/可复现性：代码仓库已提供，但数据集划分、部分基线超参数文中未说明，存在轻微可复现性风险。
- 效果大小：多数效果量级（20%、22%、42% 等）有具体数字支撑，但全维度消融实验缺失，\"20%或更高\"这一整体必要性主张的量化边界未被专门验证。
- 实验覆盖：机制证据（Figure 1、3）仅覆盖 1-2 个模型-GPU 组合，未逐一验证 35 模型/6 GPU 组合下同等成立；此为当前证据显示的覆盖缺口。
- 方法设计：多节点通信仿真简化对通信高度敏感场景的误差边界未知，作者已自陈为未来工作，非隐藏风险。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：GPU 仿真器（emulator），不使用真实 GPU 硬件、用统计模型重现其时间/内存行为的软件系统。 #strong[第一性原理角色]：连接\"研究者需求（性能足迹数据）\"与\"硬件可得性（真实 GPU 稀缺）\"两个基本量，约束是仿真精度必须逼近真实硬件行为。 #strong[本文位置]：GPEmu 的整体定位\[作者明确陈述\]\[页码：1\]。

- #strong[术语]：Profile-and-replay（画像-回放），先离线记录真实运行的耗时/资源数据，再在线查表回放。 #strong[第一性原理角色]：受\"耗时低方差可重复\"这一经验约束支撑，是时间/显存仿真的基本机制。 #strong[本文位置]：时间与显存仿真模块的核心策略\[作者明确陈述\]\[页码：3-4\]。

- #strong[术语]：锁页内存（pinned memory），操作系统不会换出到磁盘的固定地址内存区域。 #strong[第一性原理角色]：受操作系统内存管理约束，连接\"CUDA 数据传输前的暂存需求\"与\"GC 停顿\"两个因果环节。 #strong[本文位置]：解释仿真时间偏差来源及其修复\[作者明确陈述\]\[页码：4\]。

- #strong[术语]：DataParallel/DDP，多 GPU 训练的两种并行方式。 #strong[第一性原理角色]：受\"梯度同步是否与计算重叠\"这一因果约束区分，DDP 重叠通信与计算提高效率。 #strong[本文位置]：分布式系统支持模块 profile 策略的设计依据\[作者明确陈述\]\[页码：4-5\]。

- #strong[术语]：Fetch stall（数据获取阻塞），训练中 GPU 等待数据获取的时间。 #strong[第一性原理角色]：连接\"数据管道吞吐\"与\"GPU 空闲时间\"两个基本量，受 I/O 带宽约束。 #strong[本文位置]：DataStall 复现实验的核心指标\[作者明确陈述\]\[页码：6-7\]。

- #strong[术语]：JCT（任务完成时间），单个调度任务从提交到完成的耗时。 #strong[第一性原理角色]：连接\"调度策略\"与\"资源竞争\"两个基本量，是调度算法优劣的直接观测量。 #strong[本文位置]：Synergy/Allox 复现实验指标\[作者明确陈述\]\[页码：9\]。

- #strong[术语]：GPU 共享/时间片共享，多任务轮流占用同一 GPU。 #strong[第一性原理角色]：受\"单 GPU 同一时刻仅能服务一个计算流\"这一物理约束，连接\"任务数\"与\"单任务吞吐量\"。 #strong[本文位置]：GPU 共享仿真模块与 Salus/Muri 复现实验\[作者明确陈述\]\[页码：5-6,9-10\]。

=== 12.2 学习路径
<122-学习路径>
+ #strong[DNN 训练的基本步骤]（读样本→预处理→传输→前向→反向）：理解为何仿真器必须覆盖多个环节才能不失真，这是全文批判旧方法的基础。
+ #strong[GPU 显存与计算资源约束]：理解为何\"性能表现\"（耗时、显存）而非计算结果是可仿真对象，是核心洞见成立的前提。
+ #strong[Profiling 与统计建模]：理解\"实测一次、多次复用\"为何可行，是所有仿真模块的共同机制。
+ #strong[分布式训练（DP/DDP）与集群调度]：理解多 GPU/多节点/多任务场景下仿真为何需要\"batch 级别\"简化，是理解方法局限的关键。
+ #strong[GPU 共享/时间片调度]：理解多任务竞争同一 GPU 时的吞吐量变化模式，是理解 Salus/Muri 复现实验的前提。
