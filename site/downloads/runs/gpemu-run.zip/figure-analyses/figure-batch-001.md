# 图片批次 1

## 图片 1：Figure 2: (a) Amount of data transfer time (\2.1.3).

![Figure 2: (a) Amount of data transfer time (\2.1.3).](../figure-groups/page-0003-ea2cf7ceefd7.png)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：该图对应正文 §2.1.2（数据传输时间）与 §2.1.3（预处理时间）,证据类型为**机制**证据,用于说明"时间仿真"模块为何必须把数据传输时间和预处理时间当作独立于计算时间的建模对象,而不能像 MLPerf/DLCache 等旧仿真器那样只做计算时间仿真——这直接呼应"旧方法的限制"中"MLPerf/DLCache 仅做计算时间仿真"的批判,以及"核心洞见"中"若仿真器只覆盖部分步骤会导致总耗时系统性偏差"的第一性原理链条。`[正文支持]`
   - **图表角色**：方法流水线（论证时间仿真子模块的设计依据：为什么要分别对传输时间做"随模型而变"的建模、为什么预处理时间要用"采样分布"而非固定均值）。
   - **上文呼应**：第 3 页 §2.1.2 数据传输时间与 §2.1.3 预处理时间；对应"旧方法的限制"中对 MLPerf/DLCache 缺数据传输与预处理仿真的批判。

2. **图像类型与布局**：两个并列子图（面板），均为二维图表，非表格。(a) 为分组柱状图（左：ResNet50，右：Alexnet；每组两根柱，蓝色交叉纹为 Compute，红色斜纹为 Transfer）；(b) 为累计分布函数（CDF）折线图，含两条曲线（Norm-GPU-FFCV 橙色实线、Decode-Mix-DALI 紫色虚线）。

3. **如何阅读**：(a) y 轴为"Time (normalized)"（0–1.0），x 轴按模型分组（ResNet50、Alexnet），每组内比较 Compute 柱与 Transfer 柱的相对高度；(b) x 轴为"per-batch prep. time (ms)"（0–约30ms，具体上限因图片裁剪未见完整刻度标注但可读出趋势），y 轴为 CDF（0–1），比较两条曲线达到 CDF=1 所需的时间范围及曲线陡峭程度。

4. **直接可见的结论**：(a) ResNet50 组中 Compute 柱接近 1.0 而 Transfer 柱几乎贴近 0；Alexnet 组中 Compute 柱同样归一化到约 1.0，但 Transfer 柱明显可见，高度约为 Compute 柱的 15%–20% 左右。(b) Norm-GPU-FFCV 曲线在很小的 x 值处（约 2–3ms 附近）就陡峭上升至 CDF=1，形态接近阶跃；Decode-Mix-DALI 曲线则从 x=0 起缓慢爬升，跨越更宽的 x 范围（延伸到约 25–30ms 附近）才接近 CDF=1，呈现明显更宽的分布/更大变异性。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：(a) 直接支持正文机制主张——"对 ResNet50 这类计算密集模型,传输时间相对可忽略;对 Alexnet 这类计算轻量模型,传输时间可达 GPU 计算时间的 20%左右"[正文支持],从而论证时间仿真模块必须显式建模数据传输时间(而非像 MLPerf/DLCache 那样忽略),否则对轻量模型会产生不可忽视的误差,这直接支撑"忽略部分仿真维度会导致仿真误差 20%或更高"这一整体必要性主张的一个具体来源。(b) 直接支持"预处理时间高度可变"的机制主张——Normalization(FFCV)因计算复杂度稳定而变异性小,Decoding(DALI)因文件格式/压缩质量/图像复杂度不同而变异性大[正文支持],从而论证 GPEmu 为何要"从分布中采样"而非用固定均值来仿真 GPU 侧预处理时间(§2.1.3 方法设计的直接依据)。该图不能证明的是:此处两条曲线所代表的具体模型/数据集配置之外的其他模型是否也呈现同样的变异性差异,以及具体的 20%数字是否在所有 batch size 下都成立。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 ResNet50/Alexnet 两个模型(面板 a)与 FFCV 的 normalization、DALI 的 decoding 两种预处理操作(面板 b)这一具体设置,正文未说明所用 GPU 型号与 batch size,故不外推到未展示的模型/GPU/操作类型。无额外证据缺口。

---

## 图片 2：Figure 1: Compute time's pattern (\$2.1.1). The figures show that (a) compute time is consistent within the same setup, (b) compute time doesn't always linearly correlate with batch size.

![Figure 1: Compute time's pattern (\$2.1.1). The figures show that (a) compute time is consistent within the same setup, (b) compute time doesn't always linearly correlate with batch size.](../figure-groups/page-0003-f3c0d0bce81b.png)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：该图对应正文 §2.1.1（计算/传播时间预测),证据类型为**机制**证据,用于验证支撑"核心洞见"成立的关键经验前提——即 GPU 计算时间在同一（模型,GPU,batch size)配置下高度一致可重复,从而使"离线 profile 一次、多次复用"的设计可行;同时验证"计算耗时与 batch size 并非总是线性关系"这一细化机制,解释为何需要对计算轻量模型做更密集的多点 profile 而非仅两点线性外推。`[正文支持]`
   - **图表角色**：方法流水线（为时间仿真模块中"计算时间预测"子设计——profile-and-replay 策略与线性/分段线性外推策略——提供直接机制依据）。
   - **上文呼应**：第 3 页 §2.1.1 计算/传播时间；对应"核心洞见与假设"中"计算时间高度一致可重复"及"非线性关系的洞察"两条论证。

2. **图像类型与布局**：两个并列子图，均为二维曲线图。(a) 为累计分布函数（CDF）折线图，含两条曲线（Fwd 绿色实线、Bwd 蓝色虚线）；(b) 为散点连线折线图，单条蓝色曲线，呈台阶状递增趋势。

3. **如何阅读**：(a) x 轴为"Batch compute time (ms)"（0–约250+ms），y 轴为 CDF（0–1），比较 Fwd（前向）与 Bwd（反向）两条曲线各自跳变发生的位置及陡峭程度；(b) x 轴为"Batch size"（0–128），y 轴为"Compute time (ms)"（约10–55+ms），沿 x 轴从左到右观察曲线斜率变化是否恒定。

4. **直接可见的结论**：(a) Fwd 曲线在 x≈110–120ms 附近几乎垂直陡升至 CDF=1，呈近似阶跃形态；Bwd 曲线在更靠右的 x≈240–250ms 附近同样近似垂直陡升至 CDF=1；两条曲线在各自跳变点之前均贴近 CDF=0，跳变区间都非常窄。(b) 曲线整体从左下向右上单调递增，但并非一条平滑直线，而是由多段短促的"台阶/平台+跳升"交替构成的折线，斜率在不同 batch size 区间有可见差异（呈"分段线性"外观，而非单一斜率直线）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：(a) 直接支撑机制主张——"ResNet50 在 V100 上以 batch size 128 训练 1000 个 batch 时,前向/反向耗时高度一致、几乎不重复初始化异常值之外的离散"[正文支持:"training ResNet50 on a NVIDIA V100 GPU for 1000 batches at batch size 128 exhibits consistent forward and backward durations, except for the first 1-2 batches"],CDF 曲线的近阶跃形态即是"低方差、高度可重复"的可视化证据,这为整篇论文"用一次 profile 结果多次复用(sleep 回放)"的核心设计原则提供了必要性支撑。(b) 直接支撑"计算轻量模型（如 AlexNet）呈分段线性而非简单线性"的机制主张[正文支持]，解释了为何 GPEmu 对"batch size 64 时计算耗时低于 0.2 秒"的轻量模型要用更密集的多点 profile，而非仅用两点做线性外推——该图是这一方法分支设计（线性外推 vs. 密集采样）的直接证据来源。该图不能证明的是：该一致性/分段线性模式是否在其余 35 个模型或其余 5 种 GPU 型号上同样成立（论文主张地图中已指出这是尚未逐一展示的证据缺口）。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 ResNet50-on-V100（batch size 128，1000 batches，面板 a）与 AlexNet-on-P100（batch size 0–128，面板 b）这两个具体配置。除锁页内存等专门场景外，正文未说明该模式在其余模型/GPU 组合下是否同样成立，此为主张地图中已标注的既有缺口，不在本图重复展开为新缺口。无额外证据缺口。
