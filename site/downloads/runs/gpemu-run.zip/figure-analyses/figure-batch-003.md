# 图片批次 3

## 图片 1：Figure 6: FastFlow's [73] benefits with GPEMU ( 3.2).

![Figure 6: FastFlow's [73] benefits with GPEMU ( 3.2).](../assets/imgs/img_in_chart_box_114_408_581_570.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图对应正文第 8 页 §3.2，是作者复现 FastFlow [73] 论文实验的证据（Figure 6: "FastFlow's [73] benefits with GPEMU"）。作者需要它来验证"GPEmu 能否准确复现 FastFlow 相对于 TF-NO（不做预处理解耦）和 TF-DS（预处理解耦基线）的性能优势模式"，并同时检验"GPEmu 仿真结果是否与真实 GPU 运行结果吻合"这一整体准确性主张（主张地图 #5）。`[正文支持]`
   - **图表角色**：实验结论 + 对比基线（既复现 FastFlow 相对基线方法的效果，又通过 Paper/GPU/GPEmu 三面板对照检验仿真准确性）。
   - **上文呼应**：第 3.2 节"Preprocessing Disaggregation"，对应正文陈述"FastFlow consistently outperforms the others in all scenarios...Our emulation results match our GPU runs and follow the patterns reported in the FastFlow paper [73, Fig. 6]"[页码：8]。

2. **图像类型与布局**：三组并排的分组柱状图（grouped bar chart），子图分别标注 (a) Paper、(b) GPU、(c) GPEmu。顶部统一图例标出三种方法：TF-NO（紫色实心）、TF-DS（橙色实心）、TF+FF（青色斜纹）。每个子图内以 x 轴的 CPU 配比分组，每组含三根柱子。`[图像直接可见]`

3. **如何阅读**：三子图共享 y 轴 "Epoch Duration (s)"（越低越好），x 轴为 "Local CPU # : Remote CPU #"；子图 (a) 的分组为 7:7、7:14、14:7，子图 (b)(c) 的分组为 3:3、3:6、6:3。阅读时应在同一子图内比较三色柱子的高低（TF-NO vs TF-DS vs TF+FF），并跨子图比较三种方法之间的相对顺序与整体趋势是否一致。`[图像直接可见]`

4. **直接可见的结论**：在三个子图中，TF+FF（青色）柱子在各 CPU 配比下均处于最低或与最低并列的位置；TF-NO（紫色）在本地 CPU 较少时（如 (b)(c) 中的 3:3、3:6）明显偏高；TF-DS（橙色）在远程 CPU 较少时表现变差。三个子图的柱形相对顺序模式相似，但 (a) 子图的绝对时长量级（约 30–100s）与横轴取值（7:7 等）与 (b)(c) 子图（约 15–55s，3:3 等）不同。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图支持"FastFlow 在所有场景下持续优于 TF-NO 和 TF-DS"这一**效果**主张，以及"GPEmu 仿真结果与真实 GPU 运行结果吻合、且与 FastFlow 论文模式一致"这一**效果/鲁棒性**主张（对应主张地图 #4、#5）。(b) GPU 与 (c) GPEmu 两子图模式高度相似，这直接支撑了 GPEmu 的时间仿真（计算+数据传输）与分布式系统支持模块在预处理解耦场景下的准确性；同时印证了正文说明的"因原论文模型匿名化，作者被迫使用不同 CPU 配比设置"这一实验设置差异，读者不应将 (a) 与 (b)(c) 之间的绝对数值差异或横轴取值差异理解为仿真失准，而应理解为受控设置不同。该图**不能证明**的是：跨其余 35 个模型/配置下 GPEmu 是否同样准确（此为主张 #2 涉及的更广覆盖问题，本图未覆盖）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的 Transformer ASR 工作负载，在本地:远程 CPU 比为 3:3/3:6/6:3（GPU 与 GPEmu 面板）及 7:7/7:14/14:7（原论文面板，因模型匿名化而配置不同，正文已明确说明该差异原因）下的复现实验。无额外证据缺口。

---

## 图片 2：Figure 5: TF-DS [34] training speedup with GPEMU (\$3.2).

![Figure 5: TF-DS [34] training speedup with GPEMU (\$3.2).](../assets/imgs/img_in_chart_box_112_183_536_350.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图对应正文第 7-8 页 §3.2，是作者复现 tf.data service（TF-DS）[34] 论文实验的证据（Figure 5: "TF-DS [34] training speedup with GPEMU"）。作者需要它来验证"随远程 worker 数增加，TF-DS 训练加速比是否呈现论文报告的先快速上升后趋于饱和的模式"，并同时检验 GPEmu 仿真是否与真实 GPU 运行及原论文结果一致。`[正文支持]`
   - **图表角色**：实验结论 + 对比基线（Baseline 虚线代表未加速的基准线=1x）。
   - **上文呼应**：第 3.2 节"Preprocessing Disaggregation"，对应正文陈述"the speedup increases with more workers...beyond 32 workers, adding more yields minimal training time improvements, as preprocessing becomes fast enough and the bottleneck shifts to (emulated) GPU compute. These findings align with those in the TF-DS paper [34, Fig. 9]"[页码：8]。

2. **图像类型与布局**：三个并排折线图，子图分别为 (a) Paper、(b) GPU、(c) GPEmu，顶部图例标出两条曲线：Speedup（青色三角形折线）与 Baseline（橙色虚线水平线）。`[图像直接可见]`

3. **如何阅读**：三子图共享 y 轴 "Speedup"（越高越好），x 轴为 "# of workers"，子图 (a) 横轴跨度到 600 以上，子图 (b)(c) 横轴跨度到约 60-70。应比较三条 Speedup 曲线的上升-饱和形状及饱和后的稳定水平，并将其与恒定为约 1 的 Baseline 虚线对照。`[图像直接可见]`

4. **直接可见的结论**：三个子图中 Speedup 曲线均呈现"随 worker 数增加快速上升，随后趋于平缓"的饱和模式；Baseline 虚线在三子图中均保持在约 1 附近不变。子图 (a) 的饱和水平约为 12-13x，子图 (b)(c) 的饱和水平约为 16-17x，且 (b)(c) 两子图的曲线形状与饱和值高度接近；子图 (a) 的横轴 worker 数取值范围明显大于 (b)(c)。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图支持"TF-DS 加速比随 worker 数增加而提升，且超过一定数量后收益递减（瓶颈转移到 GPU 计算）"这一**效果/机制**主张，以及"GPEmu 结果与真实 GPU 运行结果吻合、并与原论文模式一致"这一**效果**主张（对应主张地图 #4、#5）。(b) GPU 与 (c) GPEmu 曲线形状与饱和值的高度相似，直接支撑了 GPEmu 时间仿真与分布式系统支持模块在数据预处理解耦解构场景下捕捉"饱和拐点"这一动态模式的能力。子图 (a) 与 (b)(c) 之间 worker 数取值范围的差异，正文已明确归因于"原论文模型被匿名化导致作者必须使用不同配置"，因此不应被解读为仿真失真。该图**不能证明**的是饱和点具体出现在多少个 worker（正文提及"beyond 32 workers"针对的是 GPU/GPEmu 面板范围内的观察，本图无法精确定位该数值对应的图上位置，只能看到曲线整体趋于平缓）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的 GAN 模型在 CUB-200-2011 数据集上的训练，单训练客户端（4 CPU）+ 8 块 V100 GPU（TensorFlow + GPEmu 集成），远程 worker 每个 4 CPU 的设置。图像本身未标出坐标刻度精确数值，无法从图上逐点核实"32 workers"这一具体数字对应的曲线位置，但此为正文已明确给出的定量描述，不构成图像证据缺口；无额外证据缺口。
