# 图片批次 2

## 图片 1：Figure 3: Memory emulation (\$2.2). The figures show (a) the GPU memory consumption of propagation and (b) GPU-driven preprocessing, as well as (c) the impact of emulating pinned memory.

![Figure 3: Memory emulation (\$2.2). The figures show (a) the GPU memory consumption of propagation and (b) GPU-driven preprocessing, as well as (c) the impact of emulating pinned memory.](../figure-groups/page-0004-ae4593485538.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本组对应正文 §2.2（Figure 3），是显存仿真模块的核心机制证据。Panel1（3a）与Panel2（3b）证据类型为**机制**——用于验证"GPU显存分配/释放模式具有重复性、可预测性"这一支撑profile-and-replay设计的经验前提[正文支持]；Panel3（3c）证据类型为**消融验证**——检验"若不做锁页内存仿真会导致仿真时间比真实GPU运行慢最多20%，加入后可消除该偏差"这一具体主张[正文支持]。
   - **图表角色**：Panel1/2=方法流水线（机制）；Panel3=消融验证。
   - **上文呼应**：对应"2.2.1 GPU显存消耗"与"2.2.2 锁页内存"两个小节，也是"方法推理树·模块二：显存仿真"的直接实验支撑。

2. **图像类型与布局**：三个独立子面板均为曲线图/柱状图组合。Panel1为折线图（红色，带数据点标记），Y轴"Mem. usage (GB)"，X轴"Time (s)"；Panel2为折线图（紫色），Y轴无标签文字但为显存量级（约0-2+），X轴"Time (s)"，范围到100；Panel3为三柱并列柱状图，Y轴"Epoch time (s)"，X轴三个类别标签"Real GPU"/"Emu. w/o PM"/"Emu. w/ PM"，柱顶各标注数值330、400、329，三柱分别用红色斜线、橙色斜线、绿色交叉纹理区分。

3. **如何阅读**：Panel1沿X轴（时间推移，0-7秒左右）观察显存占用曲线的形状——先上升到平台，再进入周期性锯齿状波动。Panel2沿X轴（0-100秒）观察显存占用从0快速上升后趋于平稳的过程。Panel3需对比三根柱子的高度及顶部标注数字，"Real GPU"为真实GPU运行基准，"Emu. w/o PM"为未做锁页内存仿真的仿真结果，"Emu. w/ PM"为加入锁页内存仿真后的结果。

4. **直接可见的结论**：Panel1显示显存占用先上升至一个较高平台（约5-6 GB），随后呈现多次重复的尖峰-下降锯齿模式[图像直接可见]。Panel2显示显存占用在约0-10秒内快速上升，之后在10-100秒区间内保持近似恒定（约2.x的水平，有一处轻微阶梯上升）[图像直接可见]。Panel3显示"Emu. w/o PM"柱（400）明显高于"Real GPU"柱（330）和"Emu. w/ PM"柱（329），后两者高度非常接近[图像直接可见]。

5. **它验证的论点与方法设计含义**：Panel1/2的重复性、稳定收敛模式为**机制**类证据，直接支撑"显存分配-释放模式可从少量批次profile后外推、预处理显存需profile至稳定后的最大值"这一设计假设[正文支持]，读者应据此理解为何显存仿真模块只需采样少数batch/epoch即可推广到未测配置，而非需要逐一实测所有场景。Panel3的**消融验证**证据直接支撑"锁页内存仿真消除了因GC造成的最高20%额外耗时"这一效果/必要性主张：(400-330)/330≈21%的差距与正文所述"最高20%"的量级相符，而"Emu. w/ PM"与"Real GPU"的高度接近验证了锁页内存仿真使仿真结果逼近真实GPU运行[正文支持]。该图仅证明锁页内存仿真对AlexNet这一具体模型/PyTorch环境下的有效性，不能证明其对其他模型同等有效。

6. **适用范围与证据缺口**：本证据覆盖正文报告的设置——Panel1/2为显存profile过程的示意性曲线（未在正文明确指出具体模型/GPU型号，图注仅标注为"propagation"和"GPU-driven preprocessing"）；Panel3为AlexNet在PyTorch环境下、锁页内存有无对比的epoch时间实验[正文支持]。无额外证据缺口。

---

## 图片 2：Figure 4: Data stall analysis with GPEMU ( 3.1).

![Figure 4: Data stall analysis with GPEMU ( 3.1).](../figure-groups/page-0007-b7d5ecfeff81.png)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：本组对应正文 §3.1"数据停滞分析"（Figure 4），是GPEmu复现DataStall（DS）论文实验的核心证据，证据类型为**实验结论**结合**对比基线**——验证GPEmu能否在不使用真实GPU的情况下复现DS论文关于数据停滞（data stall）的三个具体发现：不同模型的fetch stall占比模式、缓存比例对训练时间的影响、以及CPU核数对训练速度的影响[正文支持]。
   - **图表角色**：实验结论 / 对比基线（三方对照：DS原论文 vs 真实GPU vs GPEmu）。
   - **上文呼应**：对应"3.1 数据停滞分析"整节，及"实验、指标与文字可确认的结论"表中Fetch stall percentage指标行。

2. **图像类型与布局**：三个子面板均为多组对照的图表。Panel1（对应Figure 4a）为分组柱状图，X轴为六个模型（AN, RN18, SN, MN, RN50, V11），每个模型下有三根颜色柱（蓝=DS Paper，红=w/ GPU，绿=w/ GPEmu），Y轴"% of epoch time"。Panel2（对应Figure 4b）为并列三个堆叠柱状图子面板（(i) DS Paper, (ii) w/ GPU, (iii) GPEmu），每个内部X轴为缓存比例（25/35/50/100%），Y轴"Epoch time (s)"，堆叠成分为Compute（青色）、Ideal Stall（橙色）、Extra Stall（紫色）。Panel3（对应Figure 4c）为并列三个折线图子面板（(i) Paper, (ii) w/ GPU, (iii) GPEmu），X轴"# of CPU cores per GPU"（13/6/12/24等刻度），Y轴"# of imgs trained/s"，四条曲线对应四个模型（AN青绿、MN蓝虚线、RN18橙、RN50紫）。

3. **如何阅读**：Panel1需比较同一模型下三种来源（原论文/真实GPU/GPEmu）柱子的相对高度和跨模型的整体趋势是否一致。Panel2需在三个子面板间横向比较相同缓存比例下堆叠柱的总高度及各分段（尤其Extra Stall段）大小是否呈现相同模式。Panel3需在三个子面板间比较相同模型曲线随CPU核数增加时的形状及饱和点位置是否一致。三处均以"模式（pattern）是否跨来源一致"为核心阅读目标，而非追求绝对数值相等。

4. **直接可见的结论**：Panel1中AN（AlexNet）柱普遍最高，V11（VGG11）柱普遍最低，三种来源（DS Paper/w GPU/w GPEmu）在各模型上呈现相似的相对排序趋势，但绝对高度存在差异[图像直接可见]。Panel2中三个子面板均显示：随缓存比例从25%增至100%，总epoch时间递减，且100%缓存时Extra Stall段基本消失，三子面板的堆叠结构形态相近[图像直接可见]。Panel3中三个子面板均显示AN（青绿）曲线在CPU核数增加时上升最快且达到最高饱和水平，MN（蓝虚线）曲线次之，RN18和RN50曲线较低且平缓，三子面板中同一模型的曲线形状相近[图像直接可见]。

5. **它验证的论点与方法设计含义**：三个子面板共同支撑"GPEmu复现结果的模式（pattern）与原论文及真实GPU运行一致，尽管绝对数值因软硬件设置不同而存在差异"这一**效果/鲁棒性**类主张[正文支持]。具体而言：Panel1验证的是fetch stall占比随模型计算强度变化的跨来源一致排序（对应正文"AlexNet因轻量计算而fetch stall最高，VGG11因计算重而借助预取隐藏了大部分数据获取时间"的论述）；Panel2的三方对照验证的是"OS page cache因thrashing而效率低下"这一现象在不同来源下的一致再现；Panel3验证的是"不同模型对每GPU所需CPU核数的差异化需求"（如ResNet50仅需3核、AlexNet需24核）这一模式的跨来源一致性。该图组的方法设计含义在于：读者应理解GPEmu的验证策略是"模式一致性"而非"数值精确复制"，这也划定了本证据能证明的边界——它不能单独证明GPEmu在绝对数值上的精度，只能证明其定性趋势的可靠性。

6. **适用范围与证据缺口**：本证据覆盖正文明确报告的设置——DS论文复现实验，六模型（AlexNet/ResNet18/SqueezeNet/MobileNet/ResNet50/VGG11）用于fetch stall分析（Panel1），四模型（AlexNet/MobileNet/ResNet18/ResNet50）用于CPU核数分析（Panel3），缓存比例覆盖25%-100%（Panel2）[正文支持]。无额外证据缺口。
