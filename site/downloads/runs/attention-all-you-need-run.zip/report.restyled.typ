#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[Attention Is All You Need]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Łukasz Kaiser, Illia Polosukhin]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[NeurIPS (NIPS) 2017 · 2017]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Transformer] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[自注意力机制] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[机器翻译] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[序列建模] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[神经网络架构]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[arXiv：1706.03762]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

目前主流的序列转导模型都基于复杂的循环神经网络或卷积神经网络，包含一个编码器和一个解码器。表现最好的模型还会通过注意力机制将编码器和解码器连接起来。我们提出了一种新的简单网络架构------Transformer，它完全基于注意力机制，彻底摒弃了循环和卷积结构。在两个机器翻译任务上的实验表明，这些模型在质量上更优，同时具有更好的并行性，所需的训练时间也大幅减少。我们的模型在 WMT 2014 英德翻译任务上取得了 28.4 的 BLEU 分数，比现有的最佳结果（包括集成模型）提高了 2 个 BLEU 以上。在 WMT 2014 英法翻译任务上，我们的模型在八块 GPU 上训练 3.5 天后，建立了新的单模型最优 BLEU 分数 41.8，训练成本仅为文献中最佳模型的一小部分。我们还表明，Transformer 能够很好地泛化到其他任务，成功地将其应用于英语成分句法分析，无论是在大规模训练数据还是有限训练数据的情况下。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [Attention Is All You Need],
    [作者], [Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Łukasz Kaiser, Illia Polosukhin],
    [发表场所 / 年份], [NeurIPS (NIPS) 2017],
    [研究领域], [自然语言处理、深度学习],
    [关键词], [Transformer, 自注意力机制, 机器翻译, 序列建模, 神经网络架构],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件
- arXiv：#link("https://arxiv.org/abs/1706.03762")
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（3--5 个）]：`Transformer` · `自注意力机制` · `机器翻译` · `序列建模` · `神经网络架构`
]

论文提出 Transformer------一种完全基于（自）注意力机制、摒弃循环与卷积的序列转导架构，在 WMT2014 英德/英法翻译任务上取得更优 BLEU 且训练时间大幅缩短 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

OCR 覆盖正文第 1--10 页（引言、方法、实验、结论）及第 3、4、13、14、15 页共 5 张图片的证据分析，缺失论文附录中\"注意力分布示例讨论\"的具体内容 #strong[\[背景说明\]]。摘要与正文对英法 BLEU 数值存在不一致（41.8 对 41.0），OCR 未给出解释；指标（BLEU、F1、PPL）的具体计算公式未在正文中给出 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。以下所有结论均以论文文本与图表证据分析为准，背景知识均已明确标注。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

- #strong[问题定义]：如何在不牺牲（甚至提升）序列转导（把一个符号序列转换为另一个符号序列，如英译德）质量的前提下，摆脱循环神经网络\"必须按位置顺序逐步计算\"的限制，从而提升训练并行度、缩短训练时间 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[为什么重要]：LSTM、GRU 等循环模型是当时机器翻译等序列任务的主流方法 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；但序列长度和训练规模不断增长，训练时间与显存开销直接决定模型能否被高效训练与迭代。
- #strong[困难来源]：循环模型的隐藏状态 $h_t$ 依赖 $h_(t - 1)$，天然无法在训练样本内部并行；已有的并行化替代方案（卷积类模型）虽解决了并行问题，却在建模远距离依赖上效率低下 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[本文的 story]：旧路线（RNN 及\"RNN+注意力\"）因顺序计算失效于并行度，卷积类路线因路径长度随距离增长而失效于远距离依赖学习；本文的转折在于观察到\"信号需要经过的路径长度\"是学习依赖关系的关键因素，进而提出用自注意力把任意两位置的路径长度压缩为常数，彻底抛弃循环与卷积 #strong[\[作者明确陈述+基于文中逻辑的推断\]]。

== 4. 旧方法为何不够
<4-旧方法为何不够>

#critique-card(
  [RNN / LSTM / GRU（含 GNMT+RL 等）],
  [原本解决序列建模与转导、处理变长序列的问题 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；其依赖的前提是计算沿位置逐步展开。],
  [$h_t$ 依赖 $h_(t - 1)$ 导致训练样本内部无法并行，长序列时批处理还受显存限制 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；表1 显示其序列操作数为 $O\(n\)$、最大路径长度为 $O\(n\)$。],
  [本文用多头自注意力回应，使序列操作数与最大路径长度均降为 $O\(1\)$ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [表2 的 BLEU/训练 FLOPs 对比与 5.2 节训练时长对比。],
)

#critique-card(
  [ConvS2S 与 ByteNet（卷积类模型）],
  [原本解决并行计算所有位置隐藏表示的问题 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [关联任意两位置所需操作数随距离增长------ConvS2S 线性、ByteNet 对数 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]，路径越长越难学远距离依赖（类比传话游戏，转述越多信息越易失真 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(108, 80, 154, 13%))[#text(size: 8.1pt, weight: "bold", fill: rgb(82, 57, 126))[背景知识]]）。],
  [本文用自注意力使路径恒为 $O\(1\)$ 回应。],
  [表2 中与 Transformer 的 BLEU/训练成本对比。],
)

#critique-card(
  [加性注意力（Bahdanau 等）],
  [原本用带隐藏层的前馈网络计算兼容性函数，在大 $d_k$ 下优于未缩放点积注意力 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [理论复杂度虽相近，但点积注意力可用矩阵乘法高效实现。],
  [本文用缩放点积注意力（除以 $sqrt(d_k)$）回应 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [论文未给出两者在本文任务上的直接对比实验，无法从当前 OCR 内容确认。],
)

#critique-card(
  [RNN 序列到序列模型（用于成分句法分析 \[37\]）],
  [原本应用于英语成分句法分析 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [在小训练数据场景下未取得最先进结果。],
  [Transformer 直接应用该任务回应。],
  [表4 给出 91.3 F1 对比 Vinyals & Kaiser (2014) 88.3 F1。],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

- #strong[核心洞见]：远距离依赖建模的瓶颈是信号需经过的路径长度，自注意力可让任意两位置一步直接关联，因此可完全摒弃循环和卷积、仅用（自）注意力构建编码器-解码器 #strong[\[作者明确陈述+基于文中逻辑的推断\]]。
- #strong[实现组件层面的假设]：用注意力取代逐位置显式结构会带来\"有效分辨率下降\"（注意力输出是加权平均，存在模糊化效应），作者假设多头注意力（同时从多个表示子空间关注信息）可抵消这一损失 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[位置信息的假设]：模型不含循环/卷积则无法自动编码顺序，作者假设正余弦位置编码能让模型学会用相对位置关注，并可能外推到更长序列 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；这一外推优势本身未被直接实验验证。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入序列经词嵌入与正弦位置编码相加后，分别进入编码器和解码器的 6 层堆叠；编码器每层含多头自注意力与逐位置前馈网络两个子层，解码器每层多一个掩码自注意力子层与一个编码器-解码器注意力子层，每个子层后接残差连接+层归一化；解码器堆叠输出经线性变换与 softmax 得到输出概率分布 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

+ #strong[缩放点积注意力]：动机是需要计算高效、可并行、避免大维度下 softmax 梯度消失的注意力函数 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。输入 Q、K（维度 $d_k$）、V（维度 $d_v$），计算 $A t t e n t i o n\(Q\,K\,V\)= s o f t m a x\(frac(Q K^T, sqrt(d_k))\)V$ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。相比加性注意力可用优化矩阵乘法实现，速度更快 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
+ #strong[多头注意力]：动机是单头对不同位置加权平均会抑制模型同时关注不同表示子空间信息的能力 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。将 Q/K/V 投影 h 次（本文 $h = 8$，$d_k = d_v = 64$），各自做注意力后拼接再线性投影：$M u l t i H e a d\(Q\,K\,V\)= C o n c a t\(h e a d_1\,. . .\,h e a d_h\)W^O$ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。总计算量与单头全维度注意力相近。
+ #strong[编码器-解码器注意力/掩码自注意力]：动机是解码器需既能利用编码器全部上下文，又要保持自回归性（预测第 i 位不能看到未来） #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。查询来自解码器上一层、键值来自编码器输出；解码器自注意力将非法连接的 softmax 输入设为 $- oo$ 以屏蔽未来位置 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
+ #strong[逐位置前馈网络]：动机是注意力之外仍需对每位置表示做非线性变换 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。$F F N\(x\)= max\(0\,x W_1 + b_1\)W_2 + b_2$，$d_(m o d e l) = 512$，$d_(f f) = 2048$，各位置共享参数，等价于核大小为 1 的卷积，可完全并行 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
+ #strong[正弦位置编码]：动机是模型不含循环/卷积则无法利用序列顺序 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。$P E_(\(p o s\,2 i\)) = sin\(p o s\/10000^(2 i\/d_(m o d e l))\)$，$P E_(\(p o s\,2 i + 1\)) = cos\(p o s\/10000^(2 i\/d_(m o d e l))\)$，与词嵌入相加后输入底层 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法流程]
  #image("assets/source-crops/img_in_image_box_390_141_833_786.png", width: 100%)
  #emph[Figure 1: The Transformer - model architecture.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示编码器与解码器各 6 层堆叠结构及子层间连接拓扑。

- #strong[论证关系]：可视化印证架构模块连接，支撑完全用注意力替代循环与卷积的机制主张。

- #strong[适用范围]：仅展示架构拓扑，不能证明性能效果或消融结论。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：缩放点积与多头注意力]
  #image("assets/source-crops/img_in_image_box_333_139_940_480.png", width: 100%)
  #emph[Figure 2: (left) Scaled Dot-Product Attention. (right) Multi-Head Attention consists of several attention layers running in parallel.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示缩放点积注意力的计算步骤与多头并行投影拼接流程。

- #strong[论证关系]：对应点积与多头注意力公式，印证多子空间关注与矩阵并行计算设计。

- #strong[适用范围]：仅展示计算流程，不含数值对比与效果证明。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制→收益→条件]：自注意力使任意两位置路径为 $O\(1\)$，若该路径长度确为学习远距离依赖的关键约束，则应比 RNN/卷积更易捕获长距离依赖 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]；此推断依赖\"路径长度是依赖学习难度的主导因素\"这一前提成立。
- #strong[多头注意力]：若单头平均确实造成分辨率损失，则多头并行关注不同子空间应能部分恢复表达能力，表3(A)的消融数据为该链条提供部分实验支持 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。
- #strong[缩放操作]：若大 $d_k$ 下点积数值过大导致 softmax 梯度过小，则除以 $sqrt(d_k)$ 应能稳定训练 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]，但论文未给出缩放前后的直接数值对比。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[效果]：Transformer 是否在 BLEU 上优于 RNN/卷积类基线？对应表2 的跨模型 BLEU 与训练成本对比。
- #strong[必要性（消融）]：多头数、$d_k$、模型规模、dropout、位置编码方式对性能是否必要？对应表3。
- #strong[适用范围]：Transformer 能否泛化到非翻译的结构性任务？对应表4 成分句法分析。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 数据：WMT2014 英德（约450万句对，BPE 编码约37000词表）、英法（3600万句对，word-piece 32000词表）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- 硬件：8×NVIDIA P100 GPU #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；base 模型训练10万步（约12小时），big 模型训练30万步（3.5天）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- 优化与正则化：Adam 优化器及学习率调度、Label Smoothing、Dropout、Beam Search 解码 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- 重复次数/统计方式：文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：BLEU，机器翻译质量评分，数值越高越好。#strong[定义与公式]：正文未给出公式（无可核验公式），仅引用参考文献 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。#strong[实验用途]：比较 Transformer 与 RNN/卷积基线的翻译质量（表2）。#strong[读数与边界]：英德 28.4 BLEU（超过此前最佳含集成模型2.0以上）；英法摘要41.8/正文41.0（不一致，文中未说明原因）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；不能证明其他语言对或超出翻译范围的效果。
- #strong[指标与方向]：F1，成分句法分析准确率，越大越好。#strong[定义与公式]：无可核验公式，仅报告结果数值。#strong[实验用途]：检验 Transformer 在结构性任务上的适用范围（表4）。#strong[读数与边界]：WSJ-only 91.3 F1，半监督92.7 F1 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；仅覆盖两种数据设置，未覆盖其他解析任务。
- #strong[指标与方向]：PPL（困惑度），语言建模不确定性，越小越好。#strong[定义与公式]：无可核验公式。#strong[实验用途]：表3消融中衡量模型变体质量。#strong[读数与边界]：仅在表3中作为辅助读数出现，具体数值未在OCR文本中完整列出，读数以正文引用为准。
- #strong[指标与方向]：训练 FLOPs，训练计算成本，越小越好（同等质量下）。#strong[定义与公式]：文字说明有估计方法，具体公式无可核验。#strong[实验用途]：比较训练效率（表2）。#strong[读数与边界]：Transformer big 约 $2.3 times 10^19$ FLOPs，远低于对比模型 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [RNN/LSTM/GRU], [顺序计算无法并行，$O\(n\)$路径长度], [多头自注意力，$O\(1\)$路径], [表2 BLEU/FLOPs对比；未验证其他硬件下是否同样成立],
    [ConvS2S/ByteNet], [路径长度随距离线性/对数增长], [自注意力恒定路径], [表2 BLEU对比；未做逐距离依赖准确率的定量实验],
    [加性注意力], [理论复杂度相近但实现效率低], [缩放点积注意力], [未给出直接对比数据，无法从当前OCR内容确认],
    [RNN序列到序列（句法分析）], [小数据场景表现欠佳], [Transformer直接应用], [表4 F1对比，已验证],
  )]
  , kind: table
  )

#strong[主张与证据强度]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [Transformer在英德/英法BLEU上优于旧方法且成本更低], [表2], [强，但英法数值存在摘要/正文不一致],
    [多头优于单头], [表3行(A)], [中，仅测了部分头数区间，其余\"文中未说明\"],
    [恒定路径长度更易学远距离依赖], [表1理论对比+图片批次2定性示例], [弱到中，无逐距离定量实验，仅理论与个案],
    [可泛化到成分句法分析], [表4], [中强，仅覆盖该单一结构性任务],
  )]
  , kind: table
  )

- 表2 的 BLEU 提升为绝对分数差（如 +2.0 BLEU），分母/统计显著性文中未说明。
- 图片批次2、3 的注意力可视化为单句、单层的定性个案，不构成统计证据。
- 消融实验（表3）覆盖头数、$d_k$、模型规模、dropout、位置编码五个维度，未覆盖模块三（编码器-解码器注意力/掩码）的独立消融。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_232_198_1009_601.png", width: 100%)
    #emph[Figure 3: An example of the attention mechanism following long-distance dependencies in the encoder self-attention in layer 5 of 6. Many of the attention heads attend to a distant dependency of the verb \'making\', completing the phrase \'making...more difficult\'. Attentions here shown only for the word \'making\'. Different colors represent different heads. Best viewed in color.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：自注意力依赖学习]
    - #strong[图组结论]：展示动词 making 单跳跨越远距离直接连接到 more 和 difficult。

- #strong[论证关系]：作为定性个案支撑自注意力恒定路径长度更易学习远距离依赖的主张。

- #strong[适用范围]：仅为单句单层个案，不构成统计证据，无法证明具体语言学功能。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_242_335_1005_1206.png", width: 100%)
    #emph[Figure 4: Two attention heads, also in layer 5 of 6, apparently involved in anaphora resolution. Top: Full attentions for head 5. Bottom: Isolated attentions from just the word 'its' for attention heads 5 and 6. Note that the attentions are very sharp for this word.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：自注意力可解释性]
    - #strong[图组结论]：代词 its 的注意力集中指向其先行词 Law，呈现尖锐对齐模式。

- #strong[论证关系]：支撑自注意力可能具有可解释性及个别头自发学会代词消解的主张。

- #strong[适用范围]：仅为特定句子与注意头的定性示例，缺乏定量评估与附录完整讨论。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_238_368_998_1179.png", width: 100%)
    #emph[Figure 5: Many of the attention heads exhibit behaviour that seems related to the structure of the sentence. We give two such examples above, from two different heads from the encoder self-attention at layer 5 of 6. The heads clearly learned to perform different tasks.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：自注意力可解释性]
    - #strong[图组结论]：红色面板呈局部相邻对齐，绿色面板呈远距离多对一汇聚模式。

- #strong[论证关系]：为不同注意力头学会执行不同任务及捕获句法结构提供可视化佐证。

- #strong[适用范围]：仅展示单句两个头的定性连线，无法读取精确权重与具体句法解释。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1: Maximum path lengths, per-layer complexity and minimum number of sequential operations for different layer t...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：旧方法为何不够]
  - #strong[图组结论]：自注意力层单层复杂度为 O(n^2·d)，最大路径长度与序列操作数均为 O(1)。

- #strong[论证关系]：理论对比证明自注意力相比 RNN 与卷积在路径长度与并行度上的优势。

- #strong[适用范围]：仅为理论复杂度分析，未考虑实际显存带宽与具体硬件优化。
  #v(5pt)
  #image("table-groups/page-0006-35d5d96582f0.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2: The Transformer achieves better BLEU scores than previous state-of-the-art models on the English-to-German a...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：性能主张]
  - #strong[图组结论]：Transformer big 在英德达 28.4 BLEU、英法达 41.0 BLEU，且训练 FLOPs 大幅降低。

- #strong[论证关系]：直接支撑 Transformer 在翻译质量与训练成本上全面超越旧基线的主张。

- #strong[适用范围]：仅覆盖 WMT2014 英德英法任务，英法 BLEU 与摘要存在数值不一致。
  #v(5pt)
  #image("table-groups/page-0008-370f740f258e.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3: Variations on the Transformer architecture. Unlisted values are identical to those of the base model. All me...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：消融实验]
  - #strong[图组结论]：评估注意力头数、关键维度、模型大小、dropout 及位置编码变体的影响。

- #strong[论证关系]：验证多头机制必要性及模型规模对性能的贡献，支撑各设计选择。

- #strong[适用范围]：仅在英德开发集 newstest2013 上测试，未覆盖解码器掩码等模块独立消融。
  #v(5pt)
  #image("table-groups/page-0009-513938beeb13.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 4: The Transformer generalizes well to English constituency parsing (Results are on Section 23 of WSJ)]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：句法分析泛化]
  - #strong[图组结论]：在 WSJ 句法分析任务上，无特定调优下获得 91.3 F1，半监督达 92.7 F1。

- #strong[论证关系]：证明 Transformer 可成功泛化至序列到序列的结构性非翻译任务。

- #strong[适用范围]：仅覆盖英语成分句法分析单一任务，未验证其他领域与结构化任务。
  #v(5pt)
  #image("table-groups/page-0010-0b11338fdb84.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：如何摆脱RNN顺序计算限制，在提升并行度与训练速度的同时不损失（甚至提升）序列转导质量
  - 旧方法限制：RNN顺序依赖无法内部并行（$O\(n\)$路径）；卷积类模型路径长度随距离增长，难学远距离依赖
  - 核心洞见/假设：路径长度是依赖学习的关键约束，自注意力可使任意两位置路径恒为$O\(1\)$ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]
    - 方法模块：多头自注意力+缩放点积注意力+逐位置前馈网络+正弦位置编码构成的编码器-解码器
      - 可验证预测：完全基于注意力的模型应能在翻译质量、训练速度、并行度上超越RNN/卷积基线
        - 指标与实验：表2 BLEU与FLOPs对比；表3消融；5.2节训练时长
          - 图表证据：Figure 1/2架构与流程图；注意力可视化个案（第13-15页）
            - 结论与适用边界：英德/英法BLEU与训练效率优势有实验支持，但英法数值不一致未解释；远距离依赖优势仅有理论对比与定性个案，未被逐距离定量实验直接验证 #strong[\[实验支持+文中未说明\]]

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- #strong[贡献]：提出Transformer架构、多头注意力机制，在两个翻译基准取得当时最优BLEU且训练成本更低 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[证据充分的结论]：英德/英法翻译质量与训练效率优势有表2定量数据支持；多头优于单头、模型规模与dropout的作用有表3消融支持。
- #strong[尚属推断的意义]：自注意力恒定路径长度更利于远距离依赖学习是理论对比+定性个案支撑的推断，未有逐距离定量实验；正弦位置编码的外推能力未被验证；可解释性主张为推测性表述 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。
- #strong[适用条件]：结论覆盖机器翻译（英德、英法）与英语成分句法分析两类任务，8×P100 GPU环境；其他模态未覆盖 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[局限]：英法BLEU数值不一致未解释；附录注意力分布讨论不在OCR范围；受限局部注意力、跨模态应用列为未来工作 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[审稿式风险检查]：
  - 贡献新意：当前证据未显示该风险，架构创新点明确对应所解决的顺序计算限制。
  - 写作/可复现性：存在风险------摘要与正文BLEU数值不一致未作说明。
  - 效果大小：当前证据未显示该风险，BLEU提升幅度有直接数值支持。
  - 实验覆盖：存在风险------远距离依赖优势缺乏定量实验，仅个案与理论对比；缩放点积注意力的\"是否缩放\"消融缺失。
  - 方法设计：当前证据未显示该风险，各模块动机与消融基本对应。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：自注意力（Self-Attention）。#strong[第一性原理角色]：连接序列内任意两个位置这一基本操作，其约束是计算复杂度与路径长度。#strong[本文位置]：构成编码器/解码器所有层的核心计算单元。
- #strong[术语]：缩放点积注意力。#strong[第一性原理角色]：以Q、K、V为基本对象，受softmax梯度在大维度下消失的数学约束。#strong[本文位置]：模块一，所有注意力层的基础函数。
- #strong[术语]：多头注意力。#strong[第一性原理角色]：在表达能力（多子空间关注）与计算量（维度切分）之间的约束下设计。#strong[本文位置]：模块二，编码器/解码器所有注意力层。
- #strong[术语]：位置编码。#strong[第一性原理角色]：解决\"无序结构如何携带顺序信息\"这一约束。#strong[本文位置]：模块五，输入底层与词嵌入相加。
- #strong[术语]：残差连接与层归一化。#strong[第一性原理角色]：解决深层网络梯度消失/爆炸的训练稳定性约束。#strong[本文位置]：每个子层输出处。
- #strong[术语]：BLEU。#strong[第一性原理角色]：以n-gram重合度为基本量，衡量译文与参考译文的相似度 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(108, 80, 154, 13%))[#text(size: 8.1pt, weight: "bold", fill: rgb(82, 57, 126))[背景知识]]。#strong[本文位置]：表2主结果指标。
- #strong[术语]：自回归。#strong[第一性原理角色]：以\"已生成输出\"为约束条件的生成机制。#strong[本文位置]：解码器掩码自注意力设计依据。

=== 12.2 学习路径
<122-学习路径>
+ 序列与符号------理解\"序列转导\"处理的基本对象是什么，为何翻译可建模为序列到序列的映射（通俗类比：输入一串符号，输出另一串符号的翻译机 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(108, 80, 154, 13%))[#text(size: 8.1pt, weight: "bold", fill: rgb(82, 57, 126))[背景知识]]）。
+ 计算并行性约束------理解为何顺序依赖限制训练速度，这是本文动机的根源。
+ 注意力机制------理解\"查询-键-值\"如何实现加权信息检索，是自注意力的基础（类比图书馆按关键词查资料 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(108, 80, 154, 13%))[#text(size: 8.1pt, weight: "bold", fill: rgb(82, 57, 126))[背景知识]]）。
+ 残差与归一化------理解深层网络为何需要这些稳定训练的机制，才能理解6层堆叠为何可行。
+ 评价指标（BLEU/F1/PPL）------理解论文如何用数值证据支撑质量与效果主张，是阅读实验部分的前提。
