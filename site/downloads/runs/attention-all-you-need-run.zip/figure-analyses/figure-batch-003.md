# 图片批次 3

## 图片 1：Figure 5: Many of the attention heads exhibit behaviour that seems related to the structure of the sentence. We give two such examples above, from two different heads from the encoder self-attention at layer 5 of 6. The heads clearly learned to perform different tasks.

![Figure 5: Many of the attention heads exhibit behaviour that seems related to the structure of the sentence. We give two such examples above, from two different heads from the encoder self-attention at layer 5 of 6. The heads clearly learned to perform different tasks.](../assets/imgs/img_in_chart_box_238_368_998_1179.jpg)

*来源：OCR 第 15 页。*

### 解读

**1. 论文角色与验证问题**
该图是第4节"Why Self-Attention"末尾提出的附带主张——"自注意力可能带来更强的可解释性"（页码：7，原文："As side benefit, self-attention could yield more interpretable models... We inspect attention distributions from our models and present and discuss examples in the appendix"）——所引用的具体附录示例。图注明确说明这是"编码器自注意力第5层（共6层）中两个不同头"的注意力分布示例，用来支撑"各个注意力头明显学会执行不同任务，且许多头的行为似乎与句子的句法/语义结构相关"这一论述 `[正文支持, 页码7]`。
- **图表角色**：实验结论（定性）——为"自注意力可能产生更可解释模型"这一机制/适用范围主张提供直接可视化例证，而非量化消融或基线性能对比。
- **上文呼应**：对应第4节末尾"side benefit"段落（页码7）与主张地图中"自注意力可能带来更强的可解释性"一条（页码7）。

**2. 图像类型与布局**
两个并列的子面板（左侧红色系、右侧绿色系），均为"词对齐"式连线图：同一英文句子的词元序列分别竖排显示在面板的上方与下方（上下两份完全相同），中间用彩色线条连接上排某词元与下排某词元，线条的颜色深浅/粗细表示该连接的注意力权重强弱。图注说明左右两个面板对应第5层中两个不同的注意力头。

**3. 如何阅读**
- 面板内：上排词元序列视为"源位置"，下排为同一句子的"目标位置"（自注意力，Q/K/V 均来自同一序列）；一条从上排词元到下排词元的线代表该头在该目标位置对该源位置分配的注意力权重。
- 颜色深浅与线宽编码权重大小：深色/粗线＝高权重，浅色/细线＝低权重（背景中存在大量几乎不可辨的浅色线）。
- 应比较的量：同一句子在两个不同头（红色面板 vs 绿色面板）下连线模式的差异，以及每个面板中哪些词元承接了密集且高权重的连线。
- 词序列（The, Law, will, never, be, perfect, …, application, …, missing, …, opinion, <EOS>, <pad>）本身只是坐标标签，两面板一致，不构成独立可比较的数值轴。

**4. 直接可见的结论** `[图像直接可见]`
- 红色面板（左）中的深色高权重连线大多连接位置相邻或接近相邻的词对（如 The–Law、will–never、be–perfect、but–its、application–should、be–just、this–is–what、we–are、missing、in–my、opinion、<EOS>–<pad>），整体呈现出接近局部/短距离的连接模式。
- 绿色面板（右）中存在多条深色粗线，从多个分散位置（如 Law、application、be、just、this、is、are 等）共同汇聚到少数几个词元，尤其密集地指向 "missing"，另有若干指向 "application"、"opinion" 附近，呈现出"多个远距离位置被同一头统一连接到少数目标词"的模式。
- 两个面板的连线整体分布明显不同：红色更局部化、接近一一对应；绿色更分散且更多呈现远距离多对一汇聚。
- 除上述高权重深色线外，两个面板都还叠加了大量浅色、权重难以辨识的背景连线，覆盖句中大部分词对组合。

**5. 它验证的论点与方法设计含义**
- 该图直接支撑"自注意力可能产生更可解释模型"这一适用范围/机制类主张：两个头呈现出可辨认且彼此不同的连接模式（一头偏局部/相邻对齐，另一头偏远距离多对一汇聚），可作为"个别注意力头清晰学会执行不同任务"这句话的具体例证 `[正文支持, 页码7]`。
- 结合论文核心洞见——自注意力使任意两个位置只需一步计算即可直接建立联系，不必像 RNN 逐步传递或像卷积堆叠多层（页码2, 6-7）——绿色面板中"远距离词元被同一头直接相连"这一可见现象，可作为该机制主张（O(1) 路径长度支持远距离依赖）的定性可视化佐证 `[基于文中逻辑的推断, 页码2, 6-7]`。
- 该图**不能**证明：某个头具体执行何种句法/语义任务（如指代消解、长距离一致关系等具体语言学功能）——正文和图注均未说明连线所对应的具体语言学含义，只泛称"似乎与句子的句法和语义结构相关"，因此不能把本图解读为验证了某个具体句法功能 `[正文支持, 页码7]`。
- 该图也**不能**用于对"可解释性"做定量评估或与 RNN/卷积模型的可解释性进行对比——正文原文使用"may"（可能）这一推测性措辞，且未提供任何定量对比数据。

**6. 适用范围与证据缺口**
- 本图覆盖范围：仅展示编码器自注意力第5层（共6层）中两个（8 个头中的两个）注意力头，在图注给出的同一个具体示例句子上的可视化，不代表其他层、其他头或其他句子的普遍模式 `[正文支持, 页码15图注]`。
- 证据缺口：图上无法读取精确的注意力权重数值，仅能通过线条深浅做定性比较；正文提到"在附录中进一步展示并讨论了这些示例"，但附录具体讨论内容不在当前 OCR 范围内，图中连线对应的具体语言学解释"无法从当前 OCR 内容确认"。
- 除上述外，无额外证据缺口。
