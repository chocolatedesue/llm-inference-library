# 图片批次 2

## 图片 1：Figure 3: An example of the attention mechanism following long-distance dependencies in the encoder self-attention in layer 5 of 6. Many of the attention heads attend to a distant dependency of the verb 'making', completing the phrase 'making...more difficult'. Attentions here shown only for the word 'making'. Different colors represent different heads. Best viewed in color.

![Figure 3: An example of the attention mechanism following long-distance dependencies in the encoder self-attention in layer 5 of 6. Many of the attention heads attend to a distant dependency of the verb 'making', completing the phrase 'making...more difficult'. Attentions here shown only for the word 'making'. Different colors represent different heads. Best viewed in color.](../assets/imgs/img_in_chart_box_232_198_1009_601.jpg)

*来源：OCR 第 13 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 4 节"Why Self-Attention"中的核心机制主张——自注意力能以恒定路径长度（$O(1)$）直接连接任意两个位置，从而比 RNN/卷积更容易学习远距离依赖 `[正文支持]`。图注明确指出这是编码器自注意力第 5/6 层中，动词 "making" 追踪远距离依赖、补全短语 "making...more difficult" 的示例，属于"机制"类证据（用具体样例展示路径长度短带来的实际效果），同时呼应正文提到的"自注意力可能带来更强可解释性"的副作用主张（"我们检查了模型的注意力分布...在附录中展示并讨论示例"，页码：7）`[正文支持]`。
   - **图表角色**：机制
   - **上文呼应**：第 4 节"自注意力路径长度更短，更易学习远距离依赖"`[页码：6-7]`；第 4 节末尾"自注意力可能产生更可解释的模型"`[页码：7]`。

2. **图像类型与布局**：注意力连线示意图（非坐标轴曲线图/柱状图/表格）。左侧为聚焦单个查询词"making"的简化视图：顶部一行是完整输入句子的词序列（token 序列，含 `<EOS>`、`<pad>` 填充符），从"making"一词出发向下方（另一份完整词序列副本）用彩色线条连接到其关注的若干词，线条颜色代表不同注意力头，线宽/透明度可能代表权重大小；底部有几个高亮色块（紫、橙、绿、蓝、红、棕、灰等），可能是对应词位置的注意力头强度指示条。右侧为同一层完整的全词对全词注意力连线图（更密集的浅紫色线束），展示所有位置间的连接。

3. **如何阅读**：顶部与底部（或上下两份）均为同一句子的词序列（水平排列），线条从上方某个查询词出发连接到下方被关注的词，颜色区分不同注意力头，线的粗细/深浅代表权重强弱；应重点比较"making"一词发出的线条落点位置（词序列中的顺序距离）与线条颜色数量。

4. **直接可见的结论**：左侧简化图中，"making"发出多条颜色各异（棕色、紫色、浅紫等）的线，其中多条线明显指向序列后部的"more"和"difficult"（棕色线尤为粗重、直接连接到"difficult"），另有一条紫色线连接到"2009"；底部对应"more""difficult"位置下方有多个彩色小色块堆叠（橙、绿、蓝、红、棕、灰）表示多个头在此处有响应 `[图像直接可见]`。右侧全连接图整体线条密集、覆盖几乎所有词对，但从视觉上无法单独分辨出哪几条特定线对应"making→more/difficult"这一具体连接（该图信息量过大，需要依赖左侧简化视图定位）`[图像直接可见]`。

5. **它验证的论点与方法设计含义**：图中可见"making"这个词通过若干不同颜色（不同头）的连线，直接、单跳地连接到句子后部的"more"和"difficult"（补全短语"making...more difficult"），这与图注文字描述一致，属于"效果"类证据——具体展示了自注意力如何在没有逐步传递的情况下，一步跨越较长的词序距离直接建立语义关联 `[正文支持，结合图像直接可见]`。这支持第 4 节"自注意力最大路径长度为 $O(1)$，因而更容易学习远距离依赖"这一机制主张的直观示例，也部分对应"自注意力可能产生更可解释模型，不同头似乎学会执行不同任务"的推测性论述（页码：7）——图中不同颜色（头）确实分别指向不同的词（如"2009"与"more/difficult"），提示不同头关注不同类型的依赖关系 `[基于文中逻辑的推断]`。但该图仅是单个句子、单个查询词、单一层（5/6层）的定性个案展示，不能证明"路径长度短→更易学远距离依赖"这一命题在全数据集上的定量效果，也不能作为可解释性主张的统计证据，这些仍需表2/表3的定量结果或附录中更系统的讨论来支撑 `[正文支持]`。

6. **适用范围与证据缺口**：本图覆盖论文报告的单个示例句子、编码器自注意力第 5/6 层、聚焦单词"making"的注意力分布这一具体设置 `[正文支持]`。真实缺口：图像中颜色与具体注意力头编号的对应关系（图注仅说"不同颜色代表不同头"，但未提供头编号-颜色对照图例，OCR 页面也未提供图例说明），以及底部小色块具体数值权重，均无法从当前图像像素中精确读出——"图中无法区分的数值"。

---

## 图片 2：Figure 4: Two attention heads, also in layer 5 of 6, apparently involved in anaphora resolution. Top: Full attentions for head 5. Bottom: Isolated attentions from just the word ‘its’ for attention heads 5 and 6. Note that the attentions are very sharp for this word.

![Figure 4: Two attention heads, also in layer 5 of 6, apparently involved in anaphora resolution. Top: Full attentions for head 5. Bottom: Isolated attentions from just the word ‘its’ for attention heads 5 and 6. Note that the attentions are very sharp for this word.](../assets/imgs/img_in_image_box_242_335_1005_1206.jpg)

*来源：OCR 第 14 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 4 节末尾"自注意力可能带来更强可解释性"的推测性主张及附录中"个别注意力头似乎学会执行不同任务，部分体现句子的句法/语义结构"的论述（页码：7）`[正文支持]`。图注指出这是两个注意力头（同样在第 5/6 层）在处理代词消解（anaphora resolution，即判断"its"指代前文哪个名词）任务上的表现，属于"机制"类证据，用于展示自注意力头可能自发学到与语言学任务（指代消解）相关的行为模式 `[正文支持]`。
   - **图表角色**：机制
   - **上文呼应**：第 4 节"自注意力可能产生更可解释的模型...个体注意力头明显学会执行不同任务"`[页码：7]`。

2. **图像类型与布局**：注意力连线示意图，分为上下两部分。上半部分（Top）为"头5"的完整注意力连线图：同一句话（"The Law will never be perfect, but its application should be just - this is what we are missing, in my opinion."，含 `<EOS>`/`<pad>`）在上下两行重复排列，多条紫色线连接各词，线条密集、覆盖全句多处位置。下半部分（Bottom）为两个子图并列，分别是"头5"和"头6"仅从单词"its"出发的孤立连线视图：左侧子图"its"用紫色高亮，发出一条深紫色线指向"Law"（并有一条浅色线指向"application"）；右侧子图（推测对应头6，图中未见独立配色区分但图注说明为头5和头6的对比）"application"用棕色高亮，发出线条指向"its"。

3. **如何阅读**：与图片1类似，顶部/底部为同一词序列的重复排列，线条从查询词发出指向被关注的词，颜色/位置代表不同头；应重点比较"its"发出的线条终点（是否指向"Law"或"application"等候选先行词），并对比"完整头5视图"（信息密集）与"仅'its'的孤立视图"（信息聚焦）两种呈现方式。

4. **直接可见的结论**：底部左侧孤立视图中，"its"发出一条清晰、加粗的深紫色线直接连接到"Law"（并有一条较浅的线连接到"application"），线条明确、无歧义 `[图像直接可见]`。右侧孤立视图中，"application"发出线条明确指向"its"位置（体现另一头/角度的对应关系）`[图像直接可见]`。顶部完整视图线条密集，覆盖句子中多个词对，视觉上更难单独追踪某一特定词对关系，需要依赖下方孤立视图定位 `[图像直接可见]`。图注称"这些注意力对该词非常尖锐（sharp）"，与图中所见"its"仅少数几条突出、加粗的线（而非均匀分散到很多词）相符 `[图像直接可见，与图注一致]`。

5. **它验证的论点与方法设计含义**：图中"its"清晰地将注意力集中指向"Law"（其真实先行词），这是效果类证据的一个定性个例，展示自注意力头在没有专门指代消解监督信号的情况下，自发表现出与代词-先行词对应关系一致的注意力模式 `[正文支持，结合图像直接可见]`。这支持第 4 节"自注意力可能带来更强可解释性、部分头会体现句法/语义结构"的推测性主张，是该主张的具体可视化支撑材料 `[正文支持]`。但正文本身对此结论持谨慎措辞（"许多头似乎（appear to）表现出与句法语义结构相关的行为"），本图作为单一句子、单一词、两个头的个案，不能证明这种指代消解行为在模型中普遍存在或对翻译任务的最终性能有可量化贡献，这类"可解释性"主张的系统性证据仍依赖论文提到但未纳入本次 OCR 的附录内容 `[正文支持]`。

6. **适用范围与证据缺口**：本图覆盖论文报告的单个示例句子、编码器自注意力第 5/6 层中的头5与头6在处理代词"its"时的注意力分布这一具体设置 `[正文支持]`。真实缺口：图中未提供头5与头6的独立颜色图例或数值权重标注，无法从像素中精确区分两个孤立子图之间颜色编码的具体对应关系及权重大小——"图中无法区分的数值"；此外，正文提到的"附录中展示并讨论"更完整的注意力分布讨论不在当前 OCR 范围内，相关更系统的可解释性结论"无法从当前 OCR 内容确认"。
