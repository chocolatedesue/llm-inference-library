# 图片批次 1

## 图片 1：Figure 1: The Transformer - model architecture.

![Figure 1: The Transformer - model architecture.](../assets/imgs/img_in_image_box_390_141_833_786.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：这是论文第 3 节开篇即展示的整体架构图，作者用它给出 Transformer 编码器-解码器的完整模块拼装方式，对应"核心洞见"中"完全用（自）注意力替代循环/卷积构建编码器-解码器"的机制主张，以及模块一~五（缩放点积注意力、多头注意力、编码器-解码器/掩码自注意力、逐位置前馈网络、正弦位置编码）在整体结构中的位置关系。图注仅为"Figure 1: The Transformer - model architecture."，未单独说明每个色块的动机，需结合正文 3.1-3.5 节文字关联。`[正文支持]`
   - **图表角色**：方法流水线。
   - **上文呼应**：对应"方法推理树"模块一至模块五，以及"论文 Story 与贡献边界"中"编码器/解码器各 6 层堆叠结构"的实现组件描述（页码：3-6）。

2. **图像类型与布局**：流程/架构示意图，非曲线或表格。左右两个纵向堆叠的模块组（左=编码器，右=解码器），由灰色圆角外框各自包裹并标注"N×"；模块间用箭头连接，不同功能模块用不同颜色底色区分（粉色=Embedding，橙色=Multi-Head Attention/Masked Multi-Head Attention，浅蓝=Feed Forward，浅黄绿=Add & Norm，紫色=Linear，绿色=Softmax），底部有正弦波状图标标注"Positional Encoding"并通过"⊕"符号与embedding相加，顶部输出"Output Probabilities"。

3. **如何阅读**：自底向上阅读——底部输入 Inputs / Outputs (shifted right) 经 Embedding 与 Positional Encoding 相加后进入各自的 N× 堆叠块；左侧编码器堆叠块内部顺序为 Multi-Head Attention → Add & Norm → Feed Forward → Add & Norm；右侧解码器堆叠块内部顺序为 Masked Multi-Head Attention → Add & Norm → Multi-Head Attention（含跨模块箭头指向编码器输出）→ Add & Norm → Feed Forward → Add & Norm；解码器堆叠输出经 Linear → Softmax 得到 Output Probabilities。应比较左右两侧模块数量、连接方式的异同。

4. **直接可见的结论**：编码器堆叠中每层含两个子层（Multi-Head Attention、Feed Forward），解码器堆叠中每层含三个子层（Masked Multi-Head Attention、Multi-Head Attention、Feed Forward），每个子层后都跟一个"Add & Norm"模块；解码器的第二个 Multi-Head Attention 模块有两条箭头从编码器堆叠输出侧引入，另一条箭头来自解码器自身的前一子层，表明该层的键值来自编码器、查询来自解码器；解码器的第一个注意力模块标注为"Masked"，编码器对应模块无此标注；输入输出侧均有"Positional Encoding"正弦图标与词嵌入相加后再送入堆叠块；顶部堆叠输出后依次经过 Linear 与 Softmax 两个模块得到最终概率分布。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：图像直接可见的"编码器-解码器注意力层的键值来自编码器输出、查询来自解码器上一层"这一连接方式，正是模块三（编码器-解码器注意力）动机的可视化实现，支持"解码器可直接访问输入序列任意位置信息"的机制主张`[正文支持]`；"Masked Multi-Head Attention" 标签与自注意力模块动机中"防止关注未来位置以保持自回归性质"的文字描述一致，是该机制设计的直接图示佐证`[正文支持]`；Positional Encoding 与 Embedding 相加的连接方式印证了模块五的动机——"模型不含循环卷积，需额外注入位置信息"`[正文支持]`；"N×"标注可视化了编码器/解码器各 6 层堆叠的结构性组成部分（该具体数字 N=6 来自正文而非图中文字标出，图中仅显示"N×"符号本身）`[图像直接可见]`+`[正文支持]`。该图仅展示模块连接拓扑，不能证明任何效果或消融类主张（如多头优于单头、BLEU 提升等），这些需由表 2、表 3 提供。

6. **适用范围与证据缺口**：本图覆盖论文正文 3.1-3.5 节描述的整体架构拓扑，是原理性示意图而非某一次具体实验的可视化。无额外证据缺口。

---

## 图片 2：Figure 2: (left) Scaled Dot-Product Attention. (right) Multi-Head Attention consists of several attention layers running in parallel.

![Figure 2: (left) Scaled Dot-Product Attention. (right) Multi-Head Attention consists of several attention layers running in parallel.](../assets/imgs/img_in_image_box_333_139_940_480.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：该图对应 3.2.1 节"缩放点积注意力"与 3.2.2 节"多头注意力"两个方法模块，作者用其展示两种注意力计算的内部数据流与相互组合方式，验证"如何用矩阵运算高效并行计算注意力"这一必要性主张，并说明多头结构如何由多个缩放点积注意力并行拼接而成。`[正文支持]`
   - **图表角色**：方法流水线。
   - **上文呼应**：对应"方法推理树"模块一（缩放点积注意力）与模块二（多头注意力），页码：4-5。

2. **图像类型与布局**：流程示意图，左右两个子图并排。左子图标题"[Scaled Dot-Product Attention]"（图注文字为"(left) Scaled Dot-Product Attention"），为单一竖直流程链；右子图标题"Multi-Head Attention"，为带有多组并行重复（用叠影/阴影表示 h 个头）的竖直流程结构，两子图之间以箭头/引用关系呼应（右图中间模块直接复用左图整体作为一个方框标注"Scaled Dot-Product Attention"）。

3. **如何阅读**：左子图自底向上：输入 Q、K、V 三个箭头 → MatMul（Q 与 K 相乘）→ Scale（缩放）→ Mask (opt.)（可选掩码）→ SoftMax → 再一次 MatMul（与 V 相乘）→ 输出。右子图自底向上：V、K、Q 三路输入 → 各自经过独立的 Linear 投影 → 多组（阴影叠加表示 h 份重复，标注字母 h）并行的 "Scaled Dot-Product Attention" 模块 → Concat（拼接所有头输出）→ 一次 Linear → 输出。应比较左右两图中模块数量与是否有并行重复结构。

4. **直接可见的结论**：左子图中 Mask 模块标注为"(opt.)"（可选），位于 Scale 之后、SoftMax 之前，这与正文 3.2.3 节所述"在 softmax 输入中将非法连接位置设为 −∞"的掩码位置一致；右子图中 Scaled Dot-Product Attention 模块以多层叠影方式绘制，明确表示该模块被并行复制多份（对应头数 h），且在进入该模块前 V、K、Q 各自先经过独立的 Linear 投影，再在输出端经 Concat 与一次 Linear 得到最终结果。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：左图中"MatMul→Scale→Mask(opt.)→SoftMax→MatMul"的清晰five步链条是模块一动机——"计算高效、可并行、避免大 $d_k$ 下梯度消失"——的流程化呈现，直接对应正文公式 $Attention(Q,K,V)=softmax(QK^T/\sqrt{d_k})V$ 中的每一步骤`[正文支持]`；Mask 标注为可选（opt.）说明同一套缩放点积注意力模块既可用于编码器自注意力（不掩码），也可用于解码器掩码自注意力（掩码），是模块三"掩码自注意力复用同一注意力函数、通过设置 −∞ 屏蔽非法连接"这一设计的可视化印证`[正文支持]`；右图中多份并行的缩放点积注意力模块再经 Concat 和线性投影，直接对应模块二动机——"单头对不同位置做加权平均会抑制模型同时关注不同表示子空间信息的能力"，图像展示的正是"通过 h 个独立线性投影 + 并行注意力 + 拼接" 的具体解决方案，与公式 $MultiHead(Q,K,V)=Concat(head_1,...,head_h)W^O$ 一致`[正文支持]`。该图仅展示计算流程拓扑，不能证明"多头优于单头"或"缩放优于不缩放"的效果差异，这些效果性/消融类主张需由正文表 3 行 (A) 及文字论证支撑，图本身不含任何数值或性能比较。

6. **适用范围与证据缺口**：本图覆盖论文正文 3.2.1、3.2.2 节描述的两种注意力计算流程示意，不涉及具体实验设置或数值结果。图中并行头数以叠影和字母"h"象征性表示，未标出具体数字（h=8 由正文给出，图像本身不可见该数值）——这属于图像未标注、需依赖正文才能确定的细节，但不构成规则第 6 条定义的"真实缺口"（OCR/图题冲突或图像遮挡），故无额外证据缺口。
