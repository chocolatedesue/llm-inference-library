#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(size: 9.4pt)
#set par(justify: true, leading: 0.72em, spacing: 0.72em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#show heading.where(level: 1): it => block(above: 1.4em, below: 0.9em)[
  #text(size: 17pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]
  #v(-6pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => block(above: 1.6em, below: 0.7em, inset: (x: 9pt, y: 5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))[#text(size: 12.5pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => block(above: 1.1em, below: 0.4em)[#text(size: 10.6pt, weight: "bold", fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => block(above: 0.9em, below: 0.3em)[#text(size: 9.8pt, weight: "bold", fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(size: 12pt, weight: "bold", tracking: 3pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(6pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(size: 22pt, weight: "bold")[Frontier: Towards Comprehensive and Accurate LLM Inference Simulation]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yicheng Feng, Xin Tan, Yangtao Deng, Yimin Jiang, Yibo Zhu, Hong Xu]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[2026]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM推理模拟] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[分离式服务架构] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[离散事件仿真] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[性能建模] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[MoE并行]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[代码：https://github.com/NetX-lab/Frontier]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-26]
]
#pagebreak(weak: true)

#set page(numbering: "1")
#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

现代大语言模型（LLM）服务已不再是同质化或单体式的。生产系统如今融合了分离式执行、复杂的并行策略、运行时优化技术，以及推理、智能体和强化学习（RL）rollout等有状态工作负载。仿真是探索这一不断扩展的设计空间的有效手段，但现有仿真器缺乏其所要求的架构完整性和决策级精度。它们的单体副本抽象难以适配分离式服务架构，而基于平均情形的分析代理模型可能扭曲SLA预测，甚至颠倒优化结论。本文提出Frontier，一个面向现代LLM推理服务的离散事件仿真器。Frontier采用分离式抽象，通过为共置、Prefill-Decode分离（PDD）和Attention-FFN分离（AFD）架构建模角色专属的集群工作节点，捕捉现代服务系统的结构与动态特性；在调度器-批处理-引擎循环中集成关键运行时优化技术（如CUDA Graph、推测解码）；并支持面向新兴工作负载的有状态请求。此外，Frontier还能在具有复杂工作负载组合的多样化服务场景中，提供准确且可泛化的计算、通信与内存开销预测。在16卡H800 GPU测试平台上，Frontier的平均吞吐量误差低于4%。与最先进的仿真器相比，它将端到端延迟误差在共置场景下从44.9%降至6.4%，在分离式场景下从51.7%降至2.6%。Frontier可在普通CPU上扩展至超过1000块GPU的规模，并支持诸如SLA相关的帕累托前沿探索、异构分离式资源分配、智能体推理调度验证以及RL后训练重配置等新应用场景。Frontier已在 #link("https://github.com/NetX-lab/Frontier") 开源。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#align(center)[#table(
  columns: 2,
  align: (col, row) => (auto,auto,).at(col),
  inset: 6pt,
  [字段], [内容],
  [标题],
  [Frontier: Towards Comprehensive and Accurate LLM Inference Simulation],
  [作者],
  [Yicheng Feng, Xin Tan, Yangtao Deng, Yimin Jiang, Yibo Zhu, Hong Xu],
  [发表场所 / 年份],
  [文中未说明 / 2026],
  [研究领域],
  [LLM 推理系统、性能仿真],
  [关键词],
  [LLM推理模拟, 分离式服务架构, 离散事件仿真, 性能建模, MoE并行],
)
]

=== 资源链接
<资源链接>
- 原始文件：本地上传文件
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：#link("https://github.com/NetX-lab/Frontier")

#blockquote[
#strong[标签（3–5 个）]：`LLM推理仿真` · `分离式服务架构PDD-AFD` · `离散事件仿真` · `MoE并行性能建模` · `KV-cache容量预测`
]

论文提出离散事件仿真器 Frontier，用\"控制面/保真面分离＋角色专属集群 worker＋运行时适配器\"解决现有仿真器架构不完整、精度粗糙两大问题，在 16×H800 实测下平均吞吐误差低于 4%，端到端延迟误差从 44.9%/51.7% 降至 6.4%/2.6% `[实验支持，页码：1，3，8]`。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

OCR 覆盖论文第 1–13 页正文及 6 组图表证据（部分为 Table/Figure 混排图片），涵盖摘要、动机、方法、实验（§5）与四个使用案例（§6）。存在的限制：部分图片柱顶数字因分辨率原因无法逐位核实（如 Table 5 最后一位小数）`[无法从当前 OCR 内容确认]`；论文原始编号的 Eq. 只有 Eq.1 明确出现，其余公式无编号 `[作者明确陈述]`；另有 10 张图片超过分析上限未做视觉分析。论文事实与背景知识已在下文逐条标注区分。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

#strong[问题定义]：现代 LLM 推理服务架构（共置→PDD→AFD）、并行策略（TP/PP/DP/EP）、运行时优化（连续批处理、CUDA Graph、投机解码等）与工作负载（MoE、推理链、agent、RL rollout）同时快速演化，使生产部署\"极难建模、推理和优化\" `[作者明确陈述，页码：1]`。

#strong[为什么重要]：真实硬件扫描代价极高——在 64×H100 上扫描 100 种配置需 12,800–25,600 GPU-小时、最多耗资 18 万美元，导致团队放弃调优、退回保守配置、损失 3–5× 吞吐 `[作者明确陈述，页码：3]`。仿真是廉价替代手段，但现有仿真器不满足决策精度要求。

#strong[难点来源]：一是解耦式架构下不同 GPU 池承担不同角色、需显式跨集群同步，二是运行时优化会改变调度器可见状态而非只是加速系数，三是服务系统是闭环系统（执行成本→内存状态→准入→排队→未来批组成），微小误差会被放大 `[作者明确陈述，页码：2，4]`。

#strong[成功标准]：仿真预测需在算子/内存/端到端多层面与真实硬件对齐，且不能颠倒优化结论。

#strong[本文 story]：旧路线在\"单体副本抽象\"与\"平均情形代理模型\"这两个技术选择上失效——前者无法表达 PDD/AFD 的跨集群依赖，后者会低估长度/路由异质性造成的误差，进而在闭环系统中放大为决策错误。本文的转折是把仿真器拆成\"控制面（拓扑与调度）\"和\"保真面（硬件感知预测）\"两层分离架构，用校准的算子/内存预测器替代解析代理 `[作者明确陈述，页码：1-2，4]`。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：运行时优化会改变调度器可见状态而非只是加速系数]
  #image("assets/imgs/img_in_chart_box_106_143_380_239.jpg", width: 100%)
  #emph[Figure 1. Measured vLLM TPOT with and without CUDA Graph under different workloads (64 requests per workload, mean ISL/OSL, tested on 8×A800-SXM GPUs). Left: co-location. Right: PDD. Percentages show reduction.] \
来源：OCR 第 3 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：共置与 PDD 四种工作负载下开启 CUDA Graph 后 TPOT 均下降，降幅随工作负载而异

- #strong[论证关系]：印证运行时优化须一等公民建模，与同页 Table 2 的填充开销数据互补

- #strong[适用范围]：仅展示 vLLM 实测净效果，不单独证明填充侧的负面效应
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：单体副本抽象无法表达跨集群依赖导致的架构不完整问题]
  #image("figure-groups/page-0003-513ea5e4b078.png", width: 100%)
  #emph[Figure 2. Existing simulators vs. vLLM CUDA Graph. Percentages represent error.] \
来源：OCR 第 3 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Vidur 全部偏高（+34.6%~+61.0%），AIConfigurator 全部偏低（-31.8%~-46.4%），PDD 面板 Vidur 柱缺失

- #strong[论证关系]：证明忽略 CUDA Graph 会产生结构性双向误差，柱缺失与 Table 1 中 PDD 标✗互证架构不完整

- #strong[适用范围]：不能证明 Frontier 自身精度，需结合 Figure 1、9 佐证
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：闭环系统中执行成本到未来批组成的微小误差会被放大]
  #image("figure-groups/page-0003-5530874f0d8e.png", width: 100%)
  #emph[Figure 4. Fidelity gaps caused by simplified modeling. Left: Relying on coarse proxies (total token count) fails to capture batch heterogeneity, yielding coarse-grained performance estimates. Right: Analytical KV-cache modeling overestimates effective memory budget, leading to a cascade of errors from admission control to over-optimistic throughput projection.] \
来源：OCR 第 3 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：token 代理对 Attention/GroupedGEMM 误差远高于 Linear 算子；解析 KV 模型高估预算 8.1%/27.2%、吞吐 23.6%/32.4%

- #strong[论证关系]：为序列/路由依赖随机森林预测器与 dummy profile 内存模型提供必要性依据

- #strong[适用范围]：仅证明旧方法误差存在，不证明 Frontier 自身精度
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：难点来源——闭环服务系统会放大微小预测误差]
  #image("assets/imgs/img_in_chart_box_137_143_551_348.jpg", width: 100%)
  #emph[Figure 5. Decision drift from fidelity gaps on Llama-3.1-8B over 16 H800 GPUs (co-location). The simulator-selected best configuration lies inside the frozen SLA region, but the corresponding vLLM ground-truth point moves outside the SLA because overly optimistic comp-op and KV-cache budget predictions underestimate request latency. Note that we maintain feature parity in this evaluation by disabling vLLM optimizations unsupported by APEX.] \
来源：OCR 第 4 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：APEX 选中的最优配置在真实 vLLM 上违反 SLA，ΔTTFT\=+17.54ms，ΔTPOT\=+8.53ms

- #strong[论证关系]：可视化决策漂移机制，是 Fidelity Plane 设计动机的反面案例

- #strong[适用范围]：仅为 APEX 单一基线的单一案例，不代表 Frontier 自身表现
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

#align(center)[#table(
  columns: 6,
  align: (col, row) => (auto,auto,auto,auto,auto,auto,).at(col),
  inset: 6pt,
  [比较对象], [原本要解决什么], [依赖前提/遗留限制], [本文批判的具体 limit], [本文回应模块], [检验实验],
  [Vidur],
  [提供 DES 基础，Frontier 复用其模块 `[作者明确陈述，页码：7]`],
  [单体副本、token-only 算子代理],
  [不支持 MoE/解耦；attention 误差 p50/p95 55.4%/376.1% `[作者明确陈述，页码：8-9]`],
  [三类算子预测器+角色专属 worker],
  [Figure 7、Figure 11],
  [APEX],
  [搜索最优计划的仿真器],
  [不支持解耦架构，EP 支持有限 `[作者明确陈述，页码：8]`],
  [无法表达跨集群依赖],
  [Control Plane 两域分解],
  [Figure 5（决策漂移案例）；无逐基线量化对比表 `[无法从当前 OCR 内容确认]`],
  [AIConfigurator],
  [算子数据库+解析工作流，在 TensorRT-LLM/H200 上有效 `[作者明确陈述，页码：9]`],
  [缺 CUDA Graph 建模；MTP 用标量期望公式],
  [低接受率下预测反向趋势（27.2%–66.6% 偏差，5 例中 4 例方向错）；E2E 误差最高 170.0%/200.0% `[作者明确陈述，页码：2-4，9-10]`],
  [Runtime Adapter、投机解码状态跟踪],
  [Figure 2、3、5、11],
  [LLMServingSim2.0],
  [聚焦异构硬件仿真 `[作者明确陈述，页码：9]`],
  [Table 1 多项功能标 ✗，正文无量化批判 `[无法从当前 OCR 内容确认]`],
  [同上],
  [角色专属 worker、运行时适配器],
  [文中未说明具体对比实验],
  [FastServe（MLFQ 调度）],
  [非推理场景短作业优先调度有效 `[作者明确陈述，页码：11]`],
  [优先级仅看当前轮次可观测大小],
  [多轮 agentic 场景仅带来 1.45% p95 aTTFT 改善，隐藏规划吞吐反降 2.3% `[作者明确陈述，页码：12]`],
  [有状态请求抽象+阶段感知调度器],
  [Figure 15],
  [\"总减权重\"解析 KV-cache 模型],
  [简化估算显存预算],
  [忽略真实 profile],
  [高估预算 8.1%/27.2%，虚高吞吐 23.6%/32.4% `[作者明确陈述，页码：4]`],
  [Fidelity Plane dummy profile run],
  [Figure 4、Table 4],
)
]

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见]：不同生产引擎（vLLM、SGLang）虽调度策略/算子后端不同，但共享同一\"控制流骨架\"（准入→批处理→执行→完成），因此仿真核心可与具体框架解耦 `[作者明确陈述，页码：4]`。

#strong[两条设计原则]（作者明确提出）：①架构完整性——放弃单体副本，改用角色专属集群 worker 表达 PDD/AFD，运行时优化建模为直接更新调度器状态的\"特征专属适配器\"，引入有状态请求抽象承载推理/agent/RL 语义；②决策级精度——引入\"保真面\"，用基于真实 CUDA kernel 行为画像的校准预测器替代粗糙代理 `[作者明确陈述，页码：2]`。

#strong[前提与可能失效条件]：该架构假设\"控制流骨架\"具有跨引擎共性，若未来引擎调度范式发生根本性改变（如完全去中心化调度），这一前提可能不成立 `[基于文中逻辑的推断，推理依据：作者仅验证了 vLLM，SGLang/TensorRT-LLM 留作未来工作，页码：4，13]`。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

#strong[总览]：输入为 CLI 指定的模型/硬件/并行/运行时/工作负载配置，Control Plane 将其编译为仿真拓扑并驱动 Execution Plane 的调度器-批处理引擎循环，逐算子/逐内存查询 Fidelity Plane 获取时延与容量预测，输出仿真的端到端指标 `[作者明确陈述，页码：4-6]`。

=== 模块1：控制面（Simulation Compiler）
<模块1控制面simulation-compiler>
- #strong[动机]：需把服务规格转为可运行拓扑，显式表达跨阶段依赖，而非把 PDD/AFD 简化为延迟项 `[作者明确陈述，页码：4-5]`。
- #strong[运行]：解析出\"角色专属集群 worker+每 worker 内多 Replica Worker\"拓扑；引入两域并行原语 \#mi(\"pp,(tp\_{attn},dp\_{attn}),(tp\_{ffn},ep\_{ffn})\")，域一致性约束 \#mi(\"tp\_{attn}\\cdot dp\_{attn}\=tp\_{ffn}\\cdot ep\_{ffn}\")（Eq.1，页码：5）；五类跨阶段依赖（流水线、PDD KV传输、AFD激活传输、MoE EP同步）具象为显式事件 `[作者明确陈述，页码：5-6]`。
- #strong[技术优势]：排队/同步可\"直接从事件图导出\"，避免耦合隐藏在运行时中。
- #strong[连接]：拓扑与事件图驱动模块2的调度决策。

=== 模块2：执行面（Scheduler + Runtime Adapters）
<模块2执行面scheduler--runtime-adapters>
- #strong[动机]：既要保留真实调度机制（如 vLLM watermark 抢占），又要让运行时优化影响调度器可见状态，而非只是加速因子 `[作者明确陈述，页码：6]`。
- #strong[运行]：调度器决定准入与批组成，Runtime Adapter（如 CUDA Graph Dispatcher）重塑批（批填充、MTP 的 draft→verify→commit 状态维护），重塑后的批交给 Batch Engine 查询保真面 `[作者明确陈述，页码：5-6]`。
- #strong[技术优势]：把一个优化拆成三个可组合切面（调度器状态、查询批形状、逐请求进度），可同时表达\"填充增加计算量 vs 图重放去启动开销\"的耦合效应，\"标量加速因子无法捕捉这种耦合\" `[作者明确陈述，页码：6]`。
- #strong[连接]：输出批形状供模块3预测运行时间。

=== 模块3：保真面（算子库+内存容量模型）
<模块3保真面算子库内存容量模型>
- #strong[动机]：批组成在线决定，无法穷尽画像，需要泛化能力 `[作者明确陈述，页码：6]`。
- #strong[运行]：按算子类型分三类预测器——token 数算子用线性回归/随机森林，序列依赖算子（attention）用批大小+逐请求长度分布统计量的随机森林，路由依赖算子（MoE）用负载均衡方差/最大值等统计量的随机森林；内存容量模型通过单卡 dummy profile run 得到权重内存、torch 峰值增量、非 torch 驻留三个量，总预算减去三者得到 KV-cache 块预算 `[作者明确陈述，页码：6]`。
- #strong[技术优势]：单卡即可获得逐 rank 足迹，千卡内存预算只需一张 GPU 求解；PP 下取最坏切片作代表 rank。
- #strong[连接]：预测结果反馈给模块2的批执行时序，闭环推进仿真时钟。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：控制面/保真面分离的整体系统架构总览]
  #image("assets/imgs/img_in_image_box_665_149_1083_702.jpg", width: 100%)
  #emph[Figure 6. Frontier system architecture.] \
来源：OCR 第 5 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：四模块（Workload&Config、Fidelity Plane、Control Plane、Execution Plane）分层嵌套并以箭头连接

- #strong[论证关系]：机制性可视化，呈现控制面/保真面分离与运行时适配器\"一等公民\"地位

- #strong[适用范围]：不含精度或性能数值，无实验覆盖范围问题
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 角色专属 worker+显式跨阶段事件 → 能原生表达 PDD/AFD 的排队与传输依赖 → 前提是拓扑编译准确覆盖实际同步点 `[基于文中逻辑的推断，页码：5-6]`。
- 运行时适配器把优化建模为状态变更而非标量 → 能复现耦合效应（如 CUDA Graph 填充与图重放）→ 前提是适配器正确刻画所有相关切面 `[基于文中逻辑的推断，页码：6]`。
- 序列/路由依赖算子用随机森林捕捉批内异质性 → 能降低 attention/MoE 类算子误差 → 前提是训练数据覆盖生产环境的批形状分布，这一覆盖度论文未量化验证 `[基于文中逻辑的推断，页码：6；无法从当前 OCR 内容确认]`。
- 内存基于真实 profile 而非解析估算 → 能避免 KV-cache 预算高估进而避免吞吐虚高 → 前提是 profile 过程本身不引入侵入式开销偏差（作者已采取隔离措施）`[基于文中逻辑的推断，页码：6，13]`。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 研究问题一（效果）：Frontier 端到端预测是否比现有仿真器更准？对应比较基线 Vidur/APEX/AIConfigurator/LLMServingSim2.0，用 32 项指标误差判定 `[作者明确陈述，页码：8-10]`。
- 研究问题二（机制/必要性）：CUDA Graph、投机解码、前缀缓存等运行时优化是否需一等公民建模？对应 Figure 9/10、Table 5/6 的匹配度判定 `[作者明确陈述，页码：9]`。
- 研究问题三（必要性）：KV-cache 预算是否需基于运行时 profile？对应 Table 4、Figure 8 判定 `[作者明确陈述，页码：8-9]`。
- 研究问题四（适用范围）：仿真结论能否支撑此前无法验证的新用例（Pareto 前沿、异构分配、agentic 调度、RL 重配置）？无独立硬件复现实验，属于仿真推演层级 `[无法从当前 OCR 内容确认，页码：10-13]`。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 测试床：16×H800（部分 Challenge 论证用 8×A800-SXM）`[作者明确陈述，页码：3，8]`。
- 引擎版本：vLLM v0.10.2（V1 引擎）`[作者明确陈述，页码：3]`。
- 模型：Qwen3-30B MoE、Step3-316B、Llama-3.1-8B/405B、Llama-3.3-70B `[作者明确陈述，页码：8-10]`。
- 工作负载：prefill-heavy/decode-heavy/balanced/SharedGPT 四种模式 `[作者明确陈述，页码：7-8]`。
- 基线：Vidur、APEX、AIConfigurator、LLMServingSim2.0 `[作者明确陈述，页码：8-10]`。
- 重复次数/统计方式：文中未说明。
- 超参数细节：文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：\#mi(\"W\_R^c\")（每副本世界大小），无量纲，描述性非优劣。#strong[定义]：原文公式 \#mi(\"W\_R^c\=pp\\cdot tp\_{attn}\\cdot dp\_{attn}\")（角色∈{C,P,D,A}）或 \#mi(\"pp\\cdot tp\_{ffn}\\cdot ep\_{ffn}\")（角色\=F），来源层级：原文公式，无编号，页码：5。#strong[用途]：定义仿真拓扑规模。#strong[边界]：仅描述拓扑，不涉及精度。

- #strong[指标与方向]：域一致性约束，越大越好方向不适用（等式约束）。#strong[定义]：\#mi(\"tp\_{attn}\\cdot dp\_{attn}\=tp\_{ffn}\\cdot ep\_{ffn}\")，来源层级：原文公式 Eq.1，页码：5。#strong[用途]：确保同一角色跨域设备集合一致。#strong[边界]：仅为拓扑合法性约束。

- #strong[指标与方向]：\#mi(\"SR(g)\")（花费比），无量纲，越大越好。#strong[定义]：原文公式 \#mi(\"SR(g)\=\\dfrac{Price(g\_0)}{Price(g)}\")，来源层级：原文公式，无编号，页码：11。#strong[用途]：§6.2 判定异构分配是否比全 H800 便宜。#strong[边界]：仅反映成本，不含性能。

- #strong[指标与方向]：\#mi(\"CE(g)\")（成本效率），无量纲，越大越好，作者要求 \>1.08。#strong[定义]：原文公式 \#mi(\"CE(g)\=\\dfrac{T(g)/Price(g)}{T(g\_0)/Price(g\_0)}\")，来源层级：原文公式，无编号，页码：11。#strong[用途]：判定候选分配单位成本产出是否更高。#strong[边界]：依赖仿真吞吐 \#mi(\"T\") 的准确性。

- #strong[指标与方向]：相对误差（Table 4/5/6 等各表 Δ 值），百分比，越小越好。#strong[定义]：推导关系（非原文公式）：相对误差\=(仿真值−vLLM实测值)/vLLM实测值×100%。#strong[来源层级]：推导关系（非原文公式）\[基于文中逻辑的推断\]，推理依据：原文表格标题写\"Percentages are relative errors to vLLM\"，页码：8-9。#strong[用途]：贯穿所有算子/内存/端到端保真度对比。#strong[边界]：以 vLLM 实测为分母，不能脱离该测试床外推。

- #strong[指标与方向]：TTFT/TPOT/吞吐/E2E makespan，毫秒/tokens每秒/秒，均为越小/越大方向按名称，文中未说明具体计算公式，仅报告数值，来源层级：无可核验公式，页码：1-2，8-12。#strong[用途]：端到端保真度评估与 SLA 判定。#strong[边界]：无法核实其内部聚合口径。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]（见第4节表格，此处不重复展开）。

#align(center)[#table(
  columns: 3,
  align: (col, row) => (auto,auto,auto,).at(col),
  inset: 6pt,
  [主张], [直接证据（实验/表图）], [证据强度与边界],
  [吞吐误差\<4%],
  [摘要数值，Figure 9关联 `[实验支持，页码：1]`],
  [已验证；外推未测硬件需额外实验],
  [单体抽象与解耦系统\"根本不匹配\"],
  [Vidur/APEX 在 PDD 行标✗（Table1/Figure11）`[作者明确陈述]`],
  [属间接反证，无强行建模 PDD 的受控消融],
  [运行时优化须一等公民建模],
  [Figure 2、Table 5、6 `[实验支持，页码：9]`],
  [缺少\"去掉适配器退化为解析补丁\"的消融],
  [KV-cache 须基于运行时 profile],
  [Table 4、Figure 8 `[实验支持，页码：8-9]`],
  [已直接验证],
  [支持 1K+ GPU/商用 CPU],
  [摘要与 §1 陈述 `[作者明确陈述，页码：1，10]`],
  [无运行时长/内存占用实测数字],
  [四用例\"此前无仿真器可复现\"],
  [§6 引言陈述 `[作者明确陈述，页码：10]`],
  [作者主观声明，无逐用例失败复现实验],
)
]

- 共置端到端 32 项指标误差 ≤9.37%，PDD ≤10.99%（29/32≤9%），对比 Vidur 2.9%–45.5%、AIConfigurator 最高 170.0%/200.0% `[实验支持，页码：9-10]`。
- KV-cache 初始块预算误差 ≤1.89% vs 解析基线 14.10%–39.73% `[实验支持，页码：8-9]`。
- 投机解码 p95 误差多数 ≤11.28%，AIConfigurator 平均 46.9% 且趋势翻转 `[实验支持，页码：9]`。
- 所有数值均限定于 16×H800/8×A800、vLLM v0.10.2、特定模型集合，能否推广到其他硬件/框架/更大 MoE 稀疏度文中未说明。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0003-44aea4d244c2.png", width: 100%)
    #emph[Figure 3. Qwen3-30B MoE MTP decode speedup (verify\_tokens\=4). Bars (left axis): vLLM vs. AIConfigurator. Dashed line: prediction error. Red ×: sign-mismatch (measured speedup \> 1, predicted slowdown] \
来源：OCR 第 3 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：AIConfigurator 标量期望公式压平事件驱动的非线性加速]
    - #strong[图组结论]：AR\=20% 时部分 Batch Size 下 vLLM 显示加速而 AIConfigurator 预测减速，方向相反；AR\=80% 时方向一致但数值差距仍存

- #strong[论证关系]：证明标量期望式 MTP 模型会预测出错误趋势，支撑逐请求状态跟踪设计必要性

- #strong[适用范围]：仅覆盖 AIConfigurator 一个基线，不可推广为所有仿真器通病
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_634_444_893_620.jpg", width: 100%)
    #emph[Table 6. Speculative decoding (MTP) fidelity on Qwen30B MoE under SharedGPT.] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：前缀缓存命中率精确匹配（共置 36.98% / PDD 37.11%）]
    - #strong[图组结论]：vLLM 与 Frontier 曲线在共置、PDD 两种设置下高度重叠，锯齿波动同步

- #strong[论证关系]：支撑将前缀缓存建模为 block-hash 索引足以复现真实引擎命中动态

- #strong[适用范围]：仅验证命中率时间序列匹配，不涉及下游 TTFT/吞吐影响幅度
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_637_148_850_306.jpg", width: 100%)
    #emph[Figure 9. Decode throughput. +CG bars stack eager throughput with the CUDA Graph gain; top labels show total +CG/eager speedup.] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：CUDA Graph 解码加速匹配 vLLM，误差 1.7%（共置）/6.1%（PDD）]
    - #strong[图组结论]：共置组（2.95 vs 2.90）与 PDD 组（3.05 vs 2.86）加速倍数在 vLLM 与 Frontier 间接近

- #strong[论证关系]：支撑运行时适配器一等公民建模的必要性主张

- #strong[适用范围]：无对应\"去适配器\"消融实验
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_109_415_316_547.jpg", width: 100%)
    #emph[Figure 8. Available KV-cache blocks over time under colocation (Qwen3-30B MoE, SharedGPT trace), with a max gap of 294 blocks (115.6 MB; MB \= 0.393 B, where B is the block gap).] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：KV-cache 初始块预算误差 ≤1.89%]
    - #strong[图组结论]：vLLM 与 Frontier 曲线在整个运行时窗口高度重叠，波动同步

- #strong[论证关系]：支撑 KV-cache 内存模型基于运行时 profile 而非解析估算的必要性

- #strong[适用范围]：仅覆盖单一模型/架构组合，未标注具体并行配置
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0008-77f8b8fdcb20.png", width: 100%)
    #emph[Figure 7. Per-operator relative-error CDF on H800 for attention, and MoE kernels under BF16 (left) and FP8 (right). Vidur is undefined for MoE ops, and its baseline cannot be evaluated under FP8.] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：序列依赖算子误差数字（Frontier p50/p95 3.5%/14.2% vs Vidur 55.4%/376.1%）]
    - #strong[图组结论]：Frontier Attention/MoE 曲线 BF16 下 0.2–0.3 误差内接近 CDF\=1.0，Vidur 延伸至约 2.5；FP8 下无 Vidur 对照曲线

- #strong[论证关系]：印证随机森林预测器精度提升，同时揭示 Vidur 不支持 FP8 的架构局限

- #strong[适用范围]：仅检验\"token-only 代理对批内异质性不敏感\"这一具体 limit
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 5. Compute-participating token accounting on Qwen3-30B MoE. E: eager; CG: CUDA Graph. Eager Frontier is +0 (0%)...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：CUDA Graph 填充 token 数误差 within 2.55%]
  - #strong[图组结论]：CG-vLLM 列数值普遍高于 E-vLLM 列，ΔFrontier 误差视觉上处于个位数区间

- #strong[论证关系]：支撑填充效应建模精度，印证运行时适配器一等公民设计必要性

- #strong[适用范围]：不证明端到端延迟/吞吐整体保真度
  #v(5pt)
  #image("table-groups/page-0008-e4aea783e1b6.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_154_152_1063_482.jpg", width: 100%)
    #emph[Figure 11. End-to-end fidelity on a 16-card H800 testbed for co-location and PDD across prefill-heavy, decode-heavy, balanced, and SharedGPT workloads. Panels report TTFT, TPOT, throughput, and E2E makespan for both Llama3.1-8B (dense) and Qwen3-30B MoE; dashed bars indicate simulators that do not support the serving architecture or model family. All data are normalized against the ground truth (vLLM), represented by the black line (y\=1.0).] \
来源：OCR 第 9 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：端到端延迟误差 44.9%→6.4%，51.7%→2.6%]
    - #strong[图组结论]：Frontier 柱始终最贴近 y\=1.0；AIConfigurator/LLMServingSim2.0/Vidur 在 Thpt、E2E 频繁远离基准；APEX 多处以红叉缺失

- #strong[论证关系]：是摘要核心量化结论的直接可视化证据，缺失柱与 Table 1 功能表互证架构不完整

- #strong[适用范围]：不能单独归因某一子机制导致的误差来源，需结合 Figure 7/8/9/10
  ],
)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：现代 LLM 服务架构/并行/运行时优化/工作负载同时演化，生产部署难以建模、推理和优化 `[作者明确陈述，页码：1]`
  - 旧方法限制：单体副本抽象无法表达 PDD/AFD；平均情形代理低估异质性误差，闭环放大为决策错误 `[作者明确陈述，页码：1-2]`
    - 核心洞见/假设：服务引擎共享\"准入-批处理-执行-完成\"控制流骨架，可与调度策略/算子后端解耦 `[作者明确陈述，页码：4]`
      - 方法模块：控制面/保真面分离，角色专属集群 worker，运行时适配器，有状态请求抽象 `[作者明确陈述，页码：4-6]`
        - 可验证预测：Frontier 能以低误差复现真实系统的算子时延、内存预算、运行时优化行为、端到端延迟 `[作者明确陈述，页码：8-10]`
          - 指标与实验：per-operator CDF、KV-cache 块预算误差、CUDA Graph/MTP/前缀缓存匹配度、32 项端到端指标误差 `[实验支持，页码：8-10]`
            - 图表证据：Figure 7/8/9/10/11、Table 4/5/6
              - 结论与适用边界：在 16×H800、vLLM v0.10.2、特定模型集合下成立；能否推广到 SGLang/TensorRT-LLM、其他硬件、更大稀疏度 MoE 未被当前证据直接验证 `[无法从当前 OCR 内容确认，页码：13]`

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：去单体化的控制面/保真面分离架构；运行时优化的适配器一等公民建模范式；有状态请求抽象；校准的三类算子预测器与基于 profile 的 KV-cache 内存模型 `[作者明确陈述，页码：2，4-7]`。

#strong[证据充分的结论]：吞吐误差\<4%，端到端延迟误差大幅低于既有仿真器（44.9%→6.4%，51.7%→2.6%），KV-cache 预算误差≤1.89% `[实验支持，页码：1，8-9]`。

#strong[尚属推断的意义]：四个使用案例展示的应用价值（Pareto 前沿、异构分配、agentic 调度、RL 重配置）均为仿真推演，尚无真实硬件复现验证 `[作者明确陈述，页码：10-13]`。

#strong[适用条件]：结论限定于 vLLM v0.10.2、16×H800/8×A800、特定模型集合（Qwen3-30B MoE、Step3-316B、Llama系列）。

#strong[局限]：主要围绕 vLLM 校准，SGLang/TensorRT-LLM 扩展留作未来工作；CPU 开销建模\"可能仍缺乏鲁棒性\" `[作者明确陈述，页码：13]`；AFD 为离线校准，延迟类指标置信度可能低于 PDD/共置 `[作者明确陈述，页码：10]`。

#strong[审稿式风险检查]：

- 贡献新意：控制面/保真面分离与适配器范式有明确技术论证与对比实验支撑，当前证据未显示该风险。
- 写作/可复现性：代码已开源（GitHub），但重复次数、统计显著性、部分超参数文中未说明，存在可复现性信息缺口。
- 效果大小：主结果误差改善幅度大且有量化数字支撑，当前证据未显示夸大风险。
- 实验覆盖：四个使用案例缺乏真实硬件对照，属于已知证据缺口而非风险掩盖；部分基线（LLMServingSim2.0、APEX）缺少逐项量化对比。
- 方法设计：核心机制缺少\"去除适配器/退化为解析补丁\"的消融实验，无法单独量化\"一等公民建模\"相对补丁式建模的增量收益。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：Prefill-Decode Disaggregation（PDD）——把 LLM 推理的预填充和解码阶段分配到不同 GPU 池运行，通过传输 KV-cache 衔接。#strong[第一性原理角色]：受\"计算密集 vs 显存带宽密集\"两类资源约束的分工连接。#strong[本文位置]：Control Plane 用角色专属 worker 建模，页码：1，4-5。

- #strong[术语]：Attention-FFN Disaggregation（AFD）——在解码阶段进一步把注意力计算与 FFN/MoE 计算拆到不同 GPU 池。#strong[第一性原理角色]：受跨池激活传输带宽约束。#strong[本文位置]：模块1的角色专属 worker 建模对象，页码：1。

- #strong[术语]：CUDA Graph——把一串 GPU kernel 调用预先录制为可重放序列，减少调度开销，但重放前批大小需\"凑整\"到捕获桶，产生填充浪费 `[基于文中逻辑的推断，页码：3]`。#strong[第一性原理角色]：受\"kernel 启动开销 vs 批对齐浪费\"的权衡约束。#strong[本文位置]：模块2 Runtime Adapter 核心建模对象，页码：3，6，9。

- #strong[术语]：Fidelity Plane（保真面）——用校准的硬件感知预测器替代粗糙代理，给出算子/通信/内存开销预测。#strong[第一性原理角色]：连接\"批形状/硬件配置\"这一状态量与\"运行时间/内存占用\"这一可观测量。#strong[本文位置]：模块3，页码：2，6。

- #strong[术语]：MoE GroupedGEMM——MoE 层中多个专家的矩阵乘法被分组批量执行的算子。#strong[第一性原理角色]：受\"专家级负载偏斜\"这一路由依赖约束，token-count 代理会将其平均掉。#strong[本文位置]：路由依赖算子预测器的建模对象，页码：2，6。

- #strong[术语]：投机解码/MTP——用小/快的草稿机制一次猜测多个后续 token，主模型批量验证提交，减少串行调用次数 `[作者明确陈述，页码：6]`。#strong[第一性原理角色]：受\"验收率\"这一随机变量约束，决定实际加速比。#strong[本文位置]：Runtime Adapter 的逐请求 planned/verified/accepted/committed 状态跟踪，页码：5-6，9。

- #strong[术语]：离散事件仿真（DES）——系统状态只在\"事件\"发生时间点跳跃式更新，用优先队列按时间戳处理事件。#strong[第一性原理角色]：用离散时间戳替代连续步进，是仿真效率与保真度的基础机制。#strong[本文位置]：Frontier 的核心仿真范式，页码：5。

- #strong[术语]：KV-cache 容量模型——通过单 GPU dummy profile run 得到权重内存、峰值增量、非 torch 驻留三个量，用总预算减去它们得到块预算。#strong[第一性原理角色]：受\"总显存-占用项\=可用预算\"这一资源约束方程连接。#strong[本文位置]：模块3，页码：6。

=== 12.2 学习路径
<122-学习路径>
+ 先理解 Prefill/Decode 两阶段的计算特性差异（基本对象）——它决定了为什么会有 PDD/AFD 这类拆分需求。
+ 再理解 TP/PP/DP/EP 并行策略（约束）——它们决定了模型如何被切分到多卡，是理解 Frontier 拓扑编译的前提。
+ 然后理解 CUDA Graph、投机解码等运行时优化的工作原理（机制）——它们改变调度器可见状态，是理解\"一等公民建模\"必要性的关键。
+ 最后理解 KV-cache 内存管理与仿真中的 TTFT/TPOT/吞吐等指标含义（指标/系统行为）——它们是评判仿真精度与 SLA 是否满足的最终观测量。
