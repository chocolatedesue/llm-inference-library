# 图片批次 2

## 图片 1：Figure 2. Existing simulators vs. vLLM CUDA Graph. Percentages represent error.

![Figure 2. Existing simulators vs. vLLM CUDA Graph. Percentages represent error.](../figure-groups/page-0003-513ea5e4b078.png)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：这张图对应 §2.2 Challenge 1（架构不完整性中的"运行时行为层面"），证据类型为**问题严重性**（同时兼具**对比基线**角色）。正文明确指出："Ignoring CUDA Graph therefore yields an eager-style execution path and the workload-insensitive TPOT surface in Figure 2"，即图2用于展示：若不把 CUDA Graph 当作一等公民建模（而是当作解析补丁/直接忽略），现有仿真器（Vidur、AIConfigurator）预测的 TPOT 会与 vLLM 实测值产生系统性偏差 `[正文支持, 页码：2-3]`。
   - **图表角色**：问题严重性 / 对比基线
   - **上文呼应**：第 2.2 节 Challenge 1；对应主张地图"运行时优化必须作为一等公民而非解析补丁"

2. **图像类型与布局**：双面板并列柱状图。左面板标题"Co-located Serving"，右面板标题"PD Disagg. Serving"。每个面板 x 轴为四种 workload（ISL/OSL：2048/256、256/2048、512/512、1024/1024），左面板每组含三根柱（蓝色斜纹 vLLM CUDA Graph、橙色 Vidur、绿色 AIConfigurator，按图例标注），柱顶标注带符号百分比；右面板每组仅可见蓝色斜纹柱与柱顶百分比标签，柱底附近另有一个红色"×"标记。

3. **如何阅读**：y 轴为 TPOT（ms，左面板 0–20，右面板 0–15），x 轴为四种 workload 组合。柱高代表各来源（vLLM 实测 / 各仿真器预测）的 TPOT 数值，柱顶百分比按图题"Percentages represent error"表示该柱相对 vLLM 实测柱的预测误差。

4. **直接可见的结论**：
   - 左面板：四组 workload 中，橙色（Vidur）柱均高于蓝色（vLLM）柱，标注为正误差（+48.5%、+34.6%、+61.0%、+41.8%）；绿色（AIConfigurator）柱均低于蓝色柱，标注为负误差（-43.7%、-46.4%、-31.8%、-46.4%）`[图像直接可见]`。
   - 右面板：仅可见蓝色柱与柱顶百分比标签（约 27.8%、16.5%、9.7%、11.3%），未见对应橙色柱；每组柱底附近有一个红色"×"标记 `[图像直接可见]`。橙色（Vidur）柱在右面板中缺失，红叉可能代表该来源在此设置下未产生可绘制数值 `[基于视觉的谨慎推断]`。

5. **它验证的论点与方法设计含义**：本图属于**问题严重性**类证据，验证的是"现有仿真器若不将 CUDA Graph 建模为一等公民（而是解析补丁式处理），会产生结构性、随 workload 变化不敏感的 TPOT 误差"这一必要性主张 `[正文支持, 页码：2-3]`。左面板显示 Vidur 与 AIConfigurator 分别在正、负两个方向上偏离 vLLM 实测值（而非单一方向的固定偏移），说明二者的误差并非简单比例缩放，支持了正文"AIConfigurator 甚至可能预测出错误的优化趋势"及"标量加速因子无法捕捉 CUDA Graph 耦合效应"的论断，进而为 Frontier 的 Runtime Adapter 设计（把 CUDA Graph 填充与图重放的耦合效应同时建模）提供了必要性依据 `[正文支持, 页码：2, 6]`。右面板中橙色柱（Vidur）的缺失与红叉标记，结合 Table 1 中 Vidur 在"PDD Serving"一行标记为 ✗，可关联为"单体副本抽象无法表达 PDD"这一架构完整性 limit 的间接佐证 `[基于文中逻辑的推断，推理依据：Table 1 中 Vidur 于 PDD Serving 标记 ✗ -> 与图中右面板缺失橙色柱一致, 页码：2]`；但该图本身不能证明 Frontier 自身在此设置下的预测精度（Frontier 自身精度由 Figure 1、Figure 9 等其他图独立验证）。

6. **适用范围与证据缺口**：本图基于 8×A800-SXM GPU、vLLM v0.10.2（V1 引擎）、64 requests/workload 的四种 ISL/OSL 组合测试设置（与 Figure 1 同一测试环境）`[正文支持, 页码：3]`。证据缺口：右面板中红色"×"标记的确切含义（是否等同于"该来源在该图中未被绘制"）及绿色（AIConfigurator）柱在右面板中是否与蓝色柱重叠/未单独绘出，图像像素本身无法明确区分，正文亦未逐一说明右面板的柱构成细节，故对应归属无法完全确认。

---

## 图片 2：Figure 4. Fidelity gaps caused by simplified modeling. Left: Relying on coarse proxies (total token count) fails to capture batch heterogeneity, yielding coarse-grained performance estimates. Right: Analytical KV-cache modeling overestimates effective memory budget, leading to a cascade of errors from admission control to over-optimistic throughput projection.

![Figure 4. Fidelity gaps caused by simplified modeling. Left: Relying on coarse proxies (total token count) fails to capture batch heterogeneity, yielding coarse-grained performance estimates. Right: Analytical KV-cache modeling overestimates effective memory budget, leading to a cascade of errors from admission control to over-optimistic throughput projection.](../figure-groups/page-0003-5530874f0d8e.png)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本组对应 §2.2 Challenge 2（决策级精度缺失），证据类型为**问题严重性**。正文明确将其描述为"Fidelity gaps caused by simplified modeling"，用于展示两类既有做法的系统性误差：(a) 粗粒度 token 计数代理算子预测器的误差分布，(b) "总减权重"式解析 KV-cache 模型对可用内存预算与吞吐的高估 `[正文支持, 页码：2, 4]`。
   - **图表角色**：问题严重性
   - **上文呼应**：第 2.2 节 Challenge 2；对应主张地图"KV-cache 内存模型必须基于运行时 profile 而非解析估算"及算子预测精度相关论证

2. **图像类型与布局**：三面板组合。Panel 1 为累积分布函数（CDF）曲线图，含三条线（蓝色 Linear ops、橙色 GroupedGEMM、绿色 Attention），并附文字标注各自的中位数/均值误差。Panel 2 为柱状图"KV Budget"，两组（Llama3.1-8B、Qwen3-30B）各含蓝色斜纹 Groundtruth 柱与橙色 Analytical 柱，柱顶标注正百分比。Panel 3 为柱状图"Throughput"，同样两组模型、Groundtruth 与 Analytical 两色柱，柱顶标注正百分比。

3. **如何阅读**：Panel 1 x 轴 Error(%)（0–200），y 轴 CDF（0–1.0），曲线越靠左上方表示该算子类别预测误差越集中在低值区。Panel 2 y 轴为 KV budget (GB)（0–40），比较 Groundtruth 与 Analytical 两柱高度差即误差幅度。Panel 3 y 轴为 Normalized Value，比较两模型下 Groundtruth（<1）与 Analytical（=1，作为归一基准或反之）柱高差异。

4. **直接可见的结论**：
   - Panel 1：Linear ops 曲线最靠左（标注 med 0.8%/mean 3.2%），GroupedGEMM 次之（med 19.8%/mean 21.0%），Attention 曲线最靠右、爬升最慢（med 22.3%/mean 32.6%）`[图像直接可见]`。
   - Panel 2：两模型的 Analytical（橙色）柱均高于 Groundtruth（蓝色）柱，标注 +8.1%（Llama3.1-8B）与 +27.2%（Qwen3-30B）`[图像直接可见]`。
   - Panel 3：两模型的 Analytical 柱（归一至 1.0）均高于 Groundtruth 柱，标注 +23.6%（Llama3.1-8B）与 +32.4%（Qwen3-30B）`[图像直接可见]`。

5. **它验证的论点与方法设计含义**：本组图属于**问题严重性**证据，直接对应正文数值："token-count proxies can cause 32.6% errors on FlashAttention and 21.0% on MoE GroupedGEMM, while 'total minus weights' memory models overestimate KV-cache budget by up to 27.2% and throughput by up to 32.4%" `[正文支持, 页码：2, 4]`。Panel 1 显示粗粒度 token 计数代理对 Attention、GroupedGEMM 两类算子的预测误差显著高于 Linear 算子，支持了"批组成的序列依赖性/路由依赖性若被平均掉会产生大误差"这一机制论点，是 Frontier 采用序列依赖、路由依赖两类随机森林预测器设计的必要性依据 `[正文支持, 页码：4, 6]`。Panel 2、3 显示解析式 KV-cache 模型（总内存减权重）对预算与吞吐的连锁高估，验证了"闭环系统中内存预算误差会被放大为准入/吞吐层面的决策级错误"这一机制主张，是 Frontier 采用"vLLM 风格 dummy profile run"内存容量模型的必要性依据 `[正文支持, 页码：4, 6]`。该图本身未证明 Frontier 自身预测精度能达到多少（Frontier 自身精度由 Figure 7、Table 4 等独立呈现），仅证明旧方法（粗代理/解析模型）存在上述误差。

6. **适用范围与证据缺口**：本图基于"scheduler-isolation replay"实验设置，覆盖 Llama-3.1-8B（dense）与 Qwen3-30B MoE 两个模型；Panel 1 的算子误差来自"same population"拟合的 token-count 代理预测器（对应 Vidur 式方法）`[正文支持, 页码：4]`。无额外证据缺口——图中数值与正文页4/页2给出的百分比逐一对应，图题与正文未冲突，且图像未见像素遮挡或不可辨认区域。
