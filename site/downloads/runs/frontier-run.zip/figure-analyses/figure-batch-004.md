# 图片批次 4

## 图片 1：Table 6. Speculative decoding (MTP) fidelity on Qwen30B MoE under SharedGPT.

![Table 6. Speculative decoding (MTP) fidelity on Qwen30B MoE under SharedGPT.](../assets/imgs/img_in_chart_box_634_444_893_620.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图对应论文正文关于前缀缓存（prefix caching）保真度的评估陈述——"Figure 10 reports cumulative prefix hit ratios on Qwen3-30B MoE under co-location and PDD with vLLM's block-hash prefix cache enabled. Frontier matches vLLM's final hit ratios exactly: 36.98% under co-location and 37.11% under PDD"`[正文支持, 页码：9]`。它验证的是 Fidelity Plane / 运行时适配器建模中"前缀缓存作为 block-hash 索引重塑调度器可见准入状态"这一具体机制设计是否能复现真实引擎的缓存命中动态，而非泛泛展示"性能好"。
   - **图表角色**：实验结论
   - **上文呼应**：对应"实验、指标与文字可确认的结论"中"前缀缓存命中率精确匹配：共置 36.98% vs PDD 37.11%"一条`[实验支持, 页码：9]`；呼应模块 2（执行面/运行时适配器）中前缀缓存的建模设计。
   - 说明：图片候选图注标注为"Table 6"，但经视觉核对，该图实际内容为折线图（Prefix-Cache Hit Ratio Timeline），与正文 Figure 10 的图题描述一致，故按 Figure 10 分析，候选图注与图像内容不符`[基于视觉的谨慎推断]`。

2. **图像类型与布局**：双面板折线图（非表格）。上面板标题"Co-located Serving"，下面板标题"PPD Serving"；每个面板内绘制两条曲线（vLLM 与 Frontier），仅上面板给出图例。

3. **如何阅读**：横轴为 Runtime seconds (s)，上面板范围约 0–17.5s，下面板约 0–7s；纵轴均为 Hit Ratio，范围约 0.2–0.6+。需比较同一面板内 vLLM（橙色）与 Frontier（蓝色）两条曲线随时间的重合程度，而非跨面板比较绝对数值。

4. **直接可见的结论**：两个面板中 vLLM 与 Frontier 曲线在整个观测时间窗口内高度重叠，锯齿状波动趋势（命中率随请求到达/淘汰起伏）也基本同步；末端数值两条线趋于接近的稳定水平`[图像直接可见]`。下面板（PDD）曲线整体波动幅度和抖动看起来比上面板（共置）更剧烈`[基于视觉的谨慎推断]`。

5. **它验证的论点与方法设计含义**：可见的曲线高度重合直接支持正文"Frontier matches vLLM's final hit ratios exactly"这一实验结论`[正文支持, 页码：9]`，说明将前缀缓存建模为"block-hash 索引标记已计算前缀块、从而重塑调度器可见准入状态"这一设计（而非存储实际 KV 张量）足以复现真实引擎的块级命中/未命中序列与准入行为`[正文支持, 页码：9]`。这属于"实验结论"类证据，支撑模块 2（运行时适配器）的必要性主张，但仅验证命中率时间序列的匹配度，不能反过来证明前缀缓存对下游 TTFT/吞吐等指标的具体影响幅度（该部分由其他图表/表格覆盖）。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 Qwen3-30B MoE 模型、vLLM block-hash 前缀缓存、共置与 PDD 两种服务架构下的命中率时间曲线`[正文支持, 页码：9]`。图像分辨率下无法读出曲线上具体数值刻度对应的误差百分比（仅正文给出 36.98%/37.11% 的终值数字），属于图像裁剪/分辨率导致的真实缺口；除此之外无额外证据缺口。

---

## 图片 2：Figure 9. Decode throughput. +CG bars stack eager throughput with the CUDA Graph gain; top labels show total +CG/eager speedup.

![Figure 9. Decode throughput. +CG bars stack eager throughput with the CUDA Graph gain; top labels show total +CG/eager speedup.](../assets/imgs/img_in_chart_box_637_148_850_306.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文"Figure 9 and Table 5 report decode throughput and compute-participating token counts for Qwen3-30B MoE under vLLM's full_decode_only capture path on SharedGPT. Frontier matches vLLM's decode speedup within 1.7% under co-location and 6.1% under PDD, preserving the 2.86–3.05× envelope"`[正文支持, 页码：9]`，验证的具体问题是：CUDA Graph 这一运行时优化被建模为"调度器-批处理引擎循环内一等公民适配器"（而非标量加速因子）后，能否复现 vLLM 真实的 eager vs +CG 解码吞吐提升幅度。
   - **图表角色**：实验结论
   - **上文呼应**：对应"实验、指标与文字可确认的结论"中"CUDA Graph 解码加速匹配 vLLM，误差 1.7%（共置）/6.1%（PDD）"一条`[实验支持, 页码：9]`；呼应模块 2（执行面）中"CUDA Graph 填充增加计算量 vs 图重放去除启动开销"耦合效应建模的技术优势陈述`[正文支持, 页码：6]`。

2. **图像类型与布局**：柱状图，标题"Throughput w/o CG"。横轴分两组："Co-location"和"PDD"，每组下再分"vLLM"、"Frontier"两根柱；每根柱用斜纹填充表示 eager（无 CUDA Graph）部分，实心填充表示 +CG（CUDA Graph 增益）部分堆叠在其上；柱顶标注数值（如"2.95 2.90"、"3.05 2.86"）。图例区分 vLLM eager/+CG（橙色系）与 Frontier eager/+CG（蓝色系）。

3. **如何阅读**：纵轴为 Decode tokens / sec；应在同一组（Co-location 或 PDD）内比较 vLLM 与 Frontier 两根柱的总高度（eager+CG 堆叠总量）及柱顶标注的加速倍数是否接近，而非跨组直接比较绝对吞吐值。

4. **直接可见的结论**：Co-location 组内 vLLM 与 Frontier 柱子总高度及柱顶标注（2.95 与 2.90）接近；PDD 组内两者标注（3.05 与 2.86）也处于同一数值区间，且两组的 eager/+CG 分层比例在 vLLM 与 Frontier 之间形态相近`[图像直接可见]`。PDD 组整体柱高普遍高于 Co-location 组`[图像直接可见]`。

5. **它验证的论点与方法设计含义**：柱顶加速倍数在 vLLM 与 Frontier 之间的接近，直接支持正文所述"Frontier matches vLLM's decode speedup within 1.7%/6.1%，preserving the 2.86–3.05× envelope"这一实验结论`[正文支持, 页码：9]`，说明将 CUDA Graph 的"批量填充增加计算量"与"图重放去除启动开销"两个耦合效应同时建模（而非用单一标量加速因子）能够复现真实引擎的净吞吐增益`[正文支持, 页码：6, 9]`。这属于验证模块 2（运行时适配器为一等公民而非解析补丁）必要性主张的直接证据；但该图本身不能证明"若去掉适配器、退化为解析补丁"会产生多大误差——论文未提供对应消融实验`[无法从当前 OCR 内容确认, 页码：9]`。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 Qwen3-30B MoE 模型、SharedGPT 负载、vLLM full_decode_only 捕获路径下共置与 PDD 两种架构的解码吞吐对比`[正文支持, 页码：9]`。柱顶具体填充token数量、Padding/Inflation 的细分数值需参照 Table 5 而非本图，图像本身无法读出比正文所报告数字更精细的层级（如误差的具体来源分解），此为图像信息粒度导致的真实缺口；除此之外无额外证据缺口。
