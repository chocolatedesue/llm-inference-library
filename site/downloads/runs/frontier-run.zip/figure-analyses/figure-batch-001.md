# 图片批次 1

## 图片 1：Figure 1. Measured vLLM TPOT with and without CUDA Graph under different workloads (64 requests per workload, mean ISL/OSL, tested on 8×A800-SXM GPUs). Left: co-location. Right: PDD. Percentages show reduction.

![Figure 1. Measured vLLM TPOT with and without CUDA Graph under different workloads (64 requests per workload, mean ISL/OSL, tested on 8×A800-SXM GPUs). Left: co-location. Right: PDD. Percentages show reduction.](../assets/imgs/img_in_chart_box_106_143_380_239.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本图对应 §2.2 Challenge 1（"如何建模先进服务系统的复杂运行时行为与控制流"）中"完整性在运行时行为层面失效"的论证段落。作者用它证明：CUDA Graph 并非可有可无的"加速旋钮"，而是会显著改变解码延迟的关键因素，因此仿真器必须将其作为一等公民建模，而不是事后打补丁的"解析补丁" `[正文支持, 页码：3]`。
   - **图表角色**：问题严重性——量化 CUDA Graph 在真实 vLLM 系统中造成的延迟差异幅度，为"运行时优化必须被一等公民建模"这一必要性主张提供实测支撑证据。
   - **上文呼应**：对应 §2.2 "Completeness also breaks at the runtime-behavior level" 段落，与 Table 2（CUDA Graph 填充开销）配套，共同支撑"忽略 CUDA Graph 会产生 eager 式执行路径和 workload-insensitive TPOT 曲面（Figure 2）"这一推论链条 `[正文支持, 页码：3]`。

2. **图像类型与布局**：柱状图，左右两个子面板并排。左侧标题 "Co-located Serving"，右侧标题 "PD Disagg. Serving"。每个面板内以 4 组（对应 4 种 ISL/OSL 工作负载）成对柱子呈现，每组两根柱子分别为深色斜纹柱（vLLM Eager）与浅色柱（vLLM CUDA Graph），柱顶标注百分比数字。

3. **如何阅读**：纵轴为 TPOT（ms），横轴为四种工作负载（Workload, ISL/OSL）：2048/256、256/2048、512/512、1024/1024。图例区分"vLLM Eager"（无 CUDA Graph）与"vLLM CUDA Graph"两种柱子；每组柱顶的百分比表示从 Eager 到 CUDA Graph 的 TPOT 降低比例 `[图像直接可见]`。

4. **直接可见的结论**：在左右两个面板的全部四种工作负载下，CUDA Graph 柱（浅色）均低于 Eager 柱（深色斜纹），即开启 CUDA Graph 后 TPOT 一致性下降；柱顶标注的百分比数字表明降幅在各工作负载间存在差异，且右侧（PDD）面板柱子普遍高于左侧（共置）面板对应柱子的绝对高度 `[图像直接可见]`。各面板内四组工作负载之间的降幅百分比不完全相同，存在工作负载依赖性 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图支持"运行时优化改变调度器可见状态与批执行语义，必须作为一等公民建模"这一必要性类主张——正文明确给出的降幅区间（共置 32.3%–46.5%，PDD 37.1%–59.7%）与图中可见的"CUDA Graph 柱普遍显著低于 Eager 柱"这一趋势方向一致 `[正文支持, 页码：3]`。该图本身只展示 TPOT 的净效果，并不能单独证明"填充开销"这一负面耦合效应的存在——填充侧的证据由同页 Table 2（Padding/Inflation 数值）单独提供，二者组合才共同论证"CUDA Graph 是一个耦合效应而非纯粹的加速旋钮"这一机制类主张，这一点该图无法单独证明 `[正文支持, 页码：3]`。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 8×A800-SXM GPU 服务器、每工作负载 64 个请求、mean ISL/OSL 设置，测量对象为 vLLM 实测 TPOT（非 Frontier 仿真输出）。柱顶具体百分比数字在图片分辨率下部分字符较难精确辨读，属图像裁剪/分辨率导致的数值确认缺口；除此之外无额外证据缺口。

---

## 图片 2：Figure 3. Qwen3-30B MoE MTP decode speedup (verify_tokens=4). Bars (left axis): vLLM vs. AIConfigurator. Dashed line: prediction error. Red ×: sign-mismatch (measured speedup > 1, predicted slowdown

![Figure 3. Qwen3-30B MoE MTP decode speedup (verify_tokens=4). Bars (left axis): vLLM vs. AIConfigurator. Dashed line: prediction error. Red ×: sign-mismatch (measured speedup > 1, predicted slowdown](../figure-groups/page-0003-44aea4d244c2.png)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本图对应 §2.2 Challenge 1 中"分析式捷径同样会失效"（Analytical shortcuts fail similarly）的论证，即使 AIConfigurator 使用了 vLLM 实测的逐步验收率，其标量期望式的 MTP 解析模型仍会产生大误差、并在低验收率下预测出与实测相反的趋势 `[正文支持, 页码：3-4]`。
   - **图表角色**：对比基线——直接对照 vLLM 实测解码加速与 AIConfigurator 预测值，检验后者在投机解码建模上的具体失效条件（尤其低验收率场景）。
   - **上文呼应**：对应第 4 页正文 "an analytical MTP model deviates by 27.2%–66.6% and predicts the opposite trend on 4 of 5 low-acceptance batches"，用于论证"标量期望公式压平了事件驱动可变提交的非线性加速"这一机制类主张 `[正文支持, 页码：3-4]`。

2. **图像类型与布局**：双面板柱状图＋折线图组合。左面板标题 "Acceptance Ratio: 20%"，右面板标题 "Acceptance Ratio: 80%"；每个面板内每个 Batch Size 分组含两根柱（蓝色斜纹 = vLLM，橙色 = AIConfigurator），柱顶标注具体数值，另有红色虚线＋圆点标出对应的 Error（右侧次坐标轴，单位 %）。

3. **如何阅读**：左纵轴为 Decode speedup（倍数），右纵轴为 Error（%），横轴为 Batch Size（1、2、8、16、32）。图例区分 vLLM 实测柱、AIConfigurator 预测柱、红色误差折线；应比较同一 Batch Size 下 vLLM 柱高度与 AIConfigurator 柱高度的相对关系，以及柱值是否跨越"1.0"这一加速/减速分界线 `[图像直接可见]`。

4. **直接可见的结论**：在 AR=20% 面板中，Batch Size 1 和 2 时 vLLM 柱值（1.4、1.7）大于 1（表示实测有加速），而对应的 AIConfigurator 柱值（0.6、0.6）小于 1（表示预测反而减速），两者方向相反；Batch Size 32 时 vLLM（0.9）与 AIConfigurator（0.7）同为小于 1，方向一致但数值差距仍存在。误差折线在 Batch Size=2 处达到该面板局部峰值 `[图像直接可见]`。在 AR=80% 面板中，vLLM 柱值全部明显大于 1（3.8–3.4–3.3–3.1–2.8），AIConfigurator 柱值全部明显小于 vLLM 柱值（1.6–1.5–1.4–1.5–1.7），但两者方向一致（均表示加速），误差折线整体处于较低且随 Batch Size 增大而略有下降后回升的走势 `[图像直接可见]`。两个面板对比可见，AR=20% 面板下 vLLM 与 AIConfigurator 柱值的方向不一致情形比 AR=80% 面板更明显 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图为机制类主张提供直接证据——在低验收率（AR=20%）下，AIConfigurator 的解析式 MTP 模型不仅数值误差大，还会在部分 Batch Size 下给出与实测方向相反的结论（vLLM 显示加速，AIConfigurator 预测减速），这正是正文所述"预测出错误的优化趋势"的具体体现，支撑"标量期望公式无法捕捉事件驱动可变提交的非线性加速"这一必要性主张，进而论证 Frontier 采用逐请求 planned/verified/accepted/committed 状态跟踪的投机解码适配器设计动机 `[正文支持, 页码：3-4, 5-6]`。该图仅覆盖 AIConfigurator 一个比较对象，不能推广为"所有既有仿真器的投机解码建模都会犯同类错误"的一般性结论；AIConfigurator 试图解决的原始问题（结合算子数据库和解析工作流、在 TensorRT-LLM/H200 上原本"有效"）与本图批判的具体 limit（标量期望公式压平非线性加速、在低接受率下预测错误趋势）需分开理解，本图只检验后者，不涉及其在原生 TensorRT-LLM/H200 场景下的表现 `[正文支持, 页码：9]`。

6. **适用范围与证据缺口**：本证据覆盖论文明确说明的设置——Qwen3-30B MoE、verify_tokens=4、8×A800 GPU 服务器（Unless specified 段落），且使用"ground-truth acceptance rates and fixed batch sizes"以隔离其他建模误差，仅针对 AR=20%/80% 两组验收率与 Batch Size {1,2,8,16,32} `[正文支持, 页码：3]`。正文图注提到"Red ×: sign-mismatch"标记，但在当前图像像素中未能清晰辨识出红色×符号标记本身（是否存在或具体位于哪些柱子上），仅能通过柱值本身判断方向是否相反，这属于图像裁剪/像素确实遮挡导致的信息缺口。
