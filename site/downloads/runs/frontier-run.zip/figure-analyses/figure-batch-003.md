# 图片批次 3

## 图片 1：Figure 5. Decision drift from fidelity gaps on Llama-3.1-8B over 16 H800 GPUs (co-location). The simulator-selected best configuration lies inside the frozen SLA region, but the corresponding vLLM ground-truth point moves outside the SLA because overly optimistic comp-op and KV-cache budget predictions underestimate request latency. Note that we maintain feature parity in this evaluation by disabling vLLM optimizations unsupported by APEX.

![Figure 5. Decision drift from fidelity gaps on Llama-3.1-8B over 16 H800 GPUs (co-location). The simulator-selected best configuration lies inside the frozen SLA region, but the corresponding vLLM ground-truth point moves outside the SLA because overly optimistic comp-op and KV-cache budget predictions underestimate request latency. Note that we maintain feature parity in this evaluation by disabling vLLM optimizations unsupported by APEX.](../assets/imgs/img_in_chart_box_137_143_551_348.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Figure 5,是 Challenge 2("决策级精度缺失")论证链条的收尾证据——用一个具体案例说明"仿真器的粗糙精度如何在闭环系统中放大为决策错误"。证据类型为**问题严重性**:它验证的具体问题是"仿真器选中的'最优配置'能否在真实系统上仍然满足 SLA"。`[正文支持]`
   - **图表角色**:问题严重性
   - **上文呼应**:对应第 4 页正文 Challenge 2 结尾段"As Figure 5 shows, optimistic operator-runtime and KV-cache budget predictions can lead the simulator to select a 'best' configuration that violates the SLA on the real system"。

2. **图像类型与布局**:散点图 + 一条连接两点的强调线。横轴 P95 TTFT (ms),左纵轴 P95 TPOT (ms),右纵轴为颜色编码的 APEX throughput (req/s)。图中包含:蓝色圆点(APEX candidates,密集分布在左下方)、金色五角星(APEX best,单点)、红色三角(vLLM ground truth,单点)、绿色阴影区域(标注为 "SLA Region")、虚线(Frozen SLA 边界)、以及一条红色箭头线连接金色星与红色三角,旁标注文字。图内还有一个信息框:"76 APEX candidates pass SLA, Best: qps=16, tp=8, dp=2, max seqs=32"。

3. **如何阅读**:横轴越靠右表示 TTFT 越大(越差),纵轴越靠上表示 TPOT 越大(越差)。绿色阴影区(SLA Region)为满足 SLA 的可行域,由虚线(Frozen SLA)划出边界。蓝点是 APEX 仿真器评估的候选配置集合(其模拟位置)。金色星是 APEX 认为的最优配置(其仿真预测位置),红色三角是同一配置在真实 vLLM 上实测得到的位置。红线上的标注 "ΔTTFT=+17.54 ms, ΔTPOT=+8.53 ms" 是该配置从仿真预测位置到真实测量位置的偏移量。

4. **直接可见的结论**:APEX candidates(蓝点)绝大多数落在绿色 SLA 区域内且偏左下;APEX best(金色星)位于 SLA Region 边界附近、仍在或紧贴可行域内;而同一配置的 vLLM ground truth(红色三角)明显落在 SLA Region 右上方之外,即绿色阴影区与虚线边界之外;标注文字 "vLLM violates SLA" 直接标示该点越过了 SLA 边界;红线连接两点,量化两者在 TTFT/TPOT 上的差距。`[图像直接可见]`

5. **它验证的论点与方法设计含义**:该图直接支持"效果类"主张——现有仿真器(APEX)的粗糙精度会导致"决策漂移"(decision drift):仿真选中的最优配置在仿真视角下满足 SLA,但在真实部署中违反 SLA。这是 Challenge 2 中"per-operator/per-batch 误差在闭环系统中放大为决策错误"这一论点的具体可视化实例,直接呼应正文"can shift TTFT/TPOT...across SLA boundaries...and lead to the wrong configuration choice"。它为 Frontier 引入"保真面(Fidelity Plane)"、用校准的硬件感知预测器替代粗糙代理这一设计动机提供了具体反面案例。需注意:该图本身只展示 APEX 这一个基线仿真器的失败案例,不能证明"所有仿真器"或"Frontier 自身"在同等条件下的表现如何——Frontier 是否能避免此类漂移需由其他图(如 Figure 11 的端到端保真度)佐证,而非本图。`[正文支持]`

6. **适用范围与证据缺口**:本证据覆盖论文报告的 Llama-3.1-8B 模型、16×H800 GPU、co-location 架构这一特定实验设置(正文图题明确说明),且正文特别注明"为保持特征对等,本次评估禁用了 APEX 不支持的 vLLM 优化项"。无额外证据缺口。

---

## 图片 2：Figure 6. Frontier system architecture.

![Figure 6. Frontier system architecture.](../assets/imgs/img_in_image_box_665_149_1083_702.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**:本图对应 Figure 6,是 Frontier 整体系统架构的**方法流水线**图,回答"Frontier 的四个模块如何组织、彼此如何交互以支撑从用户配置到仿真执行的完整流程"这一机制性问题,而非验证某个实验数值主张。`[正文支持]`
   - **图表角色**:方法流水线
   - **上文呼应**:对应第 4-5 页 §3.1 "Simulator Overview" 中"System architecture. Figure 6 shows the system architecture. Frontier is organized into four modules..."一段的逐模块文字描述。

2. **图像类型与布局**:系统架构示意图,分为四个带编号标题的框:① Workload & Config(左上,浅绿色)、② Fidelity Plane(右上,浅绿色)、③ Control Plane(中部,内含 Global Controller、Sim. Compiler、Metric Tracker、Cluster Worker/Sim. Event Driver/Replica Worker 的嵌套框)、④ Execution Plane(下部,内含 Request Queue、Scheduler、Model Runner[KV-Cache Manager、Batch Engine]、Runtime Adapter[CUDA Graph Dispatcher、SpecDecode Runtime、Block-Hash Prefix Cache、Chunked Prefill]),右侧标注 "Transfer Trigger"。模块间用箭头(灰色粗箭头、双向箭头、虚线)连接,颜色区分层级(浅绿色顶层框、深绿色子模块)。

3. **如何阅读**:按编号①→④顺序阅读,代表配置输入到执行输出的流程方向;顶部①②为输入/预测支持层,中部③为控制/编排层,底部④为实际逐请求执行层;箭头方向表示模块间数据/调用关系(如①指向③的粗箭头,③与④之间及④内部各子框间的箭头,④右侧 Transfer Trigger 的位置提示跨集群传输由此触发)。

4. **直接可见的结论**:图中清晰展示四个顶层模块及各自内部子组件的命名和层级嵌套关系(如 Control Plane 内的 Cluster Worker 里嵌套 Replica Worker;Execution Plane 内 Runtime Adapter 并列四类具体适配器:CUDA Graph Dispatcher、SpecDecode Runtime、Block-Hash Prefix Cache、Chunked Prefill);模块间以带方向的箭头连接,顶部①②与③之间为双向箭头,③到④为向下箭头。`[图像直接可见]`

5. **它验证的论点与方法设计含义**:该图是**机制类**证据,直接可视化正文 §3.1 对四模块职责的文字描述(Workload & Config 定义场景、Fidelity Plane 提供校准预测、Control Plane 编译并协调仿真拓扑、Execution Plane 推进请求生命周期),并具体呈现了论文核心设计原则——"控制面/保真面分离"以及"运行时适配器作为调度器-批处理引擎循环内的一等公民"(图中 Runtime Adapter 与 Model Runner 并列且双向箭头连接,而非作为外部速度加成项)。它帮助读者建立对 §3.2-3.4(Control Plane、Execution Plane、Fidelity Plane 各节)技术细节的整体框架认知,但图本身不包含任何精度或性能数值,不能单独证明架构设计的有效性——该有效性由 §5、§6 的实验图表(如 Figure 7-12)提供。`[正文支持]`

6. **适用范围与证据缺口**:本图展示的是 Frontier 系统的通用架构,不针对特定模型/硬件/工作负载的实验设置,因此不存在"实验覆盖范围"的适用边界问题。无额外证据缺口。
