# 图片批次 6

## 图片 1：Table 5. Compute-participating token accounting on Qwen3-30B MoE. E: eager; CG: CUDA Graph. Eager Frontier is +0 (0%) for all rows; CG Frontier is the signed delta to vLLM.

![Table 5. Compute-participating token accounting on Qwen3-30B MoE. E: eager; CG: CUDA Graph. Eager Frontier is +0 (0%) for all rows; CG Frontier is the signed delta to vLLM.](../assets/imgs/img_in_chart_box_868_184_1113_277.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：这是效果类实验结论证据，验证 Frontier 的 CUDA Graph Runtime Adapter 能否准确复现 vLLM 在 CUDA Graph 模式下因"批量对齐"造成的参与计算 token 数膨胀。对应第 5.2 节"Runtime Optimization Fidelity — CUDA Graph"，直接支撑正文陈述"its padded token count tracks vLLM within 2.55% across prefill-heavy, decode-heavy, and SharedGPT workloads"（第 9 页）`[正文支持]`。
   - **图表角色**：实验结论（同时为"运行时优化须作为一等公民建模"这一必要性主张提供支撑证据）。
   - **上文呼应**：第 5.2 节 CUDA Graph fidelity；与 Figure 9（decode throughput）、Table 6（投机解码）共同构成该节的运行时优化保真度证据组。

2. **图像类型与布局**：表格（Table 5）。列为 Arch.（Co-loc. / Disagg.）、Workload（Prefill-heavy / Decode-heavy / SharedGPT）、E-vLLM（eager 模式下 vLLM 实测的参与计算 token 数）、CG-vLLM（CUDA Graph 模式下 vLLM 实测的参与计算 token 数）、ΔFrontier（Frontier 对 CG 模式 token 数预测相对 vLLM 的误差，以数值差+百分比形式给出）。表格分两大行组（Co-loc.、Disagg.），每组各含三种 workload 的一行。

3. **如何阅读**：每行对应一个（架构, workload）组合；对比 E-vLLM 与 CG-vLLM 两列可看出 CUDA Graph 批量填充带来的 token 数增量；ΔFrontier 列衡量 Frontier 对 CG-vLLM 这一膨胀后 token 数的预测误差。图题所述"Eager ΔFrontier 对所有行均为 +0 (0%)"未在表中单列出现，说明表中仅展示的是 CG 模式误差列。因图像分辨率有限，部分具体数值（尤其小数位）辨识存在不确定性。

4. **直接可见的结论**：CG-vLLM 列数值整体高于同行的 E-vLLM 列，体现 CUDA Graph 填充增加了参与计算的 token 数 `[图像直接可见]`；ΔFrontier 列中各行的百分比误差在视觉上均处于个位数或更低范围，未见明显偏离小误差区间的行 `[基于视觉的谨慎推断，具体小数位因图像清晰度限制无法逐位确认]`。

5. **它验证的论点与方法设计含义**：属于效果类主张——证明 Frontier 的 CUDA Graph 适配器（把批填充建模为改变 Fidelity Plane 查询批形状的一等公民机制，而非标量加速因子）能以低误差复现 vLLM 的批量对齐膨胀效应，与正文"within 2.55%"的量化陈述一致 `[正文支持]`。方法设计含义：该表是 §3.3 中"CUDA Graph 的填充增加计算量 vs 图重放去除启动开销"这一耦合效应建模思路的直接数值佐证，支持"运行时优化必须作为一等公民建模"这一必要性论点。该表本身**不能**证明端到端延迟/吞吐的整体保真度或跨架构泛化能力，那部分由 Figure 9、Figure 11 承担。

6. **适用范围与证据缺口**：本表覆盖 Qwen3-30B MoE 模型、co-location 与 disaggregated（PDD）两种架构、Prefill-heavy/Decode-heavy/SharedGPT 三种 workload，在 vLLM full_decode_only capture 路径下测得（第 9 页正文）。证据缺口：表中数字字号较小、部分位数因分辨率原因不能逐位精确确认，无法独立核实每行误差的最后一位小数，但不影响对"误差整体处于低个位数范围"这一趋势判断。

---

## 图片 2：Figure 11. End-to-end fidelity on a 16-card H800 testbed for co-location and PDD across prefill-heavy, decode-heavy, balanced, and SharedGPT workloads. Panels report TTFT, TPOT, throughput, and E2E makespan for both Llama3.1-8B (dense) and Qwen3-30B MoE; dashed bars indicate simulators that do not support the serving architecture or model family. All data are normalized against the ground truth (vLLM), represented by the black line (y=1.0).

![Figure 11. End-to-end fidelity on a 16-card H800 testbed for co-location and PDD across prefill-heavy, decode-heavy, balanced, and SharedGPT workloads. Panels report TTFT, TPOT, throughput, and E2E makespan for both Llama3.1-8B (dense) and Qwen3-30B MoE; dashed bars indicate simulators that do not support the serving architecture or model family. All data are normalized against the ground truth (vLLM), represented by the black line (y=1.0).](../assets/imgs/img_in_chart_box_154_152_1063_482.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：效果类实验结论，是端到端（E2E）保真度的核心可视化证据，对比 Frontier 与四个基线仿真器（AIConfigurator、LLMServingSim2.0、Vidur、APEX）在 co-location 与 PDD 架构下的 TTFT/TPOT/吞吐/E2E makespan 误差。直接支撑摘要中"reduces end-to-end latency error from 44.9% to 6.4% under co-location and from 51.7% to 2.6% under disaggregation"以及第 5.3 节"Frontier tracks vLLM within 9.37%（co-location）/ 10.99%（PDD）across 32 cases"的量化主张 `[正文支持]`。
   - **图表角色**：实验结论 + 对比基线（同时以基线柱子缺失/×标记的形式反映"架构不完整"这一旧方法限制）。
   - **上文呼应**：第 5.3 节 End-to-End Fidelity；呼应第 1 节摘要核心量化主张与 Table 1 功能对比表。

2. **图像类型与布局**：分组柱状图矩阵。整体分 2 大行块（上：Colocated Serving，下：PDD Serving）× 4 列（Prefill-Heavy / Decode-Heavy / Balanced / SharedGPT）＝8 个大面板；每个大面板内再纵向分两个子面板（上 Dense / Llama3.1-8B，下 MoE / Qwen3-30B）；每个子面板横轴为 4 个指标分组（TTFT/TPOT/Thpt/E2E），每组内含 5 根柱子（蓝=Frontier，橙=AIConfigurator，绿斜纹=LLMServingSim2.0，紫=Vidur，红=APEX），纵轴为"归一化到 vLLM=1.0"的比值，图中有黑色虚线标示 y=1.0 基准线；部分柱顶标注"x2.x"数字表示该柱实际值超出坐标轴范围的倍数；部分位置以红色 × 替代柱子表示该模拟器不支持该配置。

3. **如何阅读**：在每个指标分组内比较各柱子与 y=1.0 虚线的接近程度——越接近 1.0 表示该模拟器该指标误差越小；某模拟器某组位置若显示红色 × 而非柱子，表示其不支持该架构/模型组合（如无法在此设置下运行）；柱顶"x2.x"标签表示该柱因超出绘图纵轴范围被截断，实际值为标注倍数。

4. **直接可见的结论**：几乎所有 8 个大面板、所有指标分组中，蓝色 Frontier 柱始终最贴近 y=1.0 虚线 `[图像直接可见]`；橙色 AIConfigurator、绿色 LLMServingSim2.0、紫色 Vidur 在 Thpt 和 E2E 分组中频繁出现远离 1.0 且带"x2.x"标注的高柱 `[图像直接可见]`；红色 APEX 在多个面板（尤其 PDD 各 workload 的多个指标分组）中整组以红色 × 缺失呈现 `[图像直接可见]`；紫色 Vidur 柱在 MoE 子面板中大量缺失或以 × 标示 `[基于视觉的谨慎推断，需结合正文"Vidur 不支持 MoE/PDD"的陈述解读该缺失/×含义]`。

5. **它验证的论点与方法设计含义**：效果类主张——该图是摘要核心量化结论（44.9%→6.4%，51.7%→2.6%）以及第 5.3 节具体数字（Frontier ≤9.37%/≤10.99% vs Vidur 2.9%–45.5%、AIConfigurator 最高 170.0%/200.0%）的直接可视化证据 `[正文支持]`。方法设计含义：图中 Vidur/APEX 在 MoE、PDD 场景下大量以 × 缺席，是"架构不完整"限制（单体副本假设无法表达 PDD 跨集群依赖、无法表达 MoE 路由）的可视化对应，与 Table 1 的功能对比表相互印证；AIConfigurator 虽能出现在更多面板中但柱子频繁远离 1.0 且常超出坐标轴，对应正文对其"CUDA Graph 捕获建模缺失"与"MTP 标量近似"的批判。该图不能单独证明具体哪个子机制（CUDA Graph、KV-cache 预算、MoE 路由等）导致某基线在某一具体柱位置的误差来源，这类归因需结合 Figure 7/8/9/10 及正文文字。

6. **适用范围与证据缺口**：本图覆盖 16×H800 测试床、Llama3.1-8B（dense）与 Qwen3-30B MoE 两个模型、co-location 与 PDD 两种架构（不含 AFD，AFD 结果见 Figure 12）、四种 workload 模式（Prefill-Heavy/Decode-Heavy/Balanced/SharedGPT），合计正文所述 32 项指标条目（按架构分别统计）。证据缺口：部分柱顶因超出坐标轴范围被截断为"x2.x"标注，其精确柱高（即精确误差百分比）无法从像素本身读出，只能依赖标注倍数间接推断；正文也仅给出各面板的汇总代表性数值（如 170.0%、135.3%、200.0%），未逐柱给出精确值，因此单柱级别的精确误差数字无法仅凭图像核实。
