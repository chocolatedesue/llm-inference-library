# 图片批次 5

## 图片 1：Figure 8. Available KV-cache blocks over time under colocation (Qwen3-30B MoE, SharedGPT trace), with a max gap of 294 blocks (115.6 MB; MB = 0.393 B, where B is the block gap).

![Figure 8. Available KV-cache blocks over time under colocation (Qwen3-30B MoE, SharedGPT trace), with a max gap of 294 blocks (115.6 MB; MB = 0.393 B, where B is the block gap).](../assets/imgs/img_in_chart_box_109_415_316_547.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图对应 Figure 8（Table 4 同组指标的时间序列版本），证据类型为**实验结论**，具体验证"KV-cache 内存预算必须基于运行时 profile（而非'总减权重'式解析估算）"这一效果主张——即 Frontier 的内存容量模型不仅在初始时刻准确（Table 4），在整个请求生命周期（准入、抢占、释放）中是否也能持续贴合真实 vLLM 的可用块数变化 `[正文支持]`。
   - **图表角色**：实验结论
   - **上文呼应**：对应 §5.1"Memory (KV-cache budget) accuracy"一节及 Challenge 2（§2.2）中"总减权重"式解析模型高估 KV-cache 预算、进而虚高吞吐的问题。

2. **图像类型与布局**：单幅折线图（曲线图），标题"KV Cache Blocks Over Time"。横轴为"Runtime seconds (s)"，纵轴为"Available KV blocks"，图中包含两条颜色区分的曲线（橙色 vLLM、蓝色 Frontier），无子图或分组。

3. **如何阅读**：横轴表示仿真/实测运行时间（秒，范围约 0–40+），纵轴表示某一时刻可用的 KV-cache 块数（单位 K，范围约 107.6K–108.0K）。应比较两条曲线在同一时间点上的重合程度与波动形态是否一致。

4. **直接可见的结论**：橙色（vLLM）与蓝色（Frontier）两条曲线在整个时间窗口内高度重叠，均呈现锯齿状反复上下波动（对应块的占用与释放），波动幅度和转折时间点基本同步；未见两条曲线出现持续性、系统性偏离 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该曲线属于**效果类**主张的直接证据，支撑正文"along the SharedGPT replay the block-availability curve of Frontier overlaps the vLLM curve through admission, preemption, and release events"的陈述，即 Frontier 的"vLLM 风格 dummy profile run"内存容量模型（§3.4）不仅初始预算准确（Table 4：≤1.89% 误差），在受调度器准入/抢占/释放驱动的动态过程中也能保持贴合，从而支持"KV-cache 预算需基于真实 profile 而非解析估算"的方法设计选择 `[正文支持]`。该图本身不能证明这种贴合度在其他模型/并行配置/工作负载模式下同样成立，也不能单独证明由此带来的下游吞吐/延迟精度提升（后者由 Figure 11 等端到端图佐证）。

6. **适用范围与证据缺口**：本图覆盖论文报告的设置——Qwen3-30B MoE 模型、co-location 架构、SharedGPT trace、最大 gap 294 blocks（115.6 MB，ΔMB=0.393ΔB）`[正文支持]`。图像本身未标注具体并行配置（pp/tp/dp/ep），正文图注也未说明对应 Table 4 中的哪一组配置，属于图注未覆盖的细节缺口；除此之外无额外证据缺口。

---

## 图片 2：Figure 7. Per-operator relative-error CDF on H800 for attention, and MoE kernels under BF16 (left) and FP8 (right). Vidur is undefined for MoE ops, and its baseline cannot be evaluated under FP8.

![Figure 7. Per-operator relative-error CDF on H800 for attention, and MoE kernels under BF16 (left) and FP8 (right). Vidur is undefined for MoE ops, and its baseline cannot be evaluated under FP8.](../figure-groups/page-0008-77f8b8fdcb20.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图为 Figure 7，是"实验结论"与"对比基线"两重证据类型的组合——一方面验证 Frontier 三类算子预测策略（尤其序列依赖的 attention 随机森林预测器）相对旧方法的精度提升，另一方面直接检验对 Vidur 的批判性 limit："token-only 代理无法刻画批内长度异质性，导致 attention 误差 32.6%、且对 MoE GroupedGEMM 无法定义"这一具体缺陷 `[正文支持]`。
   - **图表角色**：实验结论 / 对比基线
   - **上文呼应**：对应 §5.1"Operator accuracy"及 §2.2 Challenge 2 中关于 Vidur token-count 代理误差（32.6% FlashAttention、21.0% MoE GroupedGEMM）的论证。

2. **图像类型与布局**：两个并排曲线图（CDF 累积分布图），左侧标题"Ops Prediction (BF16)"，右侧标题"Ops Prediction (FP8)"。左图含三条线（图例：Frontier Attention Ops 蓝色、Frontier MoE Ops 绿色、Vidur Attention Ops 橙色）；右图仅可见两条线（无图例标注，颜色与左图蓝/绿一致），未见橙色 Vidur 曲线。

3. **如何阅读**：横轴为 Relative Error（相对误差，无量纲），纵轴为 CDF（0–1，累计概率）。应比较同一误差阈值下各曲线达到的累计概率高低——曲线越靠左上（越快逼近 1.0）代表预测误差整体越小、精度越高。左图横轴范围约 0–2.5，右图横轴范围约 0–0.4（两图横轴尺度不同，不可直接跨图比较绝对误差值）。

4. **直接可见的结论**：左图（BF16）中，蓝色（Frontier Attention）与绿色（Frontier MoE）曲线几乎重合，在相对误差约 0.2–0.3 以内已迅速逼近 CDF=1.0；橙色（Vidur Attention）曲线上升明显更慢，尾部延伸至相对误差约 2.5 附近才接近 1.0，存在长尾。右图（FP8）中仅两条线（无橙色 Vidur 曲线），二者同样几乎重合，在相对误差约 0.1–0.2 以内已接近 CDF=1.0，整体曲线更陡峭 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图是**效果类**与**必要性类**主张的直接证据。左图中 Frontier 两条曲线远快于 Vidur 曲线逼近 1.0，可视化印证正文"Frontier reaches p50/p95 errors of 3.5%/14.2% on attention…whereas Vidur's token-only attention predictor…reaches p50/p95 of 55.4%/376.1%"的数值结论，支持"序列依赖算子需用批内逐请求长度分布特征的随机森林预测器，而非 token 总数代理"这一方法设计（§3.4）`[正文支持]`。右图中 Vidur 曲线缺失，与正文"a regime Vidur does not support"一致，说明该对比同时检验了 Vidur 的架构局限（不支持 FP8 场景）而非单纯精度差距 `[正文支持]`。需要说明批判边界：该图检验的是 Vidur"token-only 代理对批内异质性不敏感"这一具体 limit，不能被扩展为"Vidur 在所有场景下均失效"的一般性结论；关于 Vidur 对 MoE GroupedGEMM"undefined"（无法给出预测）这一点在图上只体现为绿色 Frontier MoE 曲线缺少对应的 Vidur 对照线，而非某条可见的"高误差"曲线。

6. **适用范围与证据缺口**：本图覆盖论文报告的设置——H800 GPU、BF16 与 FP8 两种精度、attention 与 MoE（GroupedGEMM）算子类别 `[正文支持]`。真实缺口：右图（FP8）中两条曲线均无图例标注，无法从像素本身区分蓝/绿分别对应 Attention 还是 MoE Ops，只能依据左图图例做谨慎类比推断 `[基于视觉的谨慎推断]`；此为图像裁剪/绘制导致的可辨识信息缺失，属于第 6 项定义范围内的真实证据缺口。
