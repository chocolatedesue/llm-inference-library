#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[MemOCR: Layout-Aware Visual Memory for Efficient Long-Horizon Reasoning]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yaorui Shi, Shugui Liu, Yu Yang, Wenyu Mao, Yuxin Chen, Qi Gu, Hui Su, Xunliang Cai, Xiang Wang, An Zhang]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[长时序推理] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[视觉记忆] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[上下文压缩] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[强化学习] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM智能体]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[代码：https://github.com/meituan/MemOCR]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-28]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

长时序智能体推理需要将不断增长的交互历史有效压缩进有限的上下文窗口。现有的多数记忆系统将历史初始化为文本，其中每个 token 的成本是均等的，并随长度线性增长，常常将有限的预算浪费在低价值细节上。为此，我们提出了 MemOCR，一种多模态记忆智能体，它通过视觉布局以自适应的信息密度分配记忆空间，从而在紧张的上下文预算下提升长时序推理能力。具体而言，MemOCR 维护一份结构化的富文本记忆（如标题、高亮），并将其渲染为图像供智能体查阅，在视觉上优先呈现关键证据，同时对辅助细节进行大幅压缩。为确保在不同记忆预算下的鲁棒性，我们采用强化学习并结合预算感知的训练目标来训练 MemOCR，使其接触多种压缩程度。在长上下文的多跳与单跳问答基准测试中，MemOCR 均优于强大的文本型基线方法，并在极端预算下实现了更有效的上下文利用。代码已开源：#link("https://github.com/meituan/MemOCR。")

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [MemOCR: Layout-Aware Visual Memory for Efficient Long-Horizon Reasoning],
    [作者], [Yaorui Shi, Shugui Liu, Yu Yang, Wenyu Mao, Yuxin Chen, Qi Gu, Hui Su, Xunliang Cai, Xiang Wang, An Zhang],
    [发表场所 / 年份], [文中未说明],
    [研究领域], [大语言模型智能体、多模态记忆],
    [关键词], [长时序推理, 视觉记忆, 上下文压缩, 强化学习, LLM智能体],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：#link("https://github.com/meituan/MemOCR")

#quote(block: true)[
#strong[标签（3--5 个）]：`视觉记忆` · `长时序推理` · `上下文压缩` · `强化学习` · `LLM智能体`
]

MemOCR 提出将智能体的长程记忆从\"一维文本流\"改造为\"可渲染的二维版面图像\"，通过版面显著性（标题、加粗、字号）实现自适应信息密度，在预算收紧至16 token时仍能取得62.2%准确率（对比强文本基线MemAgent同预算下31.6%）\[实验支持\]。其边界在于：文本与视觉方案使用了不同底座模型，且当记忆内容远超画布容量或任务需比较\"标题下细节\"时，该机制会整体失效\[作者明确陈述\]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- OCR 覆盖正文约第1-9页及部分图片（第3、4、5、7、8、9、22页），含摘要、方法、主实验与部分案例分析。
- Appendix A（相关工作细节）、B（局限性讨论）、C（预算实验附加细节）、D.1（统计显著性）、D.2（复杂度分析）、E（bad case分析）均被正文引用但内容不在OCR范围内，相应细节#strong[无法从当前OCR内容确认]。
- 指标\"subword exact match\"的具体判定规则、统计显著性方法#strong[文中未说明]，柱状图/小提琴图多数无数值标签，只能读相对高度关系。
- 以上均为论文事实层面的证据缺口；报告中标注\"背景知识\"的内容为外部解释，不作为论文结论使用。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

- #strong[问题定义]：智能体按顺序接收文本块流 $cal(C) = { C_1\,. . .\,C_T }$、用户问题 $Q$，需在有限记忆预算 $cal(B)$（token数）内输出答案 $A$；随着交互轮数 $T$ 增长，历史体量必然超出上下文窗口（context window，可理解为\"一次能看的稿纸篇幅\"）\[作者明确陈述\]。
- #strong[为什么重要]：长程/agentic reasoning（多轮、跨很长步骤才能完成的推理任务，如长对话或长文档问答）天然产生远超窗口容量的历史数据，是当前LLM智能体落地的基础瓶颈\[作者明确陈述\]。
- #strong[难点]：本质是一个\"预算分配问题\"------在有限token内决定保留/舍弃什么以最大化信息密度，而已有文本记忆方案均无法做到非均匀分配（见第4节）\[作者明确陈述\]。
- #strong[成功标准]：在不同预算档（16/64/256/1024）下QA准确率更高、预算收紧时降级更平缓\[基于文中逻辑的推断，依据实验设计\]。
- #strong[本文的story]：旧路线在\"token成本与语义重要性无关\"这一技术原因上失效------每个token占用相同预算单位，辅助细节与关键证据线性争抢空间；本文的洞见是把记忆变成二维图像，用版面显著性（字号、位置）把\"更重要\"直接翻译成\"更抗压缩\"，从而摆脱token级均匀分配的硬约束\[作者明确陈述\]。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第3节：预算分配为何是本文核心难点]
  #image("assets/imgs/img_in_image_box_144_146_1037_453.jpg", width: 100%)
  #emph[Figure 1. Comparison of memory paradigms. (a) Raw History Memory fetches relevant history passages but suffers from noise and redundancy. (b) Textual Summary Memory allows the agent to summarize the history but suffers from uniform information density, where auxiliary details (gray) consume as much token space as crucial information (green). (c) Visual Memory (Ours) allocates memory budget via visual layout to achieve adaptive information density.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：以10K/1K/200 token的示意对比展示三种记忆范式达到同等关键信息保留所需token量级差异

- #strong[论证关系]：支撑\"均匀信息密度致辅助细节挤占预算\"批判与自适应信息密度核心洞见

- #strong[适用范围]：概念示意图，数值为教学类比，非实测，不提供定量实验支持
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

+ #strong[Raw History Memory（原始历史检索，代表：Qwen2.5、R1-Distill Qwen、Qwen2.5-1M）]：它原本解决什么------保留原始细节避免摘要损失；依赖前提------检索片段能精准覆盖答案所需证据；失效条件------检索片段冗余或含噪声；具体后果------稀释信息密度、甚至耗尽预算\[作者明确陈述\]。本文用drafting阶段的显著性结构筛选组织信息作回应\[基于文中逻辑的推断\]，对应Table 1中三个Raw History基线与MemOCR的准确率对比实验\[实验支持\]。

+ #strong[Textual Summary Memory（Mem0、Mem-α、MemAgent）]：原本解决什么------通过增量更新/覆盖将历史蒸馏为紧凑摘要；依赖前提------摘要空间可灵活分配给重要内容；核心限制------uniform information density（均匀信息密度：每个token占用的\"预算单位\"相同，与语义重要性无关，类比记账本每笔记录不论金额大小都占同样版面），导致辅助细节与关键证据在同一预算下线性竞争、无法非均匀分配\[作者明确陈述\]；具体后果------预算收紧时出现灾难性掉点（如MemAgent 10K下从1024-token的67.8%降至16-token的31.6%，降53.3个百分点）\[实验支持\]。本文用视觉渲染+版面显著性（面积∝$L dot.op s^2$）将语义内容与token成本解耦作回应\[作者明确陈述\]，对应Table 1各预算下准确率及Table 3b（summarization替代truncation后MemAgent仍逊于MemOCR）\[实验支持\]。

+ #strong[既有\"渲染文本为图像\"压缩方法（Wei et al. 2025等）]：原本解决什么------用视觉渲染降低长上下文token开销；本文批判的具体limit------缺乏学习式内容选择或跨画布空间分配，渲染均一平铺、不自适应\[作者明确陈述\]；对应回应------RL训练的budget-aware目标显式学习分配visual salience；但#strong[是否设有与这类方法的直接定量对比实验，无法从当前OCR内容确认]，仅在Introduction/Related Work做概念性批判。

+ #strong[RAG-based无限存储（SimpleMem、LightMem、HyMem）]：其具体失效条件/前提#strong[文中未说明]，仅通过数值对比显示其在有限预算下逊于MemOCR（10K下74.6% vs HyMem 56.4%）\[实验支持\]，具体failure mode无法确认。

== 5. 核心洞见与假设
<5-核心洞见与假设>

- #strong[核心洞见]：从1D文本记忆转向2D视觉记忆------用图像而非token流表示历史，agent可通过控制\"视觉显著度\"（visual salience）显式非均匀分配预算：关键证据用醒目排版渲染，辅助细节压缩为视觉更小的文字；整体预算可通过分辨率下采样统一调控而不改变记忆内容本身\[作者明确陈述\]。
- #strong[关键假设]：渲染文本的占用面积（近似的视觉token成本）按 $cal(O)\(L dot.op s^2\)$ 增长，其中 $L$ 为文本长度、$s$ 为字号\[作者明确陈述（原文给出的近似关系）\]。这是\"字号越大→单位内容成本越高但可读性越强\"这一设计的数学基础。
- #strong[实现组件（非贡献核心）]：Markdown作为富文本载体格式；轻量渲染器 $cal(R)$ 将富文本编译为图像 $V_T = cal(R)\(M_T^(R T)\)$；GRPO强化学习优化中reading与drafting采用不同advantage聚合方式。
- #strong[可行性前提与失效场景]：该假设依赖\"关键内容确实可通过版面在压缩后保持可辨识像素\"这一图像编码器分辨率条件；当记忆总长度远超画布容量、或任务需要读取\"标题下方细节\"而非标题本身时，该假设不成立（对应第9节Failure Mode A/B）\[基于文中逻辑的推断\]。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

#strong[总览]：文本块流依次进入Memory Drafting（文本域，产出结构化富文本记忆）→ Rendering（渲染器编译）→ Memory Reading（视觉域，产出记忆图像作为agent查询时的唯一上下文）；训练阶段叠加三个budget-aware任务防止能力退化\[作者明确陈述\]。

=== 6.1 模块1：Memory Drafting（文本域富文本起草）
<61-模块1memory-drafting文本域富文本起草>
- #strong[动机]：需在文本层面标记\"哪些是关键证据、哪些是辅助细节\"，为后续渲染提供显著性线索\[作者明确陈述\]。
- #strong[输入/步骤/输出]：输入上一步记忆 $M_(t - 1)^(R T)$ 与新到达文本块 $C_t$；agent增量编辑决定保留内容与视觉优先级；输出更新后的富文本记忆 $M_t^(R T)$（含标题、加粗、缩进、字号）\[作者明确陈述\]。
- #strong[预期技术优势]：drafting过程\"budget-agnostic\"（不依赖运行时预算），只产出单一版面结构，避免为每个预算等级单独起草\[作者明确陈述\]。

=== 6.2 模块2：Memory Reading（视觉域记忆图像）
<62-模块2memory-reading视觉域记忆图像>
- #strong[动机]：把版面显著性转化为实际token成本差异------渲染面积与字号平方成正比\[作者明确陈述\]。
- #strong[输入/步骤/输出]：输入 $M_T^(R T)$；渲染器 $cal(R)$ 编译为图像并按预算做分辨率下采样；输出记忆图像 $V_T$，$A tilde.op pi_theta\(dot.op\|V_T\,Q\)$\[作者明确陈述\]。
- #strong[预期技术优势]：将语义内容与token成本解耦，同一预算下可选择性保留高价值内容\[作者明确陈述\]。

=== 6.3 模块3：Budget-aware Training Objectives
<63-模块3budget-aware-training-objectives>
- #strong[动机]：防止训练坍缩为\"shortcut policy\"------所有内容用统一中等字号渲染、绕开预期权衡\[作者明确陈述\]。
- #strong[步骤]：对同一份drafted memory构造三个任务：(1) $cal(T)_(s t d)$------原问题+512-token预算，检验充足预算下正确性；(2) $cal(T)_(a u g M)$------图像沿每维下采样4×（像素减少16×），检验极端压缩下关键证据是否存活；(3) $cal(T)_(a u g Q)$------细节导向问题+未压缩记忆，检验细节是否被完全丢弃；GRPO采样并计算各任务advantage，reading能力按任务分别更新，drafting能力用跨任务聚合advantage更新 $A = frac(sum_k w_k A^(\(k\)), sum_k w_k)$\[作者明确陈述\]。
- #strong[预期技术优势]：联合迫使drafter在极端压缩下保持关键证据可辨识，同时不因追求压缩鲁棒性而彻底丢弃细节\[作者明确陈述\]。
- #strong[明确缺口]：三个任务各自具体的reward计算公式或损失函数表达式#strong[文中未给出]，\"无可核验公式\"。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：Drafting→Rendering→Reading两阶段流水线与训练目标设计]
  #image("assets/imgs/img_in_image_box_175_150_1023_531.jpg", width: 100%)
  #emph[Figure 2. Framework of MemOCR. (a) Memory Drafting (Text Domain): The LLM agent incrementally updates a rich-text memory based on new incoming chunks, assigning visual priority via formatting and structure. (b) Memory Reading (Vision Domain): The rich text is rendered into a 2D memory image, which serves as the agent\'s sole working context for answering queries. (c) Budget-Aware Training Objectives: We train the agent under varying degrees of memory compression. The drafting ability is updated via aggregated advantages, while the reading ability is updated via separate advantages.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示富文本起草循环、渲染转视觉记忆、三个QA变体任务及聚合/分任务两条advantage更新路径

- #strong[论证关系]：支撑\"reading分任务更新、drafting聚合更新\"训练设计，与Table4消融数值互补

- #strong[适用范围]：仅呈现结构设计，不含量化训练效果，各任务reward公式文中未说明
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制→收益]：面积∝$L dot.op s^2$的渲染关系使\"更大字号/更醒目位置\"直接等价于\"更高的单位内容成本+更强的可读性\"，因此drafter把关键证据压成短文本+大字号即可用少量像素维持高可辨识度\[基于文中逻辑的推断\]。
- #strong[所需条件]：该收益成立的前提是视觉编码器在低分辨率下仍能识别\"大字号/高对比度\"区域的文字，且总内容量未超出画布容量\[基于文中逻辑的推断\]。
- #strong[训练目标→鲁棒性]：$cal(T)_(a u g M)$ 直接在训练信号中模拟\"低预算下采样\"场景，使policy学会主动为关键内容争取更大视觉占位；$cal(T)_(a u g Q)$ 防止为追求压缩鲁棒性而彻底牺牲细节，两者共同塑造非极端的、可控的信息密度分配\[基于文中逻辑的推断\]，其效果在Table 4消融中得到验证\[实验支持\]。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果问题：MemOCR整体准确率是否优于文本/RAG基线------对应Table1、Table2的跨方法对比\[实验支持\]。
- 鲁棒性问题：预算收紧时是否降级更平缓------对应Table1的drop%列及Figure4细粒度扫描\[实验支持\]。
- 机制问题：低预算鲁棒性来自版面控制还是视觉模态本身------对应w/o Visual Layout消融（Figure4）与区域级统计（Figure5、6）\[实验支持\]。
- 必要性问题：三个训练目标是否各自必要------对应Table4逐项消融\[实验支持\]。
- 适用范围问题：能否零样本迁移到对话记忆场景------对应LOCOMO评测\[实验支持，范围有限\]。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 训练数据：HotpotQA（补充干扰文档至约30K token）。
- 评测集：HotpotQA、2WikiMultiHopQA、NQ、TriviaQA，评测上下文长度10K/30K/100K，预算 $cal(B) in { 16\,64\,256\,1024 }$。
- 基线：Raw History（Qwen2.5、R1-Distill Qwen、Qwen2.5-1M）、Textual Summary（Mem0、Mem-α、MemAgent）、RAG-based（SimpleMem、LightMem、HyMem）。
- 模型版本：文本类方法backbone为Qwen2.5-7B-Instruct，MemOCR backbone为Qwen2.5-VL-7B-Instruct\[作者明确陈述\]。
- 硬件/软件、重复次数/统计方式、超参数：文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Accuracy（subword exact match），测量QA正确率（%），越高越好。

  - #strong[定义与公式]：作者仅文字说明测量方式为\"subword exact match\"，无可核验公式；具体判定规则文中未说明。
  - #strong[来源层级]：无可核验公式。
  - #strong[实验用途]：所有主表格（Table1-4）及各Obs的核心比较指标。
  - #strong[读数与边界]：见8.4；无法确认统计显著性。

- #strong[指标与方向]：Memory Budget $cal(B)$，取值 ${ 16\,64\,256\,1024 }$，代表约束松紧（越大越松）。

  - #strong[定义与公式]：原文公式，$\|M_T\|lt.eq cal(B)$（文本方法）；MemOCR通过调整渲染分辨率使视觉patch token数不超过 $cal(B)$。
  - #strong[来源层级]：原文公式。
  - #strong[实验用途]：控制所有主表格横轴条件。
  - #strong[读数与边界]：仅是约束定义，非结果本身。

- #strong[指标与方向]：相对1024-token预算的性能下降(%)，无量纲，越小（越接近0）越好。

  - #strong[定义与公式]：推导关系（非原文公式）。推理依据：Table1标题称\"百分比代表相对1024-token预算的性能下降\" → 该值应等于 $\(A c c_1024 - A c c_B\)\/A c c_1024 times 100 %$ → 用于衡量预算收紧时的降级幅度\[基于文中逻辑的推断\]，作者未给出显式分子分母符号定义。
  - #strong[来源层级]：推导关系（非原文公式）。
  - #strong[实验用途]：衡量budget鲁棒性（Obs1.2、Obs2.1等）。
  - #strong[读数与边界]：仅反映相对降幅，不反映绝对准确率水平。

- #strong[指标与方向]：面积/视觉token成本近似式，描述性关系，无绝对方向。

  - #strong[定义与公式]：原文公式（近似关系），$cal(O)\(L dot.op s^2\)$，$L$为文本长度、$s$为字号。
  - #strong[来源层级]：原文公式。
  - #strong[实验用途]：支撑\"自适应信息密度\"设计原理。
  - #strong[读数与边界]：为定性近似关系，非可精确计算的实测量。

- #strong[指标与方向]：GRPO聚合advantage，无量纲，用于策略梯度更新。

  - #strong[定义与公式]：原文公式（未标注Eq.编号），$A = frac(sum_(k in cal(K)) w_k A^(\(k\)), sum_(k in cal(K)) w_k)$，$cal(K) = { T_(s t d)\,T_(a u g M)\,T_(a u g Q) }$，$w_k$为预定义任务权重。
  - #strong[来源层级]：原文公式。
  - #strong[实验用途]：更新drafting策略。
  - #strong[读数与边界]：$w_k$具体取值文中未给出。

- #strong[指标与方向]：\"8×\"效率提升，token数量比，越大越好。

  - #strong[定义与公式]：推导关系（非原文公式）。推理依据：正文明确写\"MemOCR在8 token时达到与baseline在64 token时相当的准确率\" → 比例=64/8=8\[基于文中逻辑的推断，比值本身为作者直接给出的对比数值\]。
  - #strong[来源层级]：推导关系（非原文公式）。
  - #strong[实验用途]：论证RQ2极端预算下鲁棒性。
  - #strong[读数与边界]：仅基于单一token档位对比，是否具跨档位一般性规律文中未说明。

- #strong[指标与方向]：Precision变化（Crucial区域↑约1.8×，Detailed区域↓约0.46×），证据密度倍数变化，无绝对方向。

  - #strong[定义与公式]：作者明确陈述的实验统计结果，但precision本身的计算方法文中未说明。
  - #strong[来源层级]：无可核验公式。
  - #strong[实验用途]：论证RQ3自适应信息密度机制。
  - #strong[读数与边界]：仅反映训练前后相对变化，非绝对精度数值。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [Raw History（Qwen2.5等）], [检索片段冗余/含噪声，稀释信息密度], [drafting阶段显著性筛选], [Table1对比；未验证检索质量改进后是否仍逊于MemOCR],
    [Textual Summary（Mem0/Mem-α/MemAgent）], [uniform information density，budget收紧灾难性掉点], [视觉渲染+版面显著性], [Table1/Table3b；未验证更优摘要算法能否缩小差距],
    [既有图像渲染方法], [无学习式内容选择/空间分配], [RL+budget-aware训练], [无直接定量对比实验，无法从当前OCR确认],
    [RAG-based（SimpleMem等）], [具体失效条件文中未说明], [budget-controlled视觉记忆], [Table2对比；失效机制未验证],
  )]
  , kind: table
  )

（MemOCR w/o Visual Layout为本文自身消融对照组，非外部比较工作，用于RQ2机制验证。）

#strong[主张与证据强度]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [MemOCR整体准确率优于文本基线（10K下74.6% vs 67.8%）], [Table1, Obs1.1], [\[实验支持\]；HotpotQA在30K/100K下偏弱，原因见Appendix E，内容无法确认],
    [预算收紧时降级更平缓（10K下降16.6% vs MemAgent降53.3%）], [Table1, Obs1.2], [\[实验支持\]],
    [视觉版面（非单纯视觉模态）是低预算鲁棒性主因], [w/o Visual Layout对照, Figure4, Obs2.1], [\[实验支持\]；图上无数值标签，仅可读相对高度],
    [关键证据被放入高可见区域且更抗压缩], [Oracle注入(Figure5), precision统计(Figure6), Obs3.1/3.2], [\[实验支持\]],
    [budget-aware训练目标（尤其$T_(a u g M)$）是必要的], [Table4, Obs4.1/4.2], [\[实验支持\]],
    [零样本迁移到LOCOMO对话场景], [Obs1.6], [\[实验支持，适用范围有限\]；更广泛场景文中未说明],
    [极端预算下约8×效率提升], [Obs2.2（64→8 token）], [\[实验支持，但推广性存疑\]；仅单一档位对比],
  )]
  , kind: table
  )

- 单跳任务（NQ、TriviaQA）低预算未必降准确率，TriviaQA 16-token（80.8%）甚至反超1024-token（79.6%），此现象未在文本基线上观察到\[实验支持\]。
- 文本baseline改用summarization替代truncation后仍逊于MemOCR（MemAgent从31.6%提升到58.5%，$B = 16$）\[实验支持\]。
- 极端情况下（HotpotQA 16-token）Oracle注入反而有害，因为增加内容会使图像更难整体辨识\[实验支持\]。
- 文本与视觉方案backbone不同（Qwen2.5-7B-Instruct vs Qwen2.5-VL-7B-Instruct），比较结果可能混杂底座模型能力差异，论文未提供同底座对照实验\[基于文中逻辑的推断\]。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_image_box_119_141_566_584.jpg", width: 100%)
    #emph[Figure 3. Design of the budget-aware training objectives. (1) Standard QA uses the unmodified question and memory for global correctness. (2) QA w/ Augmented Memory requires the visibility of crucial evidence even when the visual memory is heavily compressed. (3) QA w/ Augmented Question ensures detailed information is clearly identified with sufficient tokens. The low-budget, high-detail setting (gray area) is excluded as identifying detailed features under severe compression is infeasible.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第6节：budget-aware训练目标设计；第8节Table4必要性验证]
    - #strong[图组结论]：以预算×证据粒度矩阵呈现三训练任务分别覆盖的象限，低预算高细节象限被明确排除

- #strong[论证关系]：为三训练目标\"各自必要\"的主张提供设计动机，量化必要性仍需Table4/Obs4.1-4.2

- #strong[适用范围]：仅为概念矩阵，不含准确率数值或权重$w_k$信息
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_616_674_1081_1001.jpg", width: 100%)
    #emph[Figure 4. Comparison of accuracy and relative performance drop across varying memory budgets (RQ2). MemOCR degrades more gracefully than textual baselines as budgets tighten. Without visual layout, MemOCR\'s low-budget robustness drops significantly, which suggests that adaptive information density facilitates more efficient memory budget utilization.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Obs2.1版面控制是低预算鲁棒性主因；Obs2.2约8×效率提升]
    - #strong[图组结论]：预算收紧时MemOCR降幅明显小于w/o Layout及三文本基线，差距随预算收紧扩大

- #strong[论证关系]：MemOCR与w/o Layout仅版面变量不同，差距来源确证为版面而非视觉模态本身

- #strong[适用范围]：仅限HotpotQA、10K上下文，无数值标签，无法精确读取具体百分比
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_146_533_539_925.jpg", width: 100%)
    #emph[Figure 5. Oracle analysis of layout regions (RQ3). We compare MemOCR with oracle variants that inject ground-truth evidence into either the Crucial or Detailed region of the rendered memory. While both injections improve accuracy, injecting into the crucial region yields larger gains, especially under tight memory budgets.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Obs3.1证据放置区域决定压缩鲁棒性]
    - #strong[图组结论]：高预算下三条件接近，预算收紧后Oracle(Crucial)明显优于Oracle(Detailed)

- #strong[论证关系]：证明证据可见度区域本身决定压缩鲁棒性，支撑drafting/reading模块显著性分配设计必要性

- #strong[适用范围]：仅覆盖HotpotQA/2Wiki/NQ，不含TriviaQA，无数值标签
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0008-05ad2538221c.png", width: 100%)
    #emph[Figure 6. RL induces adaptive information density (RQ3). (a) With training, ground-truth evidence becomes more concentrated in the crucial region while decreasing in the detailed region. (b) The crucial region remains much shorter than the detail part.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Obs3.2 RL诱导自适应信息密度]
    - #strong[图组结论]：训练后crucial区域precision约提升1.8倍、detailed区域降至0.46倍，crucial区域文本长度显著更短

- #strong[论证关系]：证明RL训练主动将证据精确度与长度非均匀分配至高显著区域，呼应面积∝$L dot.op s^2$假设

- #strong[适用范围]：未说明是否单一或跨数据集聚合，无精确数值刻度
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_image_box_113_148_1076_547.jpg", width: 100%)
    #emph[Figure 7. Case study at an extreme memory budget (16 tokens). (Left) The textual baseline fails due to hard truncation of the context. (Middle) MemOCR without layout control fails because uniform text becomes unreadable after down-sampling. (Right) MemOCR preserves the crucial evidence "Gene MacLellan" through adaptive layout, enabling correct reasoning even at low resolution.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8-9节：Obs2.1/Obs1.2版面显著性是低预算鲁棒性直接原因]
    - #strong[图组结论]：同一16-token案例中，MemAgent因截断丢证据、MemOCR w/o Layout因均匀渲染不可辨，完整MemOCR保留关键词正确作答

- #strong[论证关系]：具象化\"版面显著性驱动鲁棒性\"机制，不能单独证明统计普遍性

- #strong[适用范围]：单一案例展示，普遍性结论需依赖Table1/4
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_image_box_115_420_1078_1046.jpg", width: 100%)
    #emph[Figure 8. Failure Mode Analysis under Resource Constraints (16-token budget). (Top) In comparative reasoning (i.e., to choose among two candidates), while the layout successfully highlights entity headers, the body text containing crucial attributes is compressed into unreadable noise during downsampling. (Bottom) When the rich-text memory length exceeds the visual canvas capacity, the forced font scaling drops below the visual encoder\'s resolution threshold, resulting in information loss.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第9节：局限性——Failure Mode A/B边界条件]
    - #strong[图组结论]：Failure Mode A显示实体标题可辨但细节不可辨致比较任务失败；Failure Mode B显示记忆超出画布容量致关键信息不可读

- #strong[论证关系]：限定\"版面显著性提升鲁棒性\"贡献的适用边界，正文未展开讨论此图内容

- #strong[适用范围]：仅为16-token下两类单一案例，其普遍性/占比文中未说明
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1. Comparison of accuracy (%) across different context lengths (10K, 30K, and 100K tokens). Best results are hi...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Obs1.1/1.2 MemOCR整体准确率与降级平缓性优于文本基线]
  - #strong[图组结论]：10K下MemOCR 74.6% vs MemAgent 67.8%，16-token降幅仅16.6%（基线降53.3%）

- #strong[论证关系]：直接支撑\"整体准确率优于文本基线\"及\"预算收紧降级更平缓\"两条核心主张

- #strong[适用范围]：HotpotQA在30K/100K下偏弱，原因见Appendix E，内容无法确认
  #v(5pt)
  #image("table-groups/page-0006-d160cdc7b12d.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2. Comparison with recent RAG-based memory baselines with unlimited storage (accuracy %).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：RAG-based无限存储基线对比]
  - #strong[图组结论]：10K下MemOCR 74.6% vs HyMem 56.4%，MemOCR在有限预算下优于无限存储RAG方案

- #strong[论证关系]：支撑\"预算受限的版面记忆优于无限存储检索\"这一适用范围主张

- #strong[适用范围]：具体失效条件文中未说明，仅数值对比，无因果机制解释
  #v(5pt)
  #image("table-groups/page-0007-6ae47d6925d5.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3. Fairness and generalization experiments (accuracy %, 10K context). (a) Budget fairness (MemOCR w/ B = N vs t...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：预算公平性、摘要替代截断、LOCOMO零样本迁移]
  - #strong[图组结论]：(a)同等有效预算下MemOCR仍优于4倍预算文本基线；(b)MemAgent改用摘要后仍逊于MemOCR；(c)LOCOMO零样本有效

- #strong[论证关系]：分别排除\"预算不公平\"和\"截断非摘要\"两项质疑，并验证适用范围可迁移至对话场景

- #strong[适用范围]：LOCOMO为零样本迁移，更广泛场景文中未说明
  #v(5pt)
  #image("table-groups/page-0007-3915bd002529.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 4. Ablation study by progressively removing training objectives from MemOCR. Vanilla MemOCR uses , , .]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Obs4.1/4.2三训练目标必要性]
  - #strong[图组结论]：逐项去除$T_(s t d)$/$T_(a u g M)$/$T_(a u g Q)$均导致鲁棒性下降，三目标均对性能有必要贡献

- #strong[论证关系]：量化验证Figure2/3设计动机，证明三训练目标非冗余、各自必要

- #strong[适用范围]：各目标具体reward公式未公开，复现存在障碍
  #v(5pt)
  #image("table-groups/page-0008-54ab5e221dad.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：长程智能体如何在有限context budget内保留高价值历史信息
  - 旧方法限制：Raw History冗余噪声、Textual Summary的uniform information density导致灾难性掉点、既有图像渲染方法无自适应分配
  - 核心洞见/假设：2D视觉记忆+版面显著性可实现自适应信息密度，面积∝$L dot.op s^2$
    + 方法模块：Memory Drafting（富文本起草）
      - 可验证预测：drafter学会把关键证据标注到高显著区域
        - 指标与实验：Oracle注入实验、precision统计（Obs3.1/3.2）
          - 图表证据：Figure5、Figure6
            - 结论与适用边界：证据成立但仅限已测数据集/预算档，普遍性有限\[实验支持\]
    + 方法模块：Memory Reading（视觉域渲染）
      - 可验证预测：同一预算下视觉记忆保留更多任务相关信息
        - 指标与实验：Table1/2主结果对比
          - 图表证据：Figure4细粒度扫描
            - 结论与适用边界：MemOCR降级更平缓，但backbone不同这一混杂变量未被控制\[实验支持\]
    + 方法模块：Budget-aware Training Objectives
      - 可验证预测：去除任一训练目标会损害低预算鲁棒性
        - 指标与实验：Table4消融（Obs4.1/4.2）
          - 图表证据：Figure2、Figure3设计示意
            - 结论与适用边界：三目标均必要，但各自reward公式未被当前证据直接验证公开\[实验支持\]
      - 未被当前证据直接验证：与既有\"渲染为图像\"方法的直接定量对比

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- #strong[贡献]：(1) 提出2D视觉记忆范式替代1D token流以实现自适应信息密度；(2) MemOCR两阶段记忆生命周期（Drafting+Reading）；(3) budget-aware RL训练目标，防止shortcut policy\[作者明确陈述\]。
- #strong[证据充分的结论]：MemOCR在多个QA基准上整体准确率优于文本/RAG基线，且预算收紧时降级更平缓\[实验支持\]；版面显著性（非单纯视觉模态）是低预算鲁棒性的主因\[实验支持\]；三个训练目标各自对鲁棒性有必要贡献\[实验支持\]。
- #strong[尚属推断的意义]：\"8×效率提升\"具有一般性规律、视觉+版面收益完全独立于底座模型能力差异，均为\[基于文中逻辑的推断\]，未被专门实验隔离验证。
- #strong[适用条件]：多跳/单跳英文QA场景、评测上下文10K-100K、零样本迁移至LOCOMO对话场景有效\[实验支持，范围有限\]。
- #strong[局限]：记忆内容超出画布容量时会整体失效；任务需读取\"标题下细节\"而非标题本身时版面机制无法保护内容（Failure Mode A/B）\[基于文中逻辑的推断\]；Appendix B完整局限性讨论内容无法从当前OCR内容确认。
- #strong[下一步验证]：同底座模型对照实验以分离版面策略与底座能力贡献；与既有图像渲染方法的直接定量对比；更细粒度budget扫描以验证效率提升的普适性。

#strong[审稿式风险检查]

- 贡献新意：与既有\"渲染文本为图像\"方法相比，本文缺乏直接定量对比实验，新意主张目前仅有概念性区分支持\[实验支持有限\]。
- 写作/可复现性：多个关键附录（B/C/D/E）内容缺失，部分公式（如各任务reward）未公开，复现存在障碍\[作者明确陈述\]。
- 效果大小：主结果提升幅度在低预算下较大（如10K下16-token提升30.6个百分点），但指标本身（subword exact match）判定细则不明，效果大小的精确性存疑\[实验支持但细节不明\]。
- 实验覆盖：Oracle注入实验未覆盖TriviaQA数据集；效率提升\"8×\"仅基于单一档位对比\[实验支持但覆盖有限\]。
- 方法设计：文本与视觉方案backbone不同，混杂了底座模型能力差异，未见控制该变量的对照实验\[基于文中逻辑的推断\]；当前证据未显示其他方法设计层面的风险。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：Context window（上下文窗口）------LLM一次能处理的最大文本量（以token计）。

  - #strong[第一性原理角色]：是硬性资源约束，连接\"历史信息总量\"与\"模型可用输入容量\"这两个基本量。
  - #strong[本文位置]：直接决定记忆预算 $cal(B)$ 的存在必要性。

- #strong[术语]：Token------文本被切分后的最小处理单位。

  - #strong[第一性原理角色]：是衡量模型输入/计算成本的计量单位，是预算约束的计量对象。
  - #strong[本文位置]：预算 $cal(B)$ 以token数定义，文本方法中$\|M_T\|lt.eq cal(B)$。

- #strong[术语]：Uniform information density（均匀信息密度）------文本表示下每个token占用的预算单位相同，与语义重要性无关。

  - #strong[第一性原理角色]：机制层面，连接\"文本长度\"与\"预算消耗\"的线性因果关系，是旧方法失效的根源。
  - #strong[本文位置]：作为Textual Summary Memory的核心限制被批判。

- #strong[术语]：视觉patch token------图像切分成小块后每块在视觉Transformer中对应的token。

  - #strong[第一性原理角色]：连接\"渲染面积/分辨率\"与\"视觉输入计算成本\"这两个基本量。
  - #strong[本文位置]：MemOCR的记忆预算通过控制渲染分辨率间接控制patch token数。

- #strong[术语]：GRPO（Group Relative Policy Optimization）------对同一输入采样一组输出，通过组内相对好坏计算advantage来更新策略的强化学习方法。

  - #strong[第一性原理角色]：机制上连接\"采样输出的相对优劣\"与\"策略参数更新方向\"，无需额外价值网络。
  - #strong[本文位置]：用于优化drafting与reading两种能力，advantage聚合方式因能力而异。

- #strong[术语]：Shortcut policy------训练中agent倾向于把所有内容渲染为统一中等字号、绕开预期权衡的退化行为。

  - #strong[第一性原理角色]：是训练优化目标与期望行为之间的失配风险，连接\"缺乏约束的奖励信号\"与\"退化的版面策略\"。
  - #strong[本文位置]：budget-aware训练目标（$cal(T)_(s t d)\/cal(T)_(a u g M)\/cal(T)_(a u g Q)$）专门为防止此现象设计。

- #strong[术语]：Oracle注入实验------把ground-truth证据人为注入特定版面区域（Crucial或Detailed）再测准确率的对照实验方法。

  - #strong[第一性原理角色]：机制上分离\"是否有证据\"与\"证据放在哪个可见度区域\"两个变量，用于因果归因。
  - #strong[本文位置]：用于验证区域级压缩鲁棒性差异（Figure5, Obs3.1）。

- #strong[术语]：Multi-hop QA / Single-hop QA------需要拼接多条分散证据才能得出答案的问题 / 单一段落即可确定答案的问题。

  - #strong[第一性原理角色]：是任务难度的结构性约束，决定了信息压缩策略需覆盖的证据分布模式。
  - #strong[本文位置]：HotpotQA、2WikiMultiHopQA为多跳评测集，NQ、TriviaQA为单跳评测集。

=== 12.2 学习路径
<122-学习路径>
+ #strong[Context window与token]：先理解LLM输入容量是硬性资源约束，这是全文\"预算分配问题\"存在的前提。
+ #strong[RAG与文本摘要记忆]：理解已有两类文本记忆范式的运作方式，才能理解本文批判的\"uniform information density\"具体指什么。
+ #strong[视觉Transformer中的patch token]：理解图像输入如何被离散化为token，是理解\"渲染面积决定视觉成本\"这一核心假设的机制基础。
+ #strong[强化学习中的advantage与GRPO]：理解组内相对比较如何驱动策略更新，是理解budget-aware训练目标如何塑造版面行为的前提。
+ #strong[多跳QA任务结构]：理解证据分散在多处的推理需求，是理解为何\"关键证据的视觉呈现方式\"会直接影响最终准确率的系统行为基础。
