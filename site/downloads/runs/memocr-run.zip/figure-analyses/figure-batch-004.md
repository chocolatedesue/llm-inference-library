# 图片批次 4

## 图片 1：Figure 7. Case study at an extreme memory budget (16 tokens). (Left) The textual baseline fails due to hard truncation of the context. (Middle) MemOCR without layout control fails because uniform text becomes unreadable after down-sampling. (Right) MemOCR preserves the crucial evidence “Gene MacLellan” through adaptive layout, enabling correct reasoning even at low resolution.

![Figure 7. Case study at an extreme memory budget (16 tokens). (Left) The textual baseline fails due to hard truncation of the context. (Middle) MemOCR without layout control fails because uniform text becomes unreadable after down-sampling. (Right) MemOCR preserves the crucial evidence “Gene MacLellan” through adaptive layout, enabling correct reasoning even at low resolution.](../assets/imgs/img_in_image_box_113_148_1076_547.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：这是第 4.6 节 Case Study 图（Figure 7），角色为"实验结论"（兼具"方法流水线"展示功能）。它是对第 8 页 Obs.2.1（视觉版面主要贡献了低预算鲁棒性）与 Obs.1.2（MemOCR 降级更平缓）的具体化、可解释的落地案例，通过同一具体问题、同一 16-token 极端预算，直接对比"文本摘要记忆(MemAgent)"、"MemOCR w/o Layout"、"完整 MemOCR"三种方案在真实错误模式上的差异，回答"为什么版面控制能带来鲁棒性"这一机制问题，而非泛泛展示准确率数字。**图表角色**：机制 + 实验结论。**上文呼应**：第 8-9 页 "4.6. Case Study" 与 Obs.2.1/Obs.1.2。[正文支持]

2. **图像类型与布局**：三栏对比流程图（不是曲线/柱状/表格），每栏纵向分三行：第1行"Generated Memory"（未压缩的原始生成记忆文本框内容），第2行"Observed Memory (16-Token Budget)"（经过截断/下采样后实际可读到的记忆状态），第3行"Reasoning & Answer"（agent 最终推理结论，用对勾/叉号标注对错）。顶部横跨全宽标注问题"Who wrote put your hand in the hand of the man who stilled the water?"与 Ground Truth "Gene MacLellan"。三栏分别用橙/红/绿背景色区分 MemAgent(Textual Memory)、MemOCR (w/o Layout)、MemOCR。[图像直接可见]

3. **如何阅读**：横向按三栏左→中→右比较（对应三种方法），纵向按1→2→3阅读"生成记忆→观测到的压缩后记忆→最终回答"的因果链条；每栏第2行下方均有一个结果标签框（Evidence Missing / Evidence Unreadable / Evidence Preserved），第3行右侧的红叉/绿勾直接给出正确性判断。[图像直接可见]

4. **直接可见的结论**：MemAgent 一栏中"Truncation"箭头后，关键实体"Gene MacLellan"及相关句子被划掉（灰色删除线),文本框标注"Evidence Missing"，agent 回答"I don't know"（错误，红叉)。MemOCR (w/o Layout) 一栏中"Downsampling"箭头后，图像呈现为密集均匀的小字文本块，配有放大镜图标显示局部文字模糊不可辨认，标注"Evidence Unreadable"，agent 回答"Greg Brown"（错误，红叉）。MemOCR 完整版一栏中，下采样后的记忆图像里"Ocean (band)"与"MacLellan"两处关键词以加粗/独立区块形式仍清晰可辨（放大镜显示清晰字样），标注"Evidence Preserved"，agent 回答"Gene MacLellan"（正确，绿勾）。[图像直接可见]

5. **它验证的论点与方法设计含义**：这属于"机制"类主张——证明版面显著性（而非仅仅视觉模态）是低预算鲁棒性的直接原因：三栏共享相同信息内容和相同 16-token 极端预算，唯一变量是"是否有版面控制"，图像层面清晰展示了两种失败路径（文本硬截断丢证据 vs. 均匀视觉渲染下采样后不可辨认）与 MemOCR 通过版面把关键词保持在可辨识像素区域这一"成功路径"的差异，直接对应正文 Obs.2.1 中"移除视觉版面导致低预算鲁棒性显著下降"的机制论证，以及案例研究文字部分对三种失败/成功模式的描述完全一致。该图不能单独证明该现象具有统计普遍性（仅为单一案例插图），普遍性结论需依赖 Table 1/Table 4 的批量数值。[正文支持]

6. **适用范围与证据缺口**：本图覆盖论文报告的单一具体问题、10K 上下文场景、16-token 极端预算下的一次案例展示，用于解释而非统计验证。无额外证据缺口。

---

## 图片 2：Figure 8. Failure Mode Analysis under Resource Constraints (16-token budget). (Top) In comparative reasoning (i.e., to choose among two candidates), while the layout successfully highlights entity headers, the body text containing crucial attributes is compressed into unreadable noise during downsampling. (Bottom) When the rich-text memory length exceeds the visual canvas capacity, the forced font scaling drops below the visual encoder's resolution threshold, resulting in information loss.

![Figure 8. Failure Mode Analysis under Resource Constraints (16-token budget). (Top) In comparative reasoning (i.e., to choose among two candidates), while the layout successfully highlights entity headers, the body text containing crucial attributes is compressed into unreadable noise during downsampling. (Bottom) When the rich-text memory length exceeds the visual canvas capacity, the forced font scaling drops below the visual encoder's resolution threshold, resulting in information loss.](../assets/imgs/img_in_image_box_115_420_1078_1046.jpg)

*来源：OCR 第 22 页。*

### 解读

1. **论文角色与验证问题**：该图对应附录 Figure 8（Failure Mode Analysis under Resource Constraints），角色为"适用边界"（局限性说明），用于回答"MemOCR 的版面机制在什么情况下仍会失效"这一问题，是对正文"论文局限性讨论见 Appendix B"及方法边界条件的具体化补充，而非展示新的核心贡献效果。正文主体（OCR 第1-10页）未直接引用此图的具体内容，其定位依赖图题本身与图片清单中标注的"OCR 第22页"（附录）归属。**图表角色**：适用边界（机制失效案例）。**上文呼应**：对应主张地图"局限、缺失信息与适用边界"章节中"Appendix B 局限性讨论内容无法从当前 OCR 内容确认"的部分——本图即为该缺口的部分补充,但正文本身并未描述此图内容,故其与主文机制的关联为[基于文中逻辑的推断]，非[正文支持]。

2. **图像类型与布局**：上下两个独立子板块（Failure Mode A / Failure Mode B），每板块内部为"问题→下采样后的记忆图像截图→答案"三段式横向流程，配灰色标题条区分两种失败模式,右侧用红叉标注最终答案错误。板块内穿插洋红色文字标注（"Both Entity Visible, but no Details" / "Key Entity (2015) Unreadable"）指向图像中的具体问题区域。[图像直接可见]

3. **如何阅读**：先看每板块顶部灰色标题确定失败模式类型，再看左侧问题与 Ground Truth，随后看中间的"Downsampled Memory Image"截图（需结合洋红色标注定位具体不可读/缺失区域），最后看右侧红色答案框判断错误结果。两板块之间为并列对比（两种不同失败机制），非递进关系。[图像直接可见]

4. **直接可见的结论**：Failure Mode A（比较推理任务）中，下采样后图像里"Hrag Vartanian"和"Hovsep Pushman"两个实体标题（粗体框）清晰可见,但各自下方的正文细节文字已模糊成噪声无法辨认，标注"Both Entity Visible, but no Details"，模型最终回答"Hovsep Pushman"（错误，红叉，正确答案为 Hrag Vartanian）。Failure Mode B（记忆容量溢出）中，图像反复出现多段几乎相同的"Adidas Yeezy"标题及正文块（表明记忆内容超出画布容量导致被迫多次挤压重复排版），洋红标注指出关键实体"(2015)"这一年份信息不可读，模型回答"February 2012"（错误，红叉，正确答案为 February 14, 2015）。[图像直接可见]

5. **它验证的论点与方法设计含义**：这两个失败模式共同揭示 MemOCR 版面机制的适用边界——(A) 即使版面成功把"标题级"信息（实体名）保持醒目可辨，若任务需要比较的是标题下方的细节属性（而非标题本身），版面显著性机制无法保护这些细节内容,导致比较类推理失败；(B) 当富文本记忆长度超出画布容量上限时，渲染器被迫压缩字号至视觉编码器分辨率阈值以下，即使是本应"重要"的实体信息也会不可读，说明该方法在内容量远超设计容量时会整体失效。这两点均是对论文核心贡献（自适应版面分配、越重要越抗压缩）的边界限定：版面显著性能提升鲁棒性,但并非在任何任务类型或任何记忆长度下都无限有效。[基于文中逻辑的推断]（因正文主体未展开讨论此图,仅图题本身描述了这两种失败模式，图题为唯一可确认的文字锚点）

6. **适用范围与证据缺口**：本图覆盖的是论文附录中在 16-token 极端预算下针对两类特定失败场景（比较推理任务、长记忆溢出画布容量）的案例分析，均为单一案例展示。正文主体（OCR 前10页）未提供该图对应的详细文字论述（如具体触发条件、涉及的数据集/统计频率），故这两个失败模式在整体实验结果中的普遍性/占比**文中未说明**，此为真实证据缺口（附录 D.1/E/B 等相关章节内容未包含在本次 OCR 范围内）。
