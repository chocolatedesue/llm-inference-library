# 图片批次 3

## 图片 1：Figure 6. RL induces adaptive information density (RQ3). (a) With training, ground-truth evidence becomes more concentrated in the crucial region while decreasing in the detailed region. (b) The crucial region remains much shorter than the detail part.

![Figure 6. RL induces adaptive information density (RQ3). (a) With training, ground-truth evidence becomes more concentrated in the crucial region while decreasing in the detailed region. (b) The crucial region remains much shorter than the detail part.](../figure-groups/page-0008-05ad2538221c.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图对应 RQ3"层布局是否诱导区域级压缩鲁棒性，且 MemOCR 是否利用该差异实现自适应信息密度"（第 4.4 节），证据类型为**机制**验证。它要回答的具体问题是：RL 训练是否真的让 drafter 学会把精确证据集中放入版面中"crucial"高显著区域、同时压缩"detailed"低显著区域的证据密度与长度，从而支撑 Obs.3.2 的定量陈述。`[正文支持]`
   - **图表角色**：机制验证
   - **上文呼应**：第 4.4 节 RQ3，Obs.3.2（RL 使 crucial 区域精确度提升约1.8×、detailed 区域降低约0.46×，且 crucial 区域文本长度远短于 detailed 区域）

2. **图像类型与布局**：两个并列子图（Figure 6a、6b），均为柱状/分布图，非流程图。(a) "Information Density"为带误差棒的柱状图，左右两组（Crucial Memory / Detailed Memory）以竖直分隔线区分，每组内 3 根柱（w/o RL、500 steps、1000 steps），并标注倍数箭头/虚线。(b) "Length Distribution (1000 steps)"为对数坐标下的小提琴图，横轴两类（Crucial Memory / Detailed Memory），纵轴 Token Count（log scale）。

3. **如何阅读**：(a) 纵轴 Precision (%)，范围约 0–30%；横轴按训练阶段（w/o RL → 500 steps → 1000 steps）分组比较同一区域内的变化趋势，虚线标示 1000-steps 水平并配"+1.8×"（Crucial）与"-0.46×"（Detailed）标注；应比较同一区域内三柱随训练步数的变化方向。(b) 纵轴对数刻度的 token 数，横轴两个区域类别，应比较两个小提琴图的中心位置、宽度与整体量级。

4. **直接可见的结论**：(a) Crucial Memory 组：精确度随训练步数明显上升（w/o RL 约 7–8% → 500 steps 约 17% → 1000 steps 约 22%，且带虚线标注 +1.8×倍数关系）；Detailed Memory 组：精确度随训练步数下降（w/o RL 约 5% → 500/1000 steps 约 2–3%，标注 −0.46×）。(b) Crucial Memory 的 token 长度分布集中在约 10 附近且分布较窄；Detailed Memory 的 token 长度分布中心明显更高（约百级）且分布更宽、跨度更大。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于**机制**类证据，直接支持 Obs.3.2"RL 训练诱导自适应信息密度"的主张——(a) 面板量化证明训练过程确实把证据精确度非均匀地重新分配到高可见（crucial）区域，同时主动压缩低可见（detailed）区域的精确度，这正是模块 3（budget-aware training objectives）预期诱导的"版面驱动的预算分配"行为，而非仅靠视觉模态本身（呼应 Obs.2.1 的机制归因）；(b) 面板进一步显示 crucial 区域文本长度远短于 detailed 区域，印证方法设计中"关键证据应以更小 $L$、更高显著度渲染"的假设（面积 $\mathcal{O}(L\cdot s^2)$ 关系的间接体现）。但该图本身不能证明这种区域级密度差异如何直接转化为下游 QA 准确率提升——那部分由图片2（Figure 5的 oracle 注入实验）与 Table 1/4 主表格提供。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的 30K-context 设置下的统计分析（如正文所述"我们在 30K-context 设置下用 oracle 注入（Figure 5）和记忆统计（Figure 6）评估"）。柱状图未标注具体数据集来源（是否为单一数据集或跨数据集平均）——**OCR 正文未说明**该统计是否针对特定数据集或聚合结果，此为图中无法区分的实验设计细节。小提琴图未给出精确数值刻度标签（1、10、100 等具体分位数），因此其分布形状描述仅基于视觉相对位置判断。无其他额外证据缺口。

---

## 图片 2：Figure 5. Oracle analysis of layout regions (RQ3). We compare MemOCR with oracle variants that inject ground-truth evidence into either the Crucial or Detailed region of the rendered memory. While both injections improve accuracy, injecting into the crucial region yields larger gains, especially under tight memory budgets.

![Figure 5. Oracle analysis of layout regions (RQ3). We compare MemOCR with oracle variants that inject ground-truth evidence into either the Crucial or Detailed region of the rendered memory. While both injections improve accuracy, injecting into the crucial region yields larger gains, especially under tight memory budgets.](../assets/imgs/img_in_chart_box_146_533_539_925.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图对应 RQ3 的第一步——"不同版面区域在视觉压缩下的鲁棒性是否确实不同"，证据类型为**机制**验证（辅以效果对比）。它通过 oracle 注入实验直接检验：把相同的 ground-truth 证据分别注入 crucial 区域和 detailed 区域，是否会产生不同的准确率增益，从而验证"高可见区域证据更抗压缩"这一假设，并将结果与 MemOCR 自身（无注入）的实际表现对照。`[正文支持]`
   - **图表角色**：机制验证
   - **上文呼应**：第 4.4 节 RQ3，Obs.3.1（Oracle(Crucial) 始终优于 Oracle(Detailed)，且优势随预算收紧扩大；极端预算下注入反而可能有害）

2. **图像类型与布局**：网格状分组柱状图（3 列 × 4 行，共 12 个子图）。列代表数据集（HotpotQA、2Wiki、NQ），行代表 memory budget（1024、256、64、16 token，自上而下预算递减）。每个子图内含 3 根柱：橙色 Oracle (Crucial)、浅黄色 Oracle (Detailed)、绿色 MemOCR（无注入基线）。

3. **如何阅读**：每个子图纵轴为准确率（%，各列纵轴范围不同，需按子图自身刻度读数）；横轴无显式标签，由图例区分三种条件。阅读顺序应沿行方向（同一预算下三数据集对比）以及沿列方向（同一数据集下预算从 1024 降到 16 时三条件差距如何变化）。图例位于底部：Oracle (Crucial) 橙色、Oracle (Detailed) 浅黄、MemOCR 绿色。

4. **直接可见的结论**：在高预算（1024、256）时，三根柱高度普遍接近；随着预算收紧（64、16），Oracle(Crucial) 与 Oracle(Detailed) 之间的差距在多数子图中明显扩大，Oracle(Crucial) 保持相对较高水平而 Oracle(Detailed) 明显下降（尤其在 NQ 的 16-token 行，Oracle(Detailed) 降至接近该子图最低水平）。在 16-token 行的 HotpotQA 子图中，Oracle(Detailed) 柱明显低于 MemOCR（绿色）基线柱，即注入 detailed 区域后准确率低于不注入的 MemOCR 本身。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于**机制**证据，为 Obs.3.1 提供逐数据集、逐预算的定量支持——证明证据放置位置（区域可见度）本身是决定压缩鲁棒性的关键变量，而不仅是"是否有额外证据"的问题：同样的证据注入到 crucial 区域比注入到 detailed 区域更能抵抗低预算下的分辨率损失。这直接支撑方法设计中模块 1（drafting 阶段的显著性标注）和模块 2（渲染时的视觉优先级分配）的必要性——若区域间鲁棒性无差异，则版面显著性设计将失去意义。同时，HotpotQA 16-token 行中 Oracle(Detailed) 低于 MemOCR 基线的现象，与正文"极端预算下注入可能因增大图像整体尺寸而降低可辨识度反而有害"的陈述相印证。该图不能证明这种区域鲁棒性差异的底层像素/OCR 机制，也不能证明该效应能否推广到本图未覆盖的 TriviaQA 数据集或其他预算档位。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文明确报告的 30K-context 设置，数据集限于 HotpotQA、2Wiki、NQ 三者（未包含 TriviaQA），预算覆盖 {1024, 256, 64, 16} 四档。各子图纵轴的具体数值刻度、柱高对应的精确百分比数字在图中未标注数值标签，只能读出相对高度关系，无法精确复核 Obs.3.1 中提及的具体数值；此为图像本身分辨率/标注缺失导致的真实证据缺口。无其他额外证据缺口。
