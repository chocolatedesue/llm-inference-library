# 图片批次 2

## 图片 1：Figure 3. Design of the budget-aware training objectives. (1) Standard QA uses the unmodified question and memory for global correctness. (2) QA w/ Augmented Memory requires the visibility of crucial evidence even when the visual memory is heavily compressed. (3) QA w/ Augmented Question ensures detailed information is clearly identified with sufficient tokens. The low-budget, high-detail setting (gray area) is excluded as identifying detailed features under severe compression is infeasible.

![Figure 3. Design of the budget-aware training objectives. (1) Standard QA uses the unmodified question and memory for global correctness. (2) QA w/ Augmented Memory requires the visibility of crucial evidence even when the visual memory is heavily compressed. (3) QA w/ Augmented Question ensures detailed information is clearly identified with sufficient tokens. The low-budget, high-detail setting (gray area) is excluded as identifying detailed features under severe compression is infeasible.](../assets/imgs/img_in_image_box_119_141_566_584.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：图表角色为**方法流水线**（兼具**必要性**证据的概念铺垫）。它对应第3.3节"Budget-Aware Training Objectives"，具体化正文所述的问题：为防止训练坍缩为"shortcut policy"（agent把所有内容渲染成统一中等字号、绕开预期权衡），需要构造三个互补QA任务($\mathcal{T}_{std}$、$\mathcal{T}_{augM}$、$\mathcal{T}_{augQ}$)分别覆盖"预算×证据粒度"设计空间的不同象限 [正文支持]。
   - **图表角色**：方法流水线。
   - **上文呼应**：对应报告"模块3：Budget-aware Training Objectives"及"论文Story"中"核心贡献3"，第4-5页。

2. **图像类型与布局**：概念性2×2矩阵示意图（非曲线/柱状/表格）。横轴标注"Memory Budget"（Low→High，无刻度数值），纵轴标注"Evidence Granularity"（下方Detailed→上方Crucial）。四象限：左上为虚线框"(2) QA w/ Augmented Memory (Training Only)"；右上为蓝色实色填充框"(1) Standard QA (Training & Inference)"；右下为虚线框"(3) QA w/ Augmented Question (Training Only)"；左下为无编号的纯文字灰色说明区。各框内含人物/问号图标(Question)、文档图标(Memory/Compressed Memory)，以及"Goal:"文字说明。

3. **如何阅读**：横轴为预算高低的定性方向（非具体token数），纵轴为证据粒度粗细。象限位置携带语义：右上=高预算+关键证据(Standard QA)；左上=低预算+关键证据(Augmented Memory，图标显示"Compressed Memory")；右下=高预算+细节证据(Augmented Question)；左下=低预算+细节证据，无编号任务。应比较三个编号框各自的图标组合与"Goal"文字，而非坐标数值；(1)号框的蓝色实心填充样式与另两个虚线框样式不同，需结合框内文字("Training & Inference" vs "Training Only")理解视觉区分含义。

4. **直接可见的结论**：三个编号任务分别占据矩阵中的三个象限，只有左下象限没有编号任务、无图标，呈现纯文字加灰底样式 [图像直接可见]。(1)号框为蓝色实色填充且标注"Training & Inference"，(2)(3)号框为虚线边框且标注"Training Only"，两种视觉样式的区分与文字标注一致 [图像直接可见]。(2)号任务的Memory图标标注为"Compressed Memory"，与(1)(3)中未特别标注压缩的Memory图标在文字标签上不同 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图属于**必要性**类证据，将3.3节文字描述的三任务设计可视化为"预算×粒度"矩阵：右上($\mathcal{T}_{std}$)在充足预算下检验整体正确性；左上($\mathcal{T}_{augM}$)在低预算/关键证据象限下强迫关键证据下采样后仍可辨识；右下($\mathcal{T}_{augQ}$)在高预算/细节证据象限下检验细节是否被完整保留；左下(低预算+细节)象限被明确排除，与图注"identifying detailed features under severe compression is infeasible"一致，说明作者认为该任务组合本身不可行、故未纳入训练目标 [正文支持]。此图为Table 4消融实验(逐步去除$\mathcal{T}_{augM}$、$\mathcal{T}_{augQ}$、$\mathcal{T}_{std}$)提供设计动机的可视化基础，但图本身不含任何准确率数值或权重$w_k$信息，无法单独证明各任务的量化贡献——量化必要性证据仍需回到Table4/Obs.4.1-4.2 [基于文中逻辑的推断]。

6. **适用范围与证据缺口**：本图仅覆盖论文3.3节训练目标设计的概念呈现，不涉及具体数据集、模型规模或实验数值。无额外证据缺口（图为示意性矩阵，"低/高预算"与"Crucial/Detailed"为定性象限标签，非缺失的定量坐标）。

---

## 图片 2：Figure 4. Comparison of accuracy and relative performance drop across varying memory budgets (RQ2). MemOCR degrades more gracefully than textual baselines as budgets tighten. Without visual layout, MemOCR's low-budget robustness drops significantly, which suggests that adaptive information density facilitates more efficient memory budget utilization.

![Figure 4. Comparison of accuracy and relative performance drop across varying memory budgets (RQ2). MemOCR degrades more gracefully than textual baselines as budgets tighten. Without visual layout, MemOCR's low-budget robustness drops significantly, which suggests that adaptive information density facilitates more efficient memory budget utilization.](../assets/imgs/img_in_chart_box_616_674_1081_1001.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：图表角色为**机制**验证（兼**对比基线**）。对应§4.3"Analysis on Visual Robustness (RQ2)"，验证的问题是：MemOCR的低预算鲁棒性究竟来自"版面引导的预算分配"这一机制本身，还是仅来自视觉模态相对文本模态的固有优势——通过对比MemOCR、消融对照组"MemOCR w/o Visual Layout"（本文自身构造的消融组，非外部比较工作）与三个文本摘要类baseline(MemAgent、Mem-α、Mem0)在HotpotQA 10K上下文、更细粒度预算扫描下的准确率与相对降幅 [正文支持]。
   - **图表角色**：机制 + 对比基线。
   - **上文呼应**：对应报告"实验、指标与结论"中Obs.2.1、Obs.2.2，第7页。

2. **图像类型与布局**：上下两个共享横轴的子面板。上面板(a) "Accuracy (%)"为分组柱状图，横轴为Memory Budget(Tokens)，自左至右为1024/512/256/128/64/32/16/8共8档；每档下5根并排柱，颜色区分5个方法(MemOCR绿、MemOCR w/o layout灰、MemAgent粉、Mem-α浅蓝、Mem0紫)。下面板(b) "Relative Drop (%)"结构、配色、横轴与上面板一致，柱高向下延伸表示相对1024-token预算的性能下降幅度。图例位于图顶部，两面板共用。

3. **如何阅读**：横轴为预算档位，自左向右预算递减；上面板柱高越高准确率越高(y轴约20%-90%)；下面板柱高越深(越负)表示相对1024预算降幅越大(y轴约0至-70%)。应比较：同一预算档下MemOCR(绿)与MemOCR w/o layout(灰)的柱高差距（版面控制的边际贡献），以及MemOCR与三个文本baseline的差距（视觉+版面 vs 纯文本）。图上未标注具体数值标签，需以柱高相对比例判断。

4. **直接可见的结论**：随预算从1024降至8，所有方法上面板柱高均下降，但MemOCR(绿)柱高下降幅度明显小于其余四组，在最低预算档位(16、8)时MemOCR柱仍明显高于其他四组 [图像直接可见]。MemOCR w/o layout(灰)柱在中低预算档位(64及以下)的下降速率明显快于MemOCR(绿)，与文本baseline的下降趋势更接近 [图像直接可见]。下面板中MemOCR(绿)对应柱始终最贴近0线（降幅最小），其余四组在低预算区间(32/16/8)柱形明显更深 [图像直接可见]；MemOCR w/o layout、Mem-α、Mem0在极低预算下柱形深度目测已逼近面板下边界附近 [基于视觉的谨慎推断，无数值标签故无法精确读取具体百分比]。

5. **它验证的论点与方法设计含义**：该图核心验证Obs.2.1的**机制**主张——MemOCR与MemOCR w/o layout共享同一视觉模态，仅版面控制变量不同，两者在高预算下柱高接近但随预算收紧差距扩大，说明差距来源是"版面引导的非均匀分配"本身，而非视觉模态相对文本的固有优势 [正文支持]。图中横轴细化为8档(新增512/128/32/8)，超出主表{16,64,256,1024}四档，为Obs.2.2"8×token效率提升"(MemOCR在8-token的准确率与baseline在64-token相当)提供了可直接比对的视觉线索，因为x轴恰好包含8与64两个点 [基于文中逻辑的推断，具体数值仍以正文Obs.2.2陈述为准，图上无数值标签]。该图不能单独证明：三个文本baseline(MemAgent/Mem-α/Mem0)之间相对优劣的原因，以及去除版面后MemOCR与文本baseline之间剩余差距是否完全排除了其他混杂因素（如训练目标差异）——正文将该图的解释权限定于"版面控制"这一单一自变量的消融对比，未讨论其他因素 [基于文中逻辑的推断]。

6. **适用范围与证据缺口**：本图实验设置限定为HotpotQA数据集、10K上下文长度（正文§4.3明确说明），预算覆盖比主表更细的8档(1024~8)。无额外证据缺口——柱状图无数值标签，但正文Obs.2.1/2.2的定性陈述（"显著更小的降幅"、"8×效率提升"）与图中可见的相对高度关系一致，不构成OCR/图题冲突，也非正文明确缺失的实验设计细节。
