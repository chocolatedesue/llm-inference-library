# 图片批次 1

## 图片 1：Figure 1. Comparison of memory paradigms. (a) Raw History Memory fetches relevant history passages but suffers from noise and redundancy. (b) Textual Summary Memory allows the agent to summarize the history but suffers from uniform information density, where auxiliary details (gray) consume as much token space as crucial information (green). (c) Visual Memory (Ours) allocates memory budget via visual layout to achieve adaptive information density.

![Figure 1. Comparison of memory paradigms. (a) Raw History Memory fetches relevant history passages but suffers from noise and redundancy. (b) Textual Summary Memory allows the agent to summarize the history but suffers from uniform information density, where auxiliary details (gray) consume as much token space as crucial information (green). (c) Visual Memory (Ours) allocates memory budget via visual layout to achieve adaptive information density.](../assets/imgs/img_in_image_box_144_146_1037_453.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Figure 1（OCR 第 3 页），是 Introduction 部分用于说明"旧方法的限制"与"核心洞见"的**概念示意图**，而非实验结果图。它的证据类型是**问题严重性**（(a)(b) 两个面板具象化 Raw History Memory 的冗余噪声问题和 Textual Summary Memory 的"uniform information density"缺陷）叠加**方法流水线**的预览（(c) 面板引出 Visual Memory 的"adaptive information density"核心机制及 resolution control 的 budget-fidelity 权衡）。它验证/解释的具体问题是：为什么现有两类文本记忆范式在预算受限时会失效，以及本文方法在直觉上如何通过版面控制解决这一失效。`[正文支持]`（对应 Introduction 第1-2页 "uniform information density"论述与 Obs.1.2 的动机铺垫）
   - **图表角色**：问题严重性（主）+ 方法流水线（(c)面板预览）。
   - **上文呼应**：对应"旧方法的限制"章节（Raw History Memory、Textual Summary Memory 的限制）与"核心洞见与假设"章节（视觉显著性、面积∝L·s²、resolution control）。

2. **图像类型与布局**：横向三段式示意图，顶部有灰色渐变箭头标注"Compress Efficiency & Flexibility"，从左到右效率递增。三个色块面板：(a) 蓝色"Raw History Memory"、(b) 橙色"Textual Summary Memory"、(c) 绿色"Visual Memory (Ours)"。每个面板内含卡通化的 AI Agent 图标、对应的记忆表示形式示意（书本堆叠/文本摘要卡片/带版面的富文本渲染图）、一个向下箭头标注处理步骤（Tokenize/Tokenize/Rendering），底部为若干灰色/绿色堆叠方块图标代表token，并各自标注token量级文字说明。(c)面板右侧另有一个用虚线分隔的小节，展示"Resolution Control"下高分辨率与低分辨率两种渲染结果对比。

3. **如何阅读**：三个面板从左到右按顺序对比同一"AI Agent 处理历史信息"任务在三种记忆范式下的表现；每个面板下方的文字（如"~10K Tokens (10K Detailed Memory Tokens)"、"~1K Tokens (100+900)"、"~200 Tokens (100+100)"）是示意性数值标注，用于对比三种范式达到同等信息保留水平所需的token量级；(c)面板内的颜色编码（深绿"Crucial Info"、浅绿/灰"Auxiliary Info"）区分关键证据与辅助细节的版面显著度；右侧 Resolution Control 小节则通过图片方块变大变小和 "~1K Tokens"/"~10 Tokens"对比展示同一内容在不同分辨率下的token开销差异。

4. **直接可见的结论**：(a) Raw History Memory 面板展示 AI Agent 从堆叠的历史交互记录中检索 top-k 片段直接拼接，标注约"10K Tokens"且全部为"Detailed Memory Tokens"；(b) Textual Summary Memory 面板展示一份文本摘要卡片同时含"Crucial Info"与多条"Detailed Info"，标注"Uniform Information Density"，token量级标注为"~1K Tokens (100+900)"，并注明"Auxiliary details consume linear space"；(c) Visual Memory 面板展示一张带版面结构的渲染图像（大标题"Crucial Info"配图表、小字"Auxiliary Info"），标注"Adaptive Information Density"，token量级标注为"~200 Tokens (100+100)"及注释"Smaller Text = Fewer Vision Tokens"；右侧 Resolution Control 部分显示同一版面结构在"High Res"（~1K Tokens，标注"More Details"）与"Low Res"（~10 Tokens，标注"Higher Compression Rate"）下的示意对比，且两种分辨率下"Crucial Info"部分的图标均保持可辨识，而"Auxiliary"部分标注被放大镜特别标出。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：这是一张**问题严重性/方法概念**类证据，用具象化数字（10K vs 1K vs 200 tokens）直观对比三种范式在保留同等"Crucial Info"时所需的总token量差异，从而支撑论文核心主张——"Textual Summary Memory 因 uniform information density 导致辅助细节与关键证据线性争抢预算"以及"Visual Memory 通过版面显著性实现自适应信息密度，可用更少 token 保留同等关键信息"`[正文支持]`（对应正文"uniform information density"与"面积∝L·s²"论述）。(c)面板右侧的 Resolution Control 小节直观呈现了"通过分辨率下采样统一控制预算，而不改变记忆内容本身"这一设计原理，对应方法论中"整体预算可通过分辨率下采样统一调控"的表述`[正文支持]`。需要注意：图中"10K/1K/200 tokens"等具体数值是示意性类比数字，用于教学式呈现范式差异，**不能视为论文实际实验测得的数值**（真实实验数值见 Table1 等，预算档位为16/64/256/1024）；该图本身不提供任何定量实验支持，其论证效力仅限于"概念动机说明"，图中标出的"~10 Tokens"低分辨率效果也不能等同于论文真实的极端预算实验结果。
   
6. **适用范围与证据缺口**：本图为 Introduction 阶段的概念示意图，覆盖范围仅限于"直观解释三种记忆范式的原理差异"，不代表任何具体数据集、模型或预算档位下的实测结果。图中标注的具体token数值（10K/1K/200/10）为示意性类比，其确切来源、计算依据和是否对应某一具体样例，正文未说明——**文中未说明**。除此之外无额外证据缺口。

---

## 图片 2：Figure 2. Framework of MemOCR. (a) Memory Drafting (Text Domain): The LLM agent incrementally updates a rich-text memory based on new incoming chunks, assigning visual priority via formatting and structure. (b) Memory Reading (Vision Domain): The rich text is rendered into a 2D memory image, which serves as the agent's sole working context for answering queries. (c) Budget-Aware Training Objectives: We train the agent under varying degrees of memory compression. The drafting ability is updated via aggregated advantages, while the reading ability is updated via separate advantages.

![Figure 2. Framework of MemOCR. (a) Memory Drafting (Text Domain): The LLM agent incrementally updates a rich-text memory based on new incoming chunks, assigning visual priority via formatting and structure. (b) Memory Reading (Vision Domain): The rich text is rendered into a 2D memory image, which serves as the agent's sole working context for answering queries. (c) Budget-Aware Training Objectives: We train the agent under varying degrees of memory compression. The drafting ability is updated via aggregated advantages, while the reading ability is updated via separate advantages.](../assets/imgs/img_in_image_box_175_150_1023_531.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Figure 2（OCR 第 4 页），是方法章节（§3）的整体框架图，证据类型为**方法流水线**。它旨在完整呈现 MemOCR 的两阶段记忆生命周期（Memory Drafting 文本域 + Memory Reading 视觉域）以及第三部分 Budget-Aware Training Objectives 的具体任务构造（$T_{std}$、$T_{augM}$、$T_{augQ}$）和优势更新方式的分工，验证的是"论文 Story 与贡献边界"中列出的三项核心贡献（视觉记忆范式、两阶段生命周期、budget-aware RL训练目标）在结构上如何组织与衔接。`[正文支持]`（对应§3.1-§3.3 正文与"方法推理树"章节）
   - **图表角色**：方法流水线。
   - **上文呼应**：对应"方法推理树"中的模块1（Memory Drafting）、模块2（Memory Reading）、模块3（Budget-aware Training Objectives），以及"核心贡献"第2、3条。

2. **图像类型与布局**：整体是一张流程示意图，用两个大色块背景区分左右两大阶段：左侧橙红色背景为"(a) Memory Drafting in the Text Domain"，右侧绿色背景为"(b) Memory Reading in the Vision Domain"；底部中央标题"(c) Budget-Aware Training Objectives"对应连接两阶段的公式与虚线箭头。左侧流程：New Chunk → LLM Agent（图标含齿轮/火焰） → Rich Text Memory，并有一条弧形"Update"箭头把 Rich Text Memory 反馈回 LLM Agent 形成循环。中间是一个"Rendering"棱镜图标，将 Rich Text Memory 转为 Visual Memory（图像图标）。右侧 (b) 区域用三个平行的浅青色卡片分别表示三个 QA 变体：(1) Standard QA（高亮青色框，"Training & Inference"）、(2) QA w/ Augmented Memory（"Training Only"）、(3) QA w/ Augmented Question（"Training Only"），每个卡片内是 Question(+Detailed Question)→Memory(或Compressed Memory)→Agent图标→Answer 的横向小流程。底部公式 $A=\frac{\sum w_k A^{(k)}}{\sum w_k}$ 位于紫色虚线框中，左右各有紫色虚线箭头："Update Phase 1 with Aggregated Advantage"（指向左侧 LLM Agent）和 "Update Phase 2 with Separate Advantages"（指向右侧，标注"Advantages for each QA Variant"）。

3. **如何阅读**：整图按"从左到右、从上到下"的流程顺序阅读——先看左侧文本域的迭代起草循环，再看中部渲染箭头，再看右侧三个并列 QA 任务卡片（用青色深浅/加框区分"训练+推理都用"的标准任务与"仅训练用"的两个增强任务），最后看底部紫色虚线部分理解两条不同的参数更新路径（聚合优势 vs 分任务独立优势）分别对应更新左侧 drafting 能力和右侧 reading 能力。三个 QA 卡片之间应横向比较：输入的问题类型（原始问题 vs 细节导向问题）和记忆图像状态（原始/未压缩 vs 4×下采样压缩）的差异。

4. **直接可见的结论**：(a) 区域清晰显示 Rich Text Memory 由 LLM Agent 基于 New Chunk 迭代更新（循环箭头），随后通过 Rendering 转为 Visual Memory；(b) 区域三张卡片并列显示三种 QA 任务的输入差异——(1) Standard QA 使用普通 Question + 常规 Memory 图标；(2) QA w/ Augmented Memory 使用同样 Question 但 Memory 图标标注为"Compressed Memory"（图标明显更小/带压缩标记）；(3) QA w/ Augmented Question 使用标注为"Detailed Question"的问题图标 + 常规未压缩 Memory；三者输出均汇总到底部公式，公式右侧标注仅 $A^{(\mathcal{T}_{std})}$ 附近有"Advantages for each QA Variant"箭头指向右侧三个任务框（Update Phase 2），而左侧只有一条"Aggregated Advantage"箭头指向 LLM Agent（Update Phase 1）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：这是一张**方法机制**类证据，直接可视化"reading 能力用分离的任务特定 advantage 更新，drafting 能力用跨任务聚合 advantage 更新"这一训练设计——图中紫色虚线箭头的走向（一条汇聚成"Aggregated"指向 drafting 侧，另一条以"Separate"形式指向 reading 侧三个任务框）与正文"$\mathcal{T}_{std}, \mathcal{T}_{augM}, \mathcal{T}_{augQ}$ ... reading 能力按任务分别更新，drafting 能力用跨任务聚合 advantage 更新（$A=\frac{\sum_k w_k A^{(k)}}{\sum_k w_k}$）"的文字描述完全对应`[正文支持]`。这直接支撑"必要性"类主张——即三个训练目标分别针对"标准正确性"、"极端压缩下关键证据存活"、"细节不被完全丢弃"三个不同失效模式而设计，且通过不同的优势聚合方式分别驱动 drafting 与 reading 两种能力的学习，是 Table 4 消融实验（逐一去除 $\mathcal{T}_{augM}/\mathcal{T}_{augQ}/\mathcal{T}_{std}$）背后的机制图解`[基于文中逻辑的推断]`。需要注意：该图仅呈现训练目标的**结构性设计**（任务构造与更新路径），不包含任何量化训练效果或消融数值，这些效果需结合 Table 4 与 Obs.4.1/4.2 的文字结论确认，本图本身不能单独证明各训练目标的实际贡献大小。

6. **适用范围与证据缺口**：本图覆盖范围是 MemOCR 方法在训练阶段构造的三个 QA 变体任务及其与两阶段记忆生命周期的整体连接关系，是论文方法设计的示意性总览，不代表具体某个数据集/预算档位下的实际运行结果。图中标注的公式 $A=\frac{\sum w_k A^{(k)}}{\sum w_k}$ 与正文一致但未标注 Eq. 编号，且 $w_k$ 的具体取值、各任务 reward 的具体计算公式正文和图中均未给出——**文中未说明**（与"方法推理树"模块3中已记录的缺口一致）。除此之外无额外证据缺口。
