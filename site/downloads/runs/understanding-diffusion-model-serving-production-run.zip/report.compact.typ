#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[Understanding Diffusion Model Serving in Production: A Top-Down Analysis of Workload, Scheduling, and Resource Efficiency]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yanying Lin, Shuaipeng Wu, Shutian Luo, Hong Xu, Haiying Shen, Chong Ma, Min Shen, Le Chen, Chengzhong Xu, Lin Qu, Kejiang Ye]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[ACM Symposium on Cloud Computing (SoCC '25) · 2025]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[扩散模型服务] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU调度] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[模型缓存] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[生产环境workload分析] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[资源利用率]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[DOI：https://doi.org/10.1145/3772052.3772206]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

本文对生产云环境中扩散模型服务所面临的挑战进行了全面分析。我们考察了区别于传统机器学习工作负载的独特计算模式和资源需求，揭示了其多阶段流水线架构所带来的系统层面根本性挑战。我们的分析基于一个来自商业图像生成服务的数据集，该数据集在生产运行中记录了跨越300多块GPU、处理350万条请求的情况。与以往仅关注单一组件的研究不同，我们的数据集捕获了从用户请求到硬件利用率的完整执行栈，首次提供了扩散模型生产服务的整体视角。这种跨层次的监测手段使我们能够识别出在孤立层次分析中难以发现的根本性挑战，包括极端的请求分布偏斜、复杂的多级缓存需求以及显著的资源管理开销。为应对这些挑战，我们开发了一套专门的扩散模型服务系统，实现了具有动态扩缩容策略的全局缓存协调、具有优化I/O路径的异构快速实例模板，以及具有成本感知调度的分层预取机制。评估结果表明，该系统将端到端延迟降低了49.8%，模型加载时间减少了73.1%，充分说明跨层分析能够显著推动服务系统设计的改进。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [Understanding Diffusion Model Serving in Production: A Top-Down Analysis of Workload, Scheduling, and Resource Efficiency],
    [作者], [Yanying Lin, Shuaipeng Wu, Shutian Luo, Hong Xu, Haiying Shen, Chong Ma, Min Shen, Le Chen, Chengzhong Xu, Lin Qu, Kejiang Ye],
    [发表场所 / 年份], [ACM Symposium on Cloud Computing (SoCC \'25), 2025],
    [研究领域], [系统、机器学习服务],
    [关键词], [扩散模型服务, GPU调度, 模型缓存, 生产环境workload分析, 资源利用率],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：#link("https://doi.org/10.1145/3772052.3772206")
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（3--5 个）]：`扩散模型服务` · `GPU调度与缓存` · `生产环境workload分析` · `资源利用率悖论` · `多阶段流水线系统`
]

本文基于某商用图像生成服务7天、300+ GPU、350万请求的生产数据，首次跨应用/中间件/硬件层分析扩散模型服务，发现请求极端偏斜、GPU利用率-延迟悖论、缓存与资源错配三大根本问题，并设计MLoRA系统实现端到端延迟降低49.8%、模型加载时间降低73.1%#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

OCR覆盖论文引言、问题诊断（第2--5节）、方法设计（第6节）、实验（第7节）及相关工作（第13页）等主要内容，并附带6批图表的视觉分析。已知缺口：多处相关系数未说明计算方法（Pearson/Spearman）与聚合粒度\*\*\[作者明确陈述数值但未说明算法\]\*\*；部分图表标注（如Fig.3d、Fig.8c、更新延迟图）与正文文字描述的坐标轴/数值存在不一致，构成OCR图注与图像内容的衔接缺口；论文自身未给出各模块独立消融数据。以上均为论文事实层面的限制，非背景知识。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

#strong[问题]：扩散模型（通过多步\"去噪\"从噪声逐步生成图像，类似反复擦拭模糊照片直至清晰）在生产环境中如何被大规模服务，其独特的多阶段流水线架构和资源需求是否被现有系统充分理解\*\*\[作者明确陈述\]#strong[。#strong[为什么重要]：扩散模型已快速走向商用部署，QPS可达1万+，但服务效率的系统级挑战此前\"largely uncharted territory\"]\[作者明确陈述\]#strong[。#strong[难点来源于三条物理约束]：(1) 迭代去噪需20-50个不可并行步骤]\[作者明确陈述\]#strong[；(2) 基础模型+LoRA+ControlNet构成的多组件DAG（任务依赖图，好比流水线各工位必须按顺序完成）带来组合爆炸]\[作者明确陈述\]#strong[；(3) 组件体量差异悬殊（1-20GB基础模型 vs 100MB-1GB LoRA vs 500MB-10GB ControlNet）]\[作者明确陈述\]\*\*。#strong[本文story]：这些约束在生产中表现为请求偏斜、利用率悖论、缓存错配三种现象，现有系统假设\"负载稳定、缓存对象同质\"因而失效；本文转而把缓存、扩容、调度作为耦合问题联合设计，以此消除级联失效。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：请求极端偏斜]
  #image("figure-groups/page-0003-5aa81800e8f9.png", width: 100%)
  #emph[Figure 2: Base model request skewness analysis. The Gini coefficient of 0.876 indicates a highly skewed distribution, with the top 1 model accounting for 28.8% of requests. This highlights the significant concentration of requests on a few popular models, leading to resource allocation challenges.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：请求呈长尾分布且热门模型执行时间更长，频次-延迟呈U型。

- #strong[论证关系]：支撑Gini=0.876与流行度惩罚，作为热温冷分档缓存动机。

- #strong[适用范围]：图内切分口径与正文数字存在轻微差异。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：冷启动延迟惩罚]
  #image("figure-groups/page-0004-19841ecfb65f.png", width: 100%)
  #emph[Figure 4: Cold start analysis for various model sizes. The chart illustrates the significant latency incurred during the initial loading of large models, highlighting the need for improved preloading strategies.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：冷启动中模型加载占42.7%、网络占25.6%，加载频率与延迟负相关。

- #strong[论证关系]：证实数据搬运开销巨大，驱动异构快速实例模块设计。

- #strong[适用范围]：逐容器数值与正文聚合平均值口径不同。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：LoRA长尾使用]
  #image("figure-groups/page-0004-c1a335cd8364.png", width: 100%)
  #emph[Figure 3: LoRA adapter usage distribution across requests. The long-tail nature of LoRA usage leads to significant cache management challenges, as most adapters are rarely used but still need to be cached for occasional requests.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：top166适配器占80%请求，Cold LoRA带来88.5%延迟惩罚。

- #strong[论证关系]：证明组件访问模式异构，支撑多维效用淘汰与分层预取。

- #strong[适用范围]：Network Transfer Rate坐标轴与正文描述存在变量名称不一致。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：资源利用率悖论]
  #image("assets/imgs/img_in_chart_box_635_171_1128_525.jpg", width: 100%)
  #emph[Figure 6: Request scheduling and cache consistency analysis. The chart illustrates the impact of request scheduling on cache consistency, highlighting the challenges of maintaining coherent state across multiple model components during concurrent requests.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：GPU利用率与延迟正相关(0.469)，呈现低利用率高延迟异常簇。

- #strong[论证关系]：揭示编排与内存开销是瓶颈，驱动成本感知调度设计。

- #strong[适用范围]：热力图未标注具体样本量与聚合粒度。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：多级资源竞争]
  #image("figure-groups/page-0005-f9b59b9574e5.png", width: 100%)
  #emph[Figure 5: Contention analysis for multi-level cache resource competition. The chart illustrates the GPU memory usage statistics, highlighting the contention points between different model components and their impact on overall system performance.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：显存与加载频率呈时段集中峰值，BaseModel与LoRA加载时间强相关(0.86)。

- #strong[论证关系]：证明资源竞争集中爆发，支撑原子缓存与Serverless部署。

- #strong[适用范围]：散点分组标准未在图注中完整说明。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：资源分配错配]
  #image("figure-groups/page-0006-fa063c9a72a7.png", width: 100%)
  #emph[Figure 7: Resource allocation mismatch analysis. The chart illustrates the disparity between actual resource demand and uniform allocation, highlighting the inefficiencies in resource distribution across models.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：98.4% Pod GPU利用率\<20%，资源分配与需求总错配度达74.2%。

- #strong[论证关系]：量化均匀分配失效，驱动热度感知全局缓存协调模块。

- #strong[适用范围]：热力图色标未标单位，P250+末端有截断。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：缓存替换开销]
  #image("figure-groups/page-0007-21bbfa025352.png", width: 100%)
  #emph[Figure 8: Cache replacement overhead analysis. The chart illustrates the performance impact of cache replacement strategies, highlighting the significant latency incurred during model loading and unloading operations.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：BaseModel更新延迟为LoRA近5倍，组件间开销呈数量级差异。

- #strong[论证关系]：推翻LRU对象同质假设，支撑效用淘汰中的组件类型差异化建模。

- #strong[适用范围]：Fig 8c坐标轴指标与正文描述存在冲突。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

#critique-card(
  [传统ML/LLM服务系统（vLLM、Alpaserve等）],
  [稳定模型配置+可预测访问模式],
  [不适配扩散模型组合空间与极端偏斜\*\*\[作者明确陈述\]\*\*],
  [全局缓存协调],
  [无法从当前OCR内容确认直接对比数据],
)

#critique-card(
  [LoRA专用系统（Punica、dLoRA）],
  [GPU kernel层面适配器融合与显存管理],
  [未处理缓存层级、请求偏斜、多组件流水线协调\*\*\[作者明确陈述\]\*\*],
  [分层预取与调度],
  [基线含dLoRA在线融合，Fig.11 LoRA加载对比部分检验],
)

#critique-card(
  [GPU集群调度（Llumnix、Pollux、AntMan）],
  [面向训练批处理任务优化],
  [与延迟敏感、内存受限的扩散推理特征不同\*\*\[作者明确陈述\]\*\*],
  [成本感知调度],
  [无法从当前OCR内容确认直接对比],
)

#critique-card(
  [分布式缓存（NetCache、Cocktail）],
  [对象大小较均匀的通用负载],
  [未处理组件组合复杂度与尺寸异构性\*\*\[作者明确陈述\]\*\*],
  [异构快速实例+全局缓存协调],
  [无法从当前OCR内容确认直接对比],
)

#critique-card(
  [LRU/LFU淘汰策略],
  [缓存对象同质],
  [加载成本、体积、复用模式高度异构下失效\*\*\[作者明确陈述\]\*\*],
  [多维效用淘汰函数],
  [文中未说明是否有直接消融对比],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

+ #strong[洞见1（工作负载层）]：请求分布极端偏斜（Gini=0.876）且偏斜模式数天内快速漂移（主导配置可损失60-70%份额），\"优化热门会饿死长尾、均匀分配会浪费资源\"是根本张力\*\*\[作者明确陈述\]\*\*。
+ #strong[洞见2（中间件层）]：98.4%实例GPU利用率低于20%但延迟很差------\"资源利用率悖论\"；计算仅占端到端延迟15-30%，大部分时间耗在编排开销\*\*\[作者明确陈述\]\*\*。
+ #strong[洞见3（系统层）]：基础模型（稳定但体量大）与LoRA（数量巨大但生命周期不可预测）访问模式错配，放大数据搬运代价（cold-start最高47秒，级联传输15GB+）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
+ #strong[设计假设]：三层挑战联合优化可获叠加收益，这是MLoRA架构的隐含前提\*\*\[基于文中逻辑的推断，依据：正文反复强调独立处理是根因\]\*\*，其成立依赖于三层问题确实相互耦合而非独立可分；若某场景下三层挑战互不影响，该假设的收益可能不成立。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：请求先经全局缓存协调判断组件冷热档位，触发异构快速实例做数据搬运，再由分层预取与成本感知调度决定组合的静态/动态处理路径，最终输出推理结果。三大模块设计如下。

=== 模块1：全局缓存协调
<模块1全局缓存协调>
- #strong[动机]：缓存与扩容独立处理导致新实例冷启动（需47秒才追平老实例性能）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[运行]：按热度分三档------热门(top5%)一致性哈希多副本+预融合；温(5-30%)多臂老虎机时序预取；冷(70%)用评分函数 $S\(m_i\,t\)= f_(r e q)\(m_i\)dot.op e^(- lambda\(t - t_(l a s t)\)) dot.op frac(C_(l o a d)\(m_i\), M_(s i z e)\(m_i\))$ 做机会式缓存；扩容用约束优化 $min_(x_i) sum x_i\(alpha L_(q u e u e) + beta sum C_(l o a d) + gamma U_(g p u)\)$ 联合缓存状态决策。
- #strong[优势]：把\"命中/未命中\"范式转为\"预测性资源编排\"#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

=== 模块2：异构快速实例
<模块2异构快速实例>
- #strong[动机]：70%以上冷启动延迟来自I/O\*\*\[作者明确陈述\]\*\*。
- #strong[运行]：Direct I/O将读取块从128KB提升至2MB降低系统调用开销；加权K-means（k=5）按频率对组件聚类，预分配专用pinned memory池，best-fit路由分配。
- #strong[优势]：绕开内核缓冲与双拷贝开销，降低碎片化风险\*\*\[作者明确陈述\]\*\*。

=== 模块3：分层预取与调度
<模块3分层预取与调度>
- #strong[动机]：组合空间超160万种，但top50组合占73.2%请求，传统LRU/LFU假设对象同质与现实不符\*\*\[作者明确陈述\]\*\*。
- #strong[运行]：高频组合静态预融合（消除运行时张量操作）；低频组合\"非对称加载+语义相关性缓存\"；效用淘汰 $E_(s c o r e)\(c_i\)= frac(P_(r e u s e) times T_(l o a d) times alpha_(t y p e), M_(s i z e) times\(1 + beta dot.op a g e\))$。
- #strong[优势]：优先保留\"高价值-高复用-低体积\"组件\*\*\[作者明确陈述\]\*\*。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：根问题 DAG 结构]
  #image("assets/imgs/img_in_image_box_108_171_598_300.jpg", width: 100%)
  #emph[Figure 1: Diffusion model serving pipeline architecture showing multi-component DAG structure with base models, LoRA adapters, and conditioning networks requiring coordinated orchestration for image generation.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：BaseModel汇合CLIP/T5与ControlNet，与Sampler间反复迭代。

- #strong[论证关系]：可视化多组件DAG与迭代去噪，支撑流水线原子缓存设计。

- #strong[适用范围]：概念性架构示意图，不含具体量化数值。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：MLoRA系统架构]
  #image("assets/imgs/img_in_image_box_104_168_588_538.jpg", width: 100%)
  #emph[Figure 9: System architecture of MLoRA. The diagram illustrates the three core components---Global Cache Coordination, Heterogeneous Instance Manager, and Hierarchical Request Router---and their interactions within the diffusion model serving system.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示四级存储层级、异构内存模板及贯穿各层的全局缓存协调。

- #strong[论证关系]：可视化原子缓存与异构实例机制，说明跨层编排架构。

- #strong[适用范围]：示意图未标注 Request Router 独立模块。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制→收益→条件1]：将流水线视为原子缓存单元→减少级联缓存缺失→需要组件间访问模式确有相关性（co-occurrence矩阵有意义）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。
- #strong[机制→收益→条件2]：Direct I/O扩大块尺寸→降低系统调用次数占比→仅在存储吞吐本身不是瓶颈时有效（$T_(r e a d)$公式）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。
- #strong[机制→收益→条件3]：效用淘汰函数按类型和复用概率加权→比同质假设的LRU更贴合真实成本→依赖$P_(r e u s e)$估计准确，而该估计方法文中未说明，是该逻辑链最薄弱环节\*\*\[基于文中逻辑的推断\]\*\*。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[效果类]：MLoRA相对生产级基线是否降低端到端延迟/加载时间------对应主结果表（Fig.10-13）。
- #strong[机制类]：利用率-延迟悖论、访问模式异构是否真实存在------对应Fig.2-8的相关性分析。
- #strong[必要性类]：耦合设计、效用淘汰是否为必需------#strong[文中未说明]独立消融，无法直接判定。
- #strong[鲁棒性/适用范围类]：改进是否在base/LoRA/ControlNet各组件一致------部分由Fig.11体现；跨服务商/跨模态泛化#strong[文中未说明]。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
单一商用图像生成服务，7天、300+GPU、350万请求；对比基线为经六个月优化的生产级系统（SGLang+HuggingFace PEFT+dLoRA在线融合+优化LRU+增强轮询），300 GPU集群、Kubernetes serverless部署；A/B测试方法论；硬件/软件版本、重复次数、统计方式均#strong[文中未说明]。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Gini系数，测量请求频率分布不均衡（0-1），越大越不均衡。#strong[定义与公式]：文中未给出计算公式，仅报告数值0.876------#strong[无可核验公式]。#strong[实验用途]：论证请求偏斜。#strong[读数与边界]：数值本身无统计显著性说明。
- #strong[指标与方向]：资源分配错配度$Delta_(m i s m a t c h)$，无量纲，越大越差。#strong[定义与公式]：$Delta_(m i s m a t c h) = sum_(i = 1)^n\|1 / n - d_i\|$，#strong[来源层级：原文公式]；$d_i$为模型i实际请求占比。#strong[实验用途]：论证均匀分配与实际需求错配（74.2%）。#strong[读数与边界]：仅为静态快照度量，不含时间演化。
- #strong[指标与方向]：端到端延迟降低，百分比，越大越好。#strong[定义与公式]：仅报告49.8%结果数值，未给出分母定义------#strong[无可核验公式]（Fig.10）。#strong[实验用途]：主实验结果。#strong[读数与边界]：未报告置信区间/样本量。
- #strong[指标与方向]：模型加载加速（各组件），秒/百分比，越大越好。#strong[定义与公式]：结果报告值（基础模型68.2%、LoRA 73.1%、ControlNet 61.8%），非定义式（Fig.11）。#strong[实验用途]：验证异构快速实例模块收益。#strong[读数与边界]：图表中呈现的部分数值（如网络/I/O图的87.0%/76.0%/33.0%）与文字所述68.2%/73.1%/61.8%存在口径不一致，无法确认对应关系。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]：

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较对象], [核心限制], [对应模块], [直接实验/仍未验证边界],),
    table.hline(),
    [Alpaserve/vLLM], [假设稳定负载], [全局缓存协调], [无直接对比实验，仅文字批判],
    [Punica/dLoRA], [未处理系统级缓存/偏斜问题], [分层预取调度], [Fig.11 LoRA加载对比部分检验],
    [生产级基线（六个月优化）], [隐含缓存/扩容独立处理、LRU同质假设], [MLoRA三模块整体], [Fig.10-13全部A/B测试直接检验\*\*\[实验支持\]\*\*],
  )]
  , kind: table
  )

#strong[主张与证据]：

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [证据], [强度与边界],),
    table.hline(),
    [端到端延迟降49.8%], [Fig.10a A/B测试\*\*\[实验支持\]\*\*], [尾部（P99）改进仅12.8%，明显小于均值，未报告置信区间],
    [模型加载时间降73.1%], [Fig.11\*\*\[实验支持\]\*\*], [图内数值与另一图（网络/I/O图）口径不一致，需谨慎],
    [缓存-扩容耦合是必要解法], [现象描述\*\*\[作者明确陈述\]#strong[\+因果断言]\[基于文中逻辑的推断\]\*\*], [缺\"耦合vs独立\"消融实验],
    [LRU/LFU因同质假设失效], [定性论证\*\*\[作者明确陈述\]\*\*], [缺量化命中率/延迟对比],
  )]
  , kind: table
  )

- 尾部延迟（P90/P95/P99）改进幅度（约12.8-16.9%）显著小于均值改进（49.8%），说明\"49.8%\"不能代表最坏情况收益。
- 各模块（缓存协调/异构实例/分层预取）均未见独立消融，仅有整体系统vs基线对比，无法拆分各自贡献占比。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0011-0cd5db92fab2.png", width: 100%)
    #emph[Figure 11: Model loading acceleration results across different component types. MLoRA shows significant latency reductions: 68.2% for base models (22.6s → 7.2s), 73.1% for LoRA adapters (4.6s → 1.2s), and 61.8% for ControlNet modules (5.1s → 1.9s).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：模型加载加速]
    - #strong[图组结论]：BaseModel/LoRA/ControlNet加载分别加速87.0%/76.0%/33.0%。

- #strong[论证关系]：验证异构快速实例降低I/O与数据搬运开销的效果。

- #strong[适用范围]：图内各组件百分比与图注所述68.2%/73.1%存在口径差异。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0011-13bc1d8174ce.png", width: 100%)
    #emph[Figure 10: End-to-end performance comparison showing MLoRA achieves significant latency reduction compared to the baseline.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：端到端延迟降低]
    - #strong[图组结论]：端到端延迟均值降低49.8%，P95降低16.9%，P99降低12.8%。

- #strong[论证关系]：证实系统级耦合优化显著降低延迟，但尾部改进幅度小于均值。

- #strong[适用范围]：基于300 GPU集群7天A/B测试数据，无独立消融。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_640_169_1124_461.jpg", width: 100%)
    #emph[Figure 12: Network and I/O performance analysis comparing MLoRA with baseline. MLoRA achieves 89.5% reduction in network bandwidth and 60.2% reduction in disk I/O usage while significantly improving model update latency.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：网络与I/O优化]
    - #strong[图组结论]：网络带宽降低89.5%，磁盘I/O降低60.2%，消除更新延迟尖峰。

- #strong[论证关系]：证明MLoRA带来全局系统性资源改善而非单指标代偿。

- #strong[适用范围]：雷达图坐标未标注归一化区间，气泡变量未说明。
  ],
)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：扩散模型多阶段流水线在生产环境中如何被高效服务
  - 旧方法限制：稳定负载假设、缓存对象同质假设、独立层优化范式
  - 核心洞见/假设：三层问题（偏斜、利用率悖论、访问错配）应耦合优化
    - 方法模块1：全局缓存协调（热度分档+缓存-扩容联合决策）
      - 可验证预测：耦合设计降低冷启动惩罚、扩容延迟
        - 指标与实验：62.4%/78.3%数值（作者报告，未见消融实验）
          - 图表证据：MLoRA架构图展示Cache Coordination贯穿存储层
            - 结论与适用边界：验证架构存在，未验证耦合的必要性（未被当前证据直接验证）
    - 方法模块2：异构快速实例（Direct I/O+pinned memory模板）
      - 可验证预测：降低I/O相关冷启动开销
        - 指标与实验：模型加载加速68.2%/73.1%/61.8%
          - 图表证据：Fig.4冷启动开销分解（模型加载42.7%）、Fig.11加载对比
            - 结论与适用边界：与另一图数值口径不一致，需谨慎（证据缺口）
    - 方法模块3：分层预取与效用淘汰
      - 可验证预测：静态/动态组合管理降低融合开销、提升缓存命中价值
        - 指标与实验：融合开销降91.7%（未见vs LRU/LFU的独立对比）
          - 图表证据：Fig.3长尾分布（top166占80%）
            - 结论与适用边界：$P_(r e u s e)$估计方法文中未说明，机制未完全验证
  - 结论与适用边界：端到端延迟降49.8%（主实验支持），但尾部收益（12.8%）远小于均值，且限定于单一商用图像生成服务7天数据

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：（1）首个跨三层的扩散服务生产数据集；（2）识别请求偏斜、组合复杂度、资源错配三大根本挑战；（3）设计并评估MLoRA系统\*\*\[作者明确陈述\]#strong[。#strong[证据充分的结论]：端到端延迟降49.8%、模型加载降73.1%等主结果有A/B测试支撑]\[实验支持\]#strong[。#strong[尚属推断的意义]：三层耦合优化是收益的必要条件这一因果断言缺独立消融验证]\[基于文中逻辑的推断\]#strong[。#strong[适用条件]：单一商用图像生成服务、7天数据、300+GPU]\[作者明确陈述\]\*\*。#strong[局限]：统计方法透明度不足（多处相关系数未说明计算方式）；各模块独立贡献未拆分；理论公式与实测值未做对照验证。

#strong[审稿式风险检查]：

- 贡献新意：三大挑战的诊断具有一定新意，但MLoRA各模块（分层缓存、Direct I/O、效用淘汰）在已有系统中均有近似思路，论文更多是系统集成与生产验证------当前证据未显示原创性风险之外的额外问题。
- 写作/可复现性：代码/数据集链接文中未说明，K=5等超参数选择依据缺失，存在可复现性风险。
- 效果大小：均值收益大（49.8%），但尾部收益仅约1/3，若过度概括\"49.8%\"可能夸大最坏情况改善------当前证据显示此风险真实存在。
- 实验覆盖：缺各模块独立消融，无法判断收益来源；仅单一服务商/单一模态数据，泛化性未验证。
- 方法设计：$P_(r e u s e)$、$alpha_(t y p e)$等关键变量估计方法未披露，削弱了效用淘汰函数的可验证性。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：扩散模型。#strong[第一性原理角色]：通过多步去噪从噪声状态收敛到图像状态，步骤间存在严格时序依赖（因果链上不可并行）。#strong[本文位置]：决定了服务系统的非并行硬约束。
- #strong[术语]：LoRA适配器。#strong[第一性原理角色]：以小规模参数（低秩矩阵）叠加于基础模型权重上实现风格微调，受\"体积小但数量巨大\"的资源约束。#strong[本文位置]：长尾使用模式是缓存分档设计的核心对象。
- #strong[术语]：Gini系数。#strong[第一性原理角色]：将请求频率视为\"财富\"，衡量分配集中度，受0-1数学约束。#strong[本文位置]：量化请求偏斜程度（0.876）。
- #strong[术语]：冷启动（Cold Start）。#strong[第一性原理角色]：模型首次加载需完整经历远程读取→本地加载→初始化的资源搬运链条，受存储层级带宽约束。#strong[本文位置]：47秒峰值延迟的来源。
- #strong[术语]：Pinned Memory（锁页内存）。#strong[第一性原理角色]：不可被换出的物理内存区域，与GPU间传输带宽更高但分配代价大，受内存容量约束。#strong[本文位置]：异构快速实例模块的核心机制。
- #strong[术语]：Direct I/O。#strong[第一性原理角色]：绕开内核缓冲区直接传输数据，受系统调用开销与块大小的权衡约束。#strong[本文位置]：将读取块从128KB提升到2MB。
- #strong[术语]：NP-hard装箱问题。#strong[第一性原理角色]：在有限\"箱子\"（GPU资源）中放置大小不一的\"物品\"（请求负载）的组合优化问题，计算复杂度呈指数增长。#strong[本文位置]：资源分配错配的理论类比（#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]，未给出形式化证明）。

=== 12.2 学习路径
<122-学习路径>
+ #strong[扩散模型的生成机制]（基本对象）：先理解\"多步去噪生成图像\"是什么，因为它决定了后续一切延迟分析的起点。
+ #strong[多组件DAG依赖]（约束）：理解基础模型+LoRA+ControlNet为何必须按固定顺序协同工作，这是\"组合爆炸\"问题的来源。
+ #strong[缓存与内存层级]（机制）：了解远程存储→本地SSD→主机内存→GPU显存的数据搬运路径，才能理解冷启动为何耗时。
+ #strong[利用率与延迟的关系]（可观测量）：理解\"GPU利用率低≠系统高效\"这一反直觉现象，是本文诊断问题的核心观察角度。
+ #strong[A/B测试与百分比改进的解读边界]（系统行为）：理解均值改进与尾部（P99）改进可能差异巨大，避免被单一汇总数字误导。
