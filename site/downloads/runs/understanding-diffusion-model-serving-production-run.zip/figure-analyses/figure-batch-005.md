# 图片批次 5

## 图片 1：Figure 9: System architecture of MLoRA. The diagram illustrates the three core components—Global Cache Coordination, Heterogeneous Instance Manager, and Hierarchical Request Router—and their interactions within the diffusion model serving system.

![Figure 9: System architecture of MLoRA. The diagram illustrates the three core components—Global Cache Coordination, Heterogeneous Instance Manager, and Hierarchical Request Router—and their interactions within the diffusion model serving system.](../assets/imgs/img_in_image_box_104_168_588_538.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图为方法流水线类证据，用于说明 MLoRA 系统如何在存储层级与GPU实例内部组织缓存协调、异构内存模板与动态流水线组装，直接对应第6节"MLoRA Design"中"将缓存-或-未命中范式转变为预测性资源编排""把整条流水线视为原子缓存单元而非独立组件"的机制陈述，以及6.2节"异构快速实例"中提到的异构pinned memory模板机制。它回应的根问题是：多组件DAG+组件体量异构（第一性原理3）造成的资源管理压力如何被系统架构层面统一处理，而非验证具体数值结果。`[正文支持]`
   - **图表角色**：方法流水线。
   - **上文呼应**：第6节"MLoRA Design"总述 + 6.1"Global Cache Coupled with Scaling" + 6.2"Heterogeneous Fast Instances"（Figure 9候选图注）。

2. **图像类型与布局**：系统架构示意图（分层框图）。整体分为四个纵向层级：顶部"Remote Mass Storage (e.g. NAS)"、其下"Local Storage Device (e.g. SSD)"、再下方"Host Memory (DRAM)"（内含标注"Heterogeneous Templates"的橙/蓝渐变分段色块）、底部"GPU HBM"（深蓝色条）。中间嵌有橙色边框的"Fully Dynamic DiffusionPipeline"模块，内部并列三个子块："Diffusion BaseModel"（蓝底）、"Multi-ControlNet"（灰底）、"Multi-LoRA"（橙底）。整个GPU相关部分被虚线框标注为"Heterogeneous GPU Instance"。图右侧有一条纵向浅蓝色框"Cache Coordination"，通过多条水平箭头（部分双向）与Remote Storage、Local Storage、Host Memory三层相连。

3. **如何阅读**：自上而下为数据搬运路径——远程存储经"Network"箭头到本地SSD，再经"Loading Optimization"箭头进入Host Memory的异构模板区，模板中的组件被组装进"Fully Dynamic DiffusionPipeline"（由BaseModel/ControlNet/LoRA构成），最终进入GPU HBM完成计算；右侧"Cache Coordination"框与左侧三层（Remote/Local/Host Memory）分别有横向箭头交互，表示全局缓存协调是贯穿而非局限于单一层级的旁路控制模块。

4. **直接可见的结论**：
   - 存储路径清晰分为四级：远程存储→本地SSD→主机内存（DRAM）→GPU HBM `[图像直接可见]`。
   - Host Memory层中的"Heterogeneous Templates"以颜色分段（黄色多格+蓝色多格）呈现，暗示按不同大小/类别对内存池做了分区 `[图像直接可见]`；具体分区数值、大小含义无法从图中读出，仅是色块分段 `[基于视觉的谨慎推断]`。
   - Pipeline模块内BaseModel、Multi-ControlNet、Multi-LoRA三者并列排布在同一橙色容器中，表示三者被作为一个整体单元处理 `[图像直接可见]`。
   - "Cache Coordination"框与三层存储均有独立箭头连接，而非仅连接到某一层 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图支持机制类主张——MLoRA"将整条流水线视为原子缓存单元，协调三级存储层级间的放置决策"（正文6.1节原句）`[正文支持]`；图中Host Memory层的分段模板与正文6.2.2节"heterogeneous pinned memory templates"（按size-frequency加权K-means聚类分层预分配pinned pool）在概念上对应 `[正文支持]`；右侧独立的Cache Coordination模块与正文强调"避免把缓存与扩容当独立问题处理"的设计前提一致 `[正文支持]`。但该图仅展示架构关系，**不能**证明任何具体性能数字（如68.2%/73.1%等模型加载加速数字，或62.4%/78.3%的缓存耦合收益），这些结论需依赖Fig 10-13的实验图，该图本身不含任何量化坐标轴或数值。

6. **适用范围与证据缺口**：本图覆盖论文第6节所述MLoRA架构中的"全局缓存协调"与"异构快速实例（含Heterogeneous Templates）"两部分设计，与候选图注（Figure 9："三大核心组件——Global Cache Coordination、Heterogeneous Instance Manager、Hierarchical Request Router"）总体一致。真实缺口：图中仅显式标注"Cache Coordination"框，未见任何标注为"Hierarchical Request Router"（或含"Router""Scheduling"字样）的独立模块——图注声称的第三个核心组件在本图裁剪范围内无法辨认对应的可视化元素，这是图题与图像内容之间的一处不完全对应，无法确认该组件是否被省略、合并进其他框，或位于图像未覆盖的区域。

---

## 图片 2：Figure 11: Model loading acceleration results across different component types. MLoRA shows significant latency reductions: 68.2% for base models (22.6s → 7.2s), 73.1% for LoRA adapters (4.6s → 1.2s), and 61.8% for ControlNet modules (5.1s → 1.9s).

![Figure 11: Model loading acceleration results across different component types. MLoRA shows significant latency reductions: 68.2% for base models (22.6s → 7.2s), 73.1% for LoRA adapters (4.6s → 1.2s), and 61.8% for ControlNet modules (5.1s → 1.9s).](../figure-groups/page-0011-0cd5db92fab2.png)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：证据类型为效果类（Baseline vs MLoRA 的量化对比）。图像本身四个面板均围绕"更新延迟（Update Latency）"按组件类型（Base Model/LoRA/ControlNet/Pipeline）与时间/分布维度展开对比，语境上属于第7节实验评估部分对模型/流水线更新时延改进的量化证明，最贴近正文对"model update latency"及"complete pipeline update"改进的讨论（7.3/7.4节，页码11-12）。`[正文支持]`（角色定位）+ `[基于文中逻辑的推断]`（因具体数值与候选图注Figure 11不完全吻合，见第6项）。
   - **图表角色**：实验结论。
   - **上文呼应**：第7.3节"Model Loading Acceleration"与第7.4节"Network and I/O Performance"（"Model update latency decreases by 89.1% (from 38.9s to 4.2s)"及"Complete pipeline updates...improve by 69.5% (14.4s → 4.4s)"）。

2. **图像类型与布局**：四宫格（Panel 1–4）组合图。Panel 1为分组柱状图"(a) Update Latency Comparison by Component"，横轴为组件类型（Base Model/LoRA/ControlNet/Pipeline），纵轴为平均延迟(s)，蓝色=Baseline、品红色=MLora，柱顶标注百分比降幅（87.0%↑/76.0%↑/33.0%↑/69.5%↑）。Panel 2为"(b) Pipeline Update Latency Time Series"折线图，横轴为D1-D7（7天），纵轴为延迟(s)，内嵌一个局部放大子图（标注"D5"附近）。Panel 3为"(c) CDF of Update Latencies (with >50s inset)"累积分布曲线，横轴延迟(s)、纵轴累积概率，标注两条曲线的P50值（Baseline 5.59s、MLora 2.89s），内嵌子图显示<50s区间的CDF细节。Panel 4为"(d) Component Update Latency Distribution"箱线/散点分布图，横轴为组件类型，纵轴为延迟(s)，柱上方标注方差变化（如"384.3→37.0 (90.4%↑)"等）。

3. **如何阅读**：四个面板均以蓝色代表Baseline、品红/深红色代表MLora，比较对象是"更新（update/loading）延迟"在改用MLoRA前后的变化；Panel 1按组件横向比较均值降幅，Panel 2按时间序列比较逐日波动，Panel 3比较延迟的整体分布（CDF及P50中位数），Panel 4比较各组件延迟的离散程度（方差）。

4. **直接可见的结论**：
   - Base Model平均更新延迟从38.19s降至4.96s（标注87.0%↑），LoRA从4.93s降至1.19s（76.0%↑），ControlNet从5.07s降至3.40s（33.0%↑），Pipeline从14.36s降至4.38s（69.5%↑）`[图像直接可见]`。
   - 7天时间序列中Baseline延迟波动幅度显著更大（含D3附近出现接近300s的尖峰），MLora曲线全程更平稳、贴近低位 `[图像直接可见]`。
   - CDF显示MLora曲线整体更靠左（延迟更低），中位数P50由5.59s降至2.89s `[图像直接可见]`。
   - 各组件延迟方差在MLora下显著降低（如Base Model方差384.3→37.0，降90.4%；Pipeline方差213.1→36.4，降82.9%）`[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该组图从多角度（均值、时间序列、分布、方差）证明 MLoRA 在"模型/流水线更新延迟"上相对基线有效果类改进，呼应正文"Model update latency decreases by 89.1% (from 38.9s to 4.2s)"（7.4节）与"Complete pipeline updates...improve by 69.5% (14.4s → 4.4s)"（7.3节）中关于更新时延改善的整体叙事方向 `[基于文中逻辑的推断]`。其中Pipeline列的数值（14.36s→4.38s，69.5%）与正文"14.4s → 4.4s，69.5%"高度吻合，可视为同一结果的可视化 `[正文支持]`。但Base Model/LoRA/ControlNet三列在图中呈现的百分比（87.0%/76.0%/33.0%）与基线-MLoRA绝对值（38.19→4.96s；4.93→1.19s；5.07→3.40s）**并不等同于**候选图注Figure 11所述"68.2% for base models (22.6s→7.2s)、73.1% for LoRA (4.6s→1.2s)、61.8% for ControlNet (5.1s→1.9s)"——两组数字体系不一致（尤其Base Model的38.19s vs 22.6s、ControlNet降幅33.0% vs 61.8%）。因此不能将本图视为Figure 11本身的证据，只能确认它反映的是"更新延迟"这一相关但独立的度量维度，具体对应论文哪一张编号图（更贴近Fig.12b模型更新延迟或未在OCR中完整呈现的另一子图）无法从当前材料确定。

6. **适用范围与证据缺口**：本图覆盖的是论文生产集群A/B测试环境下（300 GPU、Kubernetes serverless部署、六个月优化基线）按组件类型统计的"更新/加载延迟"对比，时间跨度为D1-D7共7天，与正文数据集时间范围一致。真实缺口（OCR/图题冲突）：图片清单将该图关联到页11候选图注"Figure 11"（数值68.2%/73.1%/61.8%/69.5%，对应22.6s→7.2s等），但图像实际显示的四个百分比与三项基线-MLoRA绝对数值（Base Model、LoRA、ControlNet）与该图注不一致，仅Pipeline一项（14.36→4.38s，69.5%）吻合；该图更可能对应正文中另一处编号图（如Fig.12b"model update latency"或未展开的子图），但正文OCR未提供与本图四个百分比（87.0%/76.0%/33.0%/33%方差等）逐一匹配的编号图注，故其确切图号归属**无法从当前OCR内容确认**。
