# 图片批次 4

## 图片 1：Figure 7: Resource allocation mismatch analysis. The chart illustrates the disparity between actual resource demand and uniform allocation, highlighting the inefficiencies in resource distribution across models.

![Figure 7: Resource allocation mismatch analysis. The chart illustrates the disparity between actual resource demand and uniform allocation, highlighting the inefficiencies in resource distribution across models.](../figure-groups/page-0006-fa063c9a72a7.png)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图对应第 4.3 节"Resource Allocation Mismatch"，证据类型为**问题严重性**（兼有**机制类**成分）。作者需要用它证明"均匀资源分配与极端偏斜工作负载之间存在根本性错配"这一根问题的具体表现：98.4%的Pod GPU利用率低于20%但延迟仍差的"资源利用率悖论"，以及由Gini系数0.876驱动的74.2%总错配度（$\Delta_{mismatch}$公式的结果）。`[正文支持]`
   - **图表角色**：问题严重性
   - **上文呼应**：第4.3节"资源分配错配"；对应主张地图核心洞见2（资源利用率悖论）与主张#9（74.2%错配度）

2. **图像类型与布局**：四个子图组成的组合图（Figure 7 的四个Panel）。(a) 带误差棒的散点/条带图；(b) 热力图；(c) 散点图+趋势线；(d) 分组条形图。

3. **如何阅读**：
   - (a) x轴"Pod (Sorted by GPU Load)"（P0→P250+，按负载降序排列），y轴"GPU Utilization (%)"（0-60），红色虚线为"Overload Threshold (65%)"，绿色虚线为"Normal (20%)"，图例标注 Overloaded: 0 / Normal: 0 / Idle: 251；
   - (b) x轴"Hour of Day"，y轴"Pod (High to Low Load)"，颜色深浅表示强度（色标数值可见但坐标含义无独立图注说明）；
   - (c) x轴"Pod GPU SM Utilization (%)"（0-30），y轴"Average Latency (s)"，散点+红色虚线趋势线，标注"Correlation: 0.399"，圈出"Idle Zone"；
   - (d) x轴"Model (Ranked by Popularity)"（1-10），y轴"Resource Proportion"（0-0.35），条形按"Under-allocated / Uniform Allocation / Actual Demand"分组着色，标注"Mismatch: 74.2%"。

4. **直接可见的结论**：
   - (a) 绝大多数Pod（图例标注251个为Idle）GPU利用率集中在20%阈值线以下，仅左侧极少数Pod呈现较高且波动很大的利用率区间，Overloaded数为0；`[图像直接可见]`
   - (b) 热力图显示不同Pod在不同小时的负载强度存在明显的空间-时间不均匀分布，颜色从深到浅呈梯度分布；`[图像直接可见]`
   - (c) SM利用率与延迟之间存在弱正相关（相关系数0.399），大部分点集中在低利用率、延迟差异很大的区域（Idle Zone圈出的低利用率高延迟点群）；`[图像直接可见]`
   - (d) 各热门度排名模型的"Actual Demand"占比与"Uniform Allocation"基准线存在系统性偏离，头部模型实际需求远超均匀分配份额，尾部模型则相反，整体标注错配度74.2%；`[图像直接可见]`

5. **它验证的论点与方法设计含义**：Panel (a)直接支撑正文"98.4%的Pod GPU利用率低于20%"这一效果类主张的可视化证据（图中Idle占比与该数字量级一致）；Panel (c)支撑正文"SM利用率极低（4%）但延迟仍高且波动大"这一机制类描述，说明计算资源未被有效利用是延迟根源之一，而非计算瓶颈；Panel (d)是$\Delta_{mismatch}=74.2\%$公式结果的直接可视化，为"均匀分配与偏斜需求错配"这一必要性类主张（即需要popularity-aware分层缓存/调度而非均匀分配）提供直接证据，对应MLoRA模块1（全局缓存协调中的Popularity-Aware Cache Distribution）的设计动机。`[正文支持]` 该图不能证明"该错配问题是NP-hard装箱问题变种"这一理论断言（正文本身也未给出形式化证明）。

6. **适用范围与证据缺口**：本图覆盖论文所述的300+GPU生产集群、7天数据窗口内的Pod级资源利用快照。真实缺口：(1) Panel (b) 热力图的颜色量表具体代表何种资源指标（GPU利用率/内存/请求数）及其数值范围，正文未给出与该子图对应的具体文字说明，图上色标数字也无单位标注——**文中未说明**，图像本身也无法确认；(2) Panel (a) 中Idle/Normal/Overloaded的精确总Pod数（x轴在P250+处截断，无法确认末端具体数值），导致无法从图像本身精确核算出与正文"98.4%"完全一致的比例——图像裁剪导致的真实缺口。

---

## 图片 2：Figure 8: Cache replacement overhead analysis. The chart illustrates the performance impact of cache replacement strategies, highlighting the significant latency incurred during model loading and unloading operations.

![Figure 8: Cache replacement overhead analysis. The chart illustrates the performance impact of cache replacement strategies, highlighting the significant latency incurred during model loading and unloading operations.](../figure-groups/page-0007-21bbfa025352.png)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：本图对应第5.2节"Pipeline Shift Overhead and Cache"，证据类型为**机制类**（揭示更新开销的组件异构性与相关性），验证"模型更新/缓存替换开销存在数量级差异且呈现反直觉的负相关"这一现象，为MLoRA模块1（缓存-扩容耦合）和模块3（多维效用淘汰函数中的$T_{load}$、$\alpha_{type}$差异化处理）提供动机证据。`[正文支持]`
   - **图表角色**：机制类
   - **上文呼应**：第5.2节"Pipeline Shift Overhead and Cache"；对应主张地图模块1/模块3的"传统LRU/LFU假设对象同质"必要性论证

2. **图像类型与布局**：三个子图。(a) 堆叠/分组条形图叠加折线图；(b) 分组条形图（带误差棒）叠加折线图（双y轴）；(c) 散点图+趋势线。

3. **如何阅读**：
   - (a) x轴"Hour of Day (2025-06-16)"（00:00-21:00），左y轴"Update Latency (ms)"，条形分Base Model Updates（红）/ControlNet Updates（绿）/LoRA Updates（橙）堆叠，右y轴"Inference Latency (ms)"对应紫色折线；
   - (b) x轴"Update Type"（Base Model / LoRA / ControlNet），左y轴"Latency (ms)"，条形带±1 Std Dev误差棒，标注均值22596ms/4593ms/5071ms，右y轴"Update Count"对应蓝色折线（标注173,381 / 179,848等数值）；
   - (c) x轴"Update Frequency (updates/hour)"，y轴"Average GPU SM Utilization (%)"，散点+红色虚线趋势线，标注"Correlation: 0.988"与"High freq impact: 237.0%"。

4. **直接可见的结论**：
   - (a) 在2025-06-16全天24小时窗口内，更新延迟（各组件堆叠条）与推理延迟折线走势并非同步上升，部分更新量较大的时段推理延迟折线反而处于相对低位；`[图像直接可见]`
   - (b) Base Model的平均更新延迟（22596ms）远高于LoRA（4593ms）和ControlNet（5071ms），且Base Model的误差棒（标准差）明显更宽，同时其更新次数（约59K，图中最低）远少于LoRA/ControlNet（173K/179K级别）；`[图像直接可见]`
   - (c) 更新频率与平均GPU SM利用率呈强正相关（相关系数0.988），散点随更新频率增加大致线性上升，高频率区域被圈出并标注"High freq impact: 237.0%"；`[图像直接可见]`

5. **它验证的论点与方法设计含义**：Panel (a)/(b)支撑正文"Fig. 8a显示更新频率与流水线延迟负相关"及"Fig. 8b显示Base Model更新成本近5倍于LoRA、4.5倍于ControlNet，且变异系数达0.986"两条机制类主张，说明组件间加载/更新成本存在数量级差异，直接支持"传统LRU/LFU假设缓存对象同质"这一必要性主张不成立，进而支撑模块3效用淘汰函数中$\alpha_{type}$、$T_{load}$差异化建模的设计选择。`[正文支持]` 但Panel (c)的可见内容（"Update Frequency vs GPU Utilization"，相关系数0.988）与正文对Fig.8c的文字描述（"network I/O scales linearly with update frequency (correlation 0.985)…disk I/O…(correlation 0.178)"，即应展示更新频率与网络I/O/磁盘I/O的关系）在指标对象上不一致，无法确认二者是否为同一子图的不同呈现——该部分的因果/机制关联**无法从当前OCR内容确认**是否支持正文所述的网络I/O论证。

6. **适用范围与证据缺口**：本图数据覆盖论文所述生产集群中2025-06-16当天24小时的更新/推理延迟观测（Panel a）及全周期的按组件类型聚合统计（Panel b、c），属于7天数据集中的局部时间切片示例。真实缺口：Panel (c) 的坐标轴标签（"GPU Utilization"）与正文对应段落所述指标（网络I/O、磁盘I/O）及相关系数数值（0.985/0.178 vs 图中0.988）、增幅数值（正文"网络I/O surges by 345%" vs 图中标注"High freq impact: 237.0%"）存在明显不一致，构成OCR/图题与图像内容冲突，无法确认该Panel是否即为正文所指的Fig.8c，也无法判断此差异源于版式裁剪、多子图合并还是内容错配。
