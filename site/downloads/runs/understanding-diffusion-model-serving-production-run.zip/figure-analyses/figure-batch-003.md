# 图片批次 3

## 图片 1：Figure 6: Request scheduling and cache consistency analysis. The chart illustrates the impact of request scheduling on cache consistency, highlighting the challenges of maintaining coherent state across multiple model components during concurrent requests.

![Figure 6: Request scheduling and cache consistency analysis. The chart illustrates the impact of request scheduling on cache consistency, highlighting the challenges of maintaining coherent state across multiple model components during concurrent requests.](../assets/imgs/img_in_chart_box_635_171_1128_525.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：证据类型：机制类（揭示"GPU利用率悖论"及其成因，即利用率与延迟的反直觉关系）。图表角色：**问题严重性**（第4章资源利用低效问题的核心量化证据，为MLoRA设计提供动机，而非方法流水线或实验结论本身）。
   - **图表角色**：问题严重性
   - **上文呼应**：第4.2节"Scheduling and Cache Coherency"，对应正文Fig. 6a-d；呼应核心洞见2（资源利用率悖论）与主张地图主张2。`[正文支持]`

2. **图像类型与布局**：2×2四联复合图。(a) 散点图+虚线趋势线；(b) 相关系数热力图；(c) 柱状图（左轴）叠加折线图（右轴）的双轴图；(d) 散点图，颜色映射第三变量。

3. **如何阅读**：
   - (a) x轴：Average GPU Utilization(%)；y轴：Average Inference Latency(ms)；气泡散点+红色圆圈标注"Performance Bottleneck"；标注Correlation 0.469，Containers 242。
   - (b) 行：gpu_util、memory_util、cpu_cores、gpu_memory_gb；列：avg_latency、p95_latency、p99_latency；色标范围约-0.4至0.6。
   - (c) x轴：Model Combinations（多个如M151_L0等标签，部分因分辨率较低难以逐一辨识）；左y轴（蓝柱+误差棒）：Average Latency(s)；右y轴（橙线）：Request Frequency(K)；标注"Most Efficient: M151_L0..."。
   - (d) x轴：GPU Memory Usage(GB)；y轴：Average Latency(s)；颜色映射：GPU Utilization(%)；绿色圈标注"Efficient Zone"，标注"Memory-Latency Corr: 0.455"。

4. **直接可见的结论**：
   - (a) 整体呈弱正相关趋势；红圈标注的一簇点GPU利用率约10-15%但延迟处于全图最高区间（约27500-30000ms），可见"低利用率、高延迟"的异常簇。`[图像直接可见]`
   - (b) gpu_util与三项延迟指标均正相关(0.47/0.65/0.65)；memory_util均为负相关(约-0.42/-0.41/-0.32)；cpu_cores接近零相关(约-0.02至-0.11)；gpu_memory_gb正相关(0.45/0.64/0.66)。`[图像直接可见]`
   - (c) 不同模型组合间平均延迟差异明显、误差棒较大；橙色请求频率折线与蓝色延迟柱之间无严格单调对应关系。`[图像直接可见]`
   - (d) 多数低GPU利用率（绿色调）点聚集于左下"Efficient Zone"（低内存、低延迟）；右上方一簇高GPU利用率着色（红/橙）点对应高内存与高延迟。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：面板(a)直接对应正文"Fig. 6a reveals a counterintuitive positive correlation (0.47) between GPU utilization and inference latency"，属机制类证据，证实"利用率高不代表性能好"的悖论，支撑核心洞见2。面板(b)对应"multi-dimensional correlation analysis...GPU utilization consistently correlates with increased latency, host memory utilization shows an inverse relationship...CPU utilization shows minimal correlation"，量化支撑"内存管理是调度核心瓶颈"，为异构快速实例（Direct I/O+pinned memory）模块提供动机。面板(c)对应"frequently requested model combinations often experience disproportionately high latency"（popularity penalty），是全局缓存协调（热度分级）模块设计动机的直接证据。面板(d)对应"Fig. 6d establishes memory management as the central scheduling challenge"，支撑"需要memory-aware调度策略"的必要性主张，指向成本感知路由设计方向。`[正文支持]`。这些均属第4章问题诊断层面证据，不能证明MLoRA具体参数选择（如K=5、θ阈值）的最优性，也不能替代第7节A/B实验结果对方案有效性的验证。

6. **适用范围与证据缺口**：本图基于该商用图像生成服务7天、300+GPU、242个容器的生产观测数据（页码：5）。真实缺口：(b)热力图未标注具体样本量与聚合粒度（按请求还是按容器），图中无法判断该相关系数计算口径；(c)部分模型组合标签因图像分辨率较低难以逐一完整辨识，无法逐一核实每个组合的具体延迟数值。

---

## 图片 2：Figure 5: Contention analysis for multi-level cache resource competition. The chart illustrates the GPU memory usage statistics, highlighting the contention points between different model components and their impact on overall system performance.

![Figure 5: Contention analysis for multi-level cache resource competition. The chart illustrates the GPU memory usage statistics, highlighting the contention points between different model components and their impact on overall system performance.](../figure-groups/page-0005-f9b59b9574e5.png)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：证据类型：机制类+效果类混合（时间维度资源竞争模式与组件间加载延迟相关性）。图表角色：**问题严重性**（第4.1节资源竞争问题的核心量化证据，为MLoRA异构实例与全局缓存协调设计提供动机）。
   - **图表角色**：问题严重性
   - **上文呼应**：第4.1节"Resource Competition"，对应正文Fig. 5a-c；呼应核心洞见2及旧方法限制表中"持久化部署模型与扩散工作负载时间集中式资源争用不匹配"一条。`[正文支持]`

2. **图像类型与布局**：三联图（标注Panel 1/2/3）。(a) 时间序列图：面积阴影区间+双折线，双y轴；(b) 散点图+趋势线，颜色映射时间变量；(c) 散点图，分为两组颜色，含阈值虚线。

3. **如何阅读**：
   - (a) x轴：Hour of Day(0-24)；左y轴：GPU Memory Usage(GB)（浅蓝阴影为GPU Memory Range，深蓝折线为Avg GPU Memory）；右y轴：Model Loading Frequency（橙线LoRA Loads，深色线Base Model Loads）；橙色方框标注约6-9点区间为"Resource Competition"。
   - (b) x轴：Base Model Loading Latency(ms)；y轴：LoRA Loading Latency(ms)；颜色映射Hour of Day；红色虚线趋势线；标注Correlation: 0.858。
   - (c) x轴：GPU Duty Cycle(%)；y轴：Loading Efficiency(Events/Hour)；蓝色点与绿色点两组；橙色虚线标注Efficiency Threshold；标注Efficiency Correlation: 0.989。

4. **直接可见的结论**：
   - (a) GPU内存使用与加载频率呈现明显时段性波动，橙框标注区间（约6-9点）出现同步峰值，随后回落；其余时段（0-5点、15-24点）相对低平。`[图像直接可见]`
   - (b) 散点沿趋势线呈清晰正相关，Base Model加载延迟越高对应LoRA加载延迟越高；颜色（小时）分布在趋势线两侧但无明显系统性分层。`[图像直接可见]`
   - (c) 蓝色点多密集分布在GPU Duty Cycle较低、Loading Efficiency较低且位于阈值线以下区域；绿色点多分布在GPU Duty Cycle较高（约10-15%）、Loading Efficiency明显更高且位于阈值线以上区域，整体呈强正相关。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：面板(a)对应正文"GPU memory utilization fluctuates between 15.8GB and 47.6GB across instances. The temporal correlation between base model and LoRA adapter loading operations creates resource bottlenecks"，属效果类证据，证明资源争用在时间维度集中爆发而非均匀分布，支撑批判"持久化部署模型与扩散工作负载时间集中式资源争用模式根本不匹配"，为MLoRA异构快速实例及serverless部署选择提供动机。面板(b)对应"a strong positive correlation (0.86) between base model and LoRA loading times, indicating that resource contention degrades all loading operations collectively. This challenges conventional caching strategies that treat resource types independently"，属机制类证据，直接支撑核心洞见3（基础模型-LoRA访问错配放大数据搬运代价）及全局缓存协调模块"将整条流水线视为原子缓存单元"设计选择的必要性。面板(c)对应"Containers with highest loading frequencies maintain 22.4% average GPU utilization versus 6.4% for infrequently loaded instances...serverless approaches...could dramatically improve serving efficiency"，属效果类证据，支撑同一批判并是实验设置中采用Kubernetes serverless部署（而非MLoRA贡献本身）的动机来源。`[正文支持]`。这些面板仅建立现象与设计动机的关联，不能单独证明MLoRA各模块相对该现象的量化收益，该验证需依赖第7节Fig.10-13的A/B测试结果。

6. **适用范围与证据缺口**：本图基于该商用图像生成服务7天生产数据、300+GPU集群观测（页码：4-5）。真实缺口：(a)橙色"Resource Competition"标注区间的精确起止小时因坐标轴刻度稀疏无法精确读出；(b)颜色图例（Hour of Day）在图像中较小，无法精确判断各散点对应的具体小时数值，只能读出定性色阶趋势；(c)蓝/绿两组点的具体分组标准（图注与正文均未说明是否对应"高频vs低频加载容器"）无法从当前图像或OCR内容确认。
