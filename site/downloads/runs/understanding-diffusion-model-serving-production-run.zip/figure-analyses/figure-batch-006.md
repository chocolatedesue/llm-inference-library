# 图片批次 6

## 图片 1：Figure 10: End-to-end performance comparison showing MLoRA achieves significant latency reduction compared to the baseline.

![Figure 10: End-to-end performance comparison showing MLoRA achieves significant latency reduction compared to the baseline.](../figure-groups/page-0011-13bc1d8174ce.png)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：本图对应第7.2节"End-to-End Performance Improvements"，是MLoRA系统的**主实验结论类**证据，直接验证论文核心主张——"生产A/B测试显示MLoRA端到端延迟降低49.8%、p99尾延迟降低12.8%"（`[正文支持]`，页码：11）。它回答的问题是：把三层挑战（工作负载偏斜、资源利用率悖论、缓存/资源错配）作为耦合问题联合优化后，最终对用户可感知延迟的整体收益是多少，并且这一收益在不同延迟统计口径（均值、推理耗时、P95、P99）下是否稳健。
   - **图表角色**：实验结论。
   - **上文呼应**：第7.2节"End-to-End Performance Improvements"及摘要/引言中的49.8%/12.8%主张（页码：1, 2, 11）。

2. **图像类型与布局**：一组3个子面板（Panel 1/2/3，对应(a)、(b)、(d)，无(c)面板出现在本裁剪范围内）：(a)为分组柱状图，横轴为延迟类型（E2E RT、Infer.、P95、P99），纵轴为延迟(ms)，蓝色为Baseline、品红色为MLora，每组柱顶标注绿色百分比提升值；(b)为核密度分布图，横轴End-to-End Latency(ms)，纵轴密度(×1e-5)，Baseline（青色实线）与MLora（品红虚线）两条曲线；(d)为CDF尾延迟图，横轴Latency(ms)，纵轴累积概率，两条曲线（Baseline、MLora）并标注P90/P95/P99处的百分比差异。

3. **如何阅读**：(a)中应比较同一延迟类型下Baseline与MLoRA柱高的相对下降幅度，柱顶百分比即为该类型的改进率；(b)应比较两条密度曲线峰值位置与峰值高度，越靠左、峰越高越集中在低延迟区；(d)应比较两条CDF曲线在同一累积概率下的横坐标差异，标注框给出P90/P95/P99三个分位点处的改进百分比。三图共享同一横轴单位（ms），可交叉核对。

4. **直接可见的结论**：(a) 四种延迟类型MLoRA柱均低于Baseline，标注提升幅度从大到小依次为E2E RT 49.8%、Infer. 24.7%、P95 16.9%、P99 12.8%，即改进幅度随统计口径向尾部延伸而递减；Baseline柱的误差棒（很可能是标准差/置信区间）普遍比MLoRA柱更宽，尤其在P95、P99处；(b) Baseline密度曲线在极低延迟区（接近0）有一个更高、更尖锐的峰（约3.4e-5），随后在约5万-10万ms区间有第二个较矮的峰；MLora峰值更低（约2.4e-5）且位置右移，第二峰相对更平缓；(d) 两条CDF曲线在低延迟区MLoRA整体位于Baseline左侧（即相同累积概率下延迟更低），标注框显示P90处约+16.5%、P95处约+16.9%、P99处约+12.8%的差异，两曲线在接近1.0处趋于收敛。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：本图直接支持**实验结论类**主张"MLoRA使端到端延迟降低49.8%、p99尾延迟降低12.8%"（正文页码1, 11），且提供了正文未展开的细粒度证据——将改进拆解为E2E RT/Inference/P95/P99四个口径，显示收益并非仅集中在平均值，而是在整个延迟分布（含尾部）上均有改善，但尾部（P95/P99）改进幅度明显小于均值（E2E RT），说明MLoRA对"典型请求"的加速效果强于对"最坏情况请求"的加速效果——这与第6节所述"缓存耦合扩容""异构快速实例"等机制主要针对冷启动/常见路径优化的设计逻辑一致（`[正文支持]`，页码：8-10）。(b)图中Baseline的双峰分布（近0峰+远端峰）可视觉印证正文所述"热请求快而冷请求慢"的资源利用率悖论/请求偏斜现象（第4.3节，页码：6），MLoRA使远端峰变矮，说明其popularity-aware缓存策略压缩了长尾延迟，但未完全消除双峰结构。`[基于视觉的谨慎推断]`（因图注仅为通用性描述，双峰与冷热请求的对应关系为合理推断而非图上文字直接标注）。(d)中P90/P95/P99的改进幅度依次递减（16.5%→16.9%→12.8%，注意P90到P95略有上升后在P99下降），提示读者：单纯宣称"49.8%延迟降低"可能夸大MLoRA在最坏情况下的收益，实际尾部改进幅度仅为均值改进幅度的约1/3——这一点仍需结合具体样本量/置信区间判断，而**正文未报告**这些统计量（对应主张地图问题#3的证据缺口）。

6. **适用范围与证据缺口**：本图数据来自论文第7.1节所述300 GPU生产集群、A/B测试同一生产工作负载分布下的对比（页码：10-11），仅覆盖该商用图像生成服务7天数据窗口内的流量。真实剩余缺口：图中(a)柱状图的误差棒具体代表标准差、置信区间还是分位数范围，正文与图例均未说明——**图中无法区分**；(d)图中P90标注的"+16.5%"具体计算口径（是延迟绝对值降低百分比还是概率轴上的位移）与文字未对应说明——**文中未说明**；本页4个子面板中(c)未包含在当前图片裁剪范围内，无法评估其内容是否补充了额外证据缺口。

---

## 图片 2：Figure 12: Network and I/O performance analysis comparing MLoRA with baseline. MLoRA achieves 89.5% reduction in network bandwidth and 60.2% reduction in disk I/O usage while significantly improving model update latency.

![Figure 12: Network and I/O performance analysis comparing MLoRA with baseline. MLoRA achieves 89.5% reduction in network bandwidth and 60.2% reduction in disk I/O usage while significantly improving model update latency.](../assets/imgs/img_in_chart_box_640_169_1124_461.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：本图对应第7.4节"Network and I/O Performance"，属于**实验结论类**证据，验证MLoRA通过"异构快速实例"与"全局缓存协调"两大模块（第6.1、6.2节）对网络带宽、磁盘I/O、模型更新延迟、队列与响应时间等系统层指标的综合改善（`[正文支持]`，页码：12）。它要回答的问题是：正文声称的"89.5%网络带宽降低、60.2%磁盘I/O降低、89.1%模型更新延迟降低"等数字，在时间序列和资源竞争维度上是否呈现出一致、可解释的模式，而不只是孤立的汇总百分比。
   - **图表角色**：实验结论（含消融式的资源竞争对比）。
   - **上文呼应**：第7.4节"Network and I/O Performance"；间接呼应第4.1节"Resource Competition"中"多级资源竞争"机制主张（页码：4-5, 12）。

2. **图像类型与布局**：一组4个子面板：(a)为雷达图（六轴：Queue Size、Disk I/O、Network bandwidth、Model Update、Response Time、Request Size），Baseline（青色，覆盖面积大）与MLora（品红色，覆盖面积小）两个多边形叠加；(b)为双纵轴时间序列图，横轴为Time(Hour, 00:00-21:00)，左纵轴Disk Read Rate(MB/s，×1e9)，右纵轴Model Update Latency(ms)，四条线分别为Baseline/MLoRA的Disk Read与Model Update；(c)结构与(b)相同但左纵轴为Network Receive Rate(MB/s)；(d)为散点图，横轴Network Receive Rate(MB/s)，纵轴Disk Read Rate(MB/s)，气泡大小可能编码第三变量，颜色区分Baseline/MLora，图内标注两组的相关系数r值。

3. **如何阅读**：(a)雷达图应比较Baseline与MLora在六个维度上多边形的相对张开程度，面积越大代表该维度数值（可能是归一化后的资源消耗/延迟）越高；(b)(c)应对比同一时间点上Baseline与MLoRA两条速率曲线的高度差异，以及各自对应的Model Update Latency虚线是否同步出现尖峰；(d)应比较两组散点云的分布范围（横纵轴跨度）及标注的相关系数r值大小，r值反映该组内Network Receive Rate与Disk Read Rate的线性相关程度。

4. **直接可见的结论**：(a) Baseline在Queue Size、Disk I/O、Network Bandwidth、Model Update、Response Time、Request Size六个维度上的多边形覆盖范围明显大于MLora，MLora多边形整体收缩、更接近雷达图中心；(b) Baseline的Disk Read Rate在整个21小时窗口内持续维持在约0.8-1.2×1e9 MB/s并有波动，MLoRA的Disk Read Rate始终显著更低、接近0并更平稳；Baseline的Model Update Latency在约第9小时和第15小时附近出现明显尖峰（约达到坐标轴上限附近，视觉上远高于其余时段），MLoRA对应曲线全程平稳、未见类似尖峰；(c) Network Receive Rate呈现与(b)类似模式：Baseline持续高位波动，MLoRA持续低位平稳，Model Update Latency尖峰位置与(b)基本对应同一时间点；(d) 散点图中Baseline点云在Network Receive Rate轴上分布范围明显更宽（可延伸至约5000+区间），MLora点云集中在较低的Network Receive Rate区间；图中标注Baseline r=0.214，MLora r=0.147，即Baseline组内Disk Read Rate与Network Receive Rate的相关性略强于MLora组。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：(a)雷达图整体收缩直观印证第7.4节所报告的多指标同步改善（89.5%网络带宽降低、60.2%磁盘I/O降低等，`[正文支持]`，页码：12），说明MLoRA的收益并非单一指标的局部优化，而是跨I/O、队列、响应时间等多个维度的系统性改善，支持论文"三层耦合优化产生叠加收益"这一设计前提（对应论证地图"假设/设计前提"条目，页码：8-9）。(b)(c)中Baseline Model Update Latency在特定时间点出现尖峰，且与Disk Read/Network Receive Rate的高位波动同步出现，可视觉印证第5.1-5.2节所述"多组件缓存冲突导致级联数据搬运"（cold-start最高47秒、组合触发15GB+级联传输，页码：2, 8）以及"网络I/O随更新频率线性增长（正文相关系数0.985）"（页码：7）这一机制主张——MLoRA通过异构pinned memory与全局缓存协调消除了这种尖峰同步现象，间接支持"资源竞争集中在特定时间维度而非均匀分布"（第4.1节，页码：5）。(d)中Baseline相关系数（0.214）高于MLora（0.147），若解读为MLoRA降低了网络与磁盘I/O之间的耦合竞争程度，可作为"全局缓存协调降低跨资源级联效应"的**间接**佐证，但正文未明确给出该图对应的相关系数计算方法或统计显著性，因此这一因果解读应标注为`[基于视觉的谨慎推断]`，不构成正文直接陈述的机制证明。

6. **适用范围与证据缺口**：本图数据同样来自第7.1节所述300 GPU集群A/B测试环境、21小时时间窗口内的观测（页码：10, 12），覆盖范围与图片1相同的生产工作负载。真实剩余缺口：(a)雷达图六个轴的具体数值范围、归一化方法（是否为0-1标准化、以哪个基准归一化）在图中和正文均未标注坐标刻度——**图中无法区分**；(d)中气泡大小所编码的具体变量含义在图例中未说明——**图中无法区分**；(d)标注的相关系数r=0.214/0.147的统计计算方法（Pearson或Spearman、样本粒度）**文中未说明**，与论证地图"统计方法透明度不足"条目一致（页码：4-5, 12）。
