# 图片批次 2

## 图片 1：Figure 4: Cold start analysis for various model sizes. The chart illustrates the significant latency incurred during the initial loading of large models, highlighting the need for improved preloading strategies.

![Figure 4: Cold start analysis for various model sizes. The chart illustrates the significant latency incurred during the initial loading of large models, highlighting the need for improved preloading strategies.](../figure-groups/page-0004-19841ecfb65f.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Figure 4（Cold-start analysis for various model sizes），出现在第 3.3 节"Cold-start Penalty Severity"。证据类型为**问题严重性**（兼有机制类线索）：它要具体化"冷启动是工作负载偏斜的最严重表现形式"这一主张，把冷启动延迟拆解为可归因的开销来源（网络传输/模型加载/初始化/预热),并展示加载频率与延迟的反直觉关系，为后续 MLoRA 的 Fast I/O 与异构实例设计（第 6.2 节）提供动机依据。`[正文支持]`
   - **图表角色**：问题严重性（叠加机制类：冷启动开销来源分解、频率-延迟反相关）。
   - **上文呼应**：第 3.3 节"Cold-start Penalty Severity"；呼应根问题中"数据搬运"和"资源利用率悖论"相关主张（主张地图 #2）。

2. **图像类型与布局**：一组三联面板（Panel 1-3，对应 Fig.4a-c）。
   - (a) 双 Y 轴组合图：左轴"Loading Latency (ms)"（红线+误差带），右轴"Resource Utilization (%)"（浅蓝色柱状背景），X 轴为按加载频率排序的容器（C0-C240+），并用橙色虚线在约 C120 处分隔"Hot Instances(≥517 loads)"与"Cold Instances(<517 loads)"两个区域。
   - (b) 柱状图："Cold Start Overhead Breakdown"，四根柱子分别标注 Network Transfer 6778.9ms(25.6%)、Model Loading 11298.2ms(42.7%)、Initialization 4519.3ms(17.1%)、Warmup 3865.9ms(14.6%)。
   - (c) 散点图+回归线："Loading Frequency vs Latency"，X 轴为 Loading Frequency (# loads)，左 Y 轴为 Avg Latency (ms)，右轴为 Container Density，图内标注 Correlation: -0.411，红色虚线趋势 y=-2.8x+18126。

3. **如何阅读**：(a) 按容器加载频率从高到低排列，比较左侧高频（Hot）区域与右侧低频（Cold）区域的延迟曲线高度与柱状背景（资源利用率）差异；(b) 四根柱子高度与百分比标注直接对应冷启动总时间的四段构成，可加总验证是否≈100%；(c) 观察散点整体分布趋势方向（是否随加载频率增加而延迟下降）及回归线斜率符号。

4. **直接可见的结论**：
   - (a) 图左侧（高频/Hot 区域）红色延迟曲线整体处于较高水平且波动剧烈，右侧（低频/Cold 区域）延迟曲线整体走低但更平滑；资源利用率背景柱在左侧总体偏高、右侧偏低。`[图像直接可见]`
   - (b) 四段开销中"Model Loading"占比最大（42.7%），其次是"Network Transfer"（25.6%），"Initialization"（17.1%）与"Warmup"（14.6%）依次递减。`[图像直接可见]`
   - (c) 散点云及红色回归线呈现随加载频率增加、平均延迟下降的负向趋势，相关系数标注为 -0.411。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - 面板 (b) 属于**效果类**证据，直接对应正文"network transfer (6.8s), model loading (11.3s), initialization (4.6s), and warmup (3.9s)…I/O operations consuming nearly 70% of cold-start time"的数值描述，图中四项数值与正文四舍五入后基本一致（6.8s/11.3s/4.5s/3.9s），坐标条形高度分布支持"I/O相关开销（网络传输+模型加载）合计占比约68.3%"这一"近70%"的定性表述。`[正文支持]` 这为第 6.2 节 Fast I/O Instance（Direct I/O、异构 pinned memory）的设计动机提供直接依据。
   - 面板 (c) 属于**机制类**证据，图中可见的负相关趋势支持正文"instances handling frequent loads exhibit lower average inference latency…warm cache effects"这一反直觉论断的方向性，但图中相关系数标注为 -0.411，属于弱到中等强度的负相关，图像本身并不能证明其为"warm cache effects/GPU driver kernel caching/preferential routing"这一因果解释——该解释仅为正文提供的定性归因，图像只能确认"频率与延迟存在负相关"这一现象，不能验证其成因机制。`[正文支持]`（现象方向）+ `[基于视觉的谨慎推断]`（相关强度为弱-中等）
   - 面板 (a) 的 Hot/Cold 分界（≥517 loads vs <517 loads）为**问题严重性**证据，直观展示了"高频加载"与"低频加载"容器在延迟-利用率联合表现上的系统性差异，支持"资源利用率悖论"及"持久化部署模型与扩散工作负载不匹配"的判断，但图中未标注具体的组间平均延迟数值（12.5s vs 19.9s），因此该图不能被用来精确核实正文所述"58.6%延迟惩罚（12.5s vs 19.9s）"这一具体量化数字。

6. **适用范围与证据缺口**：本图覆盖论文报告的单一商用图像生成服务、7 天生产数据、300+ GPU 环境下的容器级冷启动测量（按加载频率排序，Hot 阈值为 ≥517 次加载）。真实证据缺口：面板 (a) 的 Y 轴（Loading Latency, ms）量程约为 0-7000ms，与正文所述"hot instances averaging 12.5 seconds versus 19.9 seconds for cold initialization"（12500ms/19900ms）的量级不完全对应——图中展示的是逐容器（per-container）细粒度数值而非两组的聚合平均值，正文所述两个聚合数字无法从本图中直接读出或核实，构成 OCR 文字与图像可辨识数值之间的一处衔接缺口。

---

## 图片 2：Figure 3: LoRA adapter usage distribution across requests. The long-tail nature of LoRA usage leads to significant cache management challenges, as most adapters are rarely used but still need to be cached for occasional requests.

![Figure 3: LoRA adapter usage distribution across requests. The long-tail nature of LoRA usage leads to significant cache management challenges, as most adapters are rarely used but still need to be cached for occasional requests.](../figure-groups/page-0004-c1a335cd8364.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Figure 3（LoRA adapter usage distribution across requests），出现在第 3.2 节"Long-tail of LoRA Adapter Usage"。证据类型为**问题严重性**（叠加机制类）：用于证实 LoRA 适配器使用呈现极端长尾分布，并揭示该长尾分布如何通过加载惩罚传导至端到端延迟，从而论证"传统缓存启发式（LRU）无法应对该组合式缓存困境"这一必要性主张，为第 6.1/6.3 节热/温/冷分级缓存与静态/动态组合管理设计提供动机。`[正文支持]`
   - **图表角色**：问题严重性 + 机制类（长尾分布→加载延迟传导机制）。
   - **上文呼应**：第 3.2 节"Long-tail of LoRA Adapter Usage"；呼应主张地图中"根问题：组件体量/访问模式异构"及核心洞见 1/3。

2. **图像类型与布局**：四联面板（Panel 1-4，对应 Fig.3a-d）。
   - (a) 双 Y 轴曲线图："LoRA Adapter Usage Distribution - Long Tail Analysis"，左轴（对数刻度）Usage Frequency，右轴 Cumulative Percentage (%)，X 轴为按使用量排序的 LoRA Adapter（0-700+），橙色虚线标注"80% usage from top 166 LoRAs"。
   - (b) 柱状+折线组合图："LoRA Count vs Proportion & Latency"，X 轴 Number of LoRAs per Request（0-6），左轴浅蓝柱为 Request Proportion (%)，右轴深蓝折线（含误差棒）为 Average Execution Time (s)，0 处柱子高亮标注"78.8%"，图内另标注"LoRA-Latency Correlation: 0.111"。
   - (c) 箱线图："Latency Distribution"，三组 No LoRA / Hot LoRA / Cold LoRA，标注均值 23.9s/40.4s/45.0s，并标注"Cold LoRA overhead: +88.5%"与"Hot vs Cold difference: -10.1%"。
   - (d) 散点图：X 轴 Network Transfer Rate (MB/s)，Y 轴 LoRA Loading Latency (ms)，点按 Hour of Day 着色，标注 Correlation: 0.661、Network CV: 0.927、LoRA CV: 0.221，红色虚线为回归趋势。

3. **如何阅读**：(a) 观察对数尺度下使用频率曲线的陡降速度及累计百分比曲线达到 80% 时对应的横轴位置（虚线标注处）；(b) 比较各 LoRA 数量下的请求占比柱高与对应执行时间折线走势，尤其 0 与 1-6 之间的差异；(c) 比较三组箱线图的中位数/均值位置与箱体离散程度；(d) 观察散点整体趋势方向及颜色（小时）是否呈现聚集模式。

4. **直接可见的结论**：
   - (a) 使用频率曲线在少数排名靠前的 LoRA 处很高、随后迅速下降并长期维持低值（长尾），累计百分比曲线在约排名 166 处穿过 80% 标线。`[图像直接可见]`
   - (b) 0 个 LoRA 对应的请求占比柱远高于其余各柱（约 78.8%），而平均执行时间折线在 0→1 之后明显上升，且随 LoRA 数量增加呈波动上升后回落趋势；图中同时标注该子图内部相关系数为 0.111。`[图像直接可见]`
   - (c) 三组箱线图均值依次为 23.9s（No LoRA）< 40.4s（Hot LoRA）< 45.0s（Cold LoRA），Cold LoRA 箱体离散范围最大。`[图像直接可见]`
   - (d) 散点整体随 Network Transfer Rate 增大而 LoRA Loading Latency 上升，回归线斜率为正，标注相关系数 0.661；点的颜色（小时）未显示明显的系统性聚集模式。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - 面板 (a) 属于**问题严重性**证据，直接对应正文"Among 705 unique adapters, only 23.5% handle 80% of all requests"（23.5%×705≈166，与图中"top 166 LoRAs"一致），确认了 LoRA 使用的极端长尾特征，支撑第 6.1.1 节"冷模型（后 70%）机会式缓存"分档设计的必要性。`[正文支持]`
   - 面板 (b) 属于**效果类**证据，标注的"78.8%"与正文"78.8% of requests use no adapters, remaining 21.2% require 1-6 adapters"精确一致，验证了组合空间中"零适配器请求占主导，但仍有相当比例需要 1-6 个适配器组合"的结构，这是第 6.3.1 节"静态高频组合 vs 动态低频组合"分层管理设计的直接依据。图内标注的"LoRA-Latency Correlation: 0.111"是本图独有的可见数值，正文未对该具体相关系数做文字陈述，仅可作为图像直接可见事实记录，不能与正文中提到的其它相关系数（如 0.66）混同。`[图像直接可见]`（对该系数本身）+ `[正文支持]`（对 78.8%/21.2% 结构）
   - 面板 (c) 属于**效果类**证据，均值 23.9s/40.4s/45.0s 与正文"Requests without adapters average 23.9 seconds…frequently-used adapters experience 69% degradation (40.4s)…rare adapter requests suffer 88.5% penalties (45s)"一致（图中亦标注"Cold LoRA overhead: +88.5%"与正文 88.5% 吻合），验证了"频繁使用 vs 稀有适配器"加载惩罚的差异化程度，支持第 6.1.1 节对热/温/冷组件采取不同缓存策略的必要性。`[正文支持]`
   - 面板 (d) 属于**机制类**证据，正文称"The strong correlation (0.66) between adapter loading latency and total inference time (Fig. 3d) confirms that adapter management constitutes a critical system bottleneck"，图中标注的相关系数 0.661 与正文 0.66 数值吻合，方向上支持"适配器加载延迟与整体延迟存在强相关，是关键瓶颈"这一结论；但图中 X 轴实际标注为"Network Transfer Rate (MB/s)"而非正文所述的"total inference time"，两者所指变量不一致，图像本身只能确认"LoRA 加载延迟与网络传输速率之间存在 0.661 的正相关"，无法直接证明正文所述"与总推理时间相关"这一具体表述。`[正文支持]`（数值与瓶颈论点方向一致）+ `[基于视觉的谨慎推断]`（变量对应关系需谨慎，见第 6 项）

6. **适用范围与证据缺口**：本图覆盖论文报告的同一商用图像生成服务、7 天数据集中 705 个 LoRA 适配器、按请求维度统计的使用频率与延迟测量。真实证据缺口：面板 (d) 的横轴标注为"Network Transfer Rate (MB/s)"，与正文对 Fig.3d 的文字描述"correlation…between adapter loading latency and total inference time"在变量命名上不一致，无法从当前 OCR 与图像内容确认二者是否为同一测量的不同表述方式，构成 OCR 图注/正文与图像坐标轴之间的一处冲突。除此之外，面板 (b) 中的"LoRA-Latency Correlation: 0.111"其计算口径（是否 Pearson、样本粒度）正文未说明，与主张地图中已标注的"文中未说明"统计透明度缺口一致，不再重复视为新缺口。
