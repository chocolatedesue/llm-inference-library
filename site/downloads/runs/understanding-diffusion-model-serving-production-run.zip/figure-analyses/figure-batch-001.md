# 图片批次 1

## 图片 1：Figure 1: Diffusion model serving pipeline architecture showing multi-component DAG structure with base models, LoRA adapters, and conditioning networks requiring coordinated orchestration for image generation.

![Figure 1: Diffusion model serving pipeline architecture showing multi-component DAG structure with base models, LoRA adapters, and conditioning networks requiring coordinated orchestration for image generation.](../assets/imgs/img_in_image_box_108_171_598_300.jpg)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：本图是论文引言部分用以说明扩散模型服务"根问题"的**方法流水线**图，用于解释为何扩散模型服务与传统ML/LLM服务本质不同——多组件DAG（BaseModel+LoRA+ControlNet+文本编码器）与迭代去噪循环共同构成一个必须整体协调的推理单元。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：第1节引言"diffusion models operate through complex multistage pipelines with interdependent components (base models, LoRA adapters, conditioning networks) that require careful orchestration (Fig. 1)"，以及"iterative denoising process...requiring 20-50 non-parallelizable steps"（页码：1-2）。

2. **图像类型与布局**：示意图（流程图/架构图），非数据图表。整体被一个大矩形框（标题"GPU Instance"）包围，内部左到右主链路为：`Noise` → `VAE`（橙色框）→ `BaseModel (LoRA Patched)`（绿色框，居中）→ `Sampler`（粉色框）→ `Image`；顶部另有两个输入框 `CLIP/T5` 与 `ControlNet`，均有箭头指向中心的 BaseModel 框；`Sampler` 到 `BaseModel` 之间有一条标注为 "Repeated Iteration" 的回流箭头，形成循环结构。整体左上角标题为"Diffusion Pipeline"。

3. **如何阅读**：无坐标轴、无图例、无数值。阅读顺序为：先看主横向链路（Noise→VAE→BaseModel→Sampler→Image）理解基础生成流程；再看顶部两个输入框汇入 BaseModel，理解 LoRA/ControlNet/文本编码器如何与基础模型耦合；最后看回流箭头理解"重复迭代"这一去噪循环，以及最外层"GPU Instance"边框表示这些组件被视为运行在同一实例上的整体。

4. **直接可见的结论**：（1）BaseModel 节点同时接收来自 CLIP/T5、ControlNet 两条独立输入路径，且自身被标注为"LoRA Patched"，即三类异构组件（基础模型、LoRA、ControlNet/文本编码器）在同一推理图中汇合；（2）Sampler 与 BaseModel 之间存在显式循环箭头（"Repeated Iteration"），表明生成过程需要对 BaseModel 做多次重复调用而非一次直通；（3）整条链路被绘制在单个"GPU Instance"边框内，表示该流水线被建模为运行在同一硬件实例上的一个整体单元。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于**机制类**证据，直接支撑正文对"根问题"的结构性描述——多组件DAG架构（页码：1,3）与迭代去噪的非并行硬约束（页码：1）。图中"BaseModel 同时汇合 LoRA/ControlNet/文本编码器"这一结构可视化了第2.1节所述"组合爆炸"（hundreds of base models × thousands of LoRAs × dozens of ControlNets）的来源；"GPU Instance"整体边框与循环箭头则为第6.1节 MLoRA"将整条流水线视为原子缓存单元"的设计动机提供了结构基础——即因为这些组件在推理时必须共存于同一实例并反复调用，才需要把它们作为整体来协调缓存/扩容，而非独立管理各组件。`[基于文中逻辑的推断]`。该图本身不能证明任何具体数值主张（如20-50步、组件体积范围、组合空间1.6M等），这些量化结论需依赖正文数字而非该示意图。

6. **适用范围与证据缺口**：本图为概念性/示意性架构图，不代表某一具体模型规模、GPU型号或实测数据，仅用于说明流水线拓扑结构。无额外证据缺口。

---

## 图片 2：Figure 2: Base model request skewness analysis. The Gini coefficient of 0.876 indicates a highly skewed distribution, with the top 1 model accounting for 28.8% of requests. This highlights the significant concentration of requests on a few popular models, leading to resource allocation challenges.

![Figure 2: Base model request skewness analysis. The Gini coefficient of 0.876 indicates a highly skewed distribution, with the top 1 model accounting for 28.8% of requests. This highlights the significant concentration of requests on a few popular models, leading to resource allocation challenges.](../figure-groups/page-0003-5aa81800e8f9.png)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本图组是第3.1节"请求分布不均衡"论证的核心证据，属于**问题严重性**类证据，用于验证"根问题"之一——请求分布极端偏斜（Gini=0.876）及其引发的"流行度惩罚"延迟悖论（热门模型因资源争用而更慢，冷门模型因冷启动而更慢）。`[正文支持]`
   - **图表角色**：问题严重性
   - **上文呼应**：第3.1节"Request Distribution Imbalance"，对应主张地图主张#1（请求分布极端偏斜）。

2. **图像类型与布局**：一个四子图组合（Figure 2 a-d）。(a) 为左侧较大的柱状图+累积曲线组合图（Pareto分析），横轴为按流行度排序的Model ID，纵轴（左，对数刻度）为Request Count蓝色柱状，纵轴（右）为红色累积百分比曲线，图内有虚线标注框"80% requests from top 8 models (8.2% of models)"；(b) 为箱线图，比较"Popular (Top 10)"与"Unpopular (Bottom 10)"两组模型的Execution Time(秒)分布，图内标注"Popular Avg: 29.0s"与"Unpopular Avg: 25.8s"，并有散点叠加；(c) 为水平条形图，展示不同风格类别（GENERAL_2D、FLUX、ANIME、GHIBLI、INK_PAINTING、SD3、PIXEL、CLAY_ANIMATION）的Request Count，各类别右侧标注具体数值（如3189、2329、1643、1092、972、867等）；(d) 为散点图，横轴Request Frequency（对数刻度），纵轴Avg Execution Time，点颜色按Model Rank（右侧色条，从深紫到黄）渐变编码。

3. **如何阅读**：(a) 应关注柱状图整体呈长尾陡降形态，以及右轴累积曲线快速逼近100%的拐点位置，二者共同支撑Gini系数所反映的集中度；(b) 应对比两组箱体的中位数/均值位置（Popular组均值线高于Unpopular组）；(c) 应比较各风格类别横条长度/右侧数值以判断风格类型的请求量分布；(d) 应观察散点在低频率区与高频率区的纵轴（延迟）是否均偏高，中间频段是否偏低，同时结合颜色（Rank）判断趋势方向。四子图无法互相替代，需分别对应各自数值。

4. **直接可见的结论**：（a）请求次数柱状图从左至右迅速衰减，累积占比曲线在前若干模型处已逼近顶部，图内标注显示约80%请求集中在前8个模型（约占模型总数8.2%），呈现极端长尾/幂律分布；（b）Popular（Top10）箱体位置整体高于Unpopular（Bottom10）箱体，标注均值29.0s vs 25.8s，即热门模型平均执行时间反而更长；（c）不同风格类别的请求量差异明显，条形长度从上到下递减，风格之间也存在不均衡分布；（d）散点在横轴两端（低频率区与高频率区）的纵轴（延迟）位置总体高于中间频率区域的点，呈现两端偏高、中段偏低的分布形态。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：(a) 直接为正文"Gini coefficient of 0.876...top model captures 28.8%...top five models serve 70.4%"（页码：3）及主张地图主张#1提供可视化支持，属于**效果类**证据，量化坐标轴细节（80%/8个模型/8.2%）与正文引用的具体数字（28.8%/70.4%）并非完全相同的切分口径，但共同指向同一"极端长尾"结论。`[正文支持]`。(b) 直接对应正文"popular models experience longer execution times (29s vs 25.8s for unpopular models) due to resource contention"（页码：3-4），属于**机制类**证据，说明请求偏斜带来的资源争用如何反噬热门模型自身性能，这一"流行度惩罚"现象是MLoRA第6.1.1节"Hot Models"多副本+一致性哈希设计（而非简单堆叠更多请求到同一实例）的直接动机。`[正文支持]`。(d) 对应正文"frequency-latency relationship (Fig. 2d) reveals performance degradation at both extremes: rarely-used models incur cold-start penalties, while heavily-requested models suffer resource constraints"（页码：4），属于**机制类**证据，验证了偏斜分布在两端（冷启动 vs 争用）都造成延迟劣化，从而支撑MLoRA按热度分三档（热/温/冷）差异化处理的设计合理性（页码：8）。(c) 风格类别分布图在当前提供的OCR文本片段中未见明确对应的正文引用或图注说明其在论证链中的具体作用，**无法从当前OCR内容确认**其具体验证的主张，仅能作为该服务请求内容多样性的补充画像。

6. **适用范围与证据缺口**：本组证据覆盖论文所述同一商用图像生成服务、7天、300+ GPU、3.5百万请求的生产数据集（页码：2），是对基础模型（base model）层面请求分布的分析，不代表LoRA/ControlNet层面的分布（后者在Fig.3等图中另行分析）。真实缺口：(1) (a)图内标注"top 8 models/8.2%/80%"与正文文字"top 1 model 28.8%/top 5 models 70.4%"是两套不同的切分统计口径，正文未说明二者关系，无法从图像判断具体是否为同一底层数据的不同读数——**OCR/图题存在口径差异**；(2) (c) 风格类型分布子图的论证角色在当前提供的正文片段中未见文字说明，**正文未明确指明该子图对应的具体论点**。
