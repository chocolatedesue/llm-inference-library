# 图片批次 5

## 图片 1：Figure 10: End-to-end latency breakdown on additional benchmarks.

![Figure 10: End-to-end latency breakdown on additional benchmarks.](../figure-groups/page-0019-c7836b740448.png)

*来源：OCR 第 19 页。*

### 解读

1. **论文角色与验证问题**：本图属于`实验结论`类证据，用于将 Section 5.3（DynaMath 上的细粒度延迟分解，Figure 5(a)）已展示的"ReaLB/FP4-All 大幅压缩 MoE 时间占比、EPLB 反而增加总时间"这一发现，扩展到正文因篇幅未纳入的另外两个 benchmark（MMMU、MathVista）与两个模型（Kimi-VL、Qwen3-VL），验证的具体问题是"C1/C3 主张（ReaLB 端到端加速、EPLB 失效）是否只是 DynaMath 上的特例，还是能跨 benchmark 泛化” `[正文支持]`。
   - **图表角色**：实验结论（辅以对比基线）。
   - **上文呼应**：Appendix I 正文（[页码：19]）明确说明——"We further report end-to-end latency breakdown on two additional benchmarks, MMMU and MathVista, for Kimi-VL and Qwen3-VL, which are not included in the main paper due to space constraints"，对应主文 Section 5.3 的延迟分解主张。

2. **图像类型与布局**：4 个子面板的堆叠柱状图（stacked bar chart），布局为 2×2：(a) Kimi-VL/MMMU，(b) Kimi-VL/MathVista，(c) Qwen3-VL/MMMU，(d) Qwen3-VL/MathVista。每个子图横轴为 6 种配置（Baseline、EPLB、Async_EPLB、FP4-All、RealB-seq、ReaLB），纵轴为 "E2E Time Breakdown (s)"；每根柱子按颜色堆叠 attn、encoder、eplb_overhead、mlp、moe、combine、dispatch、realb_overhead、overlapping 等阶段耗时；部分柱顶标注相对 Baseline 的百分比变化（红色为正/变慢，绿色为负/变快）。

3. **如何阅读**：以 Baseline 总高度为参照，比较其余各柱的总高度及顶部百分比标签；不同颜色段代表同一次前向传播中不同阶段（如 moe、dispatch、combine）各自耗时占比；四个子图之间应比较同一方法在不同模型/benchmark 下的相对变化是否一致。

4. **直接可见的结论**：
   - 四个子图中，EPLB 与 Async_EPLB 柱子均高于 Baseline，标注为正百分比（如面板1：+4.5%/+3.1%；面板3：+22.4%/+20.7%；面板4：+20.4%/+18.9%），即总时间增加 `[图像直接可见]`。
   - FP4-All、RealB-seq、ReaLB 柱子均低于 Baseline，标注为负百分比；在全部四个面板中，ReaLB 的降幅均大于 RealB-seq（如面板1：-24.5% vs -19.7%；面板2：-23.8% vs -20.9%；面板3：-11.5% vs -1.1%；面板4：-11.2% vs -0.5%）`[图像直接可见]`。
   - RealB-seq 与 ReaLB 的柱子中出现了 EPLB/Async_EPLB 所没有的 realb_overhead（浅黄色）与 overlapping（灰色）分段，且 ReaLB 柱中该灰色 overlapping 段visually更明显 `[图像直接可见]`。
   - moe 段（黄色）在 FP4-All、RealB-seq、ReaLB 中普遍比 Baseline/EPLB 中的对应段矮 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图属于`效果`类主张的跨 benchmark 复现证据——EPLB 在 MMMU、MathVista 上同样表现为总时延增加而非减少，与 Table 1 中 EPLB speedup<1.00 的结果及正文"历史统计与动态路由失配导致再平衡失效甚至加剧不均衡"的机制解释一致 `[正文支持]`；ReaLB 在四个新增设置下均优于 RealB-seq，进一步支持 C5（流水线重叠可有效隐藏精度转换开销）在不同模型/数据集上的稳健性，而不仅限于 DynaMath `[正文支持]`。ReaLB 柱中可见的 realb_overhead/overlapping 分段直观对应正文 4.3 节所述"S+T 开销被重叠隐藏在 dispatch 通信窗口内"的设计，但图中未给出这些分段各自的绝对时长数字，因此无法据此图精确量化"隐藏了多少开销"，只能确认存在该机制且未显著拖累总延迟 `[基于视觉的谨慎推断]`。

6. **适用范围与证据缺口**：本图覆盖的实际范围是 Kimi-VL 与 Qwen3-VL 两个模型在 MMMU、MathVista 两个 benchmark 上、8×RTX 5090 EP 部署下的端到端时间分解（Appendix I，[页码：19]），是对主文 5.3 节 DynaMath 结果的补充而非替代。图中各堆叠分段（如 realb_overhead、overlapping）的具体数值未标注，正文亦未给出对应绝对时间数字，仅有总百分比变化可读，属于图像本身未提供数值精度的真实缺口。

---

## 图片 2：Figure 9: Evolution of the control parameter under AIMD-based adaptive control on DynaMath. The red background indicates time steps where the global imbalance exceeds the congestion threshold.

![Figure 9: Evolution of the control parameter under AIMD-based adaptive control on DynaMath. The red background indicates time steps where the global imbalance exceeds the congestion threshold.](../figure-groups/page-0019-fda6c41ad02d.png)

*来源：OCR 第 19 页。*

### 解读

1. **论文角色与验证问题**：本图属于`机制`类证据，用于展示 4.2 节所述 AIMD 自适应阈值控制规则（$M_d$ 随 $IB_{global}$ 是否超过拥塞阈值 $\tau=1.5$ 而乘性减/加性增）在真实推理轨迹中的实际动态行为，验证的具体问题是"AIMD 控制器是否确实按设计规则响应瞬时拥塞信号，在拥塞时快速收紧、在正常期逐步放松" `[正文支持]`。
   - **图表角色**：机制（辅以适用边界，因两模型对比隐含鲁棒性含义）。
   - **上文呼应**：正文 4.2 节（[页码：6]）明确写道"A detailed empirical analysis of the evolution of $M_d$ is provided in Appendix H"，对应 C6 主张（AIMD 自适应阈值优于静态阈值）的机制细节补充。

2. **图像类型与布局**：2 个并列折线图面板：(a) Kimi-VL，(b) Qwen3-VL。每个面板双 y 轴——左轴为 $M_d$（绿色线），右轴为 $IB_{global}$（蓝色线），x 轴为 Iterations；图中叠加水平虚线标注 $\tau=1.5$，并以浅红色背景区域标出 $IB_{global}$ 超过该阈值的时间段。

3. **如何阅读**：沿横轴（迭代次数）比较绿色 $M_d$ 曲线与蓝色 $IB_{global}$ 曲线的同步变化，重点观察红色背景区域（拥塞期）内 $M_d$ 是否下降，以及白色背景区域（非拥塞期）内 $M_d$ 是否回升；两面板应比较 Kimi-VL 与 Qwen3-VL 之间波动频率/幅度的差异。

4. **直接可见的结论**：
   - 两个面板中，$M_d$ 呈现频繁的锯齿状波动：在红色背景（$IB_{global}$ 越过 $\tau=1.5$ 虚线）出现的时间段附近，$M_d$ 多次骤降；在白色背景区域，$M_d$ 呈现逐步爬升趋势 `[图像直接可见]`。
   - Kimi-VL 面板（a）右轴 $IB_{global}$ 范围大致在 1.3–1.9 之间波动，红色背景区域相对分散、较窄；Qwen3-VL 面板（b）右轴范围约 1.0–2.0，红色背景区域覆盖比例明显更大、更连续（尤其中段约 80–170 次迭代区间几乎持续处于阈值以上）`[图像直接可见]`。
   - 两面板中 $M_d$ 均未出现长期稳定在某一固定值的情况，而是持续在低值（约0.25-0.3）与高值（接近1.0）之间反复切换 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：图中 $M_d$ 骤降与红色拥塞区间在时间上的对应关系，直接展示了 4.2 节 AIMD 规则（$IB_{global}>\tau$ 时 $M_d \leftarrow 0.5M_d$，否则 $M_d \leftarrow \min(1, M_d+0.1)$）在实际路由轨迹下被触发的具体过程，支持该控制机制"响应瞬时拥塞信号而非依赖历史窗口"的设计动机 `[正文支持]`。这为 C6（AIMD 优于静态阈值）提供了机制层面的可视化解释，但本图本身并未包含静态阈值（ReaLB-m1/m2）的对照曲线，因此"AIMD 是否确实比固定 $M_d$ 效果更好"这一比较结论仍需依赖 Table 1 的 speedup/ΔAcc 数字，不能仅由本图证明 `[基于文中逻辑的推断]`。Qwen3-VL 上更宽、更连续的拥塞区间与该模型专家数更多（128 vs 64）、路由更动态的背景一致，但正文未明确讨论此关联，不应做因果推断。

6. **适用范围与证据缺口**：本图覆盖的实际范围是 DynaMath 数据集上、Kimi-VL 与 Qwen3-VL 两个模型的单次运行轨迹（图注明确标注"on DynaMath"，[页码：19]），迭代窗口长度分别约 220（a）与约 300（b）次迭代。无额外证据缺口——图中信息（$M_d$、$IB_{global}$ 曲线及红色拥塞标注）与正文 4.2 节描述的 AIMD 规则完全对应，未见 OCR/图题冲突或裁剪遮挡问题。
