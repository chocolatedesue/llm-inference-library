# 图片批次 3

## 图片 1：Figure 5: Fine-grained MoE latency analysis. Top row (a–c): Kimi-VL; bottom row (d–f): Qwen-VL.

![Figure 5: Fine-grained MoE latency analysis. Top row (a–c): Kimi-VL; bottom row (d–f): Qwen-VL.](../figure-groups/page-0009-c591154124ab.png)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 5.3 节"Latency Breakdown"，是**实验结论**类证据，用于回答"ReaLB 相较 EPLB/FP4-All 在细粒度延迟层面究竟改善了什么"这一具体问题，同时兼有**对比基线**角色（EPLB 作为预测式方法的失效示例、FP4-All 作为速度上界参照）。正文明确该图对应 Kimi-VL（a-c）与 Qwen-VL（d-f）两组子图 `[正文支持]`（[页码：9]）。
   - **图表角色**：实验结论 / 对比基线。
   - **上文呼应**：第 5.3 节；主张地图 C3（EPLB 无法适应动态路由）与 C5（流水线重叠隐藏开销）。

2. **图像类型与布局**：3×2 网格，共 6 个子图。上排（Panel1-3）为 Kimi-VL，下排（Panel4-6）为 Qwen-VL，与正文 Figure 5(a-c)/(d-f) 对应。Panel1/4 为堆叠柱状图（Time breakdown，单位秒），横轴为 Baseline/EPLB/Async_EPLB/FP4-All/ReaLB-seq/ReaLB 六种配置，柱内分段颜色代表 attn/encoder/eplb_overhead/mlp/moe/combine/dispatch/realb_overhead/overlapping 等组件。Panel2/5 为折线图（MoE Layer Latency vs Iterations），三条线为 Baseline（蓝）、EPLB（绿）、ReaLB（橙），并附均值±标准差文本框。Panel3/6 为按 EP Rank Index 分组的柱状图，同样三种配色，叠加虚线标示归一化比例并在部分柱上标注倍数（如 1.00×、1.29×、1.62×）。

3. **如何阅读**：Panel1/4 纵轴为秒，需比较不同方法柱高及各组件占比，柱顶红字为相对 Baseline 的总时长变化百分比。Panel2/5 纵轴为 ms，横轴为迭代次数（0-250），比较三条曲线的振荡幅度与均值。Panel3/6 纵轴为 ms，横轴为 EP Rank Index（0-7），比较同一 rank 下三种方法柱高及虚线标注倍数。

4. **直接可见的结论**：
   - Panel1（Kimi-VL）：EPLB、Async_EPLB 相比 Baseline 总时长分别标注 +3.9%、+2.4%（增加）；FP4-All、ReaLB-seq、ReaLB 分别标注 -25.8%、-19.9%、-22.8%（减少），且 eplb_overhead 分段在 EPLB/Async_EPLB 柱中可见，realb_overhead 与 overlapping 分段在 ReaLB 相关柱中可见 `[图像直接可见]`。
   - Panel2（Kimi-VL）：文本框显示 Baseline 均值 1.51±0.04ms，EPLB 均值 2.15±0.10ms，ReaLB 均值 1.36±0.03ms；ReaLB 曲线整体低于 Baseline，EPLB 曲线整体高于二者且波动较大 `[图像直接可见]`。
   - Panel3（Kimi-VL）：多个 Rank（如 Rank0、Rank4）标注 1.00× 虚线（对应 Baseline 或 EPLB 峰值参照），Rank4 处另标 1.29×（ReaLB 相对最大提速倍数所在 rank）；ReaLB 柱在多数 rank 上低于 Baseline 与 EPLB `[图像直接可见]`。
   - Panel4（Qwen-VL）：EPLB、Async_EPLB 标注 +19.5%、+17.8%（增加，且增幅明显大于 Kimi-VL 组）；FP4-All、ReaLB-seq、ReaLB 标注 -11.0%、-1.8%、-8.9%（减少，且 ReaLB-seq 降幅远小于 Kimi-VL 组的 -19.9%）`[图像直接可见]`。
   - Panel5（Qwen-VL）：文本框显示 Baseline 1.48±0.04ms，EPLB 1.99±0.07ms，ReaLB 1.39±0.04ms，趋势与 Kimi-VL 组一致但数值不同 `[图像直接可见]`。
   - Panel6（Qwen-VL）：可见 0.98× 与 1.00× 虚线标注（分别靠近 EPLB、Baseline 峰值 rank），另有 1.62× 标注在某 rank（Rank6 附近）上，该具体数值在正文中未被引用 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：Panel1/4 的堆叠柱状图直接对应正文"FP4-All 与 ReaLB 几乎将 MoE 时间占比减半，带来 22.8%（Kimi-VL）端到端时间下降；EPLB 反而略微增加"的**实验结论**类主张 `[正文支持]`（[页码：9]），图中 -22.8% 标注与文字数值完全吻合；Qwen-VL 组的 -8.9%（ReaLB）与正文"从 d-f 观察到类似趋势"的定性描述一致，但具体 -8.9%/-11.0%/-1.8% 等数值属于图像本身携带的补充信息，正文未逐一给出 `[基于视觉的谨慎推断]`。Panel2/5 直接对应正文"ReaLB 将平均 MoE 层延迟从 1.51ms 降到 1.36ms；EPLB 从 1.51ms 升到 2.15ms"（[页码：9]），Qwen-VL 的 1.48→1.39ms（ReaLB）、1.48→1.99ms（EPLB）为图像补充的对应数值 `[图像直接可见]`，验证了 EPLB 历史预测式重平衡在动态路由下"适得其反"的**机制**主张（对应主张地图 C3、比较工作地图中 EPLB 一行）。Panel3/6 中 ReaLB 通过针对性优化热点 rank 达到"最高 1.29×"提速与正文完全对应（[页码：9]），验证了模态感知精度切换对特定 straggler rank 的**效果**主张；Panel6 中出现的 1.62× 标注支持"Qwen-VL 上呈现类似趋势"这一定性表述，但其具体量级为图像独有信息，不能替代正文对 Qwen-VL rank 级别数值的明确报告。ReaLB-seq 与 ReaLB 在 Panel1/4 中的对比（-19.9% vs -22.8%；-1.8% vs -8.9%）直接支持流水线重叠模块（C5）的**机制**贡献：去掉重叠后总时长降幅明显收窄，说明重叠本身贡献了实际可观的速度收益，尤其在 Qwen-VL 上收窄幅度更大（-1.8% vs -8.9%，重叠贡献占比更高）。

6. **适用范围与证据缺口**：本组证据覆盖论文报告的 Kimi-VL 与 Qwen3-VL 两个模型、DynaMath（1K 样本）单一 benchmark、8×RTX 5090 单一硬件配置下的延迟分解（[页码：9]），Panel2/3/5/6 的具体迭代窗口范围（0-250 与 0-500 不确定）与部分 rank 标注倍数（如 Panel6 的 1.62×、Panel3 未标注倍数的 rank）因图像分辨率/标注密度限制无法逐一精确读取其对应的具体百分比或跨 rank 完整数值，属于图像本身的标注密度缺口而非论证缺口；除此以外无额外证据缺口。

---

## 图片 2：Figure 6: Dynamics of device-level load imbalance across MoE layers 12-21.

![Figure 6: Dynamics of device-level load imbalance across MoE layers 12-21.](../figure-groups/page-0016-22400dd38a22.png)

*来源：OCR 第 16 页。*

### 解读

1. **论文角色与验证问题**：该图位于附录（第 16 页），页面正文提到"modality tokens, highlighting workload skew, modality imbalance, and the persistence of hotspots during inference"，对应第 5.1 节 Setup 中提及的"Additional routing statistics and batching patterns are provided in Appendix F and G"`[正文支持]`（[页码：7]）。属于**必要性**类证据（支撑"推理阶段负载不均衡高度动态、跨层持续存在"这一根问题观察），补充说明该动态性不仅存在于单层，而是跨多个 MoE 层（12-21）持续出现。
   - **图表角色**：问题严重性 / 必要性。
   - **上文呼应**：第 3.1 节"Routing Dynamics across Iterations"关于设备级不均衡度量 $IB_d=Load_d/Ideal$（[页码：6]）；第 5.1 节 Appendix F/G 引用（[页码：7]）。

2. **图像类型与布局**：4×3 网格排列共 10 个子图（第三列第 3、4 行为空白，实际有效面板 10 个），对应 Figure 6 标题"Dynamics of device-level load imbalance across MoE layers 12-21"中的 (a)-(j) 十个 MoE 层。每个子图为同一形式的折线/棒线图（带圆点标记的连续曲线，浅蓝色）。

3. **如何阅读**：每个子图横轴为 Iteration（0-500），纵轴为"Rank-level Load Imbalance (max/n)"，对应正文定义的 $IB_d = Load_d/Ideal$（rank 最大负载与平均负载之比，[页码：6]）。10 个子图分别对应 Layer 12 至 Layer 21，需要比较各层曲线的振荡幅度、基线水平与峰值出现频率，判断不均衡程度是否随层数变化及是否具有跨层一致性。

4. **直接可见的结论**：所有 10 个面板均呈现高频振荡模式，基线大致在 1.0-2.0 区间反复波动，并伴随间歇性尖峰，多数面板尖峰可达 2.5-3.0，个别面板（如对应 Layer 19、Layer 21 的两个子图）尖峰达到约 4.0，且尖峰多出现在序列起始（迭代 0 附近）与末尾（迭代接近 500 附近）位置 `[图像直接可见]`。各层整体振荡形态相似（无明显单调趋势或收敛/发散模式），但个别层（如出现约 4.0 峰值的两层）峰值幅度明显高于其余层 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：本图为**必要性**类证据，验证的是核心洞见"观察2（不可预测的高动态性）"——即负载不均衡在迭代间快速、不可预测地波动，且这一现象并非单层现象，而是在 12 个连续 MoE 层（Layer12-21）上普遍观察到，从而支持正文"MMoE 推理中专家/设备负载在迭代间剧烈波动...限制静态或预测式均衡策略有效性"的论断 `[正文支持]`（对应[页码：3-4]的定性描述，及本图作为其附录层面的补充证据）。图中各层普遍存在的高频振荡与间歇尖峰，为 ReaLB"不依赖历史统计、仅用当前层瞬时状态 $IB_d$ 判定热点"这一模块设计动机（4.2 节，[页码：6]）提供了跨层级的背景支持——若不均衡在每一层都持续快速波动，则基于历史窗口的预测式方法在任意层都难以奏效，这与 EPLB 在第 3.2 节被批评的"预测失配"机制一致 `[基于文中逻辑的推断]`（推理依据：图中纵轴定义与正文 $IB_d$ 公式一致，且波动模式跨层重复出现，与"跨层持续存在的热点"表述相符）。该图不能证明的是：跨层不均衡是否存在因果关联或层间传播机制，也不能证明具体某个 rank/专家在跨层意义上的身份持续性（图中仅有聚合的 max/n 比值，无 rank 或专家标签）。

6. **适用范围与证据缺口**：本图覆盖的是论文附录中报告的 Kimi-VL（或未明确指出模型，需结合附录原文）在 MoE Layer 12-21（共 10 层）、500 次迭代窗口内的 rank 级不均衡度量，具体模型名称、GPU 配置等未在本页文字中重复说明（依赖第 5.1 节整体实验设置默认沿用）。因该页正文仅有一句概括性说明，未给出各层具体数值统计（如均值、标准差、尖峰对应的具体迭代号），故各子图峰值的精确数值以及具体触发峰值的实际路由事件为图像本身未标注、正文也未展开报告的细节，此为真实缺口；除此以外无额外证据缺口。
