# 图片批次 2

## 图片 1：Figure 3: ReaLB design for efficient multimodal MoE inference. It combines modality-aware scheduling and an overlapping execution pipeline to mitigate device-level latency imbalance while minimizing runtime overhead.

![Figure 3: ReaLB design for efficient multimodal MoE inference. It combines modality-aware scheduling and an overlapping execution pipeline to mitigate device-level latency imbalance while minimizing runtime overhead.](../figure-groups/page-0005-69d52366dd40.png)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：本图对应第 4.1/4.3 节（Figure 3），证据类型为**机制**。它不用于展示效果数字，而是把正文用文字描述的 ReaLB 整体机制（Routing and Profiling → Modality-aware LB Scheduling → Overhead-aware Pipeline Orchestration → Balanced MoE Execution 四阶段流程，以及 4.2 节的热点识别+模态判定规则、4.3 节的流水线隐藏开销机制）转成可视化架构图，用于解释"过载且视觉主导的 rank 如何被识别并切换到低精度、其余 rank 如何保持标准精度、精度转换开销如何被隐藏"这一核心方法设计。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：第 4.1 节系统总览（四阶段流程）、第 4.2 节模态感知调度（$IB_d$、$R_{vd}$、$M_d$）、第 4.3 节开销隐藏流水线与 LB Gate

2. **图像类型与布局**：示意图（架构图），分为左右两个大panel。左侧 Panel 1 上半部分为 (a) 系统总览：一行 MoE 专家 E0–E7（部分用粉色斜线底纹标出）、通信箭头、中间 ReaLB 模块（①Modality-aware LB Scheduler，②Pipeline Orchestrator）、底部四个 EP Rank 各自的 Gate/Attn 框；左侧下半部分为 ②ReaLB Orchestrator 细节：Attn→G(Gate)→S→Dispatch→MMoE→Combine 的流水线，标注"Hidden Overhead"箭头覆盖 S 和 Dispatch 阶段，整体标为"LB Gate"。右侧 Panel 2 为 ①ReaLB Scheduler 细节：四个 EP Rank（Rank-0 至 Rank-3）各自的专家组（E0–E3、E4–E7、E8–E11、E12–E15），Rank-1 标"Hot Device"+"Vision-heavy device"，用粉色斜线底纹表示 NVFP4 GEMM，并标注"TC Accelerated FLOPS×4"和"W4A4 GEMM"；Rank-2 也标"Hot Device"但为"Text-heavy device"，标注"Protected"和"W16A16 GEMM"；Rank-0、Rank-3 为标准蓝色底纹，"W16A16 GEMM"。图例区分蓝色（BF16 MoE GEMM）与粉色斜线（NVFP4 MoE GEMM）。

3. **如何阅读**：颜色/底纹是关键图例——蓝色表示标准精度（BF16）计算，粉色斜线表示低精度（NVFP4/FP4）计算；应对比 Rank-1（vision-heavy 且过载）与 Rank-2（text-heavy 且过载）在颜色上的差异，理解"过载"不等于"降精度"，只有"过载+视觉主导"才降精度；左侧 Orchestrator 子图应按从左到右的流水线顺序阅读（Attn→G→S→Dispatch→MMoE→Combine），关注"Hidden Overhead"箭头覆盖的具体阶段范围。

4. **直接可见的结论**：Rank-1 与 Rank-2 均被标记为"Hot Device"（即过载 rank），但只有 Rank-1（vision-heavy）的专家块使用粉色斜线底纹（NVFP4/W4A4 GEMM）并标注"TC Accelerated FLOPS×4"，Rank-2（text-heavy）保持蓝色底纹（W16A16 GEMM）并标注"Protected"；Rank-0、Rank-3 未被标记为 Hot Device，也保持标准精度。左下 Orchestrator 图中，"Hidden Overhead"标注的范围覆盖 S（元数据收集）阶段和 Dispatch（通信）阶段的重叠区域，而非 MMoE 计算阶段本身。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：本图直接可视化了核心洞见（"straggler 主要由视觉专家聚集的 rank 造成，且只有视觉主导的过载 rank 才适合降精度"）与模块 2（模态感知精度分配）的判定逻辑——图中 Rank-1 与 Rank-2 同为过载（Hot Device）但精度处理相反，正是正文"$d\in\mathcal{H}$ 且 $R_{vd}>M_d$ 才标记为可压缩"这一规则的具体实例化，属于**机制**类主张，说明该设计不是简单"过载即降精度"，而是叠加了模态判据来保护文本主导设备的精度。左下 Orchestrator 图则可视化了模块 5（开销隐藏流水线）的设计意图：把 S 与转换开销安排在与 Dispatch 通信重叠的窗口内，与正文"LB 开销被通信窗口淹没"的论证一致。这些是架构设计的图示说明，而非量化实验结果——图中不包含任何速度/精度的数值支持，因此不能用它论证 ReaLB 的实际效果幅度（那部分由 Table 1/Figure 5 承担）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖的是 ReaLB 方法本身的架构与调度逻辑示意，对应论文 4.1–4.3 节描述的通用设计，不针对某一具体模型/硬件配置的实测结果。图中 Rank 数（4 个）、专家数（每 rank 4 个）为示意性简化，与正文实际实验规模（8×RTX5090、64/128 专家）不同，属于示意图的正常简化，不构成证据缺口。无额外证据缺口。

---

## 图片 2：Figure 4: ReaLB is enabled only in the compute-bound regime with large batch sizes.

![Figure 4: ReaLB is enabled only in the compute-bound regime with large batch sizes.](../assets/imgs/img_in_chart_box_703_533_1009_665.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：本图对应第 4.3 节 LB Gate 部分（Figure 4），证据类型为**机制**（同时支撑适用范围）。它用于解释性支持模块 6（LB Gate，全局 batch 阈值 Γ）的设计动机——即"为什么只有在 batch 足够大、GEMM 主导延迟时才启用负载均衡，否则退回标准执行"这一判断依据。`[正文支持]`
   - **图表角色**：机制 / 适用边界
   - **上文呼应**：第 4.3 节"LB Gate"段落，图题"ReaLB is enabled only in the compute-bound regime with large batch sizes"

2. **图像类型与布局**：堆叠柱状图（stacked bar chart），横轴为 # Token（从 4 到 16384，对数间隔），纵轴为 Time (ms)。每根柱子由四种颜色堆叠组成，图例标注为 Token Alignment（浅蓝）、Activation（蓝）、Reduction（浅绿）、GEMM（深绿）。图中有一条橙色虚线分界，左侧标注"Non-Compute-bound"，右侧标注"Compute-bound"，虚线右侧文字标注"Enable ReaLB"。

3. **如何阅读**：横轴为 token 数量（batch 规模的代理），纵轴为各操作耗时的绝对时间；应比较不同 token 数下各颜色分段（尤其是 GEMM 深绿色段）占柱子总高度的比例变化，判断随 batch 增大 GEMM 是否从次要变为主导；虚线位置对应正文中 Γ=2048 附近的判定分界。

4. **直接可见的结论**：在 token 数较小（左侧，虚线以左）时，柱子总高度较低，且 GEMM（深绿）分段占比相对不突出，Token Alignment/Activation/Reduction 等非 GEMM 分段占据可观比例；随着 token 数增大（虚线以右，标注"Enable ReaLB"区域），柱子总高度迅速增长，GEMM（深绿）分段的绝对高度和占比明显主导整体高度增长。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为模块 6（LB Gate）提供了直接的可视化支持——正文陈述"per-rank token 数较小时非 GEMM 操作主导延迟，设备不均衡影响有限；batch 增大后 GEMM 成为主导成本，straggler 效应才显现"，图中 GEMM 分段随 token 数增长而占比迅速上升、在虚线右侧成为主导分段的趋势，与该文字论证的方向一致，支持"只在 compute-bound 区间开启 LB"这一**适用范围**判断的合理性。这属于机制性/定性支持，不能替代对 Γ=2048 具体取值合理性的定量消融（正文本身也未给出该消融，属于主张地图 C9 已标注的缺口）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖的是单次前向延迟按 token 数变化的分解测量（软件栈：vLLM+LLM Compressor+FlashInfer，硬件 8×RTX5090，与正文 Setup 一致），用于说明 Gate 阈值选择的定性依据。真实缺口：图中横轴仅标出若干离散 token 数刻度（4、8、16…16384），虚线分界的精确 token 数值与正文 Γ=2048 是否完全对齐在当前图像分辨率下无法精确判读（虚线视觉位置落在 256 附近刻度上，但坐标轴为对数间隔，无法读出精确交点数值）；此外，图中不包含"启用/禁用 LB"的实际加速比数值，仅有各操作耗时分解，无法据此判断 Gate 开关对最终吞吐的量化影响，此为主张地图 C9 已标注的同类缺口。
