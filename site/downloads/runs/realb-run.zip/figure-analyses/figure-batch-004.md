# 图片批次 4

## 图片 1：Figure 7: Overloaded devices and experts across iterations for layer 12-19, with token proportions for different modalities.

![Figure 7: Overloaded devices and experts across iterations for layer 12-19, with token proportions for different modalities.](../figure-groups/page-0017-b33643129340.png)

*来源：OCR 第 17 页。*

### 解读

1. **论文角色与验证问题**：该图对应 Appendix F（正文 5.1 节 Setup 明确提及"Additional routing statistics and batching patterns are provided in Appendix F and G"，[页码：7]），是对正文 3.1 节核心观察（Figure 2a：视觉 token 主导且设备/专家间分布高度不均）的扩展验证——把单层的路由统计扩展到 Layer 12–19 共 8 层。证据类型为**问题严重性**（同时具备**适用范围**属性）：验证"视觉 token 主导且设备间/专家间分布不均"这一现象是否在更多层上持续存在，而不只是正文中挑选展示的单层个例。`[正文支持]`
   - **图表角色**：问题严重性 / 适用范围
   - **上文呼应**：对应 3.1 节"Routing Dynamics across Devices, experts, and Modalities"（[页码：3]）及 5.1 节对 Appendix F 的引用（[页码：7]）

2. **图像类型与布局**：16 个子面板（Panel 1–16），按 (a) Layer 12 至 (h) Layer 19 共 8 层，每层对应两个子图：左侧为设备（Rank-0 至 Rank-7）级别的堆叠柱状图（浅橙=Vision Tokens per Rank，浅蓝=Text Tokens per Rank，虚线=Device-level Ideal Load），柱顶标注视觉 token 占比百分比；右侧为专家（Expert ID，0–63）级别的堆叠柱状图（深橙=Vision Tokens per Expert，深蓝=Text Tokens per Expert，虚线=Expert-level Ideal Load），部分柱顶标注该专家的视觉 token 占比百分比，并有竖直虚线分隔 8 个 rank 所辖的专家区间。奇数 Panel（1,3,5,7,9,11,13,15）为设备级，偶数 Panel（2,4,6,8,10,12,14,16）为专家级，两两配对对应同一层。`[图像直接可见]`

3. **如何阅读**：设备级图纵轴为 #Tokens，横轴为 Rank-0~Rank-7，比较各 rank 的总负载高度与虚线 Ideal Load 的偏离，以及柱内视觉/文本 token 的堆叠比例（柱顶百分比=视觉 token 占比）；专家级图纵轴同为 #Tokens，横轴为 Expert ID 0–63，比较各专家的负载尖峰与虚线 Ideal Load 的偏离，以及个别标注专家的视觉占比。需要逐层（8 组）比较设备级子图与专家级子图的对应关系。`[图像直接可见]`

4. **直接可见的结论**：在全部 8 层中，设备级柱状图均显示部分 rank 明显超过虚线 Ideal Load（如 Layer 12 的 Rank-2 达 79%，Layer 15 的 Rank-4 达 83%、Layer 19 的 Rank-4 达 73%），且各 rank 的视觉 token 占比差异较大（同层内可从约 46%~57% 到 89%~94% 不等，例如 Layer 13：Rank-1 74%、Rank-5 46%）。专家级柱状图在所有层中都出现少数专家显著超过 Expert-level Ideal Load 的尖峰（如 Layer 14 的某专家约 3000 tokens 远超虚线水平，Layer 17 中约 1300 tokens 的尖峰），且这些热点专家柱顶标注的视觉占比普遍偏高（多数在 60%~96% 区间，如 Layer 16 中 96%、Layer 12 中 94%），但也存在个别热点专家视觉占比较低的情形（如某柱标注 26%）。整体上，视觉 token（橙色）在几乎所有面板的柱状堆叠中占主导比例。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：这组图属于**问题严重性**证据，把 3.1 节基于单层/MMMU 的观察（"视觉 token 在整体工作负载中占主导，且设备/专家间分布高度不均"，对应主张地图 C2）扩展验证到 Layer 12–19 共 8 层，说明该现象不是单层特例，而是跨层持续存在的结构性问题——这直接支撑了 ReaLB 逐层（layer-wise）运行调度策略的必要性（4.1 节"performs online load balancing at the granularity of EP ranks"逐层执行，[页码：6]）：如果不均衡只在个别层出现，逐层判定的设计意义会打折扣；而本图显示几乎每层都存在超载 rank 与视觉主导的热点专家，为"每次前向传播前都需要重新判定 IB_d 和 R_vd"（4.2 节，[页码：6]）提供了跨层的经验支持。同时，专家级图中热点专家视觉占比总体偏高但并非绝对（个别柱视觉占比明显偏低），这与正文"专家级别的视觉 token 占比范围可达 31%–93%"的表述（[页码：3]，主张地图 C2）在方向上一致，佐证了 R_vd 阈值判定（而非简单"是否超载"）的必要性。该图不能证明 ReaLB 方法本身的加速/精度效果（那属于 Table 1/2 与 Figure 5 的范畴），只能证明其所针对的问题（跨层负载/模态不均衡）具有普遍性。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本图覆盖的实验设置为 Kimi-VL 模型、8 GPU EP、MMMU 数据集（沿用 3.1 节设置，[页码：3]）、Layer 12–19 共 8 层的路由统计，属于附录补充数据（Appendix F）。图注未给出具体的模型/数据集/迭代范围说明（正文仅笼统引用"Appendix F"提供"additional routing statistics"，[页码：7]），因此该图具体对应的模型与数据集来源"无法从当前 OCR 内容确认"，只能依据与正文 Figure 2a 同源假设做合理关联；这属于正文明确未报告的实验设计细节，为真实缺口。此外，部分柱状标注百分比数字较密集、字号小，个别专家级子图中远处柱子的具体数值难以精确辨读（如 Layer 13 专家图右侧多个未标注数字的次级峰值），但柱高的相对趋势清晰可辨，不构成影响整体结论的实质缺口。

---

## 图片 2：Figure 8: Token composition in continuous batching.

![Figure 8: Token composition in continuous batching.](../figure-groups/page-0018-846ea9c407af.png)

*来源：OCR 第 18 页。*

### 解读

1. **论文角色与验证问题**：该图对应正文 Appendix G "Batching pattern"（页面 18 正文），用于支撑"colocated 部署下的连续批处理观测结果可近似代表 prefill-only 场景"这一方法学假设（"providing a close approximation to a prefill-only setting"）。证据类型为**适用范围**：验证全文所有路由动态性观测（3.1/3.2 节及本 OCR 中 Figure 7）所依赖的 colocated 部署设置是否会因混入 decode token 而扭曲结论，以及视觉 token 占比在迭代间的波动模式。`[正文支持]`
   - **图表角色**：适用范围（同时为问题严重性提供辅助证据：视觉 token 占比的迭代间波动）
   - **上文呼应**：对应 Appendix G 正文"Prefill-dominated batches"段落（[页码：18]），呼应 5.1 节"colocated deployment...each forward batch may contain a mixture of prefill and decode requests"（[页码：7]）

2. **图像类型与布局**：两个并列折线/面积图。Panel 1 标题为"#Vision tokens / #Total tokens"，横轴为 Iterations，纵轴为 Share（0–1），橙色折线表示 Vision tokens share 随迭代变化。Panel 2 标题为"Prefill tokens and Decode tokens share of (P+D)"，横轴为 Iterations，纵轴为 Share（0–1），绿色堆叠面积图区分 Prefill/(P+D)（图例绿色区域）与 Decode/(P+D)（图例极薄的粉色/红色边缘区域）。`[图像直接可见]`

3. **如何阅读**：Panel 1 只有单条曲线，直接读取橙色折线在纵轴上的高度及其随迭代（横轴）的波动范围。Panel 2 为堆叠面积图，需比较绿色（Prefill）区域占据的纵轴高度 vs 顶部极窄的条带（Decode）所占比例，两者应在每个迭代点上加总为 1（100%）。`[图像直接可见]`

4. **直接可见的结论**：Panel 1 中视觉 token 占比在各迭代间剧烈波动，取值范围大致在约 0.2 到接近 1.0 之间反复起伏，多数迭代点集中在 0.5–1.0 区间，但存在多次骤降至 0.2~0.4 附近的低谷。Panel 2 中绿色（Prefill）面积几乎占满整个纵轴（贴近 1.0），顶部代表 Decode 的条带极其窄薄，在整个约 650+ 次迭代范围内始终保持这种绝对主导格局，未见明显趋势性变化。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：Panel 2 直接对应并验证正文明确陈述的量化结论——"decode tokens account for less than 10% of the total tokens per batch"（[页码：18]）：图中 Decode 条带在目视上远低于 10% 的量级，与文字定量描述方向一致，属于**适用范围**证据，支撑论文用 colocated 部署观测近似 prefill-only 场景这一方法学选择的合理性——这为全文所有基于 colocated 设置得到的路由动态性结论（包括 3.1/3.2 节及本 OCR 图片 1 中 Figure 7 的跨层统计）提供了"该设置不会被 decode token 显著污染"的背书。Panel 1 则呼应主张地图观察 1（"模态驱动的负载倾斜"）与观察 2（"不可预测的高动态性"）——视觉 token 占比本身在迭代间快速大幅波动，这与 3.2 节"推理阶段路由高度动态、难以预测"的论述（[页码：4]）方向一致，间接支持了"历史窗口预测方法（EPLB）难以适应这种波动"的必要性论证（对应主张地图 C3），但该图本身并非 EPLB 对比实验，不能单独证明 EPLB 失效，只能作为视觉 token 占比本身高度动态这一背景事实的补充证据。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本图对应的实验设置是正文 Appendix G 所述的 colocated 部署、max-num-seqs=12 配置下的连续批处理观测（[页码：18]），具体模型/数据集未在该页文字或图注中注明，"无法从当前 OCR 内容确认"具体是 Kimi-VL 还是 Qwen-VL、或对应哪个 benchmark，此为正文明确未报告的实验设计细节，属真实缺口。Panel 2 图例中 Decode 区域的具体数值刻度因条带过窄，无法从图像本身精确读出其数值（正文已用"<10%"的文字给出量化结论，可作为已知事实使用，不再作为缺口重复列出）。
