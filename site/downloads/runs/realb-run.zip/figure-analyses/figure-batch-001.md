# 图片批次 1

## 图片 1：Figure 1: Motivation for real-time load balancing.

![Figure 1: Motivation for real-time load balancing.](../figure-groups/page-0002-5d3886c68ea1.png)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文第 1 节引言与第 3.1 节动机描述，证据类型为**问题严重性**：作者需要先让读者直观理解"MMoE 推理中专家选择的高动态性"这一根问题的真实存在及其后果，而不是仅用文字断言。图注明确写"Figure 1 shows the highly dynamic nature of expert selection during MMoE inference...expert activation frequencies in inference fluctuate significantly across iterations. This behavior makes stragglers transient and difficult to predict."(第1页)。`[正文支持]`
   - **图表角色**：问题严重性（兼具方法流水线的系统语境展示，因 Panel (a) 呈现了 MMoE 推理的完整数据流，用于引出"Hot Device/Hot Expert"这一后续要解决的对象，但其证据功能仍是为根问题提供直观场景，而非展示 ReaLB 本身的调度机制）。
   - **上文呼应**：第1节引言"highly dynamic nature of expert selection"；第3节"Motivation and Problem Formulation"的引子。

2. **图像类型与布局**：两个子面板并列。Panel (a) 是一个从输入到输出的示意流程图：底部为"Input Image"+"Input Prompt"经 Vision Encoder / Embedding → VL Adapter → 拼接为多模态 token 序列（蓝色方块标注 Text token，黄色方块标注 Vision token）→ 送入 Attention Layer → Gate → 多个并行的 MoE Layer（"Expert Parallel"标注，×L 层）→ 顶部标注"Hot Device"（粉红色虚线框圈住一组专家块）和"Hot Expert"（红色虚线框圈住其中部分专家）→ 输出 Generated token（"There are three Spider-Men in the picture..."）。Panel (b) 是散点图：横轴 Iterations（约100–600），纵轴 Top-1 Hot Rank Index（0–7），每个点按颜色（色条 #Token，0–6000+）编码 token 数量；图中有两处橙色标注和箭头："① Limited temporal locality"指向约150–250 迭代区间内一簇密集点，"② Hot-spot shift"用橙色折线连接约350–450 迭代区间内在不同 Rank 间跳变的点。

3. **如何阅读**：Panel (a) 应按数据流方向从下往上、从左往右阅读，关注顶部粉红/红色虚线框标出的"Hot Device"/"Hot Expert"位置及其与视觉 token（黄色块）在输入侧占比的对应关系。Panel (b) 应读横轴（迭代进程）与纵轴（当前是哪个 Rank 成为 Top-1 热点），颜色深浅对应该时刻的 token 负载量；重点比较标注①处同一 Rank 是否持续占据热点位置，以及标注②处热点 Rank 是否发生跳变。

4. **直接可见的结论**：Panel (a) 中"Hot Device"框圈住的专家块数量多于"Hot Expert"框，且两者均位于同一组 Expert Parallel 专家序列中靠右侧的位置；输入 token 序列中黄色（vision token）方块数量明显多于蓝色（text token）方块。`[图像直接可见]` Panel (b) 中散点在纵轴 0–7 之间分布，颜色（token 数）深浅不均，标注①处的点在某个 Rank 附近相对集中，标注②处的橙色连线显示 Top-1 热点 Rank 在相邻迭代间发生了明显跳跃（在不同 Rank 高度间来回移动）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：Panel (a) 通过在 MMoE 推理流程图中直接标出"Hot Device"与"Hot Expert"，将正文"EP stragglers are often dominated by vision-heavy experts"（第2页）这一**机制**主张可视化为系统语境中的具体位置，帮助读者理解 ReaLB 后续"对视觉主导的过载 rank 做精度切换"这一设计动机来自哪里；但该图本身不展示任何量化对比，因此不能证明"视觉主导"与"过载"之间的因果关系，该因果关系需由后文 Figure 2/3.1 节的定量证据支持。`[基于文中逻辑的推断]` Panel (b) 直接支撑正文"expert activation frequencies in inference fluctuate significantly across iterations"这一**必要性**主张（第1页），即证明"专家选择的高动态性"确实存在，从而为 ReaLB 拒绝"历史预测式"方法（EPLB/LPLB）、转而采用"瞬时状态判定"提供了初步的可视化依据；但该图未给出具体的预测失配量化对比（那是 Figure 2c 的任务），也未标出具体是哪个模型/benchmark 的数据，因此仅能作为"现象存在性"证据，不能单独证明"预测方法必然失效"这一更强主张。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本图为引言层面的动机图，覆盖范围与正文一致——基于 8×RTX5090 上运行 Kimi-VL、MMMU 数据集的路由统计（该具体设置来自后续 3.1 节文字说明，第3页，图1本身未标注模型/数据集名称）。Panel (b) 颜色条的具体 token 数值范围（0–6000+）与坐标轴刻度均可从图中读出，无裁剪或遮挡问题。无额外证据缺口。

---

## 图片 2：Figure 2: High dynamics in MMoE routing limit the effectiveness of prediction-based methods. (a) Load imbalance across devices, experts, and modalities. (b) Temporal variation in imbalance severity across iterations. (c) Rapid shifts of the top-1 hot device and expert, highlighting the mismatch between historical observations and current load.

![Figure 2: High dynamics in MMoE routing limit the effectiveness of prediction-based methods. (a) Load imbalance across devices, experts, and modalities. (b) Temporal variation in imbalance severity across iterations. (c) Rapid shifts of the top-1 hot device and expert, highlighting the mismatch between historical observations and current load.](../figure-groups/page-0004-47a6094f6ef1.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文第 3.1 节（Panel a、b）与第 3.2 节（Panel c），是一组三联图，证据类型分别为**问题严重性**（Panel a、b：量化展示模态驱动的负载倾斜与迭代间高动态性）与**对比基线**（Panel c：直接检验 EPLB 所依赖的"历史时间局部性"假设在推理阶段是否成立）。图注明确写"Figure 2: High dynamics in MMoE routing limit the effectiveness of prediction-based methods. (a) Load imbalance across devices, experts, and modalities. (b) Temporal variation in imbalance severity across iterations. (c) Rapid shifts of the top-1 hot device and expert, highlighting the mismatch between historical observations and current load."`[正文支持]`
   - **图表角色**：问题严重性（Panel a/b）+ 对比基线（Panel c，针对 EPLB 的"滑动窗口历史预测"机制）。
   - **上文呼应**：第3.1节"Routing Dynamics across Devices, experts, and Modalities"与"Routing Dynamics across Iterations"（对应观察1、观察2）；第3.2节"Limitations of Prediction-based Load Balancing"（对应 C3 主张与 EPLB 批判）。

2. **图像类型与布局**：三个子面板纵向排列。Panel (a) 为双层柱状图：上层横轴为 Rank-0 至 Rank-7，纵轴为 #Token，柱子分为"Text Tokens per Rank"（浅蓝）与"Vision Tokens per Rank"（橙黄），叠加一条虚线"Device-level Ideal Load"，每个 Rank 上方标注一个百分比（91%、45%、68%、56%、49%、77%、66%、77%）；下层横轴为 Expert ID（0–63），同样区分 Text/Vision Tokens per Expert（配色一致）与"Expert-level Ideal Load"虚线，部分柱子上标注百分比（93%、62%、58%、79%、31%、83%、84%、72%），并有竖直虚线将上下两层对应分组。Panel (b) 为折线图：横轴 Iterations（0–500），纵轴 Load Imbalance (max/mean)，两条线——"Expert-level Imbalance"（蓝色，波动剧烈，多个尖峰）与"Device-level Imbalance"（橙色，波动幅度明显更小、更平滑）。Panel (c) 为带有背景阴影区分"Historical Record"（左侧灰色阴影，约0–200迭代）与之后区域的散点+折线组合图：横轴 Iterations（0–500），纵轴 Rank-0 至 Rank-7，灰/蓝色散点为"Top-1 rank/expert per iter"，红色实线/虚线为"Predicted Top-1 hot expert/rank"（标注"Predicted"，箭头指向水平延伸的红线），橙色/绿色虚线为"Observed Top-1 hot expert/rank"（标注"Mismatch"），显示预测线与观测线在200迭代后出现分离。

3. **如何阅读**：Panel (a) 应先看上层各 Rank 柱高与百分比（视觉 token 占比）差异，再看下层对应哪些具体 Expert ID 是各 Rank 的热点专家及其视觉占比；上下两层通过竖直虚线对应关系阅读。Panel (b) 应比较两条曲线的峰值高度与波动频率，重点关注蓝色（专家级）曲线的峰值区间与橙色（设备级）曲线的常态区间量级差异。Panel (c) 应先区分左侧灰色"Historical Record"区间与右侧"预测生效"区间，比较红色"Predicted"线（基于历史统计外推）与橙/绿色"Observed"线（实际热点）在 200 迭代后是否重合，"Mismatch"标注处即两线分离的关键位置。

4. **直接可见的结论**：Panel (a) 上层柱状图中不同 Rank 的百分比标注差异明显（如某 Rank 91% 而另一 Rank 45–49%），下层柱状图中不同 Expert ID 的百分比标注跨度更大（31%–93%）。`[图像直接可见]` Panel (b) 蓝色"Expert-level Imbalance"线在整个迭代范围内反复出现远高于橙色"Device-level Imbalance"线的尖峰，且峰值波动幅度显著大于橙色线的波动幅度。`[图像直接可见]` Panel (c) 红色"Predicted"线在 200 迭代后保持在较高的 Rank/Expert 位置基本不变，而橙/绿色"Observed"线在同一时间段内已经下降/移动到不同的 Rank 位置，两者在"Mismatch"标注处出现明显的垂直距离分离。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：Panel (a) 以量化柱状图直接支撑正文"more than 90% of tokens on Rank0 are vision tokens, whereas on Rank1 and Rank4, this ratio stays below 50%...the fraction of vision tokens ranging from 31% to 93%"（第3页）这一**机制**主张（对应观察1/C2），坐标标注的具体百分比与正文数字可对应，构成本文核心假设"过载 rank 常由视觉专家聚集造成"的直接可视化证据；这也是 ReaLB 中"模态感知精度分配"模块（4.2节，$R_{vd}$）设计的直接依据。`[正文支持]` Panel (b) 以量化曲线支撑正文"the ratio between the most-loaded expert and the average expert ranges from approximately 2× to 12×...at the device level, the peak load often exceeds the average by more than 2×"（第3页）这一**必要性**主张（对应观察2/C3），证明专家级不均衡的波动幅度远大于设备级，为"瞬时状态判定优于历史统计"提供了量化背景，支持 ReaLB 选择"每层瞬时 $IB_d$"而非"历史窗口平均"作为热点判定输入（4.2节）。`[正文支持]` Panel (c) 是本组图中**对比基线**角色最直接的体现：EPLB 原本试图解决的问题是"通过历史窗口统计识别热点专家并周期性复制"，其隐含假设是"专家/设备负载在时间上具有局部性"；本图检验的正是这条 limit 的核心——"预测（基于历史统计的外推）与观测（实际热点）是否吻合"，图中"Predicted"与"Observed"线在200迭代后的分离（"Mismatch"标注）直接对应正文"While E33 and Rank3 are top-1 hot spots during the first 200 iterations, in the subsequent 300 iterations, Rank1 and E11 become the hottest...leading to delayed or ineffective rebalancing"（第4页），证实该 limit 确实在实测数据中发生，而不仅是理论假设。`[正文支持]` 该图只检验"预测失配"这一条 limit，不涉及 EPLB 的第二、三条 limit（通信开销 $K \cdot Bytes_{expert}$、显存开销 2.4GB/专家），这两项在正文中是理论/引用数据推算，未在图中给出可视化对照，因此不能扩展为"EPLB 全面失败"的一般性结论。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本组图的实验设置与正文3.1/3.2节一致——基于 Kimi-VL、8 GPU、MMMU 数据集、PD colocated 部署下采集的路由统计（第3页）；Panel (c) 的具体窗口参数（窗口=200，再平衡间隔=300迭代）与正文一致。Panel (a) 下层柱状图中未标注百分比的其余 Expert ID（图中仅部分柱子有百分比标注）无法确认其具体视觉占比数值，这是图像本身信息呈现方式导致的真实缺口（非全部专家都标注百分比）；除此之外无额外证据缺口。
