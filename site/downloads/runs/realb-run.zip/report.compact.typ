#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(size: 9.4pt)
#set par(justify: true, leading: 0.72em, spacing: 0.72em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#show heading.where(level: 1): it => block(above: 1.4em, below: 0.9em)[
  #text(size: 17pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]
  #v(-6pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => block(above: 1.6em, below: 0.7em, inset: (x: 9pt, y: 5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))[#text(size: 12.5pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => block(above: 1.1em, below: 0.4em)[#text(size: 10.6pt, weight: "bold", fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => block(above: 0.9em, below: 0.3em)[#text(size: 9.8pt, weight: "bold", fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(size: 12pt, weight: "bold", tracking: 3pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(6pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(size: 22pt, weight: "bold")[ReaLB: Real-Time Load Balancing for Multimodal MoE Inference]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yingping Wang, Yi Wu, Xiangyu Wu, Junwei Cui, Weilin Cai, Zhijiang Guo, Jiayi Huang]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Mixture-of-Experts] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[多模态推理] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[专家并行] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[负载均衡] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[低精度计算]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-26]
]
#pagebreak(weak: true)

#set page(numbering: "1")
#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

混合专家（MoE）架构广泛应用于现代大语言模型和多模态模型中。然而，推理效率常常受到跨不同模态高度动态且倾斜的专家负载的限制。在大批量的预填充（prefill）阶段，视觉 token 往往主导输入序列。在专家并行（EP）下，这会导致严重的负载不均衡，部分设备过载，从而降低系统整体吞吐量。我们提出了 ReaLB，一种面向多模态 MoE（MMoE）推理的实时负载均衡方法，具有零调度开销。ReaLB 在运行时以每个 EP rank 为粒度动态调整 MoE 专家的计算精度：对于由视觉密集型专家主导的 rank，ReaLB 分配更低精度的计算，利用 FP4 Tensor Core 提升执行效率。ReaLB 不需要冗余专家，也不需要额外的显存分配，而是在运行过程中即时进行逐层的专家精度转换，并将相关开销隐藏在 MoE 计算之前的 dispatch 阶段中。在代表性 MMoE 模型上的实验表明，ReaLB 实现了 1.10 倍至 1.32 倍的端到端加速，同时将平均精度损失限制在 1% 以内。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#align(center)[#table(
  columns: 2,
  align: (col, row) => (auto,auto,).at(col),
  inset: 6pt,
  [字段], [内容],
  [标题],
  [ReaLB: Real-Time Load Balancing for Multimodal MoE Inference],
  [作者],
  [Yingping Wang, Yi Wu, Xiangyu Wu, Junwei Cui, Weilin Cai, Zhijiang Guo, Jiayi Huang],
  [发表场所 / 年份],
  [文中未说明],
  [研究领域],
  [系统, 机器学习],
  [关键词],
  [Mixture-of-Experts, 多模态推理, 专家并行, 负载均衡, 低精度计算],
)
]

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#blockquote[
#strong[标签（5 个）]：`Mixture-of-Experts` · `多模态推理` · `专家并行负载均衡` · `FP4低精度计算` · `vLLM推理系统`
]

ReaLB 是一种运行时、模态感知的 MoE 负载均衡方法：它不迁移专家，而是在每次前向传播前根据瞬时负载与视觉 token 占比，对\"过载且视觉专家主导\"的 EP rank 动态切换为 FP4 低精度计算，并把转换开销隐藏在 dispatch 通信中，实现 1.10×–1.32× 端到端加速、平均精度损失控制在 1% 以内 `[作者明确陈述]`（\[页码：1\]）。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

OCR 覆盖正文第 1–9 页及附录第 16–19 页（Appendix F、G、H、I 部分内容），涵盖引言、动机分析（3.1/3.2 节）、方法设计（4.1–4.3 节）与主实验（5.1–5.3 节）`[作者明确陈述]`（\[页码：1-9，16-19\]）。

- 附录 Appendix H 中关于 \#mi(\"M\_d\") 演化的\"详细实证分析\"文字部分未被本 OCR 完整收录，仅有其对应图片（图片批次 5 图片 2）`[作者明确陈述]`（\[页码：19\]）。
- 多处关键指标（ΔAcc、Speedup）仅有文字定义、无显式计算公式，具体聚合口径未披露，标注为\"文中未说明\"`[作者明确陈述]`（\[页码：8\]）。
- 论文正文出现\"ReaLB-mi\"与\"ReaLB-m1/ReaLB-m2\"两套命名，OCR 未做主观统一，如实标注不一致，可能反映 OCR 抽取或版本差异 `[基于文中逻辑的推断]`（\[页码：7-8\]）。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

在专家并行（EP，把不同专家分布到不同 GPU 上运行的并行策略）部署下，每个 GPU 通常固定托管一部分专家；一次 MoE 层前向计算的层延迟由所有 rank 中最慢的一个决定，即 \#mi(\"T\_{\\mathrm{MoE}}(x)\=\\max\_i T\_i(x)\")，这是一种\"木桶效应\"结构 `[作者明确陈述]`（\[页码：4\]）。多模态 MoE（MMoE）推理阶段，尤其是大 batch 的 prefill（一次性处理输入提示词的阶段）阶段，视觉 token 数量远多于文本 token，导致路由到不同专家/设备的 token 量高度倾斜，进而产生严重的设备间负载不均衡，拖慢整体吞吐 `[作者明确陈述]`（\[页码：1\]）。

MoE 通过每个 token 仅激活少数专家实现参数高效扩展，广泛用于现代大模型与多模态模型；但这种稀疏激活+输入依赖路由天然导致负载不均衡，多模态场景下这一问题更严重，因此直接决定了系统实际可部署的吞吐上限 `[作者明确陈述]`（\[页码：1\]）。难点在于：该\"最慢 rank\"的身份在迭代间快速、不可预测地变化，使得依赖历史统计的静态或预测式方法从根本上失效 `[实验支持]`（\[页码：3-4\]）。

#strong[本文的 story]：旧路线（无论训练期均衡损失，还是推理期的专家复制/迁移调度）失效的技术原因是\"用历史统计去预测下一时刻的热点\"，而推理阶段路由的时间局部性太弱，预测必然滞后；本文的核心转折是把问题从\"路由/专家放置优化\"转化为\"计算精度自适应\"——不追预测，只在当下\"原地\"降低已确认过载且可容忍精度损失的视觉专家的计算精度，从根本上避免了预测需求 `[作者明确陈述]`（\[页码：1-2\]）。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第3节：EP最慢rank决定层延迟且其身份不可预测]
  #image("figure-groups/page-0002-5d3886c68ea1.png", width: 100%)
  #emph[Figure 1: Motivation for real-time load balancing.] \
来源：OCR 第 2 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Hot Device/Hot Expert位于视觉token主导的输入侧，Top-1热点rank在迭代间发生明显跳变

- #strong[论证关系]：为\"视觉专家聚集致straggler\"核心洞见与专家激活高动态性提供直观场景，与Figure 2定量证据互补

- #strong[适用范围]：不含量化对比，不能单独证明视觉主导与过载之间的因果关系
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第3节：视觉token占比31%–93%的模态负载倾斜与热点预测失配]
  #image("figure-groups/page-0004-47a6094f6ef1.png", width: 100%)
  #emph[Figure 2: High dynamics in MMoE routing limit the effectiveness of prediction-based methods. (a) Load imbalance across devices, experts, and modalities. (b) Temporal variation in imbalance severity across iterations. (c) Rapid shifts of the top-1 hot device and expert, highlighting the mismatch between historical observations and current load.] \
来源：OCR 第 4 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：设备/专家视觉token占比差异显著，专家级不均衡波动远超设备级，预测线与观测线200迭代后明显分离

- #strong[论证关系]：支撑观察1/观察2及EPLB预测失配批判，是\"瞬时判定优于历史统计\"的核心可视化证据

- #strong[适用范围]：仅验证预测失配一条limit，基于Kimi-VL/MMMU单一设置，未涉及通信与显存开销
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

#align(center)[#table(
  columns: 5,
  align: (col, row) => (auto,auto,auto,auto,auto,).at(col),
  inset: 6pt,
  [路线], [原本解决什么], [依赖前提/遗留限制], [本文批判的具体 limit], [对应设计模块],
  [训练期辅助损失/device-constrained routing],
  [训练阶段调节门控提升专家利用率均衡],
  [假设可在训练时调整梯度/路由目标],
  [\"不能直接用于推理\"，未展开具体机制 `[作者明确陈述]`（\[页码：1\]）],
  [无对应设计模块（仅作背景问题设定）],
  [FasterMoE 影子专家],
  [复制过载专家到多设备均衡负载],
  [需要额外显存与通信带宽],
  [引入额外内存与通信开销 `[作者明确陈述]`（\[页码：1\]）],
  [ReaLB 原地精度切换，不复制专家],
  [EPLB 历史式专家放置],
  [用历史窗口统计周期性重放置专家],
  [假设负载具有时间局部性],
  [预测滞后、通信开销 \#mi(\"K\\cdot Bytes\_{expert}\")、显存开销线性增长 `[作者明确陈述]`（\[页码：4\]）],
  [瞬时状态判定 \#mi(\"IB\_d\") 取代历史预测],
  [LPLB],
  [用线性规划更均匀重分配 token 流量],
  [需高频调用逼近实时性],
  [高频调用的调度开销可能超过均衡收益 `[作者明确陈述]`（\[页码：3\]）],
  [LB Gate + 通信重叠的开销感知设计],
  [通信侧重叠/核融合],
  [降低 all-to-all 通信成本],
  [假设计算已经均衡],
  [无法解决计算本身不均衡 `[作者明确陈述]`（\[页码：3\]）],
  [借用既有通信窗口隐藏精度转换开销],
)
]

以上每条限制对应的实验证据仅部分完整：EPLB 一行有 Table 1/5.3 节量化对比支持 `[实验支持]`（\[页码：8-9\]）；FasterMoE、LPLB、通信侧优化、训练期方法均#strong[未被论文纳入实测对比]，其批判停留在文字论证层面，无法从当前 OCR 内容确认量化差距。

综合看，旧方法的核心技术限制可归纳为两条：#strong[(a) 依赖历史统计预测，无法适应推理路由的强瞬时波动；(b) 通过专家复制/迁移实现均衡，天然引入通信和显存开销] `[基于文中逻辑的推断]`（推理依据：训练期方法、EPLB、LPLB、FasterMoE 的批评中反复出现\"预测滞后\"与\"额外开销\"两类问题，\[页码：1，3，4\]）。

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见/贡献]：EP 的 straggler（掉队者，即拖慢整体的最慢设备）主要由聚集了视觉专家的 rank 造成；视觉 token 相较文本 token 在前向传播中表现出更高冗余性（引用支持 \[3,38\]）`[作者明确陈述]`（\[页码：2\]）。由此推出的核心假设：#strong[将\"视觉主导且过载\"的 rank 切换为低精度计算，可在几乎不损失文本相关精度的前提下降低该 rank 延迟，从而消除设备间执行时间不均衡] `[作者明确陈述]`（\[页码：2\]）。

#strong[支撑该洞见的观察（实现所需前提）]：

- 观察1（模态驱动的负载倾斜）：某 rank 视觉 token 占比可超 90%，另一些低于 50%；专家级占比范围 31%–93% `[实验支持]`（\[页码：3\]，Kimi-VL/MMMU/8GPU）。
- 观察2（不可预测的高动态性）：同一短窗口内热点专家负载/均值比可从约 2× 变到 12×，时间局部性远弱于训练阶段 `[实验支持]`（\[页码：3-4\]）。

#strong[理论支撑]：论文将均衡问题形式化为在线策略优化目标

\#mitex(`\max_{\pi}\ \mathbb{E}_{x}\big[\max_{i}T_{i}(x)-\max_{i}T_{i}(\pi(x))-T_{\mathrm{LB}}(\pi,x)\big]`)

并论证：优化\"token/专家均衡\"这类代理指标并非最小化 \#mi(\"\\max\_i T\_i\") 的必要条件；推理阶段不需要为优化稳定性维持 token 均衡，只需直接最小化执行延迟 `[作者明确陈述]`（\[页码：5\]）。这为\"不追求专家/token 完全均衡，只直接压低设备级延迟\"的设计选择提供了理论依据。

前提可能失效的场景：若视觉 token 的冗余性假设不成立（即视觉专家对精度同样敏感），或负载倾斜并非以模态为主因，该核心假设的适用性会被削弱；论文未提供该前提的反向消融，属于证据缺口（见 4.2 节相关说明）。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

#strong[总览]：输入为当前层各设备的负载与模态构成 → 判定过载设备 → 在过载设备中筛出\"视觉主导\"者 → 对这些设备的专家在线转换为 FP4 精度并执行计算 → 转换开销与元数据收集被安排在 dispatch 通信窗口内隐藏 → 输出经均衡后的 MoE 层结果，供后续 Combine/下一层使用 `[作者明确陈述]`（\[页码：6-7\]）。

+ #strong[运行时状态与热点识别（\#mi(\"IB\_d\"), 阈值 \#mi(\"C\")）]

  - 动机：需要不依赖历史统计、纯瞬时的\"是否过载\"判定 `[作者明确陈述]`（\[页码：6\]）。
  - 输入/过程/输出：输入当前层各设备 token 负载 \#mi(\"Load\_d\") 与平均负载 \#mi(\"Ideal\")；计算 \#mi(\"IB\_d \= Load\_d/Ideal\")；输出热点集合 \#mi(\"\\mathcal{H}\={d\\mid IB\_d\>C}\")，\#mi(\"C\=1\") 表示完全均衡 `[作者明确陈述]`（\[页码：6\]）。
  - 优势：仅用当前层瞬时数据，规避历史预测滞后问题 `[基于文中逻辑的推断]`（\[页码：5-6\]）。

+ #strong[模态感知精度分配（\#mi(\"R\_{vd}\"), \#mi(\"M\_d\")）]

  - 动机：区分\"视觉主导可压缩\"与\"文本主导不可压缩\"的过载设备 `[作者明确陈述]`（\[页码：6\]）。
  - 输入/过程/输出：输入设备上视觉/文本 token 数 \#mi(\"N\_{vd}, N\_{td}\")；计算 \#mi(\"R\_{vd}\=N\_{vd}/(N\_{vd}+N\_{td})\")；对 \#mi(\"d\\in\\mathcal{H}\") 且 \#mi(\"R\_{vd}\>M\_d\") 的设备标记为可压缩，其专家用低精度 GEMM 执行，其余保持标准精度 `[作者明确陈述]`（\[页码：6\]）。
  - 优势：把降精度限定在对损失不敏感的视觉专家上 `[作者明确陈述]`（\[页码：2\]）。

+ #strong[AIMD 自适应阈值控制]

  - 动机：固定阈值难以兼顾响应速度与稳定性 `[作者明确陈述]`（\[页码：6\]）。
  - 规则：\#mi(\"IB\_{global}\=\\max\_d IB\_d\")，拥塞阈值 \#mi(\"\\tau\=1.5\")；若 \#mi(\"IB\_{global}\>\\tau\") 则 \#mi(\"M\_d \= 0.5M\_d\")，否则 \#mi(\"M\_d\=\\min(1, M\_d+0.1)\") `[作者明确陈述]`（\[页码：6\]）。
  - 优势：借鉴网络拥塞控制思想，拥塞时快速收紧、平稳期逐渐放松 `[作者明确陈述]`（\[页码：6\]）。

+ #strong[在线精度转换]

  - 动机：不增加显存占用的前提下支持实时精度切换 `[作者明确陈述]`（\[页码：6-7\]）。
  - 过程：每个专家仅存原始高精度权重+预计算缩放因子；调度下发新精度配置时在线量化到目标精度 `[作者明确陈述]`（\[页码：6-7\]）。

+ #strong[开销隐藏的流水线编排]

  - 动机：元数据收集 \#mi(\"S\") 与精度转换 \#mi(\"T\") 本身引入额外计算，需从关键路径移除 `[作者明确陈述]`（\[页码：7\]）。
  - 过程：\#mi(\"S\")、\#mi(\"T\") 与 dispatch 阶段的设备间通信重叠执行 `[作者明确陈述]`（\[页码：7\]）。
  - 优势：LB 开销只涉及本地转换和轻量元数据收集，不随 EP 规模扩展，而 dispatch 延迟随 EP 规模增长，因此重叠后 LB 开销被通信\"淹没\" `[作者明确陈述]`（\[页码：7\]）。

+ #strong[LB Gate（全局 batch 阈值 \#mi(\"\\Gamma\")）]

  - 动机：只有 GEMM 计算主导延迟时，设备负载不均衡才直接转化为延迟不均衡；小 batch 时启用 LB 无意义甚至有害 `[作者明确陈述]`（\[页码：7\]）。
  - 过程：聚合设备负载超过 \#mi(\"\\Gamma\=2048\")（256×8）时启用 LB，否则退回标准执行 `[作者明确陈述]`（\[页码：7-8\]）。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：模态感知精度分配与开销隐藏流水线的整体系统设计]
  #image("figure-groups/page-0005-69d52366dd40.png", width: 100%)
  #emph[Figure 3: ReaLB design for efficient multimodal MoE inference. It combines modality-aware scheduling and an overlapping execution pipeline to mitigate device-level latency imbalance while minimizing runtime overhead.] \
来源：OCR 第 5 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Rank-1视觉主导过载转NVFP4精度，Rank-2文本主导过载保持标准精度并标注Protected

- #strong[论证关系]：具体实例化\"过载不等于降精度\"判定规则，与开销隐藏流水线设计互补

- #strong[适用范围]：为示意性简化架构，不含任何速度/精度数值，不能论证实际效果幅度
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 瞬时状态判定（\#mi(\"IB\_d\")）只依赖当前层数据，逻辑上避免了历史统计对时间局部性的假设，因而能应对 3.2 节实证的强瞬时波动 `[基于文中逻辑的推断]`（\[页码：5-6\]）。
- 将降精度限定于\"视觉主导+过载\"设备，理论上兼顾速度与精度，前提是视觉 token 冗余性假设成立（背景知识支持，非本文直接实验验证的前提本身）`[背景知识]`（\[页码：2\]）。
- 流水线重叠使 LB 开销不随 EP 规模线性增长，理论上具有可扩展性，但该扩展性论证仅为理论推演，未在不同 EP 规模下实测验证 `[基于文中逻辑的推断]`（\[页码：7\]）。
- AIMD 通过瞬时拥塞信号（而非历史窗口）调节阈值，预期能在拥塞与稳定之间取得比固定阈值更好的平衡 `[作者明确陈述]`（\[页码：6\]）。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果问题：ReaLB 相对 Baseline/EPLB/FP4-All 的端到端速度与精度损失如何？→ 对应 Table 1/2 `[实验支持]`（\[页码：8\]）。
- 机制/必要性问题：预测式方法是否确实因动态性而失效？模态感知与流水线重叠是否各自必要？→ 对应 5.3 节延迟分解、ReaLB-seq/ReaLB-m1/m2 消融 `[实验支持]`（\[页码：9\]）。
- 鲁棒性问题：方法是否跨模型（Kimi-VL、Qwen3-VL）泛化？→ 对应两模型对比结果 `[实验支持]`（\[页码：8-9\]）。
- 适用范围问题：方法是否仅在计算受限（大 batch）场景有效？→ 对应 LB Gate 部分，但缺乏量化消融 `[作者明确陈述]`（\[页码：7-8\]，量化对比\"文中未说明\"）。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 硬件：8×NVIDIA RTX 5090，DP+EP 混合并行 `[作者明确陈述]`（\[页码：7\]）。
- 框架：vLLM v0.13.0，混合精度来自 LLM Compressor，NVFP4 GEMM kernel 来自 FlashInfer `[作者明确陈述]`（\[页码：7\]）。
- 模型：Kimi-VL-A3B-Instruct（64 路由专家）、Qwen3-VL-30B-A3B-Instruct（128 路由专家），均做 NVFP4 PTQ `[作者明确陈述]`（\[页码：7\]）。
- 任务/benchmark：MMMU、MathVista、DynaMath `[作者明确陈述]`（\[页码：7-8\]）。
- 部署：Prefill-Decode colocated，continuous batching `[作者明确陈述]`（\[页码：7\]）。
- 超参数：容量因子 \#mi(\"C\=1\")，\#mi(\"M\_d\") 初始 0.9，\#mi(\"\\Gamma\=2048\") `[作者明确陈述]`（\[页码：7\]）。
- 对比方法：Baseline（W16A16）、FP4-All（全 W4A4）、EPLB、Async\_EPLB、ReaLB、ReaLB-seq、ReaLB-m1/m2 `[作者明确陈述]`（\[页码：7-8\]）。
- 重复次数/统计方式：文中未说明（Panel2/5 给出均值±标准差，但未说明重复运行次数或统计口径）。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Speedup（端到端速度提升），无符号标注，比值形式，越大越好。

  - #strong[定义与公式]：作者文字定义为\"相对 BF16 baseline 的端到端吞吐速度提升\"（\[页码：8\]）；#strong[来源层级：无可核验公式]——正文未给出显式计算式或聚合口径。
  - #strong[实验用途]：回答效果问题，比较 ReaLB 与 Baseline/EPLB/FP4-All。
  - #strong[读数与边界]：区间 1.10×–1.32×（\[页码：1\]）；不能证明该提升在不同 EP 规模、硬件平台下同样成立（仅 8×RTX5090 单一配置）。

- #strong[指标与方向]：ΔAcc（精度下降），单位百分点，越小越好。

  - #strong[定义与公式]：作者文字定义\"相对 BF16 baseline 的准确率下降\"（\[页码：8\]）；#strong[来源层级：无可核验公式]——未给出分子分母或跨 benchmark 聚合方式。
  - #strong[实验用途]：检验模态感知降精度是否比全模型降精度（FP4-All）更保守。
  - #strong[读数与边界]：如 Kimi-VL/DynaMath，FP4-All -8.19%，ReaLB -3.10% `[实验支持]`（\[页码：8\]）；Qwen-VL 上 ReaLB 平均 \<0.6%（\[页码：9\]）；\"平均精度损失\<1%\"的跨 benchmark 聚合方法文中未说明。

- #strong[指标与方向]：吞吐（tokens/sec），越大越好。

  - #strong[定义与公式]：作者明示测量方法——CUDA 事件细粒度计时+vLLM benchmark 测端到端吞吐，单位为\"处理 token 数/秒（输入+输出）\"（\[页码：8\]），属\"作者文字定义\"的测量方法而非公式。
  - #strong[实验用途]：作为 Speedup 的底层测量依据。
  - #strong[读数与边界]：具体吞吐绝对数值未在本 OCR 文字中给出，仅有换算后的 Speedup 倍数。

- #strong[指标与方向]：MoE 层延迟，单位 ms，越小越好。

  - #strong[定义与公式]：作者说明其用途为\"捕捉逐层执行效率\"（\[页码：8\]），基于 CUDA 事件测量，无显式公式；#strong[来源层级：无可核验公式]。
  - #strong[实验用途]：检验 EPLB 是否因预测失配\"加剧\"而非缓解不均衡。
  - #strong[读数与边界]：Kimi-VL 上 ReaLB 从 1.51ms→1.36ms，EPLB 反而从 1.51ms→2.15ms `[实验支持]`（\[页码：9\]）；Qwen-VL 上 1.48ms→1.39ms（ReaLB）、→1.99ms（EPLB），为图像补充数值 `[图像直接可见]`（\[页码：9\]）。

- #strong[指标与方向]：\#mi(\"IB\_d\")（设备级负载不均衡度），无量纲比值，越接近 1 越均衡。

  - #strong[定义与公式]：\#mi(\"IB\_d \= Load\_d/Ideal\")，#strong[来源层级：原文公式]（\[页码：6\]）。
  - #strong[实验用途]：作为热点识别的判定输入，也是图 6/7 类附录证据的纵轴定义。
  - #strong[读数与边界]：附录图显示跨 10 个 MoE 层普遍在 1.0–2.0 波动、间歇达 2.5–4.0 `[图像直接可见]`（\[页码：16\]）；仅是聚合比值，不揭示具体是哪个 rank/专家持续热点。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#align(center)[#table(
  columns: 4,
  align: (col, row) => (auto,auto,auto,auto,).at(col),
  inset: 6pt,
  [比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],
  [EPLB],
  [历史窗口预测滞后于路由动态性；再平衡带来通信/显存开销 `[作者明确陈述]`（\[页码：4\]）],
  [瞬时 \#mi(\"IB\_d\") 判定 + 原地降精度（4.2 节）],
  [Table 1/2、5.3 节延迟分解直接验证（EPLB speedup 多次\<1.00，MoE 延迟升至 2.15ms）`[实验支持]`（\[页码：8-9\]）；未验证不同 EP 规模下 EPLB 通信/显存开销的量化对比],
  [FP4-All],
  [均匀低精度对多模态负载过于激进，精度损失显著 `[作者明确陈述]`（\[页码：8\]）],
  [模态感知选择性降精度（4.2 节）],
  [Table 1 直接对比 ΔAcc/Speedup `[实验支持]`（\[页码：8\]）；缺少\"仅对文本主导 rank 降精度\"的反向消融],
  [FasterMoE、LPLB、通信侧重叠方法],
  [分别为显存/通信开销、高频调度开销、无法解决计算不均衡 `[作者明确陈述]`（\[页码：1，3\]）],
  [无专家复制、开销感知设计、借用通信窗口],
  [论文未将三者纳入实测对比表，无法从当前 OCR 内容确认量化差距],
)
]

#strong[主张与证据]

#align(center)[#table(
  columns: 3,
  align: (col, row) => (auto,auto,auto,).at(col),
  inset: 6pt,
  [主张], [直接证据（实验/表图）], [证据强度与边界],
  [C1：端到端 1.10×–1.32× 加速、精度损失\<1%],
  [Table 1 逐 benchmark 数值 `[实验支持]`（\[页码：8\]）],
  [覆盖较完整，但\"\<1%\"的跨 benchmark 平均口径文中未说明],
  [C3：EPLB 无法适应推理路由动态性],
  [Figure 2c 预测/观测分离、5.3 节 MoE 延迟对比 `[实验支持]`（\[页码：4，9\]）],
  [缺少\"预测命中率\"量化指标，仅有定性+间接速度证据],
  [C4：模态感知优于均匀降精度],
  [Table 1 ReaLB vs FP4-All 的 ΔAcc/Speedup `[实验支持]`（\[页码：8\]）],
  [缺少反向消融，无法完全分离\"模态选择\"与\"降精度比例\"各自贡献],
  [C5：流水线重叠隐藏开销],
  [ReaLB vs ReaLB-seq 对比（\[页码：9\]，及附录 Appendix I 跨 benchmark 复现）`[实验支持]`],
  [缺少 S+T 绝对开销时间的直接测量],
  [C9：仅计算受限场景有效],
  [LB Gate 定性说明+Γ\=2048（\[页码：7-8\]）],
  [Gate 开关的量化消融数字文中未说明],
)
]

- 消融显示 AIMD 自适应控制比固定阈值（ReaLB-m1/m2）更稳定 `[实验支持]`（\[页码：9\]），但 \#mi(\"M\_d\") 演化的详细文字分析在 Appendix H 未被本 OCR 完整收录。
- Rank 级别最高提速 1.29×（Kimi-VL）、附录图片显示 Qwen-VL 某 rank 达 1.62×（该数值未被正文引用）`[实验支持]`（\[页码：9\]）。
- 所有实验均在单一 8×RTX5090 集群上完成，未见跨 EP 规模或跨硬件平台验证 `[基于文中逻辑的推断]`（\[页码：7\]）。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_703_533_1009_665.jpg", width: 100%)
    #emph[Figure 4: ReaLB is enabled only in the compute-bound regime with large batch sizes.] \
来源：OCR 第 7 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第6节：LB Gate仅在计算受限、聚合负载超过Γ=2048时启用]
    - #strong[图组结论]：token数增大后GEMM分段占比迅速上升，虚线右侧成为主导分段

- #strong[论证关系]：为\"仅计算受限区间启用LB\"提供定性支持，呼应主张地图C9

- #strong[适用范围]：虚线与Γ\=2048精确对齐无法从对数轴判读，无开关前后量化加速数字
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0009-c591154124ab.png", width: 100%)
    #emph[Figure 5: Fine-grained MoE latency analysis. Top row (a–c): Kimi-VL; bottom row (d–f): Qwen-VL.] \
来源：OCR 第 9 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：C3（EPLB无法适应动态路由）与C5（流水线重叠隐藏开销）]
    - #strong[图组结论]：Kimi-VL上ReaLB总时长-22.8%、EPLB+3.9%，MoE延迟ReaLB 1.51→1.36ms、EPLB→2.15ms，Qwen-VL趋势一致

- #strong[论证关系]：直接验证EPLB历史预测适得其反的机制与流水线重叠的速度收益

- #strong[适用范围]：仅覆盖DynaMath单一benchmark，跨benchmark泛化性由附录图补充验证
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0016-22400dd38a22.png", width: 100%)
    #emph[Figure 6: Dynamics of device-level load imbalance across MoE layers 12-21.] \
来源：OCR 第 16 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：观察2（不可预测高动态性）从单层扩展到多层的验证边界]
    - #strong[图组结论]：跨10个MoE层（Layer12-21）\#mi(\"IB\_d\")普遍在1.0–2.0波动，间歇达2.5–4.0

- #strong[论证关系]：支撑逐层瞬时判定设计的必要性，将动态性观察从单层扩展到多层

- #strong[适用范围]：具体模型/数据集未重复说明，无法从当前OCR内容确认确切实验设置
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0017-b33643129340.png", width: 100%)
    #emph[Figure 7: Overloaded devices and experts across iterations for layer 12-19, with token proportions for different modalities.] \
来源：OCR 第 17 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：视觉token占比31%–93%的模态负载倾斜跨层泛化边界]
    - #strong[图组结论]：8层（Layer12-19）均现超载rank与视觉占比60%–96%的热点专家，个别专家仅约26%

- #strong[论证关系]：将模态驱动负载倾斜从单层扩展到8层，佐证\#mi(\"R\_{vd}\")阈值判定的必要性

- #strong[适用范围]：具体模型/数据集来源未标注，无法从当前OCR内容确认
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0018-846ea9c407af.png", width: 100%)
    #emph[Figure 8: Token composition in continuous batching.] \
来源：OCR 第 18 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：colocated部署近似prefill-only场景的方法学假设]
    - #strong[图组结论]：Decode token占比全程远低于10%，视觉token占比在0.2–1.0间剧烈波动

- #strong[论证关系]：为colocated设置不被decode token污染背书，支撑观察1/观察2的动态性描述

- #strong[适用范围]：具体模型/benchmark未标注，无法从当前OCR内容确认
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0019-c7836b740448.png", width: 100%)
    #emph[Figure 10: End-to-end latency breakdown on additional benchmarks.] \
来源：OCR 第 19 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：C1/C3/C5主张从DynaMath扩展到MMMU/MathVista的泛化验证]
    - #strong[图组结论]：MMMU/MathVista上EPLB/Async\_EPLB总时长增加（+3.1%~+22.4%），ReaLB降幅均大于ReaLB-seq

- #strong[论证关系]：复现EPLB预测失效机制与流水线重叠速度收益，验证跨benchmark稳健性

- #strong[适用范围]：各分段无绝对数值，无法精确量化究竟隐藏了多少开销
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0019-fda6c41ad02d.png", width: 100%)
    #emph[Figure 9: Evolution of the control parameter under AIMD-based adaptive control on DynaMath. The red background indicates time steps where the global imbalance exceeds the congestion threshold.] \
来源：OCR 第 19 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第6节：AIMD自适应阈值控制的瞬时拥塞响应规则（τ=1.5）]
    - #strong[图组结论]：\#mi(\"M\_d\")在拥塞区间骤降、非拥塞期逐步回升，Qwen3-VL拥塞区间更宽更连续

- #strong[论证关系]：可视化AIMD规则的实际触发过程，为AIMD优于静态阈值的主张提供机制解释

- #strong[适用范围]：无静态阈值对照曲线，是否优于固定阈值仍需依赖Table 1数字
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1: Main performance comparison and trade-offs under different load balancing strategies.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：C1（1.10×–1.32×加速、精度损失\<1%）与C4（模态感知优于均匀降精度）]
  - #strong[图组结论]：ReaLB相对Baseline加速1.10×–1.32×，较FP4-All精度损失显著更低（如DynaMath -3.10% vs -8.19%）

- #strong[论证关系]：量化对比ReaLB/EPLB/FP4-All的速度-精度权衡，直接支撑核心效果主张

- #strong[适用范围]：跨benchmark平均口径文中未说明，仅8×RTX5090单一硬件配置
  #v(5pt)
  #image("table-groups/page-0008-df74140a4bdf.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2: Accuracy stability of ReaLB across additional multimodal benchmarks ( ).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：ReaLB平均精度损失\<1%在多个多模态基准上的稳定性]
  - #strong[图组结论]：Qwen-VL上ReaLB平均精度损失\<0.6%，跨基准保持稳定低损失

- #strong[论证关系]：补充验证模态感知降精度策略的精度稳健性，支撑C4主张

- #strong[适用范围]：具体聚合口径与重复次数文中未说明
  #v(5pt)
  #image("table-groups/page-0008-e992898713af.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 4: Speedup of ReaLB in the prefill-only setting.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：LB Gate仅在计算受限、大batch场景生效的适用条件]
  - #strong[图组结论]：报告prefill-only部署下ReaLB相对Baseline的加速比，具体数值正文未展开引用

- #strong[论证关系]：为\"计算受限场景\"适用条件提供prefill-only模式下的补充验证

- #strong[适用范围]：未纳入正文Table 1/2主对比，跨EP规模下是否成立未见验证
  #v(5pt)
  #image("table-groups/page-0018-7dc1d49b56f2.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：EP 下 MMoE 推理层延迟由最慢 rank 决定，该 rank 身份在迭代间快速变化、难以预测（\[页码：3-4\]）
  - 旧方法限制：历史预测式方法（EPLB/LPLB）跟不上动态性；专家迁移/复制类方法引入通信与内存开销（\[页码：1，3，4\]）
  - 核心洞见/假设：过载 rank 往往是视觉专家聚集的 rank，视觉 token 冗余度更高、对精度下降更不敏感（\[页码：2，3\]）
    - 方法模块：模态感知精度分配 \#mi(\"R\_{vd}\")/\#mi(\"M\_d\")（\[页码：6\]）
      - 可验证预测：只对视觉主导+过载 rank 降精度，可在精度损失可控前提下降低其延迟
        - 指标与实验：ΔAcc、Speedup、MoE 层延迟（Table 1，\[页码：8\]）
          - 图表证据：Figure 5 延迟分解、附录跨 benchmark 图（\[页码：9，19\]）
            - 结论与适用边界：Kimi-VL/Qwen-VL 上均验证有效 `[实验支持]`（\[页码：8-9\]），但未覆盖\"模态隔离\"架构，未做反向消融（文中未说明）
    - 方法模块：瞬时热点识别 \#mi(\"IB\_d\")（\[页码：6\]）
      - 可验证预测：瞬时判定应比历史窗口更快命中真实热点
        - 指标与实验：Figure 2c 预测/观测对比、5.3 节 MoE 延迟（\[页码：4，9\]）
          - 图表证据：Figure 2c、附录 Figure 6（\[页码：4，16\]）
            - 结论与适用边界：定性支持充分，但\"命中率\"量化指标未被当前证据直接验证（文中未说明）
    - 方法模块：开销隐藏流水线（\[页码：7\]）
      - 可验证预测：LB 开销可被通信窗口\"淹没\"，不随 EP 规模扩展
        - 指标与实验：ReaLB vs ReaLB-seq 速度差（\[页码：9\]）
          - 图表证据：Figure 5 realb\_overhead/overlapping 分段（\[页码：9，19\]）
            - 结论与适用边界：速度收益已验证 `[实验支持]`；跨 EP 规模的可扩展性未被当前证据直接验证（仅单一硬件配置）
    - 方法模块：AIMD 阈值控制（\[页码：6\]）
      - 可验证预测：自适应阈值应比固定阈值更稳定
        - 指标与实验：ReaLB vs ReaLB-m1/m2（Table 1，\[页码：9\]）
          - 图表证据：附录 AIMD 轨迹图（\[页码：19\]）
            - 结论与适用边界：稳定性优势已验证 `[实验支持]`；\#mi(\"M\_d\") 详细收敛行为在 Appendix H 未被当前证据直接验证
    - 方法模块：LB Gate（\[页码：7-8\]）
      - 可验证预测：仅在计算受限（大 batch）场景启用才有收益
        - 指标与实验：Figure 4 定性趋势（\[页码：7\]）
          - 图表证据：Figure 4 GEMM 占比堆叠图
            - 结论与适用边界：定性支持存在；开关 Gate 前后的量化效果未被当前证据直接验证（文中未说明）

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：识别并量化 MMoE 推理中模态驱动的动态负载不均衡 `[作者明确陈述]`；提出模态感知、精度自适应的 ReaLB 调度机制配合 AIMD 控制；设计开销感知流水线编排隐藏转换延迟；在 vLLM 中实现并在两个 MMoE 模型上验证性能提升（\[页码：2\]）。

#strong[证据充分的结论]：EPLB 在动态路由下确实表现为速度不稳定甚至负收益 `[实验支持]`（\[页码：8-9\]）；ReaLB 相对 FP4-All 精度损失显著更低、吞吐相近 `[实验支持]`（\[页码：8\]）；流水线重叠对速度收益有实测贡献 `[实验支持]`（\[页码：9\]）。

#strong[尚属推断的意义]：瞬时判定\"天然\"优于历史预测的机制解释是逻辑推断而非直接量化验证（缺少命中率指标）`[基于文中逻辑的推断]`；LB 开销的可扩展性论证为理论推演，未经跨 EP 规模实测 `[基于文中逻辑的推断]`。

#strong[适用条件]：需要 GEMM 主导延迟的大 batch 计算受限场景（\#mi(\"\\Gamma\=2048\")）；需模态融合（modality-fused）架构而非模态隔离架构 `[作者明确陈述]`（\[页码：2，7\]）。

#strong[局限]：硬件规模单一（8×RTX5090）；消融未完全分离模态选择与精度切换各自贡献；关键指标（ΔAcc、Speedup）缺显式公式；命名不一致（ReaLB-mi vs ReaLB-m1/m2）未获澄清。

#strong[审稿式风险检查]：

- 贡献新意：核心创新（精度自适应替代路由/放置优化）有清晰的问题-洞见对应链，当前证据未显示明显新意风险。
- 写作/可复现性：命名不一致（ReaLB-mi/ReaLB-m1/m2）及关键指标无显式公式，存在可复现性风险 `[作者明确陈述]`（\[页码：7-8\]）。
- 效果大小：加速幅度（1.10×–1.32×）在不同模型间差异较大（Kimi-VL 高于 Qwen-VL），当前证据未充分说明该差异原因。
- 实验覆盖：单一硬件规模、缺少反向消融（仅对文本主导 rank 降精度）、部分基线（FasterMoE、LPLB）未纳入实测对比，是实验覆盖的真实缺口。
- 方法设计：LB Gate 阈值 \#mi(\"\\Gamma\")、AIMD 参数（\#mi(\"\\tau\=1.5\")、增减系数）均为经验设定，当前证据未显示这些超参数的敏感性分析覆盖不足以外的额外风险。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：MoE（Mixture-of-Experts，混合专家）——一种神经网络层设计，将前馈网络替换为多个\"小专家\"，每个 token 只经过其中少数专家计算。

  - #strong[第一性原理角色]：连接\"模型容量\"与\"计算量\"两个基本量——通过稀疏激活在扩大参数规模的同时控制单 token 计算成本。
  - #strong[本文位置]：整个负载不均衡问题的根源结构（\[页码：1\]）。

- #strong[术语]：EP（Expert Parallelism，专家并行）——把不同专家分布到不同 GPU 上运行的并行策略。

  - #strong[第一性原理角色]：受\"跨设备通信带宽\"约束；决定了负载不均衡如何转化为跨设备执行时间差异。
  - #strong[本文位置]：负载均衡问题发生的物理载体（\[页码：1\]）。

- #strong[术语]：\#mi(\"IB\_d\")（设备级负载不均衡度）——某设备负载与平均负载之比。

  - #strong[第一性原理角色]：连接\"瞬时负载状态\"与\"是否过载\"这一判定动作的基本量。
  - #strong[本文位置]：热点识别模块的核心输入（\[页码：6\]）。

- #strong[术语]：\#mi(\"R\_{vd}\")（视觉 token 占比）——某设备上视觉 token 数占该设备总 token 数的比例。

  - #strong[第一性原理角色]：连接\"输入模态构成\"与\"是否可安全降精度\"的判据。
  - #strong[本文位置]：模态感知精度分配的判定变量（\[页码：6\]）。

- #strong[术语]：FP4/NVFP4（4-bit 浮点低精度计算）——用更少比特表示数字以加速矩阵乘法，可能损失精度。

  - #strong[第一性原理角色]：受\"数值表示精度 vs 计算吞吐\"这一物理/硬件约束的权衡。
  - #strong[本文位置]：ReaLB 对视觉主导过载 rank 的执行方式（\[页码：1\]）。

- #strong[术语]：AIMD（加性增乘性减）——网络拥塞控制思想：通畅时缓慢增加、拥塞时大幅降低。

  - #strong[第一性原理角色]：连接\"瞬时拥塞信号\"与\"控制变量调整幅度\"的反馈机制。
  - #strong[本文位置]：\#mi(\"M\_d\") 阈值的自适应更新规则（\[页码：6\]）。

- #strong[术语]：dispatch（all-to-all 通信阶段）——EP 下各设备把 token 发送到对应专家所在设备的通信过程。

  - #strong[第一性原理角色]：受设备间通信带宽/延迟约束；是本文用于\"隐藏\"精度转换开销的时间窗口。
  - #strong[本文位置]：开销隐藏流水线编排的关键位置（\[页码：7\]）。

- #strong[术语]：LB Gate（负载均衡开关，全局阈值 \#mi(\"\\Gamma\")）——仅在聚合负载超过阈值时启用均衡机制。

  - #strong[第一性原理角色]：连接\"计算是否受限于 GEMM\"与\"是否值得付出 LB 开销\"的判据。
  - #strong[本文位置]：控制 ReaLB 在何种 batch 规模下生效（\[页码：7-8\]）。

=== 12.2 学习路径
<122-学习路径>
+ MoE 的基本对象是\"专家网络+路由门控\"，理解它是后续一切负载问题的起点（好比理解\"分诊制医院\"才能理解\"某科室排队\"问题）。
+ EP 的约束是\"跨设备通信带宽有限、每设备专家固定\"，理解这一物理约束才能理解为何\"最慢设备决定整层延迟\"。
+ 推理阶段路由动态性（强于训练阶段）是理解\"为什么历史预测方法失效\"的机制前提。
+ 低精度计算（FP4）的\"速度-精度权衡\"是理解 ReaLB\"降精度换速度\"这一设计选择合理性的基础。
+ AIMD 拥塞控制思想是理解 \#mi(\"M\_d\") 阈值如何在瞬时信号驱动下自动调节的最后一环，直接连接到本文的可观测指标（Speedup、ΔAcc）与结论边界。
