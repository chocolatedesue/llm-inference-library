#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[ReaLB: Real-Time Load Balancing for Multimodal MoE Inference]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yingping Wang, Yi Wu, Xiangyu Wu, Junwei Cui, Weilin Cai, Zhijiang Guo, Jiayi Huang]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Mixture-of-Experts] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[多模态推理] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[专家并行] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[负载均衡] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[低精度计算]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

混合专家（MoE）架构广泛应用于现代大语言模型和多模态模型中。然而，推理效率常常受到跨不同模态高度动态且倾斜的专家负载的限制。在大批量的预填充（prefill）阶段，视觉 token 往往主导输入序列。在专家并行（EP）下，这会导致严重的负载不均衡，部分设备过载，从而降低系统整体吞吐量。我们提出了 ReaLB，一种面向多模态 MoE（MMoE）推理的实时负载均衡方法，具有零调度开销。ReaLB 在运行时以每个 EP rank 为粒度动态调整 MoE 专家的计算精度：对于由视觉密集型专家主导的 rank，ReaLB 分配更低精度的计算，利用 FP4 Tensor Core 提升执行效率。ReaLB 不需要冗余专家，也不需要额外的显存分配，而是在运行过程中即时进行逐层的专家精度转换，并将相关开销隐藏在 MoE 计算之前的 dispatch 阶段中。在代表性 MMoE 模型上的实验表明，ReaLB 实现了 1.10 倍至 1.32 倍的端到端加速，同时将平均精度损失限制在 1% 以内。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [ReaLB: Real-Time Load Balancing for Multimodal MoE Inference],
    [作者], [Yingping Wang, Yi Wu, Xiangyu Wu, Junwei Cui, Weilin Cai, Zhijiang Guo, Jiayi Huang],
    [发表场所 / 年份], [文中未说明],
    [研究领域], [系统, 机器学习],
    [关键词], [Mixture-of-Experts, 多模态推理, 专家并行, 负载均衡, 低精度计算],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（5 个）]：`Mixture-of-Experts` · `多模态推理` · `专家并行负载均衡` · `FP4低精度计算` · `vLLM推理系统`
]

ReaLB 是一种运行时、模态感知的 MoE 负载均衡方法：它不迁移专家，而是在每次前向传播前根据瞬时负载与视觉 token 占比，对\"过载且视觉专家主导\"的 EP rank 动态切换为 FP4 低精度计算，并把转换开销隐藏在 dispatch 通信中，实现 1.10×--1.32× 端到端加速、平均精度损失控制在 1% 以内 `[作者明确陈述]`。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

OCR 覆盖正文第 1--9 页及附录第 16--19 页（Appendix F、G、H、I 部分内容），涵盖引言、动机分析（3.1/3.2 节）、方法设计（4.1--4.3 节）与主实验（5.1--5.3 节）`[作者明确陈述]`。

- 附录 Appendix H 中关于 $M_d$ 演化的\"详细实证分析\"文字部分未被本 OCR 完整收录，仅有其对应图片（图片批次 5 图片 2）`[作者明确陈述]`。
- 多处关键指标（ΔAcc、Speedup）仅有文字定义、无显式计算公式，具体聚合口径未披露，标注为\"文中未说明\"`[作者明确陈述]`。
- 论文正文出现\"ReaLB-mi\"与\"ReaLB-m1/ReaLB-m2\"两套命名，OCR 未做主观统一，如实标注不一致，可能反映 OCR 抽取或版本差异 `[基于文中逻辑的推断]`。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

在专家并行（EP，把不同专家分布到不同 GPU 上运行的并行策略）部署下，每个 GPU 通常固定托管一部分专家；一次 MoE 层前向计算的层延迟由所有 rank 中最慢的一个决定，即 $T_(upright(M o E))\(x\)= max_i T_i\(x\)$，这是一种\"木桶效应\"结构 `[作者明确陈述]`。多模态 MoE（MMoE）推理阶段，尤其是大 batch 的 prefill（一次性处理输入提示词的阶段）阶段，视觉 token 数量远多于文本 token，导致路由到不同专家/设备的 token 量高度倾斜，进而产生严重的设备间负载不均衡，拖慢整体吞吐 `[作者明确陈述]`。

MoE 通过每个 token 仅激活少数专家实现参数高效扩展，广泛用于现代大模型与多模态模型；但这种稀疏激活+输入依赖路由天然导致负载不均衡，多模态场景下这一问题更严重，因此直接决定了系统实际可部署的吞吞上限 `[作者明确陈述]`。难点在于：该\"最慢 rank\"的身份在迭代间快速、不可预测地变化，使得依赖历史统计的静态或预测式方法从根本上失效 `[实验支持]`。

#strong[本文的 story]：旧路线（无论训练期均衡损失，还是推理期的专家复制/迁移调度）失效的技术原因是\"用历史统计去预测下一时刻的热点\"，而推理阶段路由的时间局部性太弱，预测必然滞后；本文的核心转折是把问题从\"路由/专家放置优化\"转化为\"计算精度自适应\"------不追预测，只在当下\"原地\"降低已确认过载且可容忍精度损失的视觉专家的计算精度，从根本上避免了预测需求 `[作者明确陈述]`。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：根问题：论文究竟要解决什么]
  #image("figure-groups/page-0002-5d3886c68ea1.png", width: 100%)
  #emph[Figure 1: Motivation for real-time load balancing.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Top-1热点Rank在迭代间剧烈跳变，最慢设备动态变化。

- #strong[论证关系]：直观展示EP掉队者由视觉专家聚集引起及路由高度动态性。

- #strong[适用范围]：不提供量化对比，不能单独证明视觉主导过载的因果关系。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

综合看，旧方法的核心技术限制可归纳为两条：#strong[\(a) 依赖历史统计预测，无法适应推理路由的强瞬时波动；(b) 通过专家复制/迁移实现均衡，天然引入通信和显存开销] `[基于文中逻辑的推断]`（推理依据：训练期方法、EPLB、LPLB、FasterMoE 的批判中反复出现\"预测滞后\"与\"额外开销\"两类问题）。

#critique-card(
  [训练期辅助损失/device-constrained routing],
  [原本解决什么：训练阶段调节门控提升专家利用率均衡；依赖前提：假设可在训练时调整梯度/路由目标。],
  ["不能直接用于推理"，未展开具体机制 `[作者明确陈述]`],
  [无对应设计模块（仅作背景问题设定）],
  [未被论文纳入实测对比，其批判停留在文字论证层面],
)

#critique-card(
  [FasterMoE 影子专家],
  [原本解决什么：复制过载专家到多设备均衡负载；依赖前提：需要额外显存与通信带宽。],
  [引入额外内存与通信开销 `[作者明确陈述]`],
  [ReaLB 原地精度切换，不复制专家],
  [未被论文纳入实测对比，其批判停留在文字论证层面],
)

#critique-card(
  [EPLB 历史式专家放置],
  [原本解决什么：用历史窗口统计周期性重放置专家；依赖前提：假设负载具有时间局部性。],
  [预测滞后、通信开销 $K dot.op B y t e s_(e x p e r t)$、显存开销线性增长 `[作者明确陈述]`],
  [瞬时状态判定 $I B_d$ 取代历史预测],
  [Table 1/5.3 节量化对比支持 `[实验支持]`],
)

#critique-card(
  [LPLB],
  [原本解决什么：用线性规划更均匀重分配 token 流量；依赖前提：需高频调用逼近实时性。],
  [高频调用的调度开销可能超过均衡收益 `[作者明确陈述]`],
  [LB Gate + 通信重叠的开销感知设计],
  [未被论文纳入实测对比，其批判停留在文字论证层面],
)

#critique-card(
  [通信侧重叠/核融合],
  [原本解决什么：降低 all-to-all 通信成本；依赖前提：假设计算已经均衡。],
  [无法解决计算本身不均衡 `[作者明确陈述]`],
  [借用既有通信窗口隐藏精度转换开销],
  [未被论文纳入实测对比，其批判停留在文字论证层面],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见/贡献]：EP 的 straggler（掉队者，即拖慢整体的最慢设备）主要由聚集了视觉专家的 rank 造成；视觉 token 相较文本 token 在前向传播中表现出更高冗余性（引用支持 \[3,38\]）`[作者明确陈述]`。由此推出的核心假设：#strong[将\"视觉主导且过载\"的 rank 切换为低精度计算，可在几乎不损失文本相关精度的前提下降低该 rank 延迟，从而消除设备间执行时间不均衡] `[作者明确陈述]`。

#strong[支撑该洞见的观察（实现所需前提）]：

- 观察1（模态驱动的负载倾斜）：某 rank 视觉 token 占比可超 90%，另一些低于 50%；专家级占比范围 31%--93% `[实验支持]`（Kimi-VL/MMMU/8GPU）。
- 观察2（不可预测的高动态性）：同一短窗口内热点专家负载/均值比可从约 2× 变到 12×，时间局部性远弱于训练阶段 `[实验支持]`。

#strong[理论支撑]：论文将均衡问题形式化为在线策略优化目标

$ max_pi med bb(E)_x #scale(x: 120%, y: 120%)[\[] max_i T_i\(x\)- max_i T_i\(pi\(x\)\)- T_(upright(L B))\(pi\,x\)#scale(x: 120%, y: 120%)[\]] $

并论证：优化\"token/专家均衡\"这类代理指标并非最小化 $ max_i T_i $ 的必要条件；推理阶段不需要为优化稳定性维持 token 均衡，只需直接最小化执行延迟 `[作者明确陈述]`。这为\"不追求专家/token 完全均衡，只直接压低设备级延迟\"的设计选择提供了理论依据。

前提可能失效的场景：若视觉 token 的冗余性假设不成立（即视觉专家对精度同样敏感），或负载倾斜并非以模态为主因，该核心假设的适用性会被削弱；论文未提供该前提的反向消融，属于证据缺口（见 4.2 节相关说明）。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

#strong[总览]：输入为当前层各设备的负载与模态构成 → 判定过载设备 → 在过载设备中筛出\"视觉主导\"者 → 对这些设备的专家在线转换为 FP4 精度并执行计算 → 转换开销与元数据收集被安排在 dispatch 通信窗口内隐藏 → 输出经均衡后的 MoE 层结果，供后续 Combine/下一层使用 `[作者明确陈述]`。

+ #strong[运行时状态与热点识别（$I B_d$, 阈值 $C$）]

  - 动机：需要不依赖历史统计、纯瞬时的\"是否过载\"判定 `[作者明确陈述]`。
  - 输入/过程/输出：输入当前层各设备 token 负载 $L o a d_d$ 与平均负载 $I d e a l$；计算 $I B_d = L o a d_d\/I d e a l$；输出热点集合 $cal(H) = { d divides I B_d > C }$，$C = 1$ 表示完全均衡 `[作者明确陈述]`。
  - 优势：仅用当前层瞬时数据，规避历史预测滞后问题 `[基于文中逻辑的推断]`。

+ #strong[模态感知精度分配（$R_(v d)$, $M_d$）]

  - 动机：区分\"视觉主导可压缩\"与\"文本主导不可压缩\"的过载设备 `[作者明确陈述]`。
  - 输入/过程/输出：输入设备上视觉/文本 token 数 $N_(v d)\,N_(t d)$；计算 $R_(v d) = N_(v d)\/\(N_(v d) + N_(t d)\)$；对 $d in cal(H)$ 且 $R_(v d) > M_d$ 的设备标记为可压缩，其专家用低精度 GEMM 执行，其余保持标准精度 `[作者明确陈述]`。
  - 优势：把降精度限定在对损失不敏感的视觉专家上 `[作者明确陈述]`。

+ #strong[AIMD 自适应阈值控制]

  - 动机：固定阈值难以兼顾响应速度与稳定性 `[作者明确陈述]`。
  - 规则：$I B_(g l o b a l) = max_d I B_d$，拥塞阈值 $tau = 1.5$；若 $I B_(g l o b a l) > tau$ 则 $M_d = 0.5 M_d$，否则 $M_d = min\(1\,M_d + 0.1\)$ `[作者明确陈述]`。
  - 优势：借鉴网络拥塞控制思想，拥塞时快速收紧、平稳期逐渐放松 `[作者明确陈述]`。

+ #strong[在线精度转换]

  - 动机：不增加显存占用的前提下支持实时精度切换 `[作者明确陈述]`。
  - 过程：每个专家仅存原始高精度权重+预计算缩放因子；调度下发新精度配置时在线量化到目标精度 `[作者明确陈述]`。

+ #strong[开销隐藏的流水线编排]

  - 动机：元数据收集 $S$ 与精度转换 $T$ 本身引入额外计算，需从关键路径移除 `[作者明确陈述]`。
  - 过程：$S$、$T$ 与 dispatch 阶段的设备间通信重叠执行 `[作者明确陈述]`。
  - 优势：LB 开销只涉及本地转换和轻量元数据收集，不随 EP 规模扩展，而 dispatch 延迟随 EP 规模增长，因此重叠后 LB 开销被通信\"淹没\" `[作者明确陈述]`。

+ #strong[LB Gate（全局 batch 阈值 $Gamma$）]

  - 动机：只有 GEMM 计算主导延迟时，设备负载不均衡才直接转化为延迟不均衡；小 batch 时启用 LB 无意义甚至有害 `[作者明确陈述]`。
  - 过程：聚合设备负载超过 $Gamma = 2048$（256×8）时启用 LB，否则退回标准执行 `[作者明确陈述]`。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法：从洞见到可执行系统]
  #image("figure-groups/page-0005-69d52366dd40.png", width: 100%)
  #emph[Figure 3: ReaLB design for efficient multimodal MoE inference. It combines modality-aware scheduling and an overlapping execution pipeline to mitigate device-level latency imbalance while minimizing runtime overhead.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：过载且视觉主导的Rank转为FP4，文本主导受保护。

- #strong[论证关系]：实例化模态感知精度分配与开销隐藏重叠流水线设计。

- #strong[适用范围]：示意图未包含真实加速与精度数据，不能证明效果幅度。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 瞬时状态判定（$I B_d$）只依赖当前层数据，逻辑上避免了历史统计对时间局部性的假设，因而能应对 3.2 节实证的强瞬时波动 `[基于文中逻辑的推断]`。
- 将降精度限定于\"视觉主导+过载\"设备，理论上兼顾速度与精度，前提是视觉 token 冗余性假设成立（背景知识支持，非本文直接实验验证的前提本身）`[背景知识]`。
- 流水线重叠使 LB 开销不随 EP 规模线性增长，理论上具有可扩展性，但该扩展性论证仅为理论推演，未在不同 EP 规模下实测验证 `[基于文中逻辑的推断]`。
- AIMD 通过瞬时拥塞信号（而非历史窗口）调节阈值，预期能在拥塞与稳定之间取得比固定阈值更好的平衡 `[作者明确陈述]`。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果问题：ReaLB 相对 Baseline/EPLB/FP4-All 的端到端速度与精度损失如何？→ 对应 Table 1/2 `[实验支持]`。
- 机制/必要性问题：预测式方法是否确实因动态性而失效？模态感知与流水线重叠是否各自必要？→ 对应 5.3 节延迟分解、ReaLB-seq/ReaLB-m1/m2 消融 `[实验支持]`。
- 鲁棒性问题：方法是否跨模型（Kimi-VL、Qwen3-VL）泛化？→ 对应两模型对比结果 `[实验支持]`。
- 适用范围问题：方法是否仅在计算受限（大 batch）场景有效？→ 对应 LB Gate 部分，但缺乏量化消融 `[作者明确陈述]`。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 硬件：8×NVIDIA RTX 5090，DP+EP 混合并行 `[作者明确陈述]`。
- 框架：vLLM v0.13.0，混合精度来自 LLM Compressor，NVFP4 GEMM kernel 来自 FlashInfer `[作者明确陈述]`。
- 模型：Kimi-VL-A3B-Instruct（64 路由专家）、Qwen3-VL-30B-A3B-Instruct（128 路由专家），均做 NVFP4 PTQ `[作者明确陈述]`。
- 任务/benchmark：MMMU、MathVista、DynaMath `[作者明确陈述]`。
- 部署：Prefill-Decode colocated，continuous batching `[作者明确陈述]`。
- 超参数：容量因子 $C = 1$，$M_d$ 初始 0.9，$Gamma = 2048$ `[作者明确陈述]`。
- 对比方法：Baseline（W16A16）、FP4-All（全 W4A4）、EPLB、Async\_EPLB、ReaLB、ReaLB-seq、ReaLB-m1/m2 `[作者明确陈述]`。
- 重复次数/统计方式：文中未说明（Panel2/5 给出均值±标准差，但未说明重复运行次数或统计口径）。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Speedup（端到端速度提升），无符号标注，比值形式，越大越好。

  - #strong[定义与公式]：作者文字定义为\"相对 BF16 baseline 的端到端吞吐速度提升\"；#strong[来源层级：无可核验公式]------正文未给出显式计算式或聚合口径。
  - #strong[实验用途]：回答效果问题，比较 ReaLB 与 Baseline/EPLB/FP4-All。
  - #strong[读数与边界]：区间 1.10×--1.32×；不能证明该提升在不同 EP 规模、硬件平台下同样成立（仅 8×RTX5090 单一配置）。

- #strong[指标与方向]：ΔAcc（精度下降），单位百分点，越小越好。

  - #strong[定义与公式]：作者文字定义\"相对 BF16 baseline 的准确率下降\"；#strong[来源层级：无可核验公式]------未给出分子分母或跨 benchmark 聚合方式。
  - #strong[实验用途]：检验模态感知降精度是否比全模型降精度（FP4-All）更保守。
  - #strong[读数与边界]：如 Kimi-VL/DynaMath，FP4-All -8.19%，ReaLB -3.10% `[实验支持]`；Qwen-VL 上 ReaLB 平均 \<0.6%；\"平均精度损失\<1%\"的跨 benchmark 聚合方法文中未说明。

- #strong[指标与方向]：吞吐（tokens/sec），越大越好。

  - #strong[定义与公式]：作者明示测量方法------CUDA 事件细粒度计时+vLLM benchmark 测端到端吞吐，单位为\"处理 token 数/秒（输入+输出）\"，属\"作者文字定义\"的测量方法而非公式。
  - #strong[实验用途]：作为 Speedup 的底层测量依据。
  - #strong[读数与边界]：具体吞吐绝对数值未在本 OCR 文字中给出，仅有换算后的 Speedup 倍数。

- #strong[指标与方向]：MoE 层延迟，单位 ms，越小越好。

  - #strong[定义与公式]：作者说明其用途为\"捕捉逐层执行效率\"，基于 CUDA 事件测量，无显式公式；#strong[来源层级：无可核验公式]。
  - #strong[实验用途]：检验 EPLB 是否因预测失配\"加剧\"而非缓解不均衡。
  - #strong[读数与边界]：Kimi-VL 上 ReaLB 从 1.51ms→1.36ms，EPLB 反而从 1.51ms→2.15ms `[实验支持]`；Qwen-VL 上 1.48ms→1.39ms（ReaLB）、→1.99ms（EPLB），为图像补充数值 `[图像直接可见]`。

- #strong[指标与方向]：$I B_d$（设备级负载不均衡度），无量纲比值，越接近 1 越均衡。

  - #strong[定义与公式]：$I B_d = L o a d_d\/I d e a l$，#strong[来源层级：原文公式]。
  - #strong[实验用途]：作为热点识别的判定输入，也是图 6/7 类附录证据的纵轴定义。
  - #strong[读数与边界]：附录图显示跨 10 个 MoE 层普遍在 1.0--2.0 波动、间歇达 2.5--4.0 `[图像直接可见]`；仅是聚合比值，不揭示具体是哪个 rank/专家持续热点。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [EPLB], [历史窗口预测滞后于路由动态性；再平衡带来通信/显存开销 `[作者明确陈述]`], [瞬时 $I B_d$ 判定 + 原地降精度（4.2 节）], [Table 1/2、5.3 节延迟分解直接验证（EPLB speedup 多次\<1.00，MoE 延迟升至 2.15ms）`[实验支持]`；未验证不同 EP 规模下 EPLB 通信/显存开销的量化对比],
    [FP4-All], [均匀低精度对多模态负载过于激进，精度损失显著 `[作者明确陈述]`], [模态感知选择性降精度（4.2 节）], [Table 1 直接对比 ΔAcc/Speedup `[实验支持]`；缺少\"仅对文本主导 rank 降精度\"的反向消融],
    [FasterMoE、LPLB、通信侧重叠方法], [分别为显存/通信开销、高频调度开销、无法解决计算不均衡 `[作者明确陈述]`], [无专家复制、开销感知设计、借用通信窗口], [论文未将三者纳入实测对比表，无法从当前 OCR 内容确认量化差距],
  )]
  , kind: table
  )

#strong[主张与证据]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [C1：端到端 1.10×--1.32× 加速、精度损失\<1%], [Table 1 逐 benchmark 数值 `[实验支持]`], [覆盖较完整，但\"\<1%\"的跨 benchmark 平均口径文中未说明],
    [C3：EPLB 无法适应推理路由动态性], [Figure 2c 预测/观测分离、5.3 节 MoE 延迟对比 `[实验支持]`], [缺少\"预测命中率\"量化指标，仅有定性+间接速度证据],
    [C4：模态感知优于均匀降精度], [Table 1 ReaLB vs FP4-All 的 ΔAcc/Speedup `[实验支持]`], [缺少反向消融，无法完全分离\"模态选择\"与\"降精度比例\"各自贡献],
    [C5：流水线重叠隐藏开销], [ReaLB vs ReaLB-seq 对比，及附录 Appendix I 跨 benchmark 复现 `[实验支持]`], [缺少 S+T 绝对开销时间的直接测量],
    [C9：仅计算受限场景有效], [LB Gate 定性说明+Γ=2048], [Gate 开关的量化消融数字文中未说明],
  )]
  , kind: table
  )

- 消融显示 AIMD 自适应控制比固定阈值（ReaLB-m1/m2）更稳定 `[实验支持]`，但 $M_d$ 演化的详细文字分析在 Appendix H 未被本 OCR 完整收录。
- Rank 级别最高提速 1.29×（Kimi-VL）、附录图片显示 Qwen-VL 某 rank 达 1.62×（该数值未被正文引用）`[实验支持]`。
- 所有实验均在单一 8×RTX5090 集群上完成，未见跨 EP 规模或跨硬件平台验证 `[基于文中逻辑的推断]`。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0004-47a6094f6ef1.png", width: 100%)
    #emph[Figure 2: High dynamics in MMoE routing limit the effectiveness of prediction-based methods. (a) Load imbalance across devices, experts, and modalities. (b) Temporal variation in imbalance severity across iterations. (c) Rapid shifts of the top-1 hot device and expert, highlighting the mismatch between historical observations and current load.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标：证据是否支撑主张]
    - #strong[图组结论]：负载动态剧烈，预测线与实际线严重偏离。

- #strong[论证关系]：直观证明EPLB历史预测失配，支撑动态路由限制批判。

- #strong[适用范围]：仅覆盖单模型单任务，未量化预测命中率与通信开销。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_703_533_1009_665.jpg", width: 100%)
    #emph[Figure 4: ReaLB is enabled only in the compute-bound regime with large batch sizes.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法：从洞见到可执行系统]
    - #strong[图组结论]：随token增加GEMM成为主要耗时瓶颈。

- #strong[论证关系]：为LB Gate仅在大batch计算受限场景启用提供依据。

- #strong[适用范围]：缺乏开关LB Gate的前后量化对比数据。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0009-c591154124ab.png", width: 100%)
    #emph[Figure 5: Fine-grained MoE latency analysis. Top row (a--c): Kimi-VL; bottom row (d--f): Qwen-VL.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标：证据是否支撑主张]
    - #strong[图组结论]：ReaLB显著降低MoE延迟，EPLB反而增加延迟。

- #strong[论证关系]：验证流水线重叠收益及EPLB预测失配适得其反机制。

- #strong[适用范围]：单数据集测得，跨数据集泛化见附录实验。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0016-22400dd38a22.png", width: 100%)
    #emph[Figure 6: Dynamics of device-level load imbalance across MoE layers 12-21.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 5 节：核心洞见与假设]
    - #strong[图组结论]：设备级负载不均衡度在跨层跨迭代中持续剧烈波动。

- #strong[论证关系]：证明多层路由动态性，支撑逐层瞬时判定设计必要性。

- #strong[适用范围]：展示聚合比值，未揭示具体热点专家分布。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0017-b33643129340.png", width: 100%)
    #emph[Figure 7: Overloaded devices and experts across iterations for layer 12-19, with token proportions for different modalities.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 5 节：核心洞见与假设]
    - #strong[图组结论]：过载设备和专家普遍呈现显著的视觉token主导特征。

- #strong[论证关系]：实测证明过载与视觉主导强相关，支撑模态感知假设。

- #strong[适用范围]：受限于特定测试窗口，具体配置需正文补充说明。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0018-846ea9c407af.png", width: 100%)
    #emph[Figure 8: Token composition in continuous batching.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标：证据是否支撑主张]
    - #strong[图组结论]：连续批处理中prefill视觉token占绝对主导地位。

- #strong[论证关系]：支持将部署环境简化为近似prefill场景的方法假设。

- #strong[适用范围]：具体模型与任务未在图题明确标注。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0019-c7836b740448.png", width: 100%)
    #emph[Figure 10: End-to-end latency breakdown on additional benchmarks.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标：证据是否支撑主张]
    - #strong[图组结论]：ReaLB在多数据集上均实现端到端加速，EPLB普遍拖慢。

- #strong[论证关系]：证明主张C1与C5具有跨benchmark与跨模型泛化性。

- #strong[适用范围]：未标注分段绝对耗时，无法定量化隐藏开销。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0019-fda6c41ad02d.png", width: 100%)
    #emph[Figure 9: Evolution of the control parameter under AIMD-based adaptive control on DynaMath. The red background indicates time steps where the global imbalance exceeds the congestion threshold.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法：从洞见到可执行系统]
    - #strong[图组结论]：控制参数在拥塞时快速降低、非拥塞时逐步回升。

- #strong[论证关系]：可视化AIMD控制机制在瞬时拥塞信号下的动态响应。

- #strong[适用范围]：未包含静态阈值对照曲线，优越性需结合表格数据。
  ],
)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：EP 下 MMoE 推理层延迟由最慢 rank 决定，该 rank 身份在迭代间快速变化、难以预测
  - 旧方法限制：历史预测式方法（EPLB/LPLB）跟不上动态性；专家迁移/复制类方法引入通信与内存开销
  - 核心洞见/假设：过载 rank 往往是视觉专家聚集的 rank，视觉 token 冗余度更高、对精度下降更不敏感
    - 方法模块：模态感知精度分配 $R_(v d)$/$M_d$
      - 可验证预测：只对视觉主导+过载 rank 降精度，可在精度损失可控前提下降低其延迟
        - 指标与实验：ΔAcc、Speedup、MoE 层延迟（Table 1）
          - 图表证据：Figure 5 延迟分解、附录跨 benchmark 图
            - 结论与适用边界：Kimi-VL/Qwen-VL 上均验证有效 `[实验支持]`，但未覆盖\"模态隔离\"架构，未做反向消融（文中未说明）
    - 方法模块：瞬时热点识别 $I B_d$
      - 可验证预测：瞬时判定应比历史窗口更快命中真实热点
        - 指标与实验：Figure 2c 预测/观测对比、5.3 节 MoE 延迟
          - 图表证据：Figure 2c、附录 Figure 6
            - 结论与适用边界：定性支持充分，但\"命中率\"量化指标未被当前证据直接验证（文中未说明）
    - 方法模块：开销隐藏流水线
      - 可验证预测：LB 开销可被通信窗口\"淹没\"，不随 EP 规模扩展
        - 指标与实验：ReaLB vs ReaLB-seq 速度差
          - 图表证据：Figure 5 realb\_overhead/overlapping 分段
            - 结论与适用边界：速度收益已验证 `[实验支持]`；跨 EP 规模的可扩展性未被当前证据直接验证（仅单一硬件配置）
    - 方法模块：AIMD 阈值控制
      - 可验证预测：自适应阈值应比固定阈值更稳定
        - 指标与实验：ReaLB vs ReaLB-m1/m2（Table 1）
          - 图表证据：附录 AIMD 轨迹图
            - 结论与适用边界：稳定性优势已验证 `[实验支持]`；$M_d$ 详细收敛行为在 Appendix H 未被当前证据直接验证
    - 方法模块：LB Gate
      - 可验证预测：仅在计算受限（大 batch）场景启用才有收益
        - 指标与实验：Figure 4 定性趋势
          - 图表证据：Figure 4 GEMM 占比堆叠图
            - 结论与适用边界：定性支持存在；开关 Gate 前后的量化效果未被当前证据直接验证（文中未说明）

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：识别并量化 MMoE 推理中模态驱动的动态负载不均衡 `[作者明确陈述]`；提出模态感知、精度自适应的 ReaLB 调度机制配合 AIMD 控制；设计开销感知流水线编排隐藏转换延迟；在 vLLM 中实现并在两个 MMoE 模型上验证性能提升。

#strong[证据充分的结论]：EPLB 在动态路由下确实表现为速度不稳定甚至负收益 `[实验支持]`；ReaLB 相对 FP4-All 精度损失显著更低、吞吐相近 `[实验支持]`；流水线重叠对速度收益有实测贡献 `[实验支持]`。

#strong[尚属推断的意义]：瞬时判定\"天然\"优于历史预测的机制解释是逻辑推断而非直接量化验证（缺少命中率指标）`[基于文中逻辑的推断]`；LB 开销的可扩展性论证为理论推演，未经跨 EP 规模实测 `[基于文中逻辑的推断]`。

#strong[适用条件]：需要 GEMM 主导延迟的大 batch 计算受限场景（$Gamma = 2048$）；需模态融合（modality-fused）架构而非模态隔离架构 `[作者明确陈述]`。

#strong[局限]：硬件规模单一（8×RTX5090）；消融未完全分离模态选择与精度切换各自贡献；关键指标（ΔAcc、Speedup）缺显式公式；命名不一致（ReaLB-mi vs ReaLB-m1/m2）未获澄清。

#strong[审稿式风险检查]：

- 贡献新意：核心创新（精度自适应替代路由/放置优化）有清晰的问题-洞见对应链，当前证据未显示明显新意风险。
- 写作/可复现性：命名不一致（ReaLB-mi/ReaLB-m1/m2）及关键指标无显式公式，存在可复现性风险 `[作者明确陈述]`。
- 效果大小：加速幅度（1.10×--1.32×）在不同模型间差异较大（Kimi-VL 高于 Qwen-VL），当前证据未充分说明该差异原因。
- 实验覆盖：单一硬件规模、缺少反向消融（仅对文本主导 rank 降精度）、部分基线（FasterMoE、LPLB）未纳入实测对比，是实验覆盖的真实缺口。
- 方法设计：LB Gate 阈值 $Gamma$、AIMD 参数（$tau = 1.5$、增减系数）均为经验设定，当前证据未显示这些超参数的敏感性分析覆盖不足以外的额外风险。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：MoE（Mixture-of-Experts，混合专家）------一种神经网络层设计，将前馈网络替换为多个\"小专家\"，每个 token 只经过其中少数专家计算。

  - #strong[第一性原理角色]：连接\"模型容量\"与\"计算量\"两个基本量------通过稀疏激活在扩大参数规模的同时控制单 token 计算成本。
  - #strong[本文位置]：整个负载不均衡问题的根源结构。

- #strong[术语]：EP（Expert Parallelism，专家并行）------把不同专家分布到不同 GPU 上运行的并行策略。

  - #strong[第一性原理角色]：受\"跨设备通信带宽\"约束；决定了负载不均衡如何转化为跨设备执行时间差异。
  - #strong[本文位置]：负载均衡问题发生的物理载体。

- #strong[术语]：$I B_d$（设备级负载不均衡度）------某设备负载与平均负载之比。

  - #strong[第一性原理角色]：连接\"瞬时负载状态\"与\"是否过载\"这一判定动作的基本量。
  - #strong[本文位置]：热点识别模块的核心输入。

- #strong[术语]：$R_(v d)$（视觉 token 占比）------某设备上视觉 token 数占该设备总 token 数的比例。

  - #strong[第一性原理角色]：连接\"输入模态构成\"与\"是否可安全降精度\"的判据。
  - #strong[本文位置]：模态感知精度分配的判定变量。

- #strong[术语]：FP4/NVFP4（4-bit 浮点低精度计算）------用更少比特表示数字以加速矩阵乘法，可能损失精度。

  - #strong[第一性原理角色]：受\"数值表示精度 vs 计算吞吐\"这一物理/硬件约束的权衡。
  - #strong[本文位置]：ReaLB 对视觉主导过载 rank 的执行方式。

- #strong[术语]：AIMD（加性增乘性减）------网络拥塞控制思想：通畅时缓慢增加、拥塞时大幅降低。

  - #strong[第一性原理角色]：连接\"瞬时拥塞信号\"与\"控制变量调整幅度\"的反馈机制。
  - #strong[本文位置]：$M_d$ 阈值的自适应更新规则。

- #strong[术语]：dispatch（all-to-all 通信阶段）------EP 下各设备把 token 发送到对应专家所在设备的通信过程。

  - #strong[第一性原理角色]：受设备间通信带宽/延迟约束；是本文用于\"隐藏\"精度转换开销的时间窗口。
  - #strong[本文位置]：开销隐藏流水线编排的关键位置。

- #strong[术语]：LB Gate（负载均衡开关，全局阈值 $Gamma$）------仅在聚合负载超过阈值时启用均衡机制。

  - #strong[第一性原理角色]：连接\"计算是否受限于 GEMM\"与\"是否值得付出 LB 开销\"的判据。
  - #strong[本文位置]：控制 ReaLB 在何种 batch 规模下生效。

=== 12.2 学习路径
<122-学习路径>
+ MoE 的基本对象是\"专家网络+路由门控\"，理解它是后续一切负载问题的起点（好比理解\"分诊制医院\"才能理解\"某科室排队\"问题）。
+ EP 的约束是\"跨设备通信带宽有限、每设备专家固定\"，理解这一物理约束才能理解为何\"最慢设备决定整层延迟\"。
+ 推理阶段路由动态性（强于训练阶段）是理解\"为什么历史预测方法失效\"的机制前提。
+ 低精度计算（FP4）的\"速度-精度权衡\"是理解 ReaLB\"降精度换速度\"这一设计选择合理性的基础。
+ AIMD 拥塞控制思想是理解 $M_d$ 阈值如何在瞬时信号驱动下自动调节的最后一环，直接连接到本文的可观测指标（Speedup、ΔAcc）与结论边界。
