# OCR 第 1 页

# ReaLB: Real-Time Load Balancing for Multimodal MoE Inference

Yingping Wang, Yi Wu, Xiangyu Wu, Junwei Cui, Weilin Cai, Zhijiang Guo, Jiayi Huang

The Hong Kong University of Science and Technology (Guangzhou), China

hjy@hkust-gz.edu.cn

## Abstract

Mixture-of-Experts (MoE) architectures are widely used in modern large language models and multimodal models. However, inference efficiency is often limited by highly dynamic and skewed expert workloads across different modalities. During the prefill stage with large batch sizes, vision tokens frequently dominate the input sequences. Under expert parallelism (EP), this leads to severe load imbalance, where a subset of devices becomes overloaded, reducing overall system throughput. We propose ReaLB, a real-time load balancing method for multimodal MoE (MMoE) inference that introduces zero scheduling overhead. ReaLB dynamically adjusts the computation precision of MoE experts at runtime on a per-EP-rank basis. For ranks dominated by vision-heavy experts, ReaLB assigns lower-precision computation to improve execution efficiency by exploiting FP4 Tensor Cores. ReaLB does not require redundant experts or additional memory allocation. Instead, it performs layer-wise expert precision transformation on the fly and hides the associated overhead within the dispatch phase before MoE computation. Experiments on representative MMoE models show that ReaLB achieves  $ 1.10 \times -1.32 \times $ end-to-end speedup while limiting average accuracy degradation to within 1%.

## 1 Introduction

Mixture-of-Experts (MoE) models are widely adopted in modern generative models [9, 36]. From text generation to vision language tasks, MoE supports parameter-efficient scaling by activating only a subset of experts per token. However, sparse activation and input-dependent routing naturally lead to load imbalance across experts [34]. Under expert parallelism (EP), skewed expert selection causes significant inefficiency in both training and inference. This problem is more severe in multimodal MoE (MMoE) inference [10, 27].

Most prior work focuses on mitigating load imbalance during MoE training. At the model level, auxiliary balancing losses [34, 5] and device-constrained routing [8] regulate gating behavior to improve expert utilization. These methods, however, are not directly applicable to inference [9]. At the system level, FasterMoE [15] introduces shadow experts that replicate overloaded experts across devices, at the cost of extra memory usage and communication. EPLB-like methods [6, 37] extend similar ideas to inference, but relies on prediction-based scheduling, which adapts poorly to rapidly changing routing patterns.

Figure 1 shows the highly dynamic nature of expert selection during MMoE inference [10]. Unlike the strong temporal locality observed in training [15], expert activation frequencies in inference fluctuate significantly across iterations. This behavior makes stragglers transient and difficult to predict. As a result, an effective load balancing strategy must satisfy two stringent requirements: ① reacting to fast-changing routing dynamics in real time; ② incurring minimal additional overhead to remain effective in practical deployment.

---

# OCR 第 2 页

<div style="text-align: center;"><img src="assets/imgs/img_in_image_box_218_148_602_391.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">(a) Text-Image to text generation workflow of an MMoE model.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_618_183_1006_389.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">(b) Dynamics of expert selection across eight devices over inference iterations.</div>


<div style="text-align: center;">Figure 1: Motivation for real-time load balancing.</div>


To meet these requirements, we propose ReaLB, a lightweight, real-time load balancing strategy for large-scale MMoE inference. Our design is motivated by the observation that, compared to text tokens, vision tokens exhibit higher redundancy along the forward pass [3, 38]. We further observe that EP stragglers are often dominated by vision-heavy experts (Section 3). ReaLB dynamically balances workloads by switching such experts to lower-precision computation at runtime, reducing their execution latency while preserving accuracy for text tokens. Instead of storing pre-converted weights, ReaLB performs MoE precision switching on the fly while keeping original high-precision weights intact. The lightweight transformation cost is fully hidden through pipeline orchestration in the execution flow. As a result, ReaLB achieves device-level load balance without additional memory footprint or latency overhead.

We implement ReaLB on top of vLLM [31] and evaluate it on Kimi-VL-A3B-Instruct [10] (Kimi-VL) and Qwen3-VL-30B-A3B-Instruct [27] (Qwen3-VL), using an  $ 8\times $ RTX 5090 cluster with EP. Results show that ReaLB improves end-to-end throughput by up to  $ 1.32\times $, while maintaining accuracy comparable to BF16 baselines.

Our main contributions are summarized as follows:

- We identify and quantify real-time load imbalance in multimodal MoE inference, highlighting its modality-driven, highly dynamic, and hard-to-predict behavior.

- We propose ReaLB, a modality-aware, precision-adaptive MoE scheduling mechanism with AIMD-based control for inference-time load balancing.

- We design a overhead-aware pipeline orchestration method that overlaps online precision switching with all-to-all dispatch, hiding transformation latency from the critical path.

- We implement ReaLB in vLLM and demonstrate consistent performance gains on large multimodal MoE models with negligible accuracy degradation.

## 2 Background & Related Work

### 2.1 Multimodal MoE

Multimodal large language models (MLLMs) integrate text and vision processing within a unified architecture. Compared to dense feed-forward layers, MoE layers provide higher capacity and better scalability for multimodal workloads. Most existing MMoE architectures combine a Vision Transformer (ViT), a vision-language adapter, and an MoE-augmented LLM backbone. In this work, we focus on modality-fused MMoE designs [10, 27, 5, 33, 14], which are widely adopted in recent MLLMs. In such designs, tokens from different modalities are processed jointly by shared MoE layers, where a unified gating module routes all tokens to a common pool of experts without explicit modality separation. Recent studies explore modality-isolated experts to reduce cross-modal interference [32, 2, 19, 11], and these designs are still evolving.

---

# OCR 第 3 页

### 2.2 MoE Load Balancing Systems

Sparse activation and input-dependent routing make load imbalance inherent in distributed MoE inference under EP. In practice, imbalance arises across multiple system dimensions and directly limits throughput. We summarize two main sources of load imbalance in EP-based MoE systems.

Computation. Routing decisions in MoE are highly skewed across experts and vary across inputs and modalities. With static expert-to-GPU mapping under EP, this skew translates into uneven compute load. The problem is amplified in extremely sparse settings where each GPU hosts a single expert. During inference, especially in large-batch prefill for multimodal models, vision tokens often dominate routing, creating persistent stragglers. Most existing load balancing methods target training-time optimization [41, 17, 35], such as auxiliary routing losses [5] or capacity-based token dropping [34], and are not suitable for inference. Runtime approaches based on expert replication or replacement [15, 23, 6, 16, 20] attempt to rebalance load, but rely on prediction-based scheduling and introduce extra communication due to expert weight migration. Recent work, LPLB [7], extends EPLB and further leverages linear programming (LP) to redistribute token traffic more evenly across experts. However, when invoked at high frequency to approximate real-time load balancing, its additional scheduling overhead can outweigh the gains from improved balance, potentially leading to performance degradation.

Communication. EP requires all-to-all communication for token dispatch and result combination. Compute imbalance leads to synchronization stalls, where faster GPUs wait for straggling ranks. Prior work reduces communication cost through overlap and kernel fusion [1, 24], but these techniques assume balanced computation.

## 3 Motivation and Problem Formulation

### 3.1 High Dynamics of MMoE Routing

We study routing dynamics during MMoE inference by collecting layer-wise routing statistics from Kimi-VL, running on 8 GPUs and profiled with MMMU [40] over multiple iterations. Here, each iteration corresponds to a single model forward pass under a colocated deployment setting, where prefill and decode are not separated into distinct instances.

Routing Dynamics across Devices, experts, and Modalities. Figure 2a shows that several ranks (e.g.,  $ Rank_0 $,  $ Rank_1 $, and  $ Rank_2 $) process more tokens than others. Under EP execution, such load skew directly leads to stragglers, since MoE computation is globally synchronized across ranks. At the expert level, the imbalance is further amplified: hot experts such as  $ E_4 $ and  $ E_5 $ on  $ Rank_0 $ handle  $ 5 \sim 6 \times $ more tokens than the average expert.

This imbalance is largely driven by modality composition of the input. In typical vision language tasks, high-resolution images produce a large number of vision tokens, while text prompts remain relatively short. However, the proportion of vision tokens varies significantly across devices. For instance, more than 90% of tokens on  $ Rank_{0} $ are vision tokens, whereas on  $ Rank_{1} $ and  $ Rank_{4} $, this ratio stays below 50%. The heterogeneity is even more pronounced at the expert level. Across different ranks, the top-1 hot expert exhibits widely varying modality composition, with the fraction of vision tokens ranging from 31% to 93%. This indicates that modality-induced skew exhibits strong device-level dynamics, driven by highly variable routing behaviors at finer granularity. Overall, this highlights two key observations: ① vision tokens dominate the overall workload during multimodal inference, and their distribution is highly uneven across devices; ② stragglers are primarily determined by which ranks aggregate vision-heavy experts.

Routing Dynamics across Iterations. Figure 2b shows that load imbalance fluctuates rapidly during inference. Within a short window, the ratio between the most-loaded expert and the average expert ranges from approximately  $ 2\times $ to  $ 12\times $. At the device level, the peak load often exceeds the average by more than  $ 2\times $, and in some cases, by over  $ 3\times $. Notably, this device-level imbalance becomes more pronounced as the EP scale increases, since distributing experts across more devices increases routing skewness and amplifies the straggler effect. Unlike MoE training, which exhibits strong temporal locality [15], inference routing varies significantly across iterations. This behavior

---

# OCR 第 4 页

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_212_145_463_308.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_474_143_731_307.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_746_144_1005_306.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">(c)</div>


<div style="text-align: center;">Figure 2: High dynamics in MMoE routing limit the effectiveness of prediction-based methods. (a) Load imbalance across devices, experts, and modalities. (b) Temporal variation in imbalance severity across iterations. (c) Rapid shifts of the top-1 hot device and expert, highlighting the mismatch between historical observations and current load.</div>


makes future load distributions difficult to predict, thereby fundamentally limiting the effectiveness of static or prediction-based load-balancing strategies.

### 3.2 Limitations of Prediction-based Load Balancing

We further analyze the limitations of prediction-based load balancing for MoE inference, using EPLB [6] as a representative example.

Prediction Mismatch. EPLB uses a sliding window over past iterations to maintain a global view of expert loads and periodically rebalances experts across EP ranks. For example, with a window size of 200 and a rebalancing interval of 300 iterations, hot devices are identified from the average load in recent iterations, and overloaded experts are replicated accordingly. However, as shown in Figure 2c, such history-based predictions fail to track the highly dynamic load in MMoE inference. While  $ E_{33} $ and  $ Rank_3 $ are top-1 hot spots during the first 200 iterations, in the subsequent 300 iterations,  $ Rank_1 $ and  $ E_{11} $ become the hottest. These rapid fluctuations invalidate historical statistics, leading to delayed or ineffective rebalancing that not only fails to eliminate stragglers, but can even worsen load imbalance when outdated predictions trigger incorrect replication decisions.

System Overhead. Prediction-based load balancing introduces both communication and memory overhead. For EPLB-like methods, each rebalancing step requires redistributing experts across devices, incurring communication cost. Let K denote the number of expert replicas whose assignments differ between ExpertMap_{before} and ExpertMap_{after}. The communication cost is  $ K \cdot Bytes_{expert} $, scaling linearly with the number of relocated replicas. In large-scale EP deployments, this cost becomes substantial, especially when rebalancing is triggered frequently to track rapidly changing inference workloads, introducing non-trivial latency that can offset the expected benefits.

In addition, these methods increase memory usage due to redundant expert replicas. The per-rank memory overhead grows linearly with the number of redundant experts and MoE layers. For DeepSeek-V3, adding a single redundant expert per EP rank introduces approximately 2.4 GB of additional memory [29], directly limiting the achievable batch size and overall inference throughput.

### 3.3 Problem Formulation of Real-Time Load Balancing

As observed above, MMoE inference exhibits highly dynamic routing, where expert loads and device imbalance can change rapidly across layers and iterations. Let  $ T_{i}(x) $ denote the execution time of EP rank i for an MoE layer under routing outcome x. The layer latency is determined by the straggler:

 $$ T_{\mathrm{M o E}}(x)=\max_{i}T_{i}(x). $$ 

The goal of load balancing is to reduce the straggler latency while accounting for its own overhead. We formulate the load balancing objective as:

 $$ \max_{\pi}\ \mathbb{E}_{x}\big[\max_{i}T_{i}(x)-\max_{i}T_{i}(\pi(x))-T_{\mathrm{L B}}(\pi,x)\big], $$ 

where  $ \pi $ is the load balancing policy applied online based on the current routing x, and  $ T_{LB} $ denotes the latency overhead of applying  $ \pi $.

---

# OCR 第 5 页

Prediction-based methods approximate $\pi$ using historical statistics, implicitly assuming temporal locality. However, rapid routing dynamics violate this assumption, making prediction unreliable even with frequent updates while incurring extra communication cost. Moreover, optimizing proxy metrics such as token or expert balance is not a necessary condition for minimizing $\max_i T_i$. Although such proxies may correlate with execution latency, enforcing them incurs significant overhead that can offset the gains. Furthermore, unlike training where token balance supports optimization stability, inference focuses solely on minimizing execution latency, making token balance an indirect and non-essential objective.

Therefore, an effective policy  $ \pi $ must be both real-time and lightweight: it should (i) operate online based on the current routing outcome, (ii) directly target device-level latency imbalance, and (iii) introduce negligible overhead so that the net latency reduction remains positive.

## 4 Methodology

### 4.1 System Overview

We propose ReaLB to reduce rank-wise latency imbalance in MMoE inference while minimizing runtime scheduling overhead. ReaLB is integrated into existing multimodal LLM inference frameworks such as vLLM [31] and SGLang [42], and performs online load balancing at the granularity of EP ranks. The overall workflow of ReaLB is illustrated in Figure 3(a), and the inference pipeline consists of four stages:

① Routing and Profiling: Input tokens are processed by attention and gating modules, producing real-time expert assignments and device-level load statistics.

② Modality-aware LB Scheduling: The scheduler analyzes current routing outcomes to detect device-level imbalance. It identifies overloaded ranks, often caused by skewed assignment of vision-heavy experts, and constructs a per-rank execution plan by assigning GEMM precision ( $ §4.2 $). This enables straggling ranks to accelerate execution using low-precision hardware units.

③ Overhead-aware Pipeline Orchestration: The orchestrator executes the scheduling plan by collecting runtime metadata and performing online precision transformation (e.g., BF16 to FP4). These operations are overlapped with inter-device communication (e.g., All-to-All Dispatch), hiding transformation overhead from the critical path ( $ \S4.3 $).

④ Balanced MoE Execution: Each EP rank executes MMoE computation according to the generated plan, leveraging FP4 Tensor Cores for precision-insensitive workloads, thereby reducing execution skew across ranks.

<div style="text-align: center;"><img src="assets/imgs/img_in_image_box_235_1031_575_1324.jpg" alt="Image" width="27%" /></div>


<div style="text-align: center;">(c) Online precision transformation pipeline.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_image_box_590_1032_986_1305.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;">(b) Modality-aware, layer-wise scheduling for device-level load balancing in MMoE.</div>


<div style="text-align: center;">Figure 3: ReaLB design for efficient multimodal MoE inference. It combines modality-aware scheduling and an overlapping execution pipeline to mitigate device-level latency imbalance while minimizing runtime overhead.</div>

---

# OCR 第 6 页

### 4.2 Real-time Modality-aware LB Scheduling

We model ReaLB as a feedback control policy that adjusts execution precision based on instantaneous routing states in MMoE inference. The policy operates online before each MoE layer without relying on historical statistics, enabling adaptation to rapidly changing routing patterns.

Runtime State. We define the device-level imbalance as

 $$ IB_{d}=\frac{Load_{d}}{Ideal},\quad IB_{global}=\max_{d}IB_{d}, $$ 

where  $ Load_{d} $ denotes the token load on device d, and Ideal is the average load across EP ranks at current step. Each device is further characterized by the vision token ratio

 $$ R_{v d}=\frac{N_{v d}}{N_{v d}+N_{t d}}, $$ 

where  $ N_{vd} $ and  $ N_{td} $ denote the numbers of vision and text tokens on device d. The runtime state for each device is thus defined by  $ (IB_{d}, R_{vd}) $.

Hierarchical Control Policy. ReaLB adopts a two-stage control policy applied synchronously at each MMoE layer. First, devices exhibiting significant imbalance are identified as hotspots according to:

 $$ \mathcal{H}=\{d\mid I B_{d}>C\}, $$ 

where $C = 1$ corresponds to a perfectly balanced state. This step defines the set of overloaded devices within the current layer. Given the hotspot set $\mathcal{H}$, ReaLB performs device-level precision assignment based on modality skew. Devices satisfying

 $$ R_{v d}>M_{d},\quad d\in\mathcal{H}, $$ 

are marked as vision-heavy and compressible, and their hosted experts are executed using low-precision GEMM kernels, while all remaining devices execute in standard precision.

Adaptive Control via AIMD. We adopt an additive-increase multiplicative-decrease (AIMD) control principle [4], a classical feedback mechanism widely used in congestion control systems. AIMD provides a stable trade-off between responsiveness under high imbalance and stability under normal conditions. The control parameter  $ M_{d} $ is updated based on the global imbalance signal:

 $$ M_{d}=\left\{\begin{aligned}&0.5M_{d},&&\text{if}IB_{global}>\tau,\\ &\min(1,M_{d}+0.1),&&\text{otherwise},\end{aligned}\right. $$ 

where  $ \tau $ denotes the congestion threshold, which is set to 1.5 by default. This rule increases sensitivity to modality skew under severe congestion, while gradually relaxing constraints when the system stabilizes. A detailed empirical analysis of the evolution of  $ M_{d} $ is provided in Appendix H.

Scheduling Effect. As shown in Figure 3(b), both  $ Rank_{1} $ and  $ Rank_{2} $ are identified as overloaded devices, while only  $ Rank_{1} $ exhibits strong vision dominance. At runtime, ReaLB applies FP4 GEMM execution to  $ Rank_{1} $ according to the control policy, while preserving standard precision for other ranks. This selective execution targets routing-induced hotspots, which are the primary contributor to MMoE latency imbalance.

### 4.3 Overhead-Aware Pipeline Orchestration

To minimize LB overhead, ReaLB introduces an orchestrator that operates through two key mechanisms: (i) fine-grained overlap between LB scheduling and communication, and (ii) a lightweight LB gate that controls runtime activation, as illustrated in Figure 3(c).

Overlapping Pipeline. To support real-time precision switching without increasing memory footprint, ReaLB performs on-the-fly precision transformation. Each expert stores only its original high-precision weights alongside precomputed scaling factors required for low-precision conversion. When the scheduler assigns a new precision configuration, the selected expert groups are quantized

---

# OCR 第 7 页

online to the target precision and immediately launched for computation. This design eliminates the need for maintaining multiple precision copies of expert weights.

While online transformation introduces additional computation, ReaLB is designed to mask this overhead entirely. ReaLB manages two primary sources of runtime latency: ① Scheduling Metadata (S): Routing statistics are collected across EP ranks via a lightweight allgather. ② Precision Transformation (T): The transformation latency of weights from high to low precision (e.g., BF16 to FP4). Under the standard DP attention and EP MoE deployment, tokens are dispatched to their target devices after gating, and MoE computation is then executed sequentially. Instead, ReaLB adopts a pipelined execution design that overlaps metadata collecting and weights quantization with inter-device communication (e.g., dispatch), which dominates latency in practice.

As a result, the LB cost does not scale with the EP size, since it only involves lightweight metadata collection and local precision transformation. In contrast, dispatch latency increases with EP scale and becomes further amplified under multi-node deployment. This ensures that LB overhead is fully hidden by communication, making the overall system scalable.

LB Gate. To precisely control runtime overhead, we introduce an LB gate that operates after routing metadata collection to determine whether load balancing is activated. ReaLB targets the regime where MoE execution is dominated by GEMM computation, such that device-level load imbalance directly translates into latency imbalance. The activation condition is based on a global batch threshold  $ \Gamma $, where ReaLB is enabled when the aggregated load across devices exceeds  $ \Gamma $. As shown in Figure 4, when per-rank token counts are small, non-GEMM operations dominate latency and device imbalance has limited impact; as batch size increases, GEMM becomes the dominant cost and straggler



<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_703_533_1009_665.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"># Token</div>


<div style="text-align: center;">Figure 4: ReaLB is enabled only in the compute-bound regime with large batch sizes.</div>


effects emerge as the primary bottleneck. Only under this regime is the LB gate enabled; otherwise, ReaLB falls back to standard execution, ensuring negligible  $ T_{LB} $ in the overall latency objective.

## 5 Evaluation

### 5.1 Setup

Implementation Details. We build ReaLB on vLLM v0.13.0 [31], with mixed-precision MMoE support enabled via LLM Compressor [30] and NVFP4 GEMM kernels from FlashInfer [39]. The system is developed in PyTorch and Triton. We adopt a prefill-decode (PD) colocated deployment, and use vLLM's default continuous batching scheduler for serving. Communication and computation are overlapped using CUDA streams. All experiments are conducted on eight NVIDIA RTX 5090 GPUs under combined data and expert parallelism. With the colocated deployment and continuous batching mechanism in vLLM, each forward batch may contain a mixture of prefill and decode requests. Additional routing statistics and batching patterns are provided in Appendix F and G. We set the capacity factor  $ C = 1 $, the modality threshold  $ M_d $ to 0.9 initially, and the global batch threshold  $ \Gamma = 2048 $ ( $ 256 \times 8 $ ranks).

Reproducibility. To facilitate reproducibility, we provide the implementation of ReaLB and the associated scripts in the supplementary material.

Models. We evaluate two recent open-source multimodal MoE models: Kimi-VL [10] and Qwen3-VL [27] with 64 and 128 routed experts, respectively. We further apply NVFP4 post-training quantization (PTQ) [30] to the MoE layers to obtain scale factors for mixed-precision execution.

Compared Methods. To study performance and balance trade-offs, we compare the following configurations: (1) Baseline: Standard W16A16 GEMM execution for all MoE layers without load balancing. (2) FP4-All: W4A4 NVFP4 GEMM execution for all MoE layers. (3) EPLB: A history-based expert-placement LB method (following [6]). (4) Async_EPLB: An asynchronous version of EPLB that overlaps weight transfers to reduce replacement overhead. (5) ReaLB: Our proposed modality-aware real-time LB scheme with overlapped pipeline, referred to as the full

---

# OCR 第 8 页

ReaLB. (6) ReaLB-seq: A sequential variant of ReaLB that disables pipeline overlapping. (7) ReaLB-mi: ReaLB with fixed modality threshold  $ M_{d} $ that disable AIMD-based adaptive control.

Metrics. We evaluate model accuracy on representative multimodal benchmarks using 1mms-eval [12]. Efficiency is measured on the same workloads to ensure consistency between accuracy and system evaluation. We use CUDA events for fine-grained timing and the vLLM benchmark for end-to-end throughput, measured in processed tokens per second (input + output). To study the overall performance, we report three metrics: (i) accuracy degradation ( $ \Delta $Acc) relative to the BF16 baseline, (ii) end-to-end throughput speedup relative to the BF16 baseline, and (iii) MoE layer latency to capture per-layer execution efficiency.

### 5.2 Main Results and Trade-offs

We compare ReaLB against representative baselines, including EPLB as a prediction-based non-real-time LB method and FP4-All as a uniform low-precision quantization scheme. We further evaluate two fixed modality-threshold variants, ReaLB-m1 ( $ M_d = 0 $) and ReaLB-m2 ( $ M_d = 0.7 $), on the two MMoE models using MMMU [40], MathVista [21], and DynaMath [43]. End-to-end speedup and accuracy degradation ( $ \Delta Acc $) are reported relative to the BF16 baseline. As shown in Table 1, ReaLB consistently improves end-to-end throughput across all benchmarks while maintaining a favorable accuracy–efficiency trade-off compared to existing methods.

<div style="text-align: center;">Table 1: Main performance comparison and trade-offs under different load balancing strategies. The blue-highlighted values indicate the best results among ReaLB variants (gray-shaded columns).</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Model</td><td style='text-align: center; word-wrap: break-word;'>Workload</td><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>EPLB</td><td style='text-align: center; word-wrap: break-word;'>FP4-All</td><td style='text-align: center; word-wrap: break-word;'>ReaLB-m1</td><td style='text-align: center; word-wrap: break-word;'>ReaLB-m2</td><td style='text-align: center; word-wrap: break-word;'>RealB-seq</td><td style='text-align: center; word-wrap: break-word;'>ReaLB</td></tr><tr><td rowspan="6">Kimi-VL</td><td style='text-align: center; word-wrap: break-word;'>MMMU  $ \Delta Acc \downarrow $</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>-4.22</td><td style='text-align: center; word-wrap: break-word;'>-2.22</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>-1.22</td><td style='text-align: center; word-wrap: break-word;'>-1.22</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Speedup  $ \uparrow $</td><td style='text-align: center; word-wrap: break-word;'>1.00</td><td style='text-align: center; word-wrap: break-word;'>0.91</td><td style='text-align: center; word-wrap: break-word;'>1.34</td><td style='text-align: center; word-wrap: break-word;'>1.32</td><td style='text-align: center; word-wrap: break-word;'>1.29</td><td style='text-align: center; word-wrap: break-word;'>1.25</td><td style='text-align: center; word-wrap: break-word;'>1.32</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>MathVista  $ \Delta Acc \downarrow $</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>-2.00</td><td style='text-align: center; word-wrap: break-word;'>-2.00</td><td style='text-align: center; word-wrap: break-word;'>-1.10</td><td style='text-align: center; word-wrap: break-word;'>-1.70</td><td style='text-align: center; word-wrap: break-word;'>-1.70</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Speedup  $ \uparrow $</td><td style='text-align: center; word-wrap: break-word;'>1.00</td><td style='text-align: center; word-wrap: break-word;'>0.95</td><td style='text-align: center; word-wrap: break-word;'>1.40</td><td style='text-align: center; word-wrap: break-word;'>1.32</td><td style='text-align: center; word-wrap: break-word;'>1.30</td><td style='text-align: center; word-wrap: break-word;'>1.26</td><td style='text-align: center; word-wrap: break-word;'>1.31</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>DynaMath  $ \Delta Acc \downarrow $</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>-8.19</td><td style='text-align: center; word-wrap: break-word;'>-3.80</td><td style='text-align: center; word-wrap: break-word;'>-2.50</td><td style='text-align: center; word-wrap: break-word;'>-3.10</td><td style='text-align: center; word-wrap: break-word;'>-3.10</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Speedup  $ \uparrow $</td><td style='text-align: center; word-wrap: break-word;'>1.00</td><td style='text-align: center; word-wrap: break-word;'>0.96</td><td style='text-align: center; word-wrap: break-word;'>1.41</td><td style='text-align: center; word-wrap: break-word;'>1.30</td><td style='text-align: center; word-wrap: break-word;'>1.29</td><td style='text-align: center; word-wrap: break-word;'>1.25</td><td style='text-align: center; word-wrap: break-word;'>1.30</td></tr><tr><td rowspan="6">Qwen-VL</td><td style='text-align: center; word-wrap: break-word;'>MMMU  $ \Delta Acc \downarrow $</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>-2.44</td><td style='text-align: center; word-wrap: break-word;'>-0.34</td><td style='text-align: center; word-wrap: break-word;'>-0.34</td><td style='text-align: center; word-wrap: break-word;'>-0.00</td><td style='text-align: center; word-wrap: break-word;'>-0.00</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Speedup  $ \uparrow $</td><td style='text-align: center; word-wrap: break-word;'>1.00</td><td style='text-align: center; word-wrap: break-word;'>0.91</td><td style='text-align: center; word-wrap: break-word;'>1.18</td><td style='text-align: center; word-wrap: break-word;'>1.13</td><td style='text-align: center; word-wrap: break-word;'>1.13</td><td style='text-align: center; word-wrap: break-word;'>1.01</td><td style='text-align: center; word-wrap: break-word;'>1.13</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>MathVista  $ \Delta Acc \downarrow $</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>-2.70</td><td style='text-align: center; word-wrap: break-word;'>-1.60</td><td style='text-align: center; word-wrap: break-word;'>-1.30</td><td style='text-align: center; word-wrap: break-word;'>-0.40</td><td style='text-align: center; word-wrap: break-word;'>-0.40</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Speedup  $ \uparrow $</td><td style='text-align: center; word-wrap: break-word;'>1.00</td><td style='text-align: center; word-wrap: break-word;'>0.83</td><td style='text-align: center; word-wrap: break-word;'>1.16</td><td style='text-align: center; word-wrap: break-word;'>1.14</td><td style='text-align: center; word-wrap: break-word;'>1.13</td><td style='text-align: center; word-wrap: break-word;'>1.01</td><td style='text-align: center; word-wrap: break-word;'>1.13</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>DynaMath  $ \Delta Acc \downarrow $</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>0.00</td><td style='text-align: center; word-wrap: break-word;'>-1.89</td><td style='text-align: center; word-wrap: break-word;'>-1.59</td><td style='text-align: center; word-wrap: break-word;'>-1.09</td><td style='text-align: center; word-wrap: break-word;'>-0.39</td><td style='text-align: center; word-wrap: break-word;'>-0.39</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Speedup  $ \uparrow $</td><td style='text-align: center; word-wrap: break-word;'>1.00</td><td style='text-align: center; word-wrap: break-word;'>0.84</td><td style='text-align: center; word-wrap: break-word;'>1.12</td><td style='text-align: center; word-wrap: break-word;'>1.10</td><td style='text-align: center; word-wrap: break-word;'>1.10</td><td style='text-align: center; word-wrap: break-word;'>1.02</td><td style='text-align: center; word-wrap: break-word;'>1.10</td></tr></table>

Comparison with prior methods. We first compare ReaLB with prior approaches. EPLB fails to provide consistent benefits and can even degrade performance, leading to negative speedup in some settings. This is mainly due to the mismatch between historical token statistics and dynamic routing behavior in multimodal MoE, which limits its ability to capture real-time hotspots.

<div style="text-align: center;">Table 2: Accuracy stability of ReaLB across additional multimodal benchmarks ( $ \Delta Acc \downarrow $).</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Model</td><td style='text-align: center; word-wrap: break-word;'>AI2D</td><td style='text-align: center; word-wrap: break-word;'>InfoVQA</td><td style='text-align: center; word-wrap: break-word;'>TextVQA</td><td style='text-align: center; word-wrap: break-word;'>MMBench</td><td style='text-align: center; word-wrap: break-word;'>AVG</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Kimi-VL</td><td style='text-align: center; word-wrap: break-word;'>-0.13</td><td style='text-align: center; word-wrap: break-word;'>-0.38</td><td style='text-align: center; word-wrap: break-word;'>-0.91</td><td style='text-align: center; word-wrap: break-word;'>-0.00</td><td style='text-align: center; word-wrap: break-word;'>-0.36</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Qwen-VL</td><td style='text-align: center; word-wrap: break-word;'>-1.23</td><td style='text-align: center; word-wrap: break-word;'>-0.00</td><td style='text-align: center; word-wrap: break-word;'>-0.53</td><td style='text-align: center; word-wrap: break-word;'>-0.60</td><td style='text-align: center; word-wrap: break-word;'>-0.59</td></tr></table>

and introduces additional communication and expert replacement overhead. Compared to uniform low-precision execution (FP4-All), ReaLB achieves a significantly better trade-off. On Kimi-VL, it achieves up to  $ 1.32\times $ speedup on MMMU and  $ 1.30\times $ on DynaMath, while substantially reducing accuracy degradation. In contrast, FP4-All introduces notable accuracy loss (e.g., -8.19% on DynaMath), indicating that uniform quantization is overly aggressive for multimodal workloads. ReaLB reduces accuracy loss to 3.1% on DynaMath while maintaining comparable throughput gains. Table 2 further validates the stability of ReaLB in accuracy preservation across additional multimodal benchmarks. This demonstrates that exploiting modality heterogeneity and precision sensitivity differences under runtime-aware control leads to a better trade-off than uniform quantization.

---

# OCR 第 9 页

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_215_149_493_288.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;">(a) End-to-end time breakdown.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_505_145_743_291.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;">(b) MoE latency over iterations.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_753_140_1010_293.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;">(c) Rank-wise latency distribution.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_214_338_493_479.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;">(d) End-to-end time breakdown.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_505_335_743_481.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;">(e) MoE latency over iterations.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_751_334_1009_482.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">(f) Rank-wise latency distribution.</div>


<div style="text-align: center;">Figure 5: Fine-grained MoE latency analysis. Top row (a–c): Kimi-VL; bottom row (d–f): Qwen-VL.</div>


Robustness of modality-aware design across models. We observe that the benefit of ReaLB generalizes across different multimodal MoE backbones. On Qwen-VL, ReaLB achieves near-lossless accuracy (with <0.6% average degradation) while delivering  $ 1.10 \times -1.13 \times $ speedup across benchmarks. Together with Kimi-VL results, this confirms that modeling modality heterogeneity and runtime imbalance enables stable and consistent improvements across architectures.

Ablation and sensitivity analysis. To analyze the contribution of each component in ReALB, we conduct ablation studies. RealLB-seq removes pipeline overlap while retaining modality-aware scheduling, resulting in similar accuracy but reduced speedup, which highlights the importance of overlapping scheduling and precision transformation with communication. In addition, sensitivity analysis on  $ M_{d} $ shows that adaptive control provides more stable performance than static thresholds, achieving a better balance between aggressiveness and accuracy preservation.

### 5.3 Latency Breakdown

We further conduct fine-grained latency analysis on DynaMath (1K samples) under different load balancing strategies. On Kimi-VL, Figure 5(a) shows that FP4-All and ReaLB nearly halves the MoE time share, yielding 22.8% end-to-end time reduction, while EPLB slightly increases it and leads to negative gains. FP4-All serves as an upper bound, being 6% faster than ReaLB-seq; meanwhile, ReaLB achieves 3% higher speedup than ReaLB-seq, indicating that overhead control effectively removes pipeline bubbles and recovers the performance gap. Figure 5(b,c) explain the source of these gains. ReaLB reduces average MoE latency from 1.51 ms to 1.36 ms, whereas EPLB increases it from 1.51 ms to 2.15 ms, showing the limitation of prediction-based schemes under dynamic workloads over the observed iterations. At the rank level, ReaLB achieves up to  $ 1.29 \times $ speedup by targeting hotspot ranks, confirming the effectiveness of runtime-aware load balancing. From Figure 5(d–f), we observe a similar trend on Qwen-VL, where ReaLB consistently outperforms EPLB with a clear advantage in both latency reduction and stability. Additional results are provided in Appendix I.

## 6 Conclusion

We propose ReaLB, a real-time, modality-aware load balancing approach for multimodal MoE inference. Unlike prior prediction-based methods, ReaLB directly targets execution-time imbalance at the MoE layer, enabling accurate and timely load balancing without relying on indirect workload estimation. By selectively applying low-precision execution based on modality, ReaLB mitigates stragglers caused by dynamic and skewed routing patterns. An overlapped execution design further hides scheduling and precision conversion overhead, ensuring low runtime cost. Experiments across multiple multimodal MoE models show that ReaLB reduces MoE latency while preserving accuracy, demonstrating the practicality of real-time load balancing for multimodal inference.

---

# OCR 第 10 页

## References

[1] Weilin Cai, Juyong Jiang, Le Qin, junweicui, Sunghun Kim, and Jiayi Huang. Shortcut-connected expert parallelism for accelerating mixture of experts. In Forty-second International Conference on Machine Learning, 2025.

[2] Junyi Chen, Longteng Guo, Jia Sun, Shuai Shao, Zehuan Yuan, Liang Lin, and Dongyu Zhang. Eve: Efficient vision-language pre-training with masked prediction and modality-aware moe, 2024.

[3] Liang Chen, Haozhe Zhao, Tianyu Liu, Shuai Bai, Junyang Lin, Chang Zhou, and Baobao Chang. An image is worth 1/2 tokens after layer 2: Plug-and-play inference acceleration for large vision-language models, 2024.

[4] Dah-Ming Chiu and Raj Jain. Analysis of the increase and decrease algorithms for congestion avoidance in computer networks. Comput. Netw. ISDN Syst., 17(1):1–14, June 1989.

[5] Damai Dai, Chengqi Deng, Chenggang Zhao, R. X. Xu, Huazuo Gao, Deli Chen, Jiashi Li, Wangding Zeng, Xingkai Yu, Y. Wu, Zhenda Xie, Y. K. Li, Panpan Huang, Fuli Luo, Chong Ruan, Zhifang Sui, and Wenfeng Liang. Deepseekmoe: Towards ultimate expert specialization in mixture-of-experts language models, 2024.

[6] DeepSeek-AI. Expert parallelism load balancer (eplb), 2025.

[7] DeepSeek-AI. Linear-programming-based load balancer (lplb). https://github.com/deepseek-ai/LPLB, 2025. GitHub repository.

[8] DeepSeek-AI, Aixin Liu, Bei Feng, Bin Wang, Bingxuan Wang, et al. Deepseek-v2: A strong, economical, and efficient mixture-of-experts language model, 2024.

[9] DeepSeek-AI, Aixin Liu, Bei Feng, Bing Xue, Bingxuan Wang, et al. Deepseek-v3 technical report, 2025.

[10] Angang Du, Bohong Yin, Bowei Xing, Bowen Qu, Bowen Wang, et al. Kimi-vl technical report, 2025.

[11] Baidu ERNIE Team. Ernie4.5, 2025.

[12] EvolvingLMMs-Lab. lmms-eval: The evaluation suite of large multimodal models, 2025. Accessed: 2025-09-22.

[13] Hugging Face and LMMs-Lab. Ai2d, 2024. Accessed: 2025-09-21.

[14] Dong Guo, Faming Wu, Feida Zhu, Fuxing Leng, Guang Shi, Haobin Chen, Haoqi Fan, Jian Wang, Jianyu Jiang, Jiawei Wang, Jingji Chen, Jingjia Huang, Kang Lei, Liping Yuan, Lishu Luo, Pengfei Liu, Qinghao Ye, Rui Qian, Shen Yan, Shixiong Zhao, Shuai Peng, Shuangye Li, Sihang Yuan, Sijin Wu, Tianheng Cheng, Weiwei Liu, Wenqian Wang, Xianhan Zeng, Xiao Liu, Xiaobo Qin, Xiaohan Ding, Xiaojun Xiao, Xiaoying Zhang, Xuanwei Zhang, Xuehan Xiong, Yanghua Peng, Yangrui Chen, Yanwei Li, Yanxu Hu, Yi Lin, Yiyuan Hu, Yiyuan Zhang, Youbin Wu, Yu Li, Yudong Liu, Yue Ling, Yujia Qin, Zanbo Wang, Zhiwu He, Aoxue Zhang, Bairen Yi, Bencheng Liao, Can Huang, Can Zhang, Chaorui Deng, Chaoyi Deng, Cheng Lin, Cheng Yuan, Chenggang Li, Chenhui Gou, Chenwei Lou, Chengzhi Wei, Chundian Liu, Chunyuan Li, Deyao Zhu, Donghong Zhong, Feng Li, Feng Zhang, Gang Wu, Guodong Li, Guohong Xiao, Haibin Lin, Haihua Yang, Haoming Wang, Heng Ji, Hongxiang Hao, Hui Shen, Huixia Li, Jiahao Li, Jialong Wu, Jianhua Zhu, Jianpeng Jiao, Jiashi Feng, Jiaze Chen, Jianhui Duan, Jiaho Liu, Jin Zeng, Jingqun Tang, Jingyu Sun, Joya Chen, Jun Long, Junda Feng, Junfeng Zhan, Junjie Fang, Junting Lu, Kai Hua, Kai Liu, Kai Shen, Kaiyuan Zhang, Ke Shen, Ke Wang, Keyu Pan, Kun Zhang, Kunchang Li, Lanxin Li, Lei Li, Lei Shi, Li Han, Liang Xiang, Liangqiang Chen, Lin Chen, Lin Li, Lin Yan, Liying Chi, Longxiang Liu, Mengfei Du, Mingxuan Wang, Ningxin Pan, Peibin Chen, Pengfei Chen, Pengfei Wu, Qingqing Yuan, Qingyao Shuai, Qiuyan Tao, Renjie Zheng, Renrui Zhang, Ru Zhang, Rui Wang, Rui Yang, Rui Zhao, Shaoqiang Xu, Shihao Liang, Shipeng Yan, Shu Zhong, Shuaihua Cao, Shuangzhi Wu, Shufan Liu, Shuhan Chang, Songhua Cai, Tenglong Ao, Tianhao Yang, Tingting Zhang, Wanjun Zhong, Wei Jia, Wei Weng, Weihao

---

# OCR 第 11 页

Yu, Wenhao Huang, Wenjia Zhu, Wenli Yang, Wenzhi Wang, Xiang Long, XiangRui Yin, Xiao Li, Xiaolei Zhu, Xiaoying Jia, Xijin Zhang, Xin Liu, Xinchen Zhang, Xinyu Yang, Xiongcai Luo, Xiuli Chen, Xuantong Zhong, Xuefeng Xiao, Xujing Li, Yan Wu, Yawei Wen, Yifan Du, Yihao Zhang, Yining Ye, Yonghui Wu, Yu Liu, Yu Yue, Yufeng Zhou, Yufeng Yuan, Yuhang Xu, Yuhong Yang, Yun Zhang, Yunhao Fang, Yuntao Li, Yurui Ren, Yuwen Xiong, Zehua Hong, Zehua Wang, Zewei Sun, Zeyu Wang, Zhao Cai, Zhaoyue Zha, Zhecheng An, Zhehui Zhao, Zhengzhuo Xu, Zhipeng Chen, Zhiyong Wu, Zhuofan Zheng, Zihao Wang, Zilong Huang, Ziyu Zhu, and Zuquan Song. Seed1.5-vl technical report, 2025.

[15] Jiaao He, Jidong Zhai, Tiago Antunes, Haojie Wang, Fuwen Luo, Shangfeng Shi, and Qin Li. Fastermoe: modeling and optimizing training of large-scale dynamic pre-trained models. In Proceedings of the 27th ACM SIGPLAN Symposium on Principles and Practice of Parallel Programming, New York, NY, USA, 2022. Association for Computing Machinery.

[16] Haiyang Huang, Newsha Ardalani, Anna Sun, Liu Ke, Hsien-Hsin S. Lee, Anjali Sridhar, Shruti Bhosale, Carole-Jean Wu, and Benjamin Lee. Towards moe deployment: Mitigating inefficiencies in mixture-of-expert (moe) inference, 2023.

[17] Chao Jin, Ziheng Jiang, Zhihao Bai, Zheng Zhong, Juncai Liu, Xiang Li, Ningxin Zheng, Xi Wang, Cong Xie, Qi Huang, Wen Heng, Yiyuan Ma, Wenlei Bao, Size Zheng, Yanghua Peng, Haibin Lin, Xuanzhe Liu, Xin Jin, and Xin Liu. Megascale-moe: Large-scale communication-efficient training of mixture-of-experts models in production, 2025.

[18] LMMS Lab. Mmbench. https://huggingface.co/datasets/lmms-lab/MMBench, 2024. Hugging Face dataset repository.

[19] Xi Victoria Lin, Akshat Shrivastava, Liang Luo, Srinivasan Iyer, Mike Lewis, Gargi Ghosh, Luke Zettlemoyer, and Armen Aghanjyan. Moma: Efficient early-fusion pre-training with mixture of modality-aware experts, 2024.

[20] Tongxuan Liu, Tao Peng, Peijun Yang, Xiaoyang Zhao, Xiusheng Lu, Weizhe Huang, Zirui Liu, Xiaoyu Chen, Zhiwei Liang, Jun Xiong, Donghe Jin, Minchao Zhang, Jinrong Guo, Yingxu Deng, Xu Zhang, Xianzhe Dong, Siqi Wang, Siyu Wu, Yu Wu, Zihan Tang, Yuting Zeng, Yanshu Wang, Jinguang Liu, Meng Kang, Menxin Li, Yunlong Wang, Yiming Liu, Xiaolong Ma, Yifan Wang, Yichen Zhang, Jinrun Yin, Keyang Zheng, Jiawei Yin, Jun Zhang, Ziyue Wang, Xiaobo Lin, Liangyu Liu, Liwei Lan, Yang Liu, Chunhua Peng, Han Liu, Songcheng Ren, Xuezhu Wang, Yunheng Shen, Yi Wang, Guyue Liu, Hui Chen, Tong Yang, Hailong Yang, Jing Li, Guiguang Ding, and Ke Zhang. xllm technical report, 2025.

[21] Pan Lu, Hritik Bansal, Tony Xia, Jiacheng Liu, Chunyuan Li, Hannaneh Hajishirzi, Hao Cheng, Kai-Wei Chang, Michel Galley, and Jianfeng Gao. Mathvista: Evaluating mathematical reasoning of foundation models in visual contexts, 2024.

[22] Minesh Mathew, Dimosthenis Karatzas, R Manmatha, and CV Jawahar. Docvq: A dataset for vqa on document images. corr abs/2007.00398 (2020). arXiv preprint arXiv:2007.00398, 2020.

[23] Xiaonan Nie, Xupeng Miao, Zilong Wang, Zichao Yang, Jilong Xue, et al. Flexmoe: Scaling large-scale sparse pre-trained model training via dynamic device placement. 1(1), May 2023.

[24] Le Qin, Junwei Cui, Weilin Cai, and Jiayi Huang. Chimera: Communication fusion for hybrid parallelism in large language models. In Proceedings of the 52nd Annual International Symposium on Computer Architecture, ISCA '25, page 498–513, New York, NY, USA, 2025. Association for Computing Machinery.

[25] Amanpreet Singh, Vivek Natarajan, Meet Shah, Yu Jiang, Xinlei Chen, Dhruv Batra, Devi Parikh, and Marcus Rohrbach. Towards vqa models that can read. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 8317–8326, 2019.

[26] Moonshot AI Team. Kimi-vl-a3b-instruct. https://huggingface.co/moonshotai/Kimi-VL-A3B-Instruct, 2025. Hugging Face model repository.

[27] QwenLM Team. Qwen3-vl: A multimodal large language model series. https://huggingface.co/Qwen/Qwen3-VL-30B-A3B-Instruct, 2025. Accessed: 2025-10-29.

---

# OCR 第 12 页

[28] QwenLM Team. Qwen3-vl: A multimodal large language model series. https://huggingface.co/Qwen/Qwen3-VL-235B-A22B-Instruct, 2025. Accessed: 2025-10-29.

[29] vLLM Documentation. Expert parallel load balancer (eplb) parameters. https://docs.vllm.ai/en/latest/serving/expert_parallel_deployment/#eplb-parameters, 2025. Accessed: 2025-10-07.

[30] vLLM Project. Llm-compressor. https://github.com/vllm-project/llm-compressor, 2025. Accessed: 2025-09-22.

[31] vLLM Project. vllm: A high-throughput and memory-efficient inference and serving engine for large language models, 2025.

[32] Weihan Wang, Qingsong Lv, Wenmeng Yu, Wenyi Hong, Ji Qi, Yan Wang, Junhui Ji, Zhuoyi Yang, Lei Zhao, Xixuan Song, Jiazheng Xu, Keqin Chen, Bin Xu, Juanzi Li, Yuxiao Dong, Ming Ding, and Jie Tang. Cogvlm: visual expert for pretrained language models. In Proceedings of the 38th International Conference on Neural Information Processing Systems, NIPS '24, Red Hook, NY, USA, 2025. Curran Associates Inc.

[33] Weiyun Wang, Zhangwei Gao, Lixin Gu, Hengjun Pu, Long Cui, Xingguang Wei, Zhaoyang Liu, Linglin Jing, Shenglong Ye, Jie Shao, Zhaokai Wang, Zhe Chen, Hongjie Zhang, Ganlin Yang, Haomin Wang, Qi Wei, Jinhui Yin, Wenhao Li, Erfei Cui, Guanzhou Chen, Zichen Ding, Changyao Tian, Zhenyu Wu, Jingjing Xie, Zehao Li, Bowen Yang, Yuchen Duan, Xuehui Wang, Zhi Hou, Haoran Hao, Tianyi Zhang, Songze Li, Xiangyu Zhao, Haodong Duan, Nianchen Deng, Bin Fu, Yinan He, Yi Wang, Conghui He, Botian Shi, Junjun He, Yingtong Xiong, Han Lv, Lijun Wu, Wenqi Shao, Kaipeng Zhang, Huipeng Deng, Biqing Qi, Jiaye Ge, Qipeng Guo, Wenwei Zhang, Songyang Zhang, Maosong Cao, Junyao Lin, Kexian Tang, Jianfei Gao, Haian Huang, Yuzhe Gu, Chengqi Lyu, Huanze Tang, Rui Wang, Haijun Lv, Wanli Ouyang, Limin Wang, Min Dou, Xizhou Zhu, Tong Lu, Dahua Lin, Jifeng Dai, Weijie Su, Bowen Zhou, Kai Chen, Yu Qiao, Wenhai Wang, and Gen Luo. Internv13.5: Advancing open-source multimodal models in versatility, reasoning, and efficiency, 2025.

[34] Fedus William, Zoph Barret, and Shazeer Noam. Switch transformers: scaling to trillion parameter models with simple and efficient sparsity. J. Mach. Learn. Res., 23(1), January 2022.

[35] Yongji Wu, Wenjie Qu, Tianyang Tao, Zhuang Wang, Wei Bai, Zhuohao Li, Yuan Tian, Jiaheng Zhang, Matthew Lentz, and Danyang Zhuo. Lazarus: Resilient and elastic training of mixture-of-experts models with adaptive expert placement, 2024.

[36] Zhiyu Wu, Xiaokang Chen, Zizheng Pan, Xingchao Liu, et al. Deepseek-vl2: Mixture-of-experts vision-language models for advanced multimodal understanding, 2024.

[37] Ao Xiao, Bangzheng He, Baoquan Zhang, Bingji Wang Baoxing Huai, et al. xdeepserve: Model-as-a-service on huawei cloudmatrix384, 2025.

[38] Long Xing, Qidong Huang, Xiaoyi Dong, Jiajie Lu, Pan Zhang, Yuhang Zang, Yuhang Cao, Conghui He, Jiaqi Wang, Feng Wu, and Dahua Lin. Pyramid drop: Accelerating your large vision-language models via pyramid visual redundancy reduction, 2025.

[39] Zihao Ye, Lequn Chen, Ruihang Lai, Wuwei Lin, Yineng Zhang, Stephanie Wang, Tianqi Chen, Baris Kasikci, Vinod Grover, Arvind Krishnamurthy, and Luis Ceze. Flashinfer: Efficient and customizable attention engine for llm inference serving, 2025.

[40] Xiang Yue, Yuansheng Ni, Kai Zhang, Tianyu Zheng, Ruoqi Liu, Ge Zhang, Samuel Stevens, Dongfu Jiang, Weiming Ren, Yuxuan Sun, et al. Mmmu: A massive multi-discipline multimodal understanding and reasoning benchmark for expert agi. arXiv preprint arXiv:2311.16502, 2023.

[41] Mingshu Zhai, Jiaao He, Zixuan Ma, Zan Zong, Runqing Zhang, and Jidong Zhai. SmartMoE: Efficiently training Sparsely-Activated models through combining offline and online parallelization. In 2023 USENIX Annual Technical Conference (USENIX ATC 23), pages 961–975, Boston, MA, July 2023. USENIX Association.

---

# OCR 第 13 页

[42] Lianmin Zheng, Liangsheng Yin, Zhiqiang Xie, Chuyue Sun, Jeff Huang, Cody Hao Yu, Shiyi Cao, Christos Kozyrakis, Ion Stoica, Joseph E. Gonzalez, Clark Barrett, and Ying Sheng. Slang: efficient execution of structured language model programs. In Proceedings of the 38th International Conference on Neural Information Processing Systems, NIPS '24, Red Hook, NY, USA, 2025. Curran Associates Inc.

[43] Chengke Zou, Xingang Guo, Rui Yang, Junyu Zhang, Bin Hu, and Huan Zhang. Dynamath: A dynamic visual benchmark for evaluating mathematical reasoning robustness of vision language models, 2025.

---

# OCR 第 14 页

## A Broader Impacts

Positive societal impact. ReaLB improves multimodal MoE inference efficiency by reducing execution imbalance and improving hardware utilization under mixed-precision execution. This leads to higher device utilization and lower end-to-end latency, improving throughput efficiency in large-scale multimodal serving systems. By better aligning computation with runtime workload imbalance, ReaLB can also reduce redundant computation and improve energy efficiency during inference, which is important for cost-sensitive datacenter deployment of large multimodal models. In addition, improved load balancing enhances system stability under high concurrency, which is critical for production-level multimodal services.

Negative societal impact. ReaLB may introduce potential risks related to accuracy degradation under mixed-precision execution. Although the observed accuracy loss is generally small in our evaluation, aggressive precision control or misconfiguration may lead to non-negligible performance degradation on certain inputs or tasks, particularly under distribution shifts. Such effects may be more critical in high-stakes applications, such as medical image analysis or other safety-critical multimodal systems, where even small accuracy variations can impact downstream decisions. Therefore, careful validation and conservative deployment are required when integrating ReaLB into such scenarios.

## B LLM Usage Declaration

This manuscript uses LLMs strictly for the purpose of language editing and textual polishing to enhance presentation quality. We declare that the novel ideas, methodological framework, experimental execution, and data analysis are the original work of the authors. All content modified by AI tools has been carefully reviewed and validated by the authors to ensure accuracy.

## C Compute Reporting

Reproducing the full experimental results reported in this paper requires approximately 5 days on 8 NVIDIA RTX 5090 GPUs. This estimate includes all evaluation workloads and profiling experiments used in the paper.

## D Limitations

ReaLB directly targets execution-time imbalance without explicit token redistribution, avoiding the mismatch introduced by prediction-based methods. The effectiveness of ReaLB is closely related to the intrinsic routing characteristics of the underlying MoE model and the deployment configuration. For models trained with strong load-balancing regularization (e.g., higher auxiliary loss weights), routing skew during inference can be naturally mitigated, which reduces the degree of execution imbalance that ReaLB can further optimize. The degree of device-level imbalance is also influenced by expert parallelism (EP) configuration. When the number of devices is small relative to the total number of experts (e.g., 2–4 GPUs with >64 routed experts), each device hosts a larger set of experts, which statistically smooths token distribution and alleviates inter-device imbalance. In such cases, the optimization space for execution-time rebalancing becomes more limited. In addition, ReaLB currently leverages mixed-precision execution for latency control. Extending this mechanism to richer precision configurations, together with corresponding kernel improvement, remains an important direction for future work.

## E Implementation Details

Models. Our primary target is large-scale multimodal MoE models, such as Qwen3-VL-235B-A22B [28]. However, due to GPU memory constraints (8 GPUs with 32 GB each), we evaluate ReaLB on relatively lightweight yet representative multimodal MoE models: Kimi-VL-A3B-Instruct [26], Qwen3-VL-30B-A3B-Instruct [27]. These models retain key characteristics of large-scale multimodal MoE systems, including sparse expert routing and mixed-modality token distributions.

Datasets. We evaluate multimodal MoE models on the following vision-language benchmarks using lmms-eval [12]. (1) MMMU [40]: multi-image reasoning, requiring cross-image integration; The

---

# OCR 第 15 页

selected benchmarks cover diverse modality compositions: (2) MathVista [21]: visual mathematical reasoning benchmark requiring integration of visual context and symbolic math reasoning; (3) DynaMath [43]: dynamic visual math reasoning benchmark for evaluating robustness of vision-language models under challenging and shifting distributions. (4) AI2D [13]: single-image diagram understanding; (5) InfoVQA [22]: single-image information graphics reasoning; (6) TextVQA [25]: single-image text understanding via OCR; (7) MMBench [18]: single-image multimodal QA with a mix of perception, reasoning, and common-sense tasks.

This selection spans single-image, multi-image, and relatively text-heavy scenarios, enabling evaluation of model accuracy across a variety of cross-modal reasoning challenges and ensuring that our load balancing and precision strategies are tested under diverse multimodal conditions.

Testbed. Our target deployment environment is large-scale server-grade GPU clusters based on the Blackwell architecture (e.g., multi-node B100 or B200 systems), where large expert parallelism (EP) exacerbates device-level load imbalance. Due to hardware availability, all experiments are conducted on a single node with 8 NVIDIA RTX 5090 GPUs (64 GB/s).

As RTX 5090 is a consumer-grade GPU with limited interconnect bandwidth, MoE inference end-to-end performance in this setting is heavily communication-bound compared to server-class GPUs. To better emulate server deployment, we measure the communication latency on NVIDIA H20 GPUs using NVLink (4 TB/s) and replace the communication component in the 5090 end-to-end measurements with these high-bandwidth values. This approach preserves the computation characteristics of the 5090 setup while providing an estimate of e2e performance under high-bandwidth interconnects. The software and hardware configurations are summarized in Table 3.

<div style="text-align: center;">Table 3: Software and hardware configuration for experiments.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Component</td><td style='text-align: center; word-wrap: break-word;'>Configuration</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>vLLM</td><td style='text-align: center; word-wrap: break-word;'>v0.13.0</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Lmms-eval</td><td style='text-align: center; word-wrap: break-word;'>v0.5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Sample Params</td><td style='text-align: center; word-wrap: break-word;'>topp=0.8,topk=20,temperature=0.7</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>EPLB</td><td style='text-align: center; word-wrap: break-word;'>8 redundant experts, window size=100, interval=100</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Python</td><td style='text-align: center; word-wrap: break-word;'>3.12</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>PyTorch</td><td style='text-align: center; word-wrap: break-word;'>2.8.0</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>CUDA</td><td style='text-align: center; word-wrap: break-word;'>12.8</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>OS</td><td style='text-align: center; word-wrap: break-word;'>Ubuntu 22.04</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>GPU</td><td style='text-align: center; word-wrap: break-word;'>8  $ \times $ NVIDIA RTX 5090 (32 GB each)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Interconnect</td><td style='text-align: center; word-wrap: break-word;'>Gen5 PCIe, 64 GB/s per GPU</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>CPU</td><td style='text-align: center; word-wrap: break-word;'>100 vCPU Intel Xeon Platinum 8470Q</td></tr></table>

Quantization Details. We adopt the NVFP4 (W4A4) scheme, where weights and activations are represented in FP4 (E2M1), and scaling factors are stored in FP8 (E4M3). Quantization is performed in a per-group manner with a group size of 16. For each group, we apply symmetric min-max quantization. Specifically, we compute the dynamic range as and derive the local scale by normalizing with the maximum representable FP4 value (6.0). A global scale factor is further applied to align magnitudes across groups or tensors. The resulting scale is then quantized into FP8 and clamped to its valid range, ensuring numerical stability. Each value is quantized by dividing by the scale and mapping to the nearest FP4 representable value. During inference, matrix multiplication is performed directly on FP4 operands.

## F Routing Statistics

Device-level load imbalance. Figure 6 shows device-level load imbalance (1× to 3×) for Kimi-VL under EP=8, measured on the MMMU dataset.

Dynamics of load distribution across devices, experts, and modalities. Figure 7 shows several representative MoE layers, illustrating how the load distribution of each device and the most selected expert (top-1 hot expert) evolve over iterations. The plots also indicate the proportion of different

---

# OCR 第 16 页

modality tokens, highlighting workload skew, modality imbalance, and the persistence of hotspots during inference.

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_234_285_601_473.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(a) Layer 12</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_625_286_990_473.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(b) Layer 13</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_234_514_601_697.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(c) Layer 14</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_625_514_989_696.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(d) Layer 15</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_234_740_600_921.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(e) Layer 16</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_625_739_989_920.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(f) Layer 17</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_234_963_600_1145.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(g) Layer 18</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_625_964_989_1144.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(h) Layer 19</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_223_1187_590_1367.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(i) Layer 20</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_614_1187_979_1367.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(j) Layer 21</div>


<div style="text-align: center;">Figure 6: Dynamics of device-level load imbalance across MoE layers 12-21.</div>

---

# OCR 第 17 页

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_231_219_602_306.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_232_306_605_457.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_622_219_993_306.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(a) Layer 12</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_619_308_992_457.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(b) Layer 13</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_232_490_603_577.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_231_575_605_727.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_622_490_991_577.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(c) Layer 14</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_621_576_992_727.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(d) Layer 15</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_232_757_602_848.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_231_845_605_1003.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(e) Layer 16</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_622_760_991_848.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_620_850_992_1001.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_220_1033_592_1121.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(f) Layer 17</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_220_1118_595_1269.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(g) Layer 18</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_612_1034_980_1120.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_609_1119_982_1269.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">(h) Layer 19</div>


<div style="text-align: center;">Figure 7: Overloaded devices and experts across iterations for layer 12-19, with token proportions for different modalities.</div>

---

# OCR 第 18 页

## G Batching pattern

Mixed prefill and decode scheduling. Mixing prefill and decode tokens within a batch naturally arises from the continuous batching mechanism in vLLM under a colocated deployment setting. In this setup, prefill and decode requests are not separated into distinct instances. Instead, the scheduler dynamically forms batches from incoming requests at each step. Moreover, chunked prefill further splits long prefill requests into smaller segments, allowing them to be scheduled together with decode requests within the same batch. This design improves overall utilization and avoids decode starvation. Under this setting, we define an iteration as one continuous batching step, corresponding to a single model forward pass.

Comparison with disaggregated deployment. In contrast, prefill/decode-disaggregated deployment assigns prefill and decode workloads to different instances, typically requiring duplicated resources. Under such settings, ReaLB mainly applies to prefill workers, where the majority of computation and routing decisions occur.

Prefill-dominated batches. Although batches may contain mixed prefill and decode tokens, they are strongly dominated by prefill tokens in our workload. With max-num-seqs=12, a mixed batch contains at most 11 decode tokens (one per request), while prefill tokens occupy the remaining capacity. In practice, decode tokens account for less than 10% of the total tokens per batch, as shown in Figure 8. As a result, under our colocated deployment (used due to limited GPU resources), the observed routing dynamics are largely dominated by prefill tokens, providing a close approximation to a prefill-only setting without explicitly separating prefill and decode execution.

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_373_659_850_821.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_373_834_849_1009.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">Figure 8: Token composition in continuous batching.</div>


<div style="text-align: center;">Table 4: Speedup of ReaLB in the prefill-only setting.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Model</td><td style='text-align: center; word-wrap: break-word;'>MMMU</td><td style='text-align: center; word-wrap: break-word;'>MathVista</td><td style='text-align: center; word-wrap: break-word;'>DynaMath</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Kimi-VL</td><td style='text-align: center; word-wrap: break-word;'>1.35 $ \times $</td><td style='text-align: center; word-wrap: break-word;'>1.33 $ \times $</td><td style='text-align: center; word-wrap: break-word;'>1.34 $ \times $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Qwen-VL</td><td style='text-align: center; word-wrap: break-word;'>1.12 $ \times $</td><td style='text-align: center; word-wrap: break-word;'>1.12 $ \times $</td><td style='text-align: center; word-wrap: break-word;'>1.10 $ \times $</td></tr></table>

## H AIMD-based Adaptive Control Analysis

We analyze the dynamics of the AIMD-based adaptive control on real-world vision-language tasks. The congestion threshold  $ \tau $ is set to 1.5, above which the system is considered to be under severe imbalance (highlighted by the red background in the figures).

Figure 9 illustrates the evolution of the control parameter  $ M_{d} $ over time for two representative multimodal MoE models. When the global imbalance exceeds the threshold,  $ M_{d} $ is rapidly decreased, enabling more aggressive acceleration for overloaded devices with high concentrations of visual

---

# OCR 第 19 页

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_215_141_572_355.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(a) Kimi-VL.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_647_146_1006_357.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(b) Qwen3-VL.</div>


<div style="text-align: center;">Figure 9: Evolution of the control parameter  $ M_{d} $ under AIMD-based adaptive control on DynaMath. The red background indicates time steps where the global imbalance exceeds the congestion threshold.</div>


tokens, thereby improving execution efficiency. In contrast, when the system operates below the congestion threshold,  $ M_{d} $ gradually increases, relaxing the constraint to preserve model accuracy.

These results show that the AIMD-based controller can effectively adapt to dynamic imbalance conditions, achieving a stable balance between efficiency and accuracy.

End-to-end Latency Breakdown. We further report end-to-end latency breakdown on two additional benchmarks, MMMU and MathVista, for Kimi-VL and Qwen3-VL, which are not included in the main paper due to space constraints.

## I Additional Efficiency Results

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_228_757_588_927.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(a) Kimi-VL, MMMU.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_634_757_993_927.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_229_963_588_1130.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(b) Kimi-VL, MathVista.</div>


<div style="text-align: center;">(c) Qwen3-VL, MMMU.</div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_634_962_993_1129.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">(d) Qwen3-VL, MathVista.</div>


<div style="text-align: center;">Figure 10: End-to-end latency breakdown on additional benchmarks.</div>
