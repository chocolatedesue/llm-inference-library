# 图片批次 6

## 图片 1：Figure 11. Pipeline stall recovery time across systems and request distribution variability (CV). FLEXPIPE achieves substantially faster recovery under high-variability workloads (9ms at CV=4), demonstrating the effectiveness of dynamic pipeline refactoring in addressing structural stall causes.

![Figure 11. Pipeline stall recovery time across systems and request distribution variability (CV). FLEXPIPE achieves substantially faster recovery under high-variability workloads (9ms at CV=4), demonstrating the effectiveness of dynamic pipeline refactoring in addressing structural stall causes.](../assets/imgs/img_in_chart_box_636_145_1108_316.jpg)

*来源：OCR 第 12 页。*

### 解读

1. **论文角色与验证问题**：本图对应第 9.3 节"Pipeline Stall Recovery"，证据类型为**实验结论（效果）+ 对比基线**。作者在正文中先给出流水线停滞（stall）的客观定义（延迟超过基线 1.5× 记为停滞，回落到 1.2× 内记为恢复），本图要验证的具体问题是：在不同请求波动程度（CV=1/2/4）下，FLEXPIPE 的"inflight pipeline refactoring"机制能否比静态/离线优化系统更快地从流水线停滞中恢复，尤其是这一优势是否随 CV 增大而扩大 `[正文支持]`。
   - **图表角色**：实验结论 / 对比基线。
   - **上文呼应**：第 9.3 节"Pipeline Stall Recovery"，对应主张地图中"CV=4 时恢复时间 9ms，比 AlphaServe 快 44%，比 MuxServe/ServerlessLLM 快 82%"。

2. **图像类型与布局**：三个并排的箱线图（box plot）子图，分别标注 (a) CV=1、(b) CV=2、(c) CV=4；每个子图内横轴为五个系统（MuxServe、AlpaServe、FlexPipe、ServerlessLLM、Tetris），纵轴均为"Recovery Time (seconds)"，且为对数坐标（从约 0.01s 到 10s）。各系统箱体用不同深浅的绿色/黄绿色区分。

3. **如何阅读**：横向比较同一子图内五个系统的箱体位置（中位数线、箱体范围、须线/离群点），纵向比较三个子图（CV 递增）中同一系统箱体的变化趋势；由于是对数坐标，箱体位置的微小差异对应数量级上的差异。

4. **直接可见的结论**：
   - (a) CV=1 时，五个系统的箱体中位数普遍集中在 0.1s 量级附近，彼此差异不大，FlexPipe 箱体与 AlpaServe 接近，均低于 Tetris `[图像直接可见]`。
   - (b) CV=2 与 (c) CV=4 时，各系统箱体整体上移且离散度（箱体高度、须线长度、上方离群点数量）明显增大，尤其 ServerlessLLM 与 Tetris 的箱体范围显著扩大、中位数上移 `[图像直接可见]`。
   - 在 (c) CV=4 子图中，FlexPipe 的箱体中位数位置相对其余四个系统（尤其 ServerlessLLM、Tetris）更低、箱体更紧凑 `[图像直接可见]`。
   - 三个子图中箱体上方均存在离群点（outliers），且离群点在高 CV 子图中更多、更高 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图属于**效果类**主张的直接证据，支持"FLEXPIPE 相比静态/离线优化系统在高波动负载下恢复更快"这一结论，对应正文报告的具体数值（CV=1 时 FlexPipe 88ms 对比 AlphaServe 83ms、MuxServe 131ms、ServerlessLLM 115ms、Tetris 179ms；CV=4 时 FlexPipe 9ms，比 AlpaServe/MuxServe/ServerlessLLM 分别快 44%/82%/82%）`[正文支持]`。视觉上箱体离散度随 CV 增大而扩大且 FlexPipe 相对收窄，与"inflight refactoring 通过检测拥塞 stage 并针对性重构来缩短停滞时间"的机制设计相呼应，说明该模块的价值在高 CV 场景下更突出 `[基于文中逻辑的推断]`。但该图**不能**证明具体是"KV cache 一致性协议"还是"候选粒度评分函数"哪个子机制贡献了恢复速度优势，两者均未被单独消融 `[基于文中逻辑的推断]`。

6. **适用范围与证据缺口**：本图覆盖论文 82-GPU/42-server 集群、OPT-66B 相关设置下、CV=1/2/4 三种条件、五个对比系统（MuxServe/AlpaServe/FlexPipe/ServerlessLLM/Tetris）的停滞恢复时间箱线图。真实缺口：正文仅给出中位数具体数值，图中箱体的具体四分位数、离群点数量及 y 轴精确刻度线未标注数值，无法从图像本身读出精确的箱体统计量（如 P25/P75）`[图像/像素限制]`。

---

## 图片 2：Figure 13. Performance comparison with production workloads: (a) Average prefill latency across model scales showing FlexPipe's consistent advantage (6.43%-24.38% improvement), (b) Latency distribution showing tighter performance bounds with fewer outliers.

![Figure 13. Performance comparison with production workloads: (a) Average prefill latency across model scales showing FlexPipe's consistent advantage (6.43%-24.38% improvement), (b) Latency distribution showing tighter performance bounds with fewer outliers.](../assets/imgs/img_in_chart_box_636_144_1113_316.jpg)

*来源：OCR 第 13 页。*

### 解读

1. **论文角色与验证问题**：本图对应第 9.5 节"Performance in Production Workloads"，证据类型为**实验结论（效果）+ 适用范围**。前文实验（Fig.8-12）多基于合成的 Azure Functions trace + Splitwise 语料在统一集群上测试；本图要验证的具体问题是：FLEXPIPE 的延迟优势是否在**真实生产工作负载轨迹**、跨越不同规模模型（WHISPER-9B 到 OPT-66B）时依然成立，以及该优势是否随模型规模增大而增强 `[正文支持]`。
   - **图表角色**：实验结论 / 适用范围。
   - **上文呼应**：第 9.5 节"Performance in Production Workloads"，对应主张地图中"OPT-66B 上 prefill 延迟降低 24.38%……整体平均 17.32%"。

2. **图像类型与布局**：两个并排子图。(a) "Prefill Latency"为分组柱状图，横轴为四个模型（WHISPER、LLAMA-7B、BERT-21B、OPT-66B），每组含 FlexPipe（深绿）、AlpaServe（中绿）、ServerlessLLM（卡其色）三根柱子，纵轴为 Latency(s)（0–0.6+s），部分柱子上标注百分比数字（6%、20%、19%、24%）；(b) "Distribution of Prefill Latency"为对应四个模型的箱线图，同样按系统着色，纵轴 Latency(s)（0–1.0s）。

3. **如何阅读**：(a) 组内比较三个系统柱高，组间比较不同模型规模下柱高及百分比标注的变化趋势；(b) 组内比较箱体位置与离散度，判断分布的紧凑程度和离群点情况。两子图共享同一图例（System: FlexPipe/AlpaServe/ServerlessLLM）。

4. **直接可见的结论**：
   - (a) 四个模型分组中，FlexPipe 柱子均低于同组的 AlpaServe 与 ServerlessLLM 柱子；柱高随模型从 WHISPER 到 OPT-66B 增大而整体升高 `[图像直接可见]`。
   - 柱状图上标注的百分比数字（约 6%、20%、19%、24%）随模型规模呈上升趋势，且见于 FlexPipe 柱子附近 `[图像直接可见]`。
   - (b) 箱线图显示 FlexPipe 箱体在四个模型上普遍比 AlpaServe/ServerlessLLM 更低且更紧凑（箱体高度更小、须线更短），尤其在 OPT-66B 上三者箱体位置差异最明显 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图属于**效果类**主张的直接证据，支持正文"FLEXPIPE consistently achieves lower prefill latency across all model scales……average 17.32% latency improvement"的结论 `[正文支持]`。图中百分比标注与正文报告的具体数值（WHISPER 6.43% vs AlpaServe、LLAMA-7B 19.52% vs ServerlessLLM、BERT-21B 18.97% vs ServerlessLLM、OPT-66B 24.38% vs AlpaServe）量级吻合，但**图像本身未标明每个百分比具体是相对哪个基线系统计算的**——这一归属信息只能来自正文，不能仅凭视觉判断 `[基于视觉的谨慎推断]`。(b) 图的箱体收窄进一步支持"更少离群点、更稳定的 SLO 表现"这一说法 `[正文支持]`。该图验证的是"生产真实负载下效果的外部有效性"，但**不能**证明该优势的来源具体是三大模块中的哪一个（分区、inflight refactoring 还是资源分配），因为这是端到端系统级对比 `[基于文中逻辑的推断]`。

6. **适用范围与证据缺口**：本图覆盖论文在生产集群上、四个代表性模型（WHISPER-9B/LLAMA2-7B/BERT-21B/OPT-66B）、仅对比 AlpaServe 与 ServerlessLLM 两个基线（未包含 MuxServe/Tetris）的 prefill 延迟结果。真实缺口：正文虽给出四个改进百分比的具体数值和对应基线归属，但柱状图和箱线图上均未标注具体的纵轴数值刻度，无法从图像本身精确读出各柱高/箱体的绝对延迟数值 `[图像/像素限制]`。
