# 图片批次 4

## 图片 1：Figure 7. The process of model scaling using fine-grained pipeline stages. FLEXPIPE conference satisfies the minimum granularity pipeline stage for loading and executing inference. Then, after traffic changes, it modifies to a coarser granularity pipeline stage with fewer additional overheads.

![Figure 7. The process of model scaling using fine-grained pipeline stages. FLEXPIPE conference satisfies the minimum granularity pipeline stage for loading and executing inference. Then, after traffic changes, it modifies to a coarser granularity pipeline stage with fewer additional overheads.](../assets/imgs/img_in_image_box_110_148_581_406.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：图表角色 = **方法流水线**。它对应第6节 Inflight Pipeline Refactoring 的决策公式 $g^*$（页9）与第7节 Adaptive Pipeline Scaling 的扩容粒度公式 $m_j$、SLO 约束（页9-10），是 Insight 2/3（细粒度流水线抗突发、粗粒度流水线省通信，页5-6）与贡献1（"无需中断服务、根据请求分布动态重构流水线架构"，页2）在系统机制层面的图解说明。`[正文支持]`
   - **上文呼应**：第6-7节（Inflight Pipeline Refactoring / Adaptive Pipeline Scaling 的粒度选择公式）。

2. **图像类型与布局**：流程/机制示意图（非实验曲线或柱状图）。分三段纵向排列：顶部左侧"Initial Model Pipeline: 4 Stages"——4 个绿色方块经网络箭头连接；顶部右侧文字"Constructed by 4 Finest Stages, with Constraint of Computation Graph"。中段红色标题"Bursty Request: Using Fine-Grain Stage to Increase Throughput"，向下箭头"Scaling up"引出两排更细粒度（每排约8个）黄色小方块，标注"Scaling Pipeline Stages: Dynamic Load Balance"、"Parallel Loading in Serverless Instance"、"Data Parallelism using Multi-LLM Stage Replicas"。底部红色标题"Stable Request: Reduce Communication Overhead"，左侧给出 $g^*$ 决策公式与"Scaling Granularity" $m_j$ 公式，右侧两组箭头"Merge g* finest stage"指向合并后仅剩约4个蓝色方块的较粗流水线，标注"Retain the 'Warm' pipelines with Granularity g*"。

3. **如何阅读**：无坐标轴/图例，按从上到下的流程顺序阅读：初始4段流水线 → 突发请求时细分扩容（黄色，双排并行）→ 稳定请求时合并回粗粒度并保留"温"流水线（蓝色）。公式符号与正文 $g^*/m_j$ 一致，但图中不含具体数值。

4. **直接可见的结论**：图中可见流水线在突发请求下从初始4段被进一步细分为更多、更小的stage（约8个一排，两排并行，暗示引入数据并行副本），标注"Dynamic Load Balance"与"Parallel Loading"；在稳定请求场景下，细粒度stage被"Merge g* finest stage"合并回较少方块（约4个），标注"Retain 'Warm' pipelines"。`[图像直接可见]` 图中公式记号与正文 $g^*/m_j$ 对应，但未显示具体参数值或实验读数。`[基于视觉的谨慎推断]`

5. **它验证的论点与方法设计含义**：该图是机制说明类证据，直观呈现 Insight 2/3（细粒度流水线在突发负载下提供弹性和批处理能力，粗粒度在稳定负载下减少通信开销，页5-6）与贡献1在系统层面的具体运作方式：细分（scale up）与合并（merge/retain warm）两条路径分别对应模块二 Inflight Pipeline Refactoring 的决策公式 $g^*$ 和模块三 Adaptive Pipeline Scaling 的扩容粒度公式 $m_j$。`[正文支持, 页码：9-10]` 图像本身不能证明该机制在实际系统中的延迟/吞吐效果——效果层面的验证需依赖 Fig. 8/9/12 等实验图（页11-13）。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：覆盖论文描述的 FLEXPIPE 三模块（细粒度分区、Inflight Refactoring、Adaptive Scaling）协同的机制示意；图注未指明具体模型/参数规模。真实缺口：图中公式涉及的具体参数取值（如 β, σ, λ_max 等）未在图像或可见正文中给出数值，`文中未说明`；图中细分后每排方块的具体数量（约8个）是否对应正文 Table 2 中具体 stage 数（4/8/16/32），图像未标注数字，无法从图像确认。

---

## 图片 2：Figure 9. Latency under highly variable workload (CV=8, first 300s). (a) Request distribution CV variability measured in 15s windows, (b) Response latency comparison across systems.

![Figure 9. Latency under highly variable workload (CV=8, first 300s). (a) Request distribution CV variability measured in 15s windows, (b) Response latency comparison across systems.](../assets/imgs/img_in_chart_box_640_565_1102_821.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：图表角色 = **实验结论**（含对比基线）。对应第9.1节"Burst Absorption"段落（页11-12），验证极端突发工作负载（CV=8）下 FLEXPIPE 相对 AlpaServe 与 MuxServe 的延迟表现，是对贡献1及 Insight 2/3 在极端场景下端到端效果的验证。`[正文支持]`
   - **上文呼应**：第9.1节"Burst Absorption"（Fig. 9，页11-12）。

2. **图像类型与布局**：上下两子面板共享横轴 Time(seconds, 0–300s)。上面板 (a)：浅绿色柱状/面积图表示 Frequency（左纵轴），叠加一条带圆点及数值标注的折线"15s Window CV"（右纵轴 CV，0–3+），折线上标注了约19个具体数值（如2.12、2.44、3.47、0.59等）。下面板 (b)：三条颜色区分的面积/线图——深青色 FlexPipe、中绿色 AlpaServe、浅黄绿色 MuxServe，纵轴 RT(s)（响应时间，0–20s）。

3. **如何阅读**：上下面板横轴时间对齐，用于对照某时刻 CV 波动幅度与对应系统响应时间；下面板需比较同一时间点三条曲线的相对高度，越低代表延迟越小越好；图例标于面板内标明三系统颜色映射。

4. **直接可见的结论**：上面板显示15秒窗口 CV 在300秒内剧烈波动，标注最低值0.59、最高值3.47，无明显周期性规律。`[图像直接可见]` 下面板显示 MuxServe（浅黄绿）曲线整体位置最高、多次接近或达到15–20s区间且波动剧烈；AlpaServe（中绿）曲线呈现若干阶段性峰值，高于 FlexPipe 但多数区间低于 MuxServe；FlexPipe（深青）曲线全程维持在最低且相对平稳的位置，未见与上面板 CV 峰值明显对应的剧烈延迟尖峰。`[图像直接可见]` 三者相对高度差异全程可辨。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图验证的是效果类主张——"在极端 CV=8 突发工作负载下，FLEXPIPE 通过动态流水线重构维持稳定低延迟，而 MuxServe 持续高延迟（正文称'经常超过10秒'）、AlpaServe 出现周期性性能尖峰"。`[正文支持, 页码：12]` 这支撑 Insight 2/3 与贡献1中"实时响应短期负载波动"的设计目标，并与 AlphaServe"仅做离线长期优化、无法响应短期波动"的被批判限制（页码：2）形成对照：图中 AlpaServe 曲线的周期性尖峰即是该限制的可见表现。`[基于文中逻辑的推断]` MuxServe 的持续高延迟对应其"统计复用在高 CV 下延迟持续偏高"的被批判限制（页码：11-12）。该图不能证明具体机制（如 $g^*$ 决策公式本身的最优性）为何有效，只能证明端到端效果差异。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：覆盖论文报告的极端突发场景 CV=8、300秒观测窗口，对比 AlpaServe 与 MuxServe 两个基线系统（未包含 ServerlessLLM 或 Tetris）。`[正文支持, 页码：11-12]` 真实缺口：上面板标注的具体 CV 数值点与下面板延迟曲线在时间轴上的精确逐点对应关系因像素精度限制无法确认；下面板未标注具体 y 轴刻度对应的精确读数，仅可读出大致范围（0–20s），无法给出更精确的数值对比。
