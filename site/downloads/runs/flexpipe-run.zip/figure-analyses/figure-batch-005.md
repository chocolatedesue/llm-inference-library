# 图片批次 5

## 图片 1：Figure 8. End-to-End Latency Breakdown across varying request distributions. FLEXPIPE maintains lower overall latency despite higher communication overhead by significantly reducing queue wait times: (a) CV=1 (stable workload), (b) CV=2 (moderate variability), and (c) CV=4 (highly variable workload).

![Figure 8. End-to-End Latency Breakdown across varying request distributions. FLEXPIPE maintains lower overall latency despite higher communication overhead by significantly reducing queue wait times: (a) CV=1 (stable workload), (b) CV=2 (moderate variability), and (c) CV=4 (highly variable workload).](../assets/imgs/img_in_chart_box_636_149_1108_441.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 9.1 节"End-to-End Performance"中的 Fig. 8，图表角色为**实验结论**（同时包含与多个基线系统的**对比基线**关系）。它验证的具体问题是：在不同请求波动程度（CV=1/2/4）下，FLEXPIPE 相对 AlpaServe、MuxServe、ServerlessLLM、Tetris 的端到端延迟构成（排队时间/执行时间/通信时间）与吞吐（Goodput）表现如何随 CV 变化，用以支撑"细粒度流水线重构以更高通信开销换取更低排队时间"这一核心机制主张 `[正文支持]`。
   - **图表角色**：实验结论 + 对比基线。
   - **上文呼应**：对应第 9.1 节"Latency Breakdown"段落，即 CV=1 时 FLEXPIPE 比 AlphaServe/ServerlessLLM 低 38.3% 延迟、CV=2 时比 MuxServe 低 46.9%、CV=4 时比 AlphaServe/MuxServe 分别低 66.1%/80.6% 的量化主张 `[正文支持, 页码：11]`。

2. **图像类型与布局**：三联并排堆叠柱状图 + 折线图组合，子图分别标注 (a) CV=1、(b) CV=2、(c) CV=4。每个子图内横轴为 5 个系统（FlexPipe、AlpaServe、MuxServe、ServerlessLLM、Tetris），每根柱子由三段颜色堆叠（深绿=Queue Time、深蓝绿=Execution Time、金黄=Communication Time），叠加一条橄榄绿圆点折线表示 Goodput(%)（右侧次坐标轴）。柱顶标注具体响应时间数值。

3. **如何阅读**：左侧主坐标轴为 Response Time (s)，右侧次坐标轴为 Goodput Rate (%)；横向依次比较五个系统在同一 CV 下的延迟构成与吞吐是否维持稳定；三个子图之间比较同一系统随 CV 增大时延迟构成的变化趋势。柱内三段颜色的相对厚度反映排队/执行/通信各自占比。

4. **直接可见的结论**：
   - 三个子图中 FlexPipe 柱体总高度均为五者中最低（(a) 0.83s，(b) 1.00s，(c) 1.45s），且其柱内通信时间段（金黄色）占比随 CV 增大而明显增厚 `[图像直接可见]`。
   - AlpaServe、MuxServe、ServerlessLLM 的柱体总高度随 CV 增大而显著增长（尤其 MuxServe 与 ServerlessLLM 在 (c) 中接近 5s），其柱内主要由绿色 Queue Time 段主导增长 `[图像直接可见]`。
   - Tetris 在三个子图中柱体始终最高（4.31s→5.06s→6.22s），且其对应的 Goodput 折线点位置明显低于其余四个系统（前四者标注/位置显示为接近 100%，Tetris 处则线明显下坠）`[图像直接可见]`。
   - 折线在 (c) 中于 MuxServe/ServerlessLLM 处也出现下坠（标注约 88%附近），显示高 CV 下部分基线吞吐开始下降 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图属于**实验结论**类证据，直接支撑摘要与 9.1 节"FLEXPIPE 在不同 CV 下均降低端到端延迟，且以增加通信开销换取排队时间大幅下降"的效果主张，柱内三段构成的可视化直接呼应文字所述"接受更高通信时间以换取排队等待时间下降"的策略性权衡（机制类主张）`[正文支持]`。Goodput 折线显示 FlexPipe 及主要基线在多数条件下维持接近满吞吐，而 Tetris 吞吐明显更低，佐证 9.4 节"高利用率不等于高有效吞吐"的对比基线论点在此处以延迟视角获得侧面印证 `[基于文中逻辑的推断]`。该图不能单独证明具体的模块归因（例如通信开销增加具体来自哪个内部机制的贡献），也不能证明该现象在不同硬件或模型规模下是否成立。

6. **适用范围与证据缺口**：本图覆盖论文报告的 82-GPU/42-server 集群、OPT-66B 上以 20 QPS 基线、CV=1/2/4 三种设定的端到端延迟与吞吐对比 `[正文支持]`。柱顶及折线各点的精确数值因图像分辨率与标注拥挤（尤其 (c) 图中部分百分比标签相互靠近）存在少量像素级读数不确定性；除此之外无额外证据缺口。

---

## 图片 2：Figure 10. Performance stability analysis across varying request distributions (CV=1, 2, 4), showing FLEXPIPE maintains consistently lower latency percentiles even as workload variability increases in serverless.

![Figure 10. Performance stability analysis across varying request distributions (CV=1, 2, 4), showing FLEXPIPE maintains consistently lower latency percentiles even as workload variability increases in serverless.](../assets/imgs/img_in_chart_box_110_148_582_340.jpg)

*来源：OCR 第 12 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 9.2 节"Performance Stability"中的 Fig. 10，图表角色为**实验结论**（含**对比基线**）。它验证的具体问题是：随着请求分布 CV 从 1 增至 4，FLEXPIPE 与两类代表性 Serverless 部署方案（ServerlessLLM、Tetris）在不同延迟分位点（P50–P99）上的稳定性差异，用以支撑"静态 Serverless 架构在高分位点出现指数级延迟退化，而 FLEXPIPE 的动态流水线重构能维持稳定分位延迟"这一鲁棒性/稳定性主张 `[正文支持]`。
   - **图表角色**：实验结论 + 对比基线。
   - **上文呼应**：对应第 9.2 节"我们重点关注 ServerlessLLM 和 Tetris 作为代表性 Serverless LLM 部署方案"及"CV 从 1 增至 4 时，FLEXPIPE 维持可控 P99 延迟，而竞争对手出现 2–3× 退化"的文字主张 `[正文支持, 页码：12]`。

2. **图像类型与布局**：三联并排折线图，子图分别标注 (a) CV=1、(b) CV=2、(c) CV=4。每个子图内三条折线分别代表 FlexPipe（深色圆点、实线）、ServerlessLLM（绿色方块、虚线）、Tetris（浅绿色菱形、虚线），横轴为延迟分位点 (50, 75, 90, 95, 99)，纵轴为 Response Time (s)，各数据点标注具体数值。

3. **如何阅读**：横轴从左到右分位点递增（P50→P99），代表延迟分布的尾部严重程度；纵轴为响应时间；比较同一子图内三条线在各分位点处的垂直间距，间距越大代表该系统在该分位点相对越差；再横向比较三个子图（CV 递增）观察各系统线形随负载波动加剧而抬升/发散的程度。

4. **直接可见的结论**：
   - 在三个子图中，FlexPipe 曲线始终位于最下方且斜率最平缓，从 P50 到 P99 抬升幅度明显小于另外两条线 `[图像直接可见]`。
   - ServerlessLLM 与 Tetris 曲线随分位点上升而明显更陡峭地抬高，且 Tetris 曲线整体位于三者中最高位置 `[图像直接可见]`。
   - 三个子图对比显示，随着 CV 从 1 增至 4，ServerlessLLM 与 Tetris 在 P99 处的数值持续增大（例如 (a) 中 Tetris 顶端约 6.1s，到 (c) 中约 8.8s），而 FlexPipe 在 P99 处的数值增幅相对更小（约 1.3→3.3s 区间）`[图像直接可见]`。
   - 三条曲线在 P50 处彼此更接近，差距随分位点右移逐渐拉大，形成"喇叭口"发散形态，在 (c) 子图中该发散更为显著 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图属于**实验结论**类证据，直接支撑 9.2 节"FLEXPIPE 在所有分位点尤其 P90–P99 保持更低且更一致的延迟，此优势随 CV 增大而更明显"的稳定性主张（效果类）`[正文支持]`。三线在高分位点发散、且发散随 CV 增大而加剧的可见形态，为文字所述"竞争者出现 2–3× 尾部退化"提供了直接的可视化支持，说明 FLEXPIPE 的动态流水线重构机制主要作用于压制尾部（高分位）延迟膨胀，而非仅改善中位数表现 `[基于文中逻辑的推断]`。该图不能证明这种尾部延迟改善的具体内部归因（例如具体是队列监控触发重构还是数据并行副本调整所致），这些机制细节由第 6 节文字与 Fig. 6/Fig. 11 等其他证据分别支撑，本图仅提供分位延迟层面的整体效果证据。

6. **适用范围与证据缺口**：本图覆盖论文报告的同一 82-GPU 集群设置下，FlexPipe 与 ServerlessLLM、Tetris 两个 Serverless 基线在 CV=1/2/4 下的延迟分位数对比，AlpaServe/MuxServe 未纳入本图对比范围（正文说明本节"重点关注 ServerlessLLM 和 Tetris"）`[正文支持]`。部分数据点标签因文字与线条重叠导致个别数值在像素层面难以完全精确区分（尤其低分位点密集处），除此之外无额外证据缺口。
