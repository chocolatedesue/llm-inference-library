# 图片批次 3

## 图片 1：Figure 5. FLEXPIPE system architecture showing the three core components: ① Fine-Grained Pipeline Model Partitioning that decomposes LLMs at operator level for optimal adaptability, ② Inflight Pipeline Refactoring that dynamically adjusts pipeline granularity based on request patterns, and ③ Adaptive Pipeline Scaling that enables efficient resource allocation during traffic fluctuations.

![Figure 5. FLEXPIPE system architecture showing the three core components: ① Fine-Grained Pipeline Model Partitioning that decomposes LLMs at operator level for optimal adaptability, ② Inflight Pipeline Refactoring that dynamically adjusts pipeline granularity based on request patterns, and ③ Adaptive Pipeline Scaling that enables efficient resource allocation during traffic fluctuations.](../assets/imgs/img_in_image_box_642_150_1096_533.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：这是 Section 4 System Overview 中的 Figure 5，展示 FLEXPIPE 整体系统架构，将 Introduction/摘要中列出的三大贡献（细粒度模型分区、Inflight Pipeline Refactoring、拓扑感知/自适应扩缩容）落实为一张离线（Offline，§5）+在线（Online，§6/§7）两阶段的系统流程图，其证据类型为**方法流水线**：不是验证某个实验数值，而是解释各模块如何组织、彼此如何交互，为后续 §5–§7 的公式与算法提供整体框架 `[正文支持]`。
   - **图表角色**：方法流水线。
   - **上文呼应**：对应 Section 4 "System Overview" 段落("As illustrated in Fig. 5, FLEXPIPE comprises three synergistic components")及其后对 Fine-Grained Pipeline Model Partitioning、Inflight Pipeline Refactoring、Adaptive Pipeline Scaling 三段的文字描述。

2. **图像类型与布局**：流程图（架构图），由虚线分隔为上下两大区块：上半部分标注"OFFLINE §5"（黄色标签），下半部分标注"ONLINE"（绿色虚线框）。左侧另有独立的"Users"框通过"Prompts/Response"与在线区块交互。图中用编号圆圈①②③标出三个核心组件位置：①在 Offline 区的"Model Partitioning"模块；②在 Online 区的"Pipeline Refactoring"模块；③在 Online 区的"Adaptive Scaling"模块。方框用箭头连接表示数据/控制流方向，且用不同颜色区分模块类别（如 Model Partitioning 用深色高亮、Pipeline Refactoring 和 Adaptive Scaling 用绿色边框条状图标）。

3. **如何阅读**：上半部分（Offline）从左至右为 Model Developer → Pretrained Models → Profiling（输出 Operator-Level Performance）→ Model Partitioning①（输出 Executable Model Stages，用二进制图标示意"可执行模型段"）→ Storage；旁边并列 Configs 框，接收 Profiling 的 Model Param.(latency, memory) 并向 Storage 提供 Positions。下半部分（Online）从左至右/上下：Users 通过 Prompts/Response 与 API Manager 交互；API Manager 与 Scheduler 通过"Update API"互联；Scheduler 与 Resource Monitor 通过"GPU, Mem Utilization"互联；Resource Monitor 向 Pipeline Refactoring②传递"CV, Latency"；Pipeline Refactoring②与 Performance Controller 通过"Instance TP, latency feedback"互联；Performance Controller 与 Adaptive Scaling③通过"TP Update"及"SLO, TP notify"双向互联；Adaptive Scaling③再通过"QPS, SLO"与 API Manager 相连，形成闭环。阅读顺序建议：先看上半部分的离线一次性分区流程，再看下半部分的在线监控-决策-执行闭环。

4. **直接可见的结论**：图中三个编号组件（Model Partitioning①、Pipeline Refactoring②、Adaptive Scaling③）确实分处离线/在线两个区域，且在线部分由 Resource Monitor 提供的 CV/Latency/GPU 利用率信号驱动 Pipeline Refactoring 和 Adaptive Scaling 两个模块的决策，二者与 Performance Controller 之间存在双向反馈箭头，形成闭环而非单向流水线 `[图像直接可见]`。Offline 部分的 Model Partitioning 输出经 Storage 落盘后，在线的 Pipeline Refactoring 通过 Storage 隐含读取(图中未画出显式箭头连接 Storage 与在线区块) `[基于视觉的谨慎推断]`。

5. **它验证的论点与方法设计含义**：该图属于**方法流水线**类证据，对应摘要与 Introduction 中"三大挑战对应三大创新"的整体设计逻辑——即模型分区(①)在离线阶段一次性完成、并为在线阶段的粒度切换保留可重构性；在线阶段由实时 CV/队列信号驱动 Pipeline Refactoring(②)与 Adaptive Scaling(③)的联动决策 `[正文支持]`。这直接支持论文 Story 中"三个系统组件依次解决三个技术难题"的论证结构，说明 Inflight Refactoring 与 Adaptive Scaling 并非独立模块，而是通过 Performance Controller 共享反馈回路。该图不能证明任何具体的性能收益数值或算法最优性（如决策延迟<5ms、8.5×效率提升等），这些主张需由后续实验图（Fig. 8–13）验证；此图也未展示分区算法内部（Eq. in §5）或粒度选择公式（Eq. in §6.1）的具体计算逻辑，只呈现模块间的宏观数据/控制流 `[基于文中逻辑的推断]`。

6. **适用范围与证据缺口**：本图覆盖论文 FLEXPIPE 系统的整体架构设计，适用于其全部评测场景（不局限于某一模型或某一 CV 值）。图中 Storage 与 Online 区块之间、以及 Configs 与 Scheduler 之间是否存在直接连接线在图像中不易分辨清楚；但这属于架构图的连接细节，正文 §4 已用文字描述了模块间的因果关系（如"Storage"保存 Executable Model Stages 供在线读取），故不构成规则要求的真实缺口。无额外证据缺口。

---

## 图片 2：Figure 6. Inflight pipeline refactoring mechanism. (a) Stage refinement process where fine-grained partitioning occurs by evicting parameters and redistributing them onto additional GPUs; (b) Temporal sequence diagram showing synchronization protocol during refactoring; (c) Stage consolidation process where parameters from multiple stages are merged, utilizing host memory caching to minimize loading overhead from persistent storage.

![Figure 6. Inflight pipeline refactoring mechanism. (a) Stage refinement process where fine-grained partitioning occurs by evicting parameters and redistributing them onto additional GPUs; (b) Temporal sequence diagram showing synchronization protocol during refactoring; (c) Stage consolidation process where parameters from multiple stages are merged, utilizing host memory caching to minimize loading overhead from persistent storage.](../assets/imgs/img_in_image_box_638_146_1109_483.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：这是 Section 6 "Inflight Pipeline Refactoring" 中的 Figure 6，其证据类型为**机制**：具体说明该系统核心模块（贡献1、对应挑战②"如何在不中断服务前提下完成流水线粒度切换与缓存一致性迁移"）内部是如何执行"扩展(refinement)"与"合并(consolidation)"两类粒度切换操作的，回应第 6 节开头提出的核心挑战——"在时变请求分布下动态调整流水线粒度，同时保持硬件效率与一致性" `[正文支持]`。
   - **图表角色**：机制。
   - **上文呼应**：对应 Section 6 引言段（"we design an inflight pipeline refactoring mechanism (Fig. 6)"）及 §6.3 Consistency Maintenance 中提到的"asynchronous KV cache transfers (Fig. 6(b))"、"refinement process (Fig. 6(a))"、"consolidation (Fig. 6(c))"。

2. **图像类型与布局**：三段式流程示意图组合。(a) "Pipeline Expansion" 为一条从左到右的阶段条形序列图，用编号①②③④标出四个操作步骤，条形颜色区分"Splited Stage"（浅绿色）与图例中的"New Instance"（紫色边框）、"Reserved Stage"（绿色边框）两种状态标记；(b) "Reconstruct Process" 为左右两栏的文字+箭头时间线示意图，左栏（红色标题"Pipeline expansion to handle burst request"）与右栏（蓝色标题"Reduce pipeline depth to lower overhead"）各自列出一串按时间顺序执行的操作框，中间用"Pipeline Reconstruct"节点连接，底部标注"Time"箭头表示时间轴方向；(c) "Enlarge Pipeline Stage" 同样为条形阶段序列图，用编号①②③④标出四个步骤，并用图标（缓存图标、层状合并图标、直方图状"Activation Recompute"图标）辅助说明每步操作内容。

3. **如何阅读**：(a) 应按①→②→③→④顺序阅读："Load Stage in New Instance(Splited Stage)"→"Layer-wised Merge State"→"Pipeline Reconstruct and Update Gateway"→"Evict from GPU to Host Mem"，对照图例中紫色"New Instance"和绿色"Reserved Stage"色块区分新旧实例角色；(b) 应分别沿左栏（扩展场景）和右栏（缩容场景）自上而下按时间顺序阅读，两栏中部经由共同的"Pipeline Reconstruct"节点交汇，代表两种触发条件（突发流量 vs 负载趋稳）分别导向的操作序列；(c) 同样按①→②→③→④顺序阅读："Load New Stages"（缓存图标）→"Layer-Wised State Merge"（多色块图标）→"Activation Recompute"（柱状图图标）→"Stage Reconstruct/Update LoadBalancing"。

4. **直接可见的结论**：(a)中被拆分的新增 Stage 先加载到"New Instance"上，再经历状态合并、流水线重构与网关更新，最后才把参数从 GPU 逐出到 Host Memory，四步呈线性时序排列 `[图像直接可见]`；(b)中扩展与缩容两条路径都在时间线上显式包含"Pipeline Reconstruct"这一共同步骤，且缩容路径（右栏）比扩展路径（左栏）列出的操作框数量更多（图中右栏文字步骤明显多于左栏）`[图像直接可见]`；(c)显示合并多个 Stage 时需要"Layer-Wised State Merge"和"Activation Recompute"两个专门步骤，而非直接拼接 `[图像直接可见]`。三个子图均未包含任何数值坐标轴或性能读数 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图属于**机制**类证据，具体化了 §6.3 中"KV cache 一致性通过选择性同步而非全局状态复制"这一设计论点——(a)与(c)分别对应"精细化(refinement)"与"合并(consolidation)"两种粒度切换方向，图中"Layer-wised Merge State"与"Evict from GPU to Host Mem"步骤直观印证了正文所述"异步 KV cache 传输在原流水线仍继续推理的同时进行"的机制描述 `[正文支持]`；(b)的双栏时间线进一步表明扩展与缩容触发路径不同但共享"Pipeline Reconstruct"这一核心动作，支持论文"扩展/缩容是同一重构框架的两个方向"这一方法设计逻辑。该图能够解释重构机制的操作步骤组成，但**不能**证明该机制在真实高频切换下的正确性（即 KV cache 一致性协议是否会引入错误结果），这与主张地图中已标注的证据缺口一致——正文和该图均未提供独立于端到端延迟指标之外的"一致性/正确性验证实验" `[基于文中逻辑的推断]`；该图也不能证明具体的耗时数值（如决策延迟<5ms 出自正文其他段落，非本图）。

6. **适用范围与证据缺口**：本图覆盖 FLEXPIPE 通用的流水线重构机制设计，不针对某一具体模型或 CV 值，属于系统机制说明而非某次特定实验的结果图。图(b)中左右两栏具体每个操作框对应的耗时、触发阈值等量化细节在图像中未标注数字，且正文 §6.3 也仅定性描述该流程，未给出各步骤具体耗时拆分或量化数据；此为正文明确未报告的实验设计细节，构成真实缺口。除此之外无额外证据缺口。
