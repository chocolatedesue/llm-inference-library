# 图片批次 1

## 图片 1：Figure 1. Request distribution CV (coefficient of variation) variations across different periods. Significant mismatches exist in CV calculated with different window sizes (180s, 3h, 12h), variation exists. (a) Request distribution CV of Alibaba Trace, (b) Request distribution CV of Top-1 App, and (c) Top-2 App from Azure [57].

![Figure 1. Request distribution CV (coefficient of variation) variations across different periods. Significant mismatches exist in CV calculated with different window sizes (180s, 3h, 12h), variation exists. (a) Request distribution CV of Alibaba Trace, (b) Request distribution CV of Top-1 App, and (c) Top-2 App from Azure [57].](../figure-groups/page-0002-5d18fe5b63f1.png)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：本图为 Figure 1，对应 Introduction（页 1）中"Production analysis of Alibaba clusters reveals... workload volatility: request patterns exhibit extreme variability with coefficient of variation (CV) fluctuating up to 7× across timeframes (Fig. 1)"。证据类型为**问题严重性**（根问题重要性的量化证据），试图验证"请求分布的波动性极高、且用不同时间窗口测得的 CV 结果彼此不一致"这一现象，为后文"静态流水线无法适配动态波动"的论证提供根源性依据。`[正文支持]`
   - **图表角色**：问题严重性
   - **上文呼应**：第 1 节 Introduction，"workload volatility" 根问题的实验支持；第 3.3 节（页 5-6）Fig. 3/4 的波动性分析建立在此基础之上。

2. **图像类型与布局**：三个独立折线图子面板（Panel 1/2/3），分别标注为 (a) Alibaba Trace、(b) Top-1 App、(c) Top-2 App。每个子图内均含三条曲线，用图例区分：蓝色=180s 窗口、绿色=3h 窗口、橙色=12h 窗口；横轴为日期（Panel1 跨约一个月 D1-D31，Panel2/3 跨约一周 D1-D7），纵轴为 CV 值。

3. **如何阅读**：横轴为时间（不同面板时间跨度不同），纵轴为 CV；同一面板内比较三条不同窗口尺寸曲线的高低与波动幅度差异，跨面板比较三个不同数据源（Alibaba Trace vs 两个 Azure Top App）的 CV 绝对量级与形态差异。

4. **直接可见的结论**：Panel 1（Alibaba Trace）：三条曲线整体量级最低，180s（蓝）多在 0-2 之间但在约 D6 附近出现约 6 的尖峰；3h（绿）在 0-3 间波动；12h（橙）在 1-4 间相对平滑但仍有峰谷。Panel 2（Top-1 App）：整体量级明显更高，180s（蓝）多次出现剧烈尖峰（可达约 20+），3h/12h（绿/橙）大致在 15-25 间震荡。Panel 3（Top-2 App）：180s（蓝）基线约 4-6，在约 D2-D3 处有一个约 13 的显著尖峰，3h/12h（绿/橙）大致在 4-7 间较平滑，D4-D5 附近出现下凹。三个面板之间 CV 绝对范围差异悬殊（约 0-6 vs 约 0-25 vs 约 4-13），且同一面板内不同窗口大小得到的 CV 曲线走势并不一致（例如短窗口常出现长窗口未捕捉到的尖峰）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：这是一条**效果类**证据，直接支撑正文"CV 计算窗口不同（180s/3h/12h）会导致数值显著不一致，且跨时间段 CV 波动可达 7×"的陈述——图中三条曲线彼此错位、且三个应用/数据源的 CV 绝对量级差异巨大，直观印证了请求波动的"多尺度不一致性"，是 FLEXPIPE"需要实时监测 CV 并动态调整流水线粒度"这一设计动机（对应 Inflight Pipeline Refactoring 模块，页 7-9）的根源性证据。该图不能证明 FLEXPIPE 具体如何响应这些波动（那是 Algorithm 1/公式机制层面的证据），也不能被用来精确复现"7×"这一具体倍数的计算来源。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文两周分析中的 Alibaba 生产集群 trace 以及来自 Azure 的两个代表性应用（Top-1、Top-2 App），测量窗口为 180s/3h/12h。真实缺口：正文只笼统给出"7× variation"这一结论，但未说明该倍数具体是基于哪个面板、哪两个数值点的比值计算得出，图像本身也无法唯一定位该比值的来源坐标点，属于图题/正文未指明的细节缺口。

---

## 图片 2：Figure 2. Resource fragmentation in Alibaba. (a) GPU subscription rate averaging 216%, indicating significant resource overcommitment, and (b) Heatmap revealing spatially scattered GPU availability patterns that impede formation of high-bandwidth interconnected GPU groups needed for tensor parallelism.

![Figure 2. Resource fragmentation in Alibaba. (a) GPU subscription rate averaging 216%, indicating significant resource overcommitment, and (b) Heatmap revealing spatially scattered GPU availability patterns that impede formation of high-bandwidth interconnected GPU groups needed for tensor parallelism.](../figure-groups/page-0004-af1fd5c2db15.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图为 Figure 2，对应第 3.1 节"Resource Fragmentation in Cloud"（页 3-4）。Panel (a) 对应"a striking 216% average GPU subscription rate...indicating that two services typically share each GPU"；Panel (b) 对应"co-locating 4 GPUs on the same server drops to 0.02%"及"the scattered distribution of available GPUs (Fig. 2b) creates persistent misalignment between physical topology and logical requirements"。证据类型为**问题严重性**，验证"资源过度订阅+空间碎片化"这一根问题的具体表现。`[正文支持]`
   - **图表角色**：问题严重性
   - **上文呼应**：第 3.1 节资源碎片化分析，直接支撑 Insight 1（页 4：资源碎片化阻碍通信密集型并行策略）。

2. **图像类型与布局**：两个子图。(a) 为带阴影区间的折线图，展示 C1（蓝）、C2（橙）两条 GPU 订阅率曲线随时间变化，并有一条虚线标示 100% Subscription 基准；橙色阴影表示 C2 的波动范围。(b) 为热力图（heatmap），行为 48 台抽样服务器节点（Node IDs），列为 12 小时时间轴，颜色深浅（浅黄到深绿）表示该节点在该时刻的 Available GPUs (Idle) 数量（色标范围约 0-4.0）。

3. **如何阅读**：(a) 横轴为时间，纵轴为 GPU Subscription (%)，比较 C1/C2 曲线相对于 100% 基准线的位置及波动幅度。(b) 横轴为 12 小时时间，纵轴为 48 个采样节点，通过颜色深浅判断某节点某时刻的空闲 GPU 数量，进而观察空闲资源在空间（跨节点）与时间上是否连续聚集。

4. **直接可见的结论**：(a) C1、C2 两条曲线绝大部分时间都持续高于 100% 基准线；C2（橙）整体高于 C1（蓝）且波动更剧烈，阴影区间显示局部可达约 900% 附近的高点；C1（蓝）相对平稳，多集中在约 150%-250% 区间。(b) 热力图中颜色分布零散、不规则，绝大多数格子颜色偏浅（idle GPU 数量低，多接近 0-1），仅少数几行/几个时间点出现较深的绿色（数值接近 4），且这些深色格子在不同节点、不同时间点上零星、不连续地分布，没有形成跨多个相邻节点或跨连续时间段同时保持高 idle 值的色带。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：(a) 支撑**效果类**主张——曲线持续显著高于 100% 直接印证正文"216% 平均订阅率"的过度订阅现象，是资源碎片化的成因之一（页 3-4："aggressive oversubscription maximizing utilization at the cost of availability"）。(b) 支撑**机制类**主张——热力图显示空闲 GPU 在空间和时间上高度分散、深色区（多 GPU 同时空闲）稀少且不连续，直观解释了"为何难以凑齐同机相邻多个高带宽互联 GPU"，从而为张量并行在该环境下不可行、进而必须依赖流水线并行（对应 Insight 1 及 Fine-Grained Model Partitioning 模块的设计前提）提供了空间分布层面的可视化依据。该图不能证明"0.02% 同机 4 卡可用概率"这一精确统计量的计算过程（该数值来自正文统计口径，图仅提供直观佐证），也不能推广到论文未分析的其他生产集群。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本图覆盖论文两周分析中的 Alibaba 云集群（C1 推理专用集群、C2 训练推理混合集群；热力图为 48 台抽样服务器、12 小时时间窗口）。真实缺口：热力图色标标注范围为 0-4.0（含非整数刻度，如 0.5/1.5 等），但正文未说明该数值是否严格对应"空闲 GPU 整数计数"还是某种归一化/插值后的连续指标，图像本身也无法明确澄清这一标注与预期离散 GPU 计数之间的换算关系。
