# 图片批次 2

## 图片 1：Figure 3. Impact of request distribution variability on pipeline performance. (a) Goodput decreases by 37% as CV increases from 0.1 to 8 due to resource contention; (b) Average queue length grows nearly 4× with increasing CV, indicating pipeline congestion; (c) Stall cycle ratio increases exponentially (22×) at high CV values, showing how static pipelines become inefficient under variable workloads.

![Figure 3. Impact of request distribution variability on pipeline performance. (a) Goodput decreases by 37% as CV increases from 0.1 to 8 due to resource contention; (b) Average queue length grows nearly 4× with increasing CV, indicating pipeline congestion; (c) Stall cycle ratio increases exponentially (22×) at high CV values, showing how static pipelines become inefficient under variable workloads.](../figure-groups/page-0005-3266f66c293d.png)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：本图对应第3.3节"Pipeline Overhead in Request Distributions"，是"根问题"部分关于CV波动破坏静态流水线效率这一主张的核心量化证据；证据类型为**问题严重性**——用于回答"CV波动到底在多大程度上损害静态4-stage流水线的性能"这一具体问题，而非展示FLEXPIPE自身方案的效果 `[正文支持]`。
   - **图表角色**：问题严重性
   - **上文呼应**：第3.3节；对应"根问题"中"静态流水线场景下平均GPU利用率仅17%""goodput随CV上升而下降37%"等效果类主张。

2. **图像类型与布局**：三个独立柱状图（Panel 1 Goodput、Panel 2 Queue Length、Panel 3 Stall Cycle），横轴均为CV离散取值（0.1、1、2、4、8），柱体颜色由浅绿到深绿随CV递增；Panel 2带误差棒，各柱顶均标注具体数值。

3. **如何阅读**：横轴为CV（负载波动程度），纵轴分别为Goodput（req/sec）、Queue Length（长度）、Stall Cycle（秒）；应比较同一面板内不同CV下柱高的变化趋势，而非跨面板比较绝对数值。

4. **直接可见的结论** `[图像直接可见]`：
   - Goodput在CV=0.1/1/2时基本持平（20.0、20.0、20.4），CV=2以后显著下降，CV=4降至15.4，CV=8降至12.7。
   - Queue Length随CV单调上升：12.5→16.0→25.8→51.2→48.8，在CV=2到CV=4之间跳升最大。
   - Stall Cycle从CV=0.1的0.15s、CV=1的0.24s、CV=2的0.49s缓慢增长，随后在CV=4骤增至2.26s、CV=8增至3.36s，呈明显非线性跳变。

5. **它验证的论点与方法设计含义**：三面板共同支持"根问题"中效果类主张——CV增大导致goodput下降约37%（20.0→12.7，实测约36.5%）、queue length增长近4×（12.5→48.8，实测约3.9×）、stall cycle增长约22×（0.15→3.36，实测约22.4×），与正文数值高度吻合 `[正文支持]`。Stall Cycle在CV=1到CV=4之间从0.24s增至2.26s（约9.4×，对应正文"nearly 10×"表述）进一步印证正文强调的非线性恶化。该图属于问题严重性证据，为后续"需要动态调整流水线粒度"的方法设计提供必要性论证，但**不能**证明FLEXPIPE自身机制的有效性——那部分证据由第9节Fig.8-13承担 `[基于文中逻辑的推断]`。

6. **适用范围与证据缺口**：本图覆盖静态4-stage OPT-66B流水线，baseline QPS=20，CV测量范围0.1-8（第3.3节明确说明）。无额外证据缺口。

---

## 图片 2：Figure 4. Latency distribution across different request patterns. (a) Box plot comparing pipeline granularities across varying CV values, showing fine-grained pipelines perform better with high-variability workloads; (b) Detailed latency distribution for CV=4 with 4-stage pipeline, revealing significant variance from pipeline stalls.

![Figure 4. Latency distribution across different request patterns. (a) Box plot comparing pipeline granularities across varying CV values, showing fine-grained pipelines perform better with high-variability workloads; (b) Detailed latency distribution for CV=4 with 4-stage pipeline, revealing significant variance from pipeline stalls.](../figure-groups/page-0006-6be2eefe26a5.png)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图对应第3.3节，是"核心洞见2/3"（细粒度流水线在突发负载下更具弹性、最优stage数应随CV调整）的直接可视化证据；证据类型为**机制**——回答"流水线粒度（4/8/16 stage）与CV之间的此消彼长关系具体表现为怎样的延迟分布"`[正文支持]`。
   - **图表角色**：机制
   - **上文呼应**：第3.3节 Insight 2/3；对应Story"16段流水线在CV=4时平均延迟仅为4段的1/3"这一效果类主张。

2. **图像类型与布局**：两个子图。(a) 箱线图，横轴为CV（0.1、1、2、4）分组，每组内含4-stage（浅黄）、8-stage（浅绿）、16-stage（深绿）三个箱体；(b) 核密度分布图，仅针对CV=4场景，横轴为Latency(s)，纵轴为Density，三条曲线对应三种stage配置。

3. **如何阅读**：(a) 应比较同一CV分组内三种stage配置箱体的中位线高度、箱体宽度及离群点，判断哪种配置延迟更低更稳定；(b) 应比较三条密度曲线的峰值位置（延迟高低）和峰值宽度（波动大小）。

4. **直接可见的结论** `[图像直接可见]`：
   - (a) CV=0.1时三种配置箱体均低而窄，差异不大；CV=1时4-stage中位数明显高于8/16-stage；CV=2、CV=4时4-stage箱体显著抬升且范围拉宽（CV=4上须及离群点接近或超过10s），而16-stage箱体在CV=4时保持最低最集中（中位数明显低于4-stage与8-stage）。
   - (b) CV=4时，4-stage（黄）密度峰值位于约8-9s附近且分布较宽；8-stage（浅绿）峰值居中，约2-4s；16-stage（深绿）峰值最低（约1-2s）且曲线最窄最高，即延迟最集中于低值区间。

5. **它验证的论点与方法设计含义**：(b)图直接可视化支持"16段流水线在CV=4时平均延迟仅为4段的1/3"这一效果类主张 `[正文支持]`；同时(a)图显示低CV（0.1、1）时细粒度（16-stage）并未表现出明显优势（部分甚至更差），说明"细粒度更优"仅在高CV场景下成立，是一个**适用边界**而非普适结论——这正是FLEXPIPE需要在第6节设计"inflight pipeline refactoring"以根据实时CV动态切换粒度的核心动机 `[基于文中逻辑的推断]`。该图证明的是"stage数与CV存在此消彼长关系"这一前提性观察，**不能**证明FLEXPIPE自动切换机制本身的正确性或效率（该部分由Algorithm 1及第9节实验承担）。

6. **适用范围与证据缺口**：本图覆盖4/8/16-stage OPT-66B流水线在CV=0.1/1/2/4（(a)）及CV=4单一场景（(b)）下的延迟分布测量。无额外证据缺口——各面板可辨读的趋势与正文"4-stage/8-stage在低CV下约0.5s、16-stage在低CV下约1.2s（2.7×）、16-stage在CV=4时约为4-stage 1/3"等描述一致，未见冲突。
