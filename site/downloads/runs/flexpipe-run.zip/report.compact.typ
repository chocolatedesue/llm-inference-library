#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[FLEXPIPE: Adapting Dynamic LLM Serving Through Inflight Pipeline Refactoring in Fragmented Serverless Clusters]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yanying Lin, Shijie Peng, Chengzhi Lu, Chengzhong Xu, Kejiang Ye]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[European Conference on Computer Systems (EUROSYS '26) · 2026]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM Serving] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Pipeline Parallelism] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Serverless Computing] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[资源碎片化] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[动态调度]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[DOI：https://doi.org/10.1145/3767295.3769316]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

在生产环境中服务大语言模型（LLM）面临着请求模式高度多变以及无服务器集群中资源严重碎片化所带来的重大挑战。现有系统依赖静态的流水线配置，难以适应动态变化的负载条件，导致效率严重低下。我们提出了FLEXPIPE，一个能够在运行时动态重新配置流水线架构以解决这些根本性限制的新系统。FLEXPIPE将模型分解为细粒度阶段，并根据实时请求模式分析智能调整流水线粒度，实现了三项关键创新：在保留计算图约束的前提下进行细粒度模型划分、具备一致缓存转换的运行中流水线重构，以及能够应对GPU资源碎片化的拓扑感知资源分配。在一个拥有82块GPU的集群上进行的综合评估表明，与最先进的系统相比，FLEXPIPE在保持38.3%更低延迟的同时，资源效率提升高达8.5倍，并将GPU预留需求从峰值容量的75%降低到30%。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [FLEXPIPE: Adapting Dynamic LLM Serving Through Inflight Pipeline Refactoring in Fragmented Serverless Clusters],
    [作者], [Yanying Lin, Shijie Peng, Chengzhi Lu, Chengzhong Xu, Kejiang Ye],
    [发表场所 / 年份], [European Conference on Computer Systems (EuroSys \'26), 2026],
    [研究领域], [分布式系统、LLM 推理服务],
    [关键词], [LLM Serving, Pipeline Parallelism, Serverless Computing, 资源碎片化, 动态调度],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：#link("https://doi.org/10.1145/3767295.3769316")
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（5 个）]：`LLM推理服务` · `流水线并行` · `Serverless计算` · `资源碎片化` · `动态调度`
]

FLEXPIPE 是一个面向碎片化 Serverless 集群的 LLM 推理服务系统，其核心方法是让流水线（把模型按层切成多个连续处理段，像装配线一样逐段处理请求）的段数（粒度）能在运行时根据请求波动程度（用变异系数 CV 衡量）动态重构，而非采用现有系统的固定配置；在 82-GPU 集群评测中，作者报告资源效率最高提升 8.5 倍、端到端延迟最低降低 38.3%、GPU 常驻预留从峰值容量的 75% 降至 30% `[作者明确陈述；实验支持]`。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- #strong[OCR 覆盖范围]：文本证据覆盖论文第 1--14 页的引言、根问题分析、方法设计（第 4--7 节）与实验（第 9 节）；图表证据覆盖 Fig. 1、2、3、4、5、6、8、9、10、11、12 共 11 组图（第 2、4、5、6、8、10、11、12、13 页），另有 1 张图片超出分析上限未处理 `[基于文中逻辑的推断]`。
- #strong[明显缺失或损坏]：分区算法（第5节）、KV cache 一致性协议（6.3节）、拓扑资源协调（HRG，第7节）均无独立消融实验；多个公式中的校准参数（如 $alpha\,beta_1\,beta_2\,gamma_0\,sigma\,lambda$ 等）未给出具体取值或标定方法 `文中未说明`。
- #strong[区分论文事实与背景知识]：本报告中所有性能数字、机制描述均取自 OCR 文本与图表证据分析，标注为作者陈述或实验支持；术语的通俗类比属于背景知识，不代表论文原文表述。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

#strong[问题定义]：LLM 参数规模达数千亿，单设备内存无法容纳，必须做分布式推理；主流方案是张量并行（需要设备间高带宽互联）和流水线并行（只需点对点通信）`[作者明确陈述]`。在生产 Serverless 集群中，请求量波动（CV 值）与 GPU 资源碎片化程度都极高，而现有系统采用固定的流水线配置去应对，无法适配这种动态性 `[作者明确陈述]`。

#strong[为什么重要]：阿里巴巴生产集群分析显示，不同时间窗口测得的 CV 可波动达 7 倍 `[实验支持]`；同一服务器同时凑齐 4 块 GPU 的概率仅 0.02% `[实验支持]`；静态流水线场景下平均 GPU 利用率仅 17% `[实验支持]`。这意味着资源浪费与性能瓶颈同时存在，服务提供商既无法保证 SLO，又无法压低成本。

#strong[难点来源]：难点并非单一维度问题，而是\"负载波动\"与\"资源碎片化\"两个变量相互耦合------想用张量并行应对波动峰值，却因碎片化找不到相邻高带宽 GPU；想固定流水线粒度以省去重配置开销，却无法同时兼顾低 CV 时的通信效率与高 CV 时的弹性缓冲。

#strong[本文的 story]：旧路线的共同失效原因是\"静态\"------无论是离线优化的流水线架构，还是固定容量预留策略，都假设资源和负载相对稳定。本文的核心转折是把流水线粒度从\"部署时定死的常量\"变成\"运行时可按实时 CV 动态调整的变量\"，用一套可在线安全重构的机制去连接细粒度（抗突发）与粗粒度（省通信）两端。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：请求波动极高与多尺度不一致性]
  #image("figure-groups/page-0002-5d18fe5b63f1.png", width: 100%)
  #emph[Figure 1. Request distribution CV (coefficient of variation) variations across different periods. Significant mismatches exist in CV calculated with different window sizes (180s, 3h, 12h), variation exists. (a) Request distribution CV of Alibaba Trace, (b) Request distribution CV of Top-1 App, and (c) Top-2 App from Azure \[57\].]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：三个数据源在不同窗口测得的 CV 曲线显著错位，跨时间段波动最高达 7 倍。

- #strong[论证关系]：证明请求分布具有强突发性与窗口依赖性，为动态流水线重构提供根源性依据。

- #strong[适用范围]：无法基于图像唯一定位正文所指 7 倍波动的具体计算坐标点。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：GPU 资源碎片化与过度订阅问题]
  #image("figure-groups/page-0004-af1fd5c2db15.png", width: 100%)
  #emph[Figure 2. Resource fragmentation in Alibaba. (a) GPU subscription rate averaging 216%, indicating significant resource overcommitment, and (b) Heatmap revealing spatially scattered GPU availability patterns that impede formation of high-bandwidth interconnected GPU groups needed for tensor parallelism.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：GPU 平均订阅率达 216%，且空闲 GPU 在空间与时间上零星分布，缺乏连续高带宽集群。

- #strong[论证关系]：证实张量并行在云集群中不可行，支撑细粒度流水线模型分区的必要性前提。

- #strong[适用范围]：热力图色标与实际离散 GPU 计数的换算关系未作详细说明。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：静态流水线应对波动负载效率低下]
  #image("figure-groups/page-0005-3266f66c293d.png", width: 100%)
  #emph[Figure 3. Impact of request distribution variability on pipeline performance. (a) Goodput decreases by 37% as CV increases from 0.1 to 8 due to resource contention; (b) Average queue length grows nearly 4× with increasing CV, indicating pipeline congestion; (c) Stall cycle ratio increases exponentially (22×) at high CV values, showing how static pipelines become inefficient under variable workloads.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：CV 从 0.1 增至 8 时，Goodput 下降 36.5%，队列长度增长 3.9 倍，停滞周期暴增 22.4 倍。

- #strong[论证关系]：量化静态流水线在突发负载下的性能退化，证明运行时动态调整流水线粒度的必要性。

- #strong[适用范围]：仅覆盖静态 4-stage 配置下的 OPT-66B 模型测试。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

#critique-card(
  [张量并行],
  [原本用于把同层计算拆分给多 GPU 并行执行以加速单次前向计算。],
  [依赖高带宽互联做频繁 all-reduce 同步，通信复杂度 $O\(n^2\)$；在碎片化环境中同步开销主导执行时间，导致其不可行 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。生产集群中 78% 的张量并行请求被迫降级为流水线并行 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。],
  [拓扑感知资源分配模块与细粒度模型分区设计。],
  [],
)

#critique-card(
  [流水线并行],
  [原本用点对点通信规避高带宽依赖，通信复杂度降为 $O\(1\)$。],
  [存在填充/排空阶段的空闲时间（流水线气泡）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [引入动态粒度切换以吸收波动。],
  [],
)

#critique-card(
  [AlphaServe],
  [原本解决基于历史请求模式做长期流水线架构优化的问题，依赖负载模式相对稳定的前提。],
  [只能做离线、长期优化，无法响应短期负载波动 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [Inflight Pipeline Refactoring 模块（实时 CV 驱动的在线重配置）。],
  [Fig. 8/9 CV=1/2/4 下的延迟对比（38.3%\~66.1% 改善）与 Fig. 11 恢复时间对比 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。],
)

#critique-card(
  [ServerlessLLM],
  [原本用 DeepSpeed 并行为 Serverless 场景提供分布式推理资源。],
  [静态并行配置，在高 CV 下延迟/P99 显著劣化 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [Adaptive Pipeline Scaling + Inflight Refactoring。],
  [Fig. 10 P99 延迟对比、Fig. 11 恢复时间对比（115ms vs 9ms）。],
)

#critique-card(
  [Serverless 反亲和性调度],
  [],
  [为防止级联故障，调度器故意把服务副本分散到不同节点，这与分布式推理需要的紧耦合高带宽 GPU 集群直接冲突 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [拓扑感知资源分配模块设计。],
  [],
)

#critique-card(
  [保守扩容策略],
  [],
  [为防止中断，常驻维持约 75% 历史峰值容量，正常时段浪费资源，突发时仍因扩容延迟（秒级）导致 SLO 违规 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [热启动资源分配设计。],
  [],
)

#critique-card(
  [其余相关工作（Tetris、MuxServe、Megatron/Alpha 类静态优化等）],
  [针对可预测资源模式优化。],
  [论文仅在相关工作段落定性归类，原始动机与具体失效条件多数情形下无法从当前 OCR 内容确认。],
  [面向动态波动的实时粒度重构与自适应扩缩容。],
  [],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见（作者原文三条）]：

+ 资源碎片化严重阻碍依赖高带宽互联的通信密集型并行策略 `[作者明确陈述]`。
+ 细粒度流水线在突发负载下具有更好弹性与批处理能力但带来更多通信开销，最优做法是动态在细/粗粒度间切换 `[作者明确陈述]`。
+ 请求波动会造成流水线各阶段负载失衡，不同负载对应不同最优流水线架构，高突发场景下更深流水线能通过分布式缓冲吸收峰值 `[作者明确陈述]`。

#strong[核心假设]：论文明确挑战\"固定流水线配置对稳定性能是必要的\"这一传统假设 `[作者明确陈述]`。

#strong[可行性依据与前提]：这一洞见依赖两个前提------细粒度切分后各 stage 仍能保持计算图约束下的正确性（第5节分区算法保证），以及粒度切换过程中 KV cache 能保持一致（第6节协议保证）。若切分破坏了模型计算图完整性，或缓存迁移引入错误，则该洞见不再成立；但论文未提供针对这两个前提本身的独立验证实验，`文中未说明`。#strong[实现组件]（区别于核心洞见）包括计算图分析/算子级 profiling、层级化数据传输（RDMA 优先退化到 sendfile）、Hierarchical Resource Graph（HRG），它们是支撑洞见落地的工程手段，而非本文声称的核心贡献本身。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

#strong[总览]：输入为预训练模型与实时请求流；离线阶段（第5节）先对模型做细粒度分区并落盘为可执行 stage；在线阶段（第6-7节）持续监测 CV 与队列长度，在候选粒度间动态选择并执行\"扩展/合并\"重构，同时由拓扑感知模块决定在何处扩缩容；输出为响应请求的推理结果与实时调整后的流水线拓扑 `[正文支持（Fig. 5）]`。

+ #strong[细粒度模型分区（第5节）]------动机：需要在\"计算-通信开销均衡\"与\"保留未来可重构性\"间找到分区方式，静态一次性切分无法应对后续动态调整 `[作者明确陈述]`。运行：输入模型计算图 $G =\(V\,E\)$ 及每个算子的计算时间 $t_c\(v_i\)$、参数量与激活量（Profiling 测得），通过动态规划求解分区优化问题，正则项 $R\(S_k\)$ 偏好保留 Transformer 注意力模块等结构边界的切割方式；输出 K 个 stage 划分及支持任意 micro-batch 的通信量预测。技术优势：既保证各 stage 计算均衡又为未来合并/再切分留有余地 `[作者明确陈述]`。与后续模块相连：输出的 Executable Model Stages 经 Storage 供在线阶段读取（Fig. 5）。该分区算法本身无独立消融实验，`无法从当前 OCR 内容确认` 是否存在专门评测。

+ #strong[Inflight Pipeline Refactoring（第6节，系统核心）]------动机：需要让流水线粒度随实时 CV 动态切换，同时不中断服务、保持 KV cache 一致 `[作者明确陈述]`。运行（Algorithm 1）：持续监控 CV $nu_t$ 与队列长度，对候选粒度集合 $cal(G) = { g_1\,. . .\,g_K }$ 计算优化得分，选出最优粒度 $g^(*)$；若发生变化，确定所需数据并行副本数并执行参数迁移，通过一致性协议 $C\(t\)$ 同步 KV cache，再更新路由。图 6 显示\"扩展\"经\"加载新实例→逐层合并状态→流水线重构与网关更新→GPU 逐出到 Host Mem\"四步线性时序 `[图像直接可见]`；\"合并\"额外包含 Activation Recompute 步骤。技术优势：作者称决策延迟在 2-32 stage 范围内始终低于 5ms `[作者明确陈述]`。该模块内部评分函数是否选出最优粒度、一致性协议在高频切换下是否引入正确性问题，均无独立验证实验，`文中未说明`/`无法从当前 OCR 内容确认`。

+ #strong[拓扑感知资源分配 / Adaptive Pipeline Scaling（第7节）]------动机：多模型并发扩容会争抢 GPU 显存、PCIe/网络带宽，且缩容后冷启动代价高 `[作者明确陈述]`。运行：用 Sigmoid 型决策函数结合 SLO 约束确定扩容粒度 $m_j$；用 Hierarchical Resource Graph 在 server/rack/cluster 三层协调资源，避开近期发生扩容活动的路径；用亲和性调度选择历史托管过该模型且当前可用 GPU 较多的服务器，并在 host memory 保留参数副本实现\"温启动\"。技术优势：将冷启动转化为温启动，降低初始化延迟 `[作者明确陈述]`。HRG 三层协调机制与亲和性调度公式本身是否存在单独消融，`文中未说明`。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：离线分区与在线重构及扩缩容系统总览]
  #image("assets/imgs/img_in_image_box_642_150_1096_533.jpg", width: 100%)
  #emph[Figure 5. FLEXPIPE system architecture showing the three core components: ① Fine-Grained Pipeline Model Partitioning that decomposes LLMs at operator level for optimal adaptability, ② Inflight Pipeline Refactoring that dynamically adjusts pipeline granularity based on request patterns, and ③ Adaptive Pipeline Scaling that enables efficient resource allocation during traffic fluctuations.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：离线分区与在线重构、自适应扩缩容通过 Performance Controller 构成双向反馈闭环。

- #strong[论证关系]：阐释三大核心组件的交互逻辑与控制流，为动态调度与重构机制提供系统架构支撑。

- #strong[适用范围]：仅展示系统宏观控制流，不提供具体性能数值或优化收敛证明。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：Inflight Pipeline Refactoring 在线重构机制]
  #image("assets/imgs/img_in_image_box_638_146_1109_483.jpg", width: 100%)
  #emph[Figure 6. Inflight pipeline refactoring mechanism. (a) Stage refinement process where fine-grained partitioning occurs by evicting parameters and redistributing them onto additional GPUs; (b) Temporal sequence diagram showing synchronization protocol during refactoring; (c) Stage consolidation process where parameters from multiple stages are merged, utilizing host memory caching to minimize loading overhead from persistent storage.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：扩展过程经加载、状态合并、重构与逐出四步；合并过程增加激活重算步骤。

- #strong[论证关系]：具体化异步 KV cache 选择性同步流程，证明在线流水线粒度重构的可行性。

- #strong[适用范围]：未标注各重构步骤的精确耗时及高频切换下的正确性验证。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：基于细粒度 stage 的动态扩缩容流程]
  #image("assets/imgs/img_in_image_box_110_148_581_406.jpg", width: 100%)
  #emph[Figure 7. The process of model scaling using fine-grained pipeline stages. FLEXPIPE conference satisfies the minimum granularity pipeline stage for loading and executing inference. Then, after traffic changes, it modifies to a coarser granularity pipeline stage with fewer additional overheads.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：突发流量时扩展为多排并行细粒度 stage，稳定时合并为粗粒度并保留温启动流水线。

- #strong[论证关系]：图解粒度选择与扩缩容决策的具体运作，支撑高效资源利用的设计主张。

- #strong[适用范围]：示意图未标注决策公式的具体参数取值与实际 Stage 数量对应关系。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制→收益]：细粒度切分降低单 stage 显存占用、加快加载（Table 2 实测 4 段加载 47.14s vs 32 段 5.43s），但通信开销随 stage 数增加而上升（6.3ms→65.1ms）`[实验支持]`；在高 CV 时，分布式缓冲吸收峰值负载的收益超过通信开销负面影响，16 段流水线在 CV=4 时平均延迟为 4 段的 1/3 `[实验支持]`。这一因果链条本身是论文给出的实测观察，但\"为何超过\"背后的定量归因（具体阈值条件）需要更多假设支撑，标为 `[基于文中逻辑的推断]`。
- #strong[需要的条件]：该效果依赖 CV 确实处于高波动区间；(a)图显示低 CV（0.1、1）下细粒度并未表现出明显优势、甚至部分更差 `[图像直接可见]`，说明\"细粒度更优\"是有条件的适用边界而非普适结论 `[基于文中逻辑的推断]`。
- #strong[拓扑感知资源分配→收益]：热启动路径预期能把资源分配等待和初始化延迟压低，前提是历史托管信息可用且当前碎片化程度未超出协调能力范围；此因果关系由生产案例综合数据佐证（9.6节），但无法单独验证 HRG 机制的贡献占比 `[基于文中逻辑的推断]`。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[效果类问题]：FLEXPIPE 相较 AlphaServe/MuxServe/ServerlessLLM/Tetris，在不同 CV 下端到端延迟与吞吐是否更优------对应 Fig. 8/9/10/12，若延迟更低同时 Goodput 不降则支持主张。
- #strong[机制类问题]：流水线粒度与 CV 之间是否存在此消彼长关系------对应 Fig. 3/4，若细粒度在高 CV 下延迟更低、低 CV 下无优势甚至更差，则支持\"需要动态切换\"的设计动机。
- #strong[必要性问题]（消融）：分区正则项、KV cache 一致性协议、HRG 协调机制是否为达成上述效果所必需------#strong[无对应实验]，`文中未说明`。
- #strong[鲁棒性问题]：在极端突发（CV=8）与不同分位点（P50-P99）下 FLEXPIPE 是否维持稳定------对应 Fig. 9(b)、Fig. 10。
- #strong[适用范围问题]：在真实生产工作负载与不同模型规模下效果是否成立------对应 Fig. 13（9.5节）。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 集群：82 GPU / 42 服务器 Kubernetes 集群 `[作者明确陈述]`。
- 负载：Azure Functions trace + Splitwise 语料生成的合成请求，另有真实生产工作负载轨迹用于 9.5 节 `[作者明确陈述]`。
- 模型：WHISPER-9B、LLAMA2-7B、BERT-21B、OPT-66B `[作者明确陈述]`。
- 对比系统：AlphaServe、MuxServe、ServerlessLLM、Tetris，及未具名的\"\[1\]\"（吞吐-延迟优化）、\"\[19\]\"（干扰缓解）`[实验支持]`；后两者 `无法从当前 OCR 内容确认` 具体名称。
- 硬件/软件细节、重复次数与统计方式（如是否多次运行取均值、置信区间）：`文中未说明`。
- 基线超参数具体取值：`文中未说明`。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Goodput（有效吞吐，满足 SLO 的请求速率，req/s，越大越好）。#strong[定义与公式]：作者文字定义为\"满足延迟 SLO 的有效吞吐\"，未给出可核验的显式公式；#strong[来源层级]：无可核验公式。#strong[实验用途]：检验 CV 上升时系统是否维持吞吐（Fig. 3 Panel1、Fig. 8 折线）。#strong[读数与边界]：静态 4-stage 系统在 CV 从 0.1 增至 8 时 Goodput 由 20.0 降至 12.7，约降 36.5% `[实验支持]`；不能证明该下降的具体内部机制归因。
- #strong[指标与方向]：Queue Length（排队长度，无量纲计数，越小越好）。#strong[定义与公式]：作者文字定义为等待处理的请求数量，无显式公式，来源层级为无可核验公式。#strong[实验用途]：衡量负载失衡对静态流水线的冲击（Fig. 3 Panel2）。#strong[读数与边界]：CV 从 0.1 到 8，队列长度由 12.5 增至 48.8（约 3.9×）`[实验支持]`；仅反映静态基线现象，非 FLEXPIPE 自身效果证据。
- #strong[指标与方向]：Stall Cycle（流水线停滞周期，秒，越小越好）。#strong[定义与公式]：作者文字定义为延迟超过基线阈值的持续时间概念雏形，具体定义在 9.3 节明确为\"延迟超过基线 1.5× 记为停滞，回落到 1.2× 内记为恢复\"，属作者文字定义，来源层级为原文公式（阈值关系）`[作者明确陈述]`。#strong[实验用途]：衡量停滞发生频度与恢复速度（Fig. 3 Panel3、Fig. 11）。#strong[读数与边界]：CV 从 0.1 增至 8，停滞周期由 0.15s 增至 3.36s（约 22.4×）`[实验支持]`；CV=4 时 FLEXPIPE 恢复时间 9ms，比 AlphaServe 快 44%、比 MuxServe/ServerlessLLM 快 82% `[实验支持]`；不能单独归因于一致性协议或评分函数中哪一个子机制。
- #strong[指标与方向]：Response Time / Latency Breakdown（端到端响应时间及其排队/执行/通信构成，秒，越小越好）。#strong[定义与公式]：作者以柱内三段堆叠形式给出构成，无显式聚合公式，来源层级为无可核验公式。#strong[实验用途]：检验\"以更高通信开销换取更低排队时间\"的机制主张（Fig. 8）。#strong[读数与边界]：CV=1/2/4 下 FLEXPIPE 总延迟为 0.83s/1.00s/1.45s，均为五系统中最低，通信段占比随 CV 增大而增厚 `[实验支持]`；不能证明具体归因于分区、重构或调度三模块中的哪一个。
- #strong[指标与方向]：GPU 利用率与资源效率（%，与 req/s 联合评估资源效率，越低利用率配合越高吞吐越好）。#strong[定义与公式]：文字描述为\"利用率下达到的吞吐\"对比，无显式公式，来源层级为无可核验公式。#strong[实验用途]：检验\"高利用率不等于高有效吞吐\"（Fig. 12(c)）。#strong[读数与边界]：CV=4 时 FLEXPIPE 在 43% 利用率下达 12,000 req/s，Tetris 在 85% 利用率下仅 1,543 req/s，即约 8.5× 效率差距 `[实验支持]`；不能推广到非 LLM 或更大规模集群。
- #strong[指标与方向]：变异系数 CV（负载波动，无量纲，标准差/均值）。#strong[定义与公式]：作者文字定义为标准差除以均值，来源层级为原文公式（文字定义）`[作者明确陈述]`。#strong[实验用途]：作为实验分组变量贯穿全文所有对比。#strong[读数与边界]：不同测量窗口（180s/3h/12h）下同一数据源 CV 数值不一致，跨窗口波动可达 7 倍 `[实验支持]`；正文未说明该 7× 倍数具体取自哪两个数值点，图像也无法唯一定点。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [AlphaServe], [离线长期优化，无法应对短期波动], [Inflight Pipeline Refactoring], [Fig. 8/9.1节延迟对比（38.3%\~66.1%）；未验证更大规模集群下是否仍成立],
    [ServerlessLLM], [静态并行配置，高 CV 下 P99 显著劣化], [Adaptive Scaling + Inflight Refactoring], [Fig. 10 P99 对比；恢复时间对比；未单独验证具体子机制贡献占比],
    [Tetris], [高利用率但低有效吞吐], [拓扑感知资源分配], [Fig. 12(c) 8.5× 效率差距；未验证该差距是否随负载类型变化],
    [MuxServe], [高 CV 下延迟持续偏高、吞吐降 33.3%], [按 CV 动态调整的粒度切换机制], [Fig. 9(b) CV=8 延迟对比；未见与其复用策略的正面消融比较],
  )]
  , kind: table
  )

以上比较结果仅说明本文实验设置内相对表现，不能证明对方方法在所有场景下均失效。

#strong[主张与证据强度]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据], [证据强度与边界],),
    table.hline(),
    [细粒度流水线在高 CV 下显著优于粗粒度], [Fig. 4(b) 密度曲线，正文数值], [实验支持，但低 CV 下不成立，是有条件结论],
    [FLEXPIPE 端到端延迟降低 38.3%\~80.6%], [Fig. 8，正文 9.1节], [实验支持，限于本文测试集群与模型；未做统计显著性检验（文中未说明）],
    [FLEXPIPE 资源效率提升达 8.5×], [Fig. 12(c)], [实验支持，仅针对 CV=4 单点条件下与 Tetris 对比],
    [KV cache 一致性协议不引入正确性问题], [无], [无独立正确性/精度验证实验，无法从当前 OCR 内容确认],
    [决策延迟 2-32 stage 范围内 \< 5ms], [正文页9], [实验支持，但测量方法（端到端或纯计算耗时）未说明],
  )]
  , kind: table
  )

- 分区正则项 $R\(S_k\)$、HRG 三层协调机制均缺乏独立消融，已报告数值均为系统整体对比，无法单独归因 `[基于文中逻辑的推断]`。
- 生产工作负载验证（9.5节）覆盖四种模型规模，是外部有效性证据，但同样是端到端对比，无法定位具体模块贡献。
- 论文未给出的实验细节（重复次数、显著性检验、参数标定方法）均写\"文中未说明\"。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0006-6be2eefe26a5.png", width: 100%)
    #emph[Figure 4. Latency distribution across different request patterns. (a) Box plot comparing pipeline granularities across varying CV values, showing fine-grained pipelines perform better with high-variability workloads; (b) Detailed latency distribution for CV=4 with 4-stage pipeline, revealing significant variance from pipeline stalls.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 5 节：细粒度流水线在高 CV 下的弹性优势]
    - #strong[图组结论]：高 CV 时细粒度流水线延迟显著更低，而低 CV 时细粒度并无优势甚至开销更大。

- #strong[论证关系]：揭示粒度与 CV 的此消彼长关系，划定细粒度优势的适用边界，导出动态切换动机。

- #strong[适用范围]：无法直接证明自动切换算法自身的决策效率与收敛性。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_640_565_1102_821.jpg", width: 100%)
    #emph[Figure 9. Latency under highly variable workload (CV=8, first 300s). (a) Request distribution CV variability measured in 15s windows, (b) Response latency comparison across systems.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：极端突发负载下的延迟稳定性对比]
    - #strong[图组结论]：在 CV=8 极端突发下，FlexPipe 延迟全程最低平稳，而基线系统出现持续高延迟或周期尖峰。

- #strong[论证关系]：验证系统在极端波动下的抗突发能力，对比证明离线与静态优化基线的局限性。

- #strong[适用范围]：仅对比了 AlpaServe 与 MuxServe 两个基线，未覆盖全部对比系统。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_636_149_1108_441.jpg", width: 100%)
    #emph[Figure 8. End-to-End Latency Breakdown across varying request distributions. FLEXPIPE maintains lower overall latency despite higher communication overhead by significantly reducing queue wait times: (a) CV=1 (stable workload), (b) CV=2 (moderate variability), and (c) CV=4 (highly variable workload).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：端到端延迟构成与有效吞吐表现]
    - #strong[图组结论]：FlexPipe 在各 CV 下总延迟均最低，以适度增加通信开销大幅换取排队等待时间下降。

- #strong[论证关系]：证实细粒度重构通过缓解排队拥塞降低端到端延迟的因果机制。

- #strong[适用范围]：测试局限于 OPT-66B 与特定 82-GPU 集群环境。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_110_148_582_340.jpg", width: 100%)
    #emph[Figure 10. Performance stability analysis across varying request distributions (CV=1, 2, 4), showing FLEXPIPE maintains consistently lower latency percentiles even as workload variability increases in serverless.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：不同请求分布下的分位延迟稳定性]
    - #strong[图组结论]：FlexPipe 在 P50-P99 全分位点延迟最低且曲线最平缓，有效抑制了高 CV 下的尾部发散。

- #strong[论证关系]：支撑系统在 Serverless 环境下保障服务质量 SLO 与压制尾部延迟的主张。

- #strong[适用范围]：仅对比了 ServerlessLLM 与 Tetris 两种部署方案。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_636_145_1108_316.jpg", width: 100%)
    #emph[Figure 11. Pipeline stall recovery time across systems and request distribution variability (CV). FLEXPIPE achieves substantially faster recovery under high-variability workloads (9ms at CV=4), demonstrating the effectiveness of dynamic pipeline refactoring in addressing structural stall causes.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：流水线停滞恢复速度对比]
    - #strong[图组结论]：CV=4 时 FlexPipe 停滞恢复时间仅 9ms，显著快于各对比基线系统。

- #strong[论证关系]：证明在线重构能快速消除结构性停滞，展现动态架构调节的恢复效率。

- #strong[适用范围]：无法区分 KV cache 协议与评分函数各自对恢复速度的独立贡献。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_636_144_1113_316.jpg", width: 100%)
    #emph[Figure 13. Performance comparison with production workloads: (a) Average prefill latency across model scales showing FlexPipe\'s consistent advantage (6.43%-24.38% improvement), (b) Latency distribution showing tighter performance bounds with fewer outliers.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：真实生产工作负载与跨模型扩展性]
    - #strong[图组结论]：在四种模型规模下 FlexPipe prefill 延迟均最低，提升幅度随模型增大达 6% 至 24%。

- #strong[论证关系]：验证系统在真实生产轨迹与不同模型规模下的外部有效性与通用扩展力。

- #strong[适用范围]：图像未标注纵轴绝对数值刻度，且未包含 MuxServe 与 Tetris 基线。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1. GPU cluster statistics showing resource utilization patterns.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：生产集群 GPU 资源利用率统计]
  - #strong[图组结论]：展示生产集群真实的 GPU 资源分布与利用率统计特征。

- #strong[论证关系]：提供真实云环境资源使用数据，支撑碎片化与过度订阅的背景论述。

- #strong[适用范围]：仅代表特定生产集群在统计时间段内的状况。
  #v(5pt)
  #image("table-groups/page-0004-3bd0e21e0d2c.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2. Performance metrics for different pipeline granularities.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 7 节：不同流水线切分粒度的性能开销指标]
  - #strong[图组结论]：细粒度切分显著降低单段加载时间，但跨段通信开销随段数增加而上升。

- #strong[论证关系]：量化切分粒度带来的加载与通信 Trade-off，支撑权衡设计的必要性。

- #strong[适用范围]：数据受限于具体测试硬件环境与模型架构配置。
  #v(5pt)
  #image("table-groups/page-0004-4fd1e2952bb2.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：请求波动（CV 可变 7×）与资源碎片化（同机 4-GPU 概率仅 0.02%）共同使现有静态流水线系统低效 `[实验支持]`
  - 旧方法限制：张量并行依赖高带宽互联在碎片化环境不可行（78% 请求被迫降级）；AlphaServe/ServerlessLLM 等依赖静态或离线配置无法响应短期波动 `[作者明确陈述]`
  - 核心洞见/假设：流水线粒度应随实时 CV 动态切换，而非固定 `[作者明确陈述]`
    - 方法模块：细粒度模型分区（保留可重构性）→ Inflight Pipeline Refactoring（在线粒度切换与一致性）→ 拓扑感知资源分配（碎片化环境下的扩缩容）`[作者明确陈述]`
      - 可验证预测：高 CV 下细粒度流水线延迟显著低于粗粒度，且该优势随 CV 增大扩大
        - 指标与实验：Latency Breakdown（Fig. 8）、分位延迟（Fig. 10）、停滞恢复时间（Fig. 11）
          - 图表证据：Fig. 4、8、9、10、11 显示 FlexPipe 在中高 CV 下全面占优，低 CV 下优势不明显
            - 结论与适用边界：效果在本文测试集群/模型范围内成立 `[实验支持]`；分区算法、一致性协议、HRG 机制各自的必要性未被独立验证，标为\"未被当前证据直接验证\"

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献总结]：论文提出（1）无需中断服务、根据请求分布变化动态重构流水线架构的方法；（2）保留计算效率的细粒度模型分区方法；（3）通过动态资源分配与拓扑适配提升弹性的系统；（4）在生产级 82-GPU 基础设施上的大规模实证评测 `[作者明确陈述]`。

#strong[证据充分的结论]：在合成负载（Azure Functions trace + Splitwise）与真实生产轨迹下，FLEXPIPE 相比 AlphaServe/MuxServe/ServerlessLLM/Tetris 在延迟、尾部稳定性、恢复速度与资源效率上均表现更优 `[实验支持]`。

#strong[尚属推断的意义]：细粒度切换带来净收益的临界 CV 阈值、以及 $S prop sqrt(C V_a)$ 这一经验关系的稳健性，仅基于本文测试范围观察，未给出拟合图或回归系数验证 `[基于文中逻辑的推断]`。

#strong[适用条件]：结论建立在 82-GPU/42-server 集群、Azure Functions + Splitwise 负载、四个特定模型规模之上；`文中未说明`是否在更大规模集群或非 LLM 负载上验证。

#strong[局限与下一步验证]：分区算法、KV cache 一致性协议、HRG 资源协调机制均缺乏独立消融，无法归因具体贡献占比；校准参数取值与标定方法未披露，影响可复现性。

#strong[审稿式风险检查]：

- 贡献新意：三大模块组合本身在论文中有明确对应挑战和实验支撑，当前证据未显示明显的新意风险。
- 写作/可复现性：多个公式的校准参数未公开取值，存在可复现性风险 `[基于文中逻辑的推断]`。
- 效果大小：报告的提升幅度（8.5×、38.3%等）均有对应实验支持，当前证据未显示明显夸大风险，但缺乏统计显著性检验说明。
- 实验覆盖：核心模块级消融缺失，是当前证据实际暴露的覆盖风险。
- 方法设计：KV cache 一致性协议的正确性未经独立验证，属当前证据未覆盖的设计风险，而非已确认缺陷。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：流水线并行（Pipeline Parallelism）------把模型按层切成若干连续段，像流水线工位一样依次处理请求的分布式推理方式。
  - #strong[第一性原理角色]：连接\"单设备显存有限\"与\"多设备协同计算\"两个基本量，只需点对点通信（约束更宽松），代价是填充/排空阶段产生空闲（气泡）。
  - #strong[本文位置]：是本文一切设计的基础范式，第3、5、6节反复涉及 `[作者明确陈述]`。
- #strong[术语]：变异系数 CV------标准差除以均值，衡量请求到达波动的相对指标。
  - #strong[第一性原理角色]：连接\"负载统计特征\"与\"系统需要的弹性程度\"，CV 越大代表突发程度越高。
  - #strong[本文位置]：贯穿全文作为实验分组变量与在线决策输入 `[作者明确陈述]`。
- #strong[术语]：资源碎片化（Resource Fragmentation）------可用 GPU 分散在多个物理节点，难以凑齐相邻高带宽互联资源。
  - #strong[第一性原理角色]：连接\"总资源量\"与\"可用拓扑结构\"，即使总量充足，空间分布仍可能限制并行策略选择。
  - #strong[本文位置]：论文根问题的核心成因之一，Fig. 2 提供量化证据 `[实验支持]`。
- #strong[术语]：KV Cache------Transformer 推理中缓存已生成 token 对应 Key/Value 向量，避免重复计算。
  - #strong[第一性原理角色]：连接\"计算量\"与\"内存占用\"，是流水线重构过程中需要保持一致的状态量。
  - #strong[本文位置]：第6.3节一致性协议核心操作对象 `[作者明确陈述]`。
- #strong[术语]：Goodput------满足延迟 SLO 的有效吞吐量，区别于不考虑超时的普通吞吐量。
  - #strong[第一性原理角色]：连接\"系统吞吐能力\"与\"服务质量约束\"两个量，是效果类实验的核心观测指标。
  - #strong[本文位置]：Fig. 3、8 中的关键评估指标 `[作者明确陈述]`。
- #strong[术语]：冷启动/温启动（Cold/Warm Start）------从零加载模型参数 vs 利用留存缓存直接复用。
  - #strong[第一性原理角色]：连接\"资源释放后的状态保留程度\"与\"重新可用的时延\"。
  - #strong[本文位置]：第7节拓扑感知资源分配模块的关键机制 `[作者明确陈述]`。
- #strong[术语]：Hierarchical Resource Graph（HRG）------在 server/rack/cluster 三层组织资源信息的数据结构。
  - #strong[第一性原理角色]：连接\"局部资源状态\"与\"全局调度决策\"，用于导航碎片化资源。
  - #strong[本文位置]：第7节资源分配机制的具体实现组件 `[作者明确陈述]`。
- #strong[术语]：流水线气泡（Pipeline Bubble）------流水线填充/排空阶段产生的设备空闲时间。
  - #strong[第一性原理角色]：连接\"stage 数量\"与\"启动/收尾开销\"，是流水线并行固有代价的来源。
  - #strong[本文位置]：第3节旧方法限制分析的一部分 `[作者明确陈述]`。

=== 12.2 学习路径
<122-学习路径>
+ #strong[分布式计算基本约束]：先理解\"单设备内存/算力有限，必须多设备协同\"这一基本约束，才能理解为何需要并行策略。
+ #strong[通信 vs 计算的权衡机制]：理解张量并行（高带宽、强同步）与流水线并行（弱同步、有气泡）之间的因果权衡，这是本文所有设计选择的基础机制。
+ #strong[负载统计量（CV）如何驱动系统行为]：理解 CV 这一指标如何把\"请求到达的随机性\"转化为可量化、可决策的输入信号。
+ #strong[资源碎片化对拓扑选择的约束]：理解物理资源的空间分布如何限制逻辑并行策略的选择，这是本文问题成立的现实基础。
+ #strong[在线系统重构与状态一致性]：理解\"运行时改变计算拓扑同时保持状态（KV cache）正确\"这一系统行为模式，是理解本文核心机制（Inflight Refactoring）的最后一环。
