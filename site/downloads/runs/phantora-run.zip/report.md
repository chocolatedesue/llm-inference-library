# 论文解构报告

### 论文元数据

| 字段 | 内容 |
|---|---|
| 标题 | Phantora: Maximizing Code Reuse in Simulation-based Machine Learning System Performance Estimation |
| 作者 | Jianxing Qin, Jingrong Chen, Xinhao Kong, Yongji Wu, Tianjun Yuan, Liang Luo, Zhaodong Wang, Ying Zhang, Tingjun Chen, Alvin R. Lebeck, Danyang Zhuo |
| 发表场所 / 年份 | USENIX Symposium on Networked Systems Design and Implementation / 2026 |
| 研究领域 | Machine Learning Systems |
| 关键词 | ML Systems, GPU Cluster Simulation, Performance Estimation, Code Reuse, LLM Training |

### 资源链接

- 原始文件：本地上传文件
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：https://github.com/QDelta/Phantora

> **标签（3–5 个）**：`ML Systems` · `GPU Cluster Simulation` · `Performance Estimation` · `Code Reuse` · `LLM Training`

## 1. 一句话总览

**[作者明确陈述]** Phantora 提出了用于机器学习（ML）系统性能评估的“混合 GPU 集群模拟”（Hybrid Simulation，将真实系统代码执行与离散事件模拟无缝集成的技术）架构，通过在单 GPU 容器化环境中直接运行未经修改的 ML 框架源码，结合透传拦截、单卡算子性能 Profiling、流级网络模拟与时间回滚机制，在保证与静态模拟相当精度（平均误差 2.9%–3.7%）的前提下，消除了手写重构框架调度逻辑的巨大维护开销。

## 2. 阅读范围与证据状态

- **[作者明确陈述]** OCR 覆盖了论文全文文本、算法描述、实验图表解读以及开源仓库信息。
- **[作者明确陈述]** 论文未披露或无法确认的信息：未披露代码的具体 arXiv/DOI 页面链接；未建模数值依赖的控制流（如动态路由的专家并行、RLHF 动态序列长度）；未建模计算与通信重叠时硬件内部物理干涉；未给出 Figure 13 在真实集群上的 Ground Truth 实测对比数据。
- **[基于文中逻辑的推断]** 本报告严格基于论文 OCR 提取出的事实与推断进行解构，涉及的背景知识已明确标注。

## 3. 根问题：论文究竟要解决什么

- **基本对象与资源约束**：在大规模大语言模型（LLM）分布式训练中，集群包含大量 GPU、NVLink 以及 RDMA 高速网络资源；上层软件必须组合混合并行策略（数据、流水线、张量、专家并行）与显存优化手段（ZeRO、FSDP、选择性激活重算）。
- **根问题与重要性**：**[作者明确陈述]** 在部署大规模训练任务前，精准评估系统性能（如单迭代耗时、模型 FLOPS 利用率 MFU）对于指导并行策略选择、集群硬件配置与采购规划至关重要。然而，现有模拟器需要手写重构 ML 框架的下发调度逻辑，面临巨大的开发与维护开销。
- **困难来源**：**[背景知识]** 现代 ML 框架（如 Megatron-LM、DeepSpeed、TorchTitan）演进极快，新算子与新并行策略层出不穷。**[作者明确陈述]** 手写重构调度逻辑的模拟器无法跟上框架迭代更新，而在真实大集群上高成本采集 Trace（运行轨迹）又严重限制了性能估算工具的实用性。
- **本文的 Story**：旧路线（静态工作负载模拟）陷入了“要么必须依赖大集群采集 Trace，要么必须在模拟器中手动 Mock/重构框架调度算法”的失效困境。本文的转折在于提出“混合 GPU 集群模拟”洞见：不重写框架调度逻辑，而是让未经修改的真实 ML 框架代码在单 GPU 容器中直接运行，拦截底层 API 并向离散事件模拟器注入事件，从而实现 100% 框架代码复用。

## 4. 旧方法为何不够

现有静态工作负载模拟（Static Workload Simulation）主要分为两类，均存在不可忽视的技术局限：

1. **基于 Trace 的模拟（Trace-based simulation）**
   - **原本解决的问题**：通过在真实大集群上运行框架并收集算子 Trace，进行配置探索与事件驱动模拟。
   - **前提与失效条件**：依赖昂贵的大规模物理集群 Trace 采集；依赖“工作负载提取”（Workload Extraction），这本质上是反向重构框架调度逻辑，依赖脆弱的人工启发式规则，难以跨框架泛化。
   - **后果**：用户一旦更改并行配置，模拟器仍需手写重构调度逻辑将抽象 Workload 重新展开为事件。
2. **SimAI 模拟器**
   - **原本解决的问题**：通过编写 Mock（模仿）框架直接生成底层事件，避免 Trace 采集与工作负载提取。
   - **前提与失效条件**：仍需在 Mock 框架中手写重构调度逻辑，导致与特定框架版本强绑定（如给定相同配置时，SimAI 生成的模型尺寸与 Megatron 原生结构存在 7.4% 的偏差）；不支持 TorchTitan 等新框架及选择性激活重算等新特性。
   - **后果**：采用数据包级（packet-level）网络模拟，导致模拟运行速度极慢（小规模测试中比 Phantora 慢数十倍）。

**批判比较工作链**：
- **基于 Trace 的模拟器**：原本解决大集群性能预测 -> 依赖真实集群 Trace 采集与反向 De-scheduling 提取 -> 本文批判其高硬件开销与脆弱启发式规则 -> 本文提出透传拦截层与单 GPU Profiling 缓存回应 -> 实验 Figure 9/10 检验免 Trace 下的高精度。
- **SimAI**：原本解决免 Trace 事件生成 -> 依赖 Mock 框架重构调度算法 -> 本文批判其模型尺寸偏差 7.4%、无法适配新框架/新特性及网络包模拟极慢 -> 本文提出混合模拟架构与流级网络模拟器回应 -> 实验 Table 1 和 Figure 10 检验评估速度与精度。
- **Wisconsin Wind Tunnel (WWT)**：原本解决体系结构共享内存模拟 -> 依赖固定微小时间量子高频同步 -> 本文批判其同步开销巨大、极大地拖慢模拟速度 -> 本文提出松散时间同步与时间回滚机制回应 -> 实验 Figure 9/11 检验模拟运行速度与扩展性。

## 5. 核心洞见与假设

- **核心洞见（Hybrid Simulation）**：**[作者明确陈述]** 将真实的系统执行与事件驱动模拟直接集成，为 ML 框架创造运行在真实 GPU 集群上的“时间与空间幻觉”。在容器化环境中利用单块物理 GPU 执行未经修改的 ML 框架源码，拦截 PyTorch、CUDA Runtime 和 NCCL 的 API 调用；计算 kernel 耗时在单 GPU 上 Profiling 测量并缓存，通信耗时由流级网络模拟器计算，各 rank 的虚拟时钟由模拟器统一推进。
- **底层假设**：
  1. **[基于文中逻辑的推断]** **控制流数据无关假设**：ML 框架的控制流逻辑（决定下一个调用的算子或通信）不依赖于张量内部的具体数值（Tensor Values）。推理依据：Phantora 在显存中填充随机/垃圾数值，若控制流依赖数值，模拟将无法正常执行。
  2. **[基于文中逻辑的推断]** **算子耗时确定性假设**：GPU 计算 kernel 的执行时间主要由算子类型和张量形状（Tensor Shapes）决定，与具体数值无关。推理依据：Phantora 仅需对每个“算子+张量形状”组合 Profiling 一次并缓存即可复用。
  3. **[基于文中逻辑的推断]** **有限过去事件与回滚收敛假设**：真实系统在混合模拟中仅注入有限数量的过去事件，因此时间回滚（Time Rollback）次数有限，系统必然能向前推进。

## 6. 方法：从洞见到可执行系统

Phantora 从输入到输出的总流程为：用户输入未经修改的 ML 框架训练脚本与集群配置；容器层直接运行脚本，拦截层截获算子与通信 API 并推入事件队列；计算模拟器与网络模拟器协同计算逻辑时间戳并推进虚拟时钟；最终输出原生的控制台日志、吞吐量指标与 Perfetto Trace 性能轨迹。

### 1. Phantora 环境与拦截层（Runtime Patching & Interception）
- **动机**：支持未经修改的 ML 框架直接运行，消除重写源码的需求。
- **运行机制**：在容器中运行 Python 解释器。使用 Runtime Patching 动态替换不可配置依赖（如替换 `time.perf_counter`）；实现 Phantora Tracer（收集 PyTorch 算子与形状）、Phantora CUDA Runtime（模拟显存分配与追踪 Stream/Event 依赖）和 Phantora NCCL（截获通信 API）。
- **优势与连接**：极低侵入性，开箱即用，将截获到的计算与通信事件推送给后端 Event Queue。

### 2. 单 GPU 算子性能 Profiler 与缓存管理器（Operator Profiler & Performance Cache）
- **动机**：在无需真实大集群的前提下，精准获取单个 GPU 算子在目标张量形状下的真实耗时。
- **运行机制**：截获计算算子后，在单块物理 GPU 上实际 Profiling 执行该算子；将结果存入 Performance Cache；后续相同算子及形状直接查表。
- **优势与连接**：仅需单 GPU 即可完成大规模集群计算耗时评估，消除重复 Profiling 开销，输出逻辑执行耗时给离散事件模拟器。

### 3. 网络模拟与松散时间同步/时间回滚机制（Flow-Level Netsim & Time Rollback）
- **动机**：真实容器会动态注入网络事件，与按离散时间推进的模拟器产生“过去事件”冲突；细粒度时间量子同步开销过大。
- **运行机制**：基于 NetHint 的流级模拟器（netsim）采用水填算法按最大最小公平性计算流量吞吐；保留历史吞吐状态；收到过去发生的事件时，回滚模拟器状态并重新计算受影响流的完成时间，再通过依赖图更新后续事件时间戳；当所有 rank 时间超越 $T$ 时触发垃圾回收（GC）。
- **优势与连接**：避免细粒度量子同步的巨大开销，输出通信完成时间线以推进 rank 虚拟时钟。

### 4. 扩展性优化模块：CPU 内存共享与 CPU 时间度量（Parameter Sharing & CPU Time）
- **动机**：单机模拟多容器时，每个容器独立加载模型会导致 CPU 内存爆表；CPU 核心超分配会导致进程频繁上下文切换，虚高墙上时间。
- **运行机制**：将同一模拟服务器上不同容器的模型参数透明映射到共享内存同一区域，单服务器仅初始化一份模型拷贝；仅统计每个进程实际消耗的 CPU 时间（CPU time），排除上下文切换干扰。
- **优势与连接**：突破单机模拟节点规模瓶颈（256GB 内存下 64 GPUs 占用降至 64GB 以下），维持 CPU 资源紧张时的模拟精度。

## 7. 为什么它可能有效

1. **[基于文中逻辑的推断]** **拦截层 -> 零源码修改 -> 高代码复用与框架兼容性**：通过在 Python/CUDA/NCCL 层透传拦截 API 调用，ML 框架感知不到底层是虚拟环境，从而能够 100% 复用框架原生调度逻辑，天然适配新框架与新特性。
2. **[基于文中逻辑的推断]** **单 GPU Profiling 缓存 -> 免大集群硬件 -> 低物理资源开销**：基于算子耗时仅由张量形状决定的确定性假设，利用单块 GPUProfiling 并缓存结果即可准确推算全集群计算时间。
3. **[基于文中逻辑的推断]** **松散同步与时间回滚 -> 消除量子同步开销 -> 高模拟运行效率**：允许容器异步推进，仅在发生过去事件碰撞时沿着依赖图精准回滚重新计算，既保证了因果时间轴正确，又大幅降低了高频同步开销。
4. **[基于文中逻辑的推断]** **内存共享与 CPU 时间 -> 消除单机资源瓶颈 -> 大规模扩展性**：透明共享模型参数内存，避免了 N 个容器重复加载模型的内存爆表；采用 CPU 时间度量消除了超分配时的上下文切换干扰。

## 8. 实验与指标：证据是否支撑主张

### 8.1 实验问题与判定标准

- **问题 1（效果）**：Phantora 的模拟精度是否能达到与传统静态模拟或真实物理测试床相当的水平？判定标准：在多框架、多规模下的吞吐量评估误差是否控制在数个百分点以内。
- **问题 2（机制与扩展性）**：Phantora 在单机上模拟大规模 GPU 集群时的运行速度与主存扩展能力如何？判定标准：单步模拟耗时是否在数十秒内，CPU 内存占用是否低于硬件上限。
- **问题 3（适用范围）**：Phantora 是否能无缝支持复杂新特性（如选择性激活重算）的吞吐与显存联合分析？判定标准：能否开箱即用准确评估显存节省与吞吐权衡。

### 8.2 数据、任务、对比与运行设置

- **硬件测试床**：
  - H200 测试床：2x AMD EPYC 9355 CPU, 4x NVIDIA H200 NVL GPU。
  - A100 测试床：2x Intel Xeon Gold 6348 CPU, 1x NVIDIA A100 40G GPU。
- **评估框架与模型**：Megatron-LM、DeepSpeed、TorchTitan；模型涵盖 Llama2 (7B, 13B, 70B)、Llama3 (8B, 70B)。
- **基线与统计设置**：对比真实测试床（Ground Truth）、SimAI 静态模拟器及官方公开基准报告；重复多次迭代取均值（带 95% 置信区间）。作者未报告的具体超参数在文中未说明。

### 8.3 指标字典与对应公式

1. **$wps$（Words/Tokens Per Second，每秒处理 Token 数）**
   - **指标与方向**：模型训练吞吐量，单位 tokens/s。越大越好。
   - **定义与公式**：`原文公式`
     $$wps = \frac{ntokens\_since\_last\_log}{time\_delta \times parallel\_dims.model\_parallel\_size}$$
     对应 Section 5.1 / Figure 7。$ntokens\_since\_last\_log$ 为日志间隔 token 数；$time\_delta$ 为间隔秒数；$parallel\_dims.model\_parallel\_size$ 为模型并行维度。
   - **实验用途**：评估 TorchTitan 训练吞吐量及 Phantora 输出一致性。
   - **读数与边界**：用于衡量整体训练吞吐，不直接反映单算子延迟。

2. **$mfu$（Model FLOPS Utilization，模型 FLOPS 利用率）**
   - **指标与方向**：硬件算力利用率，单位 %。越大越好。
   - **定义与公式**：`原文公式`
     $$mfu = \frac{100 \times num\_flop\_per\_token \times wps}{gpu\_peak\_flops}$$
     对应 Section 5.1 / Figure 7。$num\_flop\_per\_token$ 为单 token 计算量；$wps$ 为吞吐量；$gpu\_peak\_flops$ 为理论峰值算力。
   - **实验用途**：评估 GPU 硬件算力利用率与性能日志输出。
   - **读数与边界**：依赖硬件理论峰值定义，无法区分通信等待与计算低效。

3. **$time\_end\_to\_end$（端到端平均迭代耗时）**
   - **指标与方向**：单次训练迭代平均耗时，单位秒（s）。越小越好。
   - **定义与公式**：`原文公式`
     $$time\_end\_to\_end = \frac{time\_delta}{job\_config.metrics.log\_freq}$$
     对应 Section 5.1 / Figure 7。$time\_delta$ 为日志间隔总时间；$job\_config.metrics.log\_freq$ 为日志记录步数。
   - **实验用途**：评估单迭代运行耗时。
   - **读数与边界**：包含计算与通信综合时间。

4. **$time\_data\_loading$（数据加载平均耗时）**
   - **指标与方向**：训练数据加载平均耗时，单位秒（s）。越小越好。
   - **定义与公式**：`原文公式`
     $$time\_data\_loading = \text{np.mean}(data\_loading\_times)$$
     对应 Section 5.1 / Figure 7。$data\_loading\_times$ 为数据加载耗时采样数组；$\text{np.mean}$ 为算术平均。
   - **实验用途**：评估数据加载开销。
   - **读数与边界**：仅衡量 IO/数据准备阶段。

5. **平均模拟误差率（Average Simulation Error）**
   - **指标与方向**：模拟吞吐量与真实集群值的相对偏差，单位 %。越小越好。
   - **定义与公式**：`推导关系（非原文公式）` **[基于文中逻辑的推断]** 推理依据：文中多处引用 average error（如 2.9%, 3.7%）与 maximum error，基于文字描述其含义为模拟吞吐量与 Ground Truth 实测值之间的相对偏差聚合，但原文未给出正式 Eq. 编号。
   - **实验用途**：验证 Phantora 模拟精度的有效性。
   - **读数与边界**：TorchTitan 128 卡下平均误差 2.9%（最大 8.5%）；Megatron 下平均误差 3.7%（最大 5.3%）。

### 8.4 主结果、消融与证据边界

**比较工作与被批判限制的呼应**：

| 比较工作 / 基线 | 原本试图解决的问题 / 优势 | 本文指出的具体 Limit / 失效条件 | 本文对应的设计模块 | 检验批判的比较实验 / 指标 / 图表 |
| :--- | :--- | :--- | :--- | :--- |
| **基于 Trace 的模拟器** | 基于真实运行 Trace 进行抽象工作负载提取与事件驱动模拟。 | 1. 需在真实大集群高成本收集 Trace。<br>2. 工作负载提取属反向重构调度逻辑，依赖脆弱启发式规则。<br>3. 无法应对框架快速演进。 | 混合模拟架构 + 容器内直接执行源码 + Phantora API 拦截与 Profiler | 免大集群 Trace 下，在单 GPU 运行 TorchTitan/Megatron 并测量吞吐误差 (Figure 9, Figure 10) |
| **SimAI** | 通过 Mock 框架直接生成事件，避免 Trace 收集与 Workload 提取。 | 1. 仍需在 Mock 框架中重写调度逻辑（模型尺寸偏差达 7.4%）。<br>2. 不支持 TorchTitan 与激活重算等新特性。<br>3. 包级网络模拟运行极慢。 | 流级网络模拟器 (netsim) + 依赖拦截 + CPU 内存共享 | Figure 10（精度及模型尺寸偏差对比）、Table 1（运行耗时对比）、Section 5.4（激活重算 Case Study） |
| **Wisconsin Wind Tunnel (WWT)** | 利用执行驱动模拟评估共享内存系统。 | 采用固定微小时间量子在各组件间高频同步，带来巨大的同步开销，极大地拖慢模拟速度。 | 松散时间同步与时间回滚机制 | 模拟运行耗时与扩展性实验 (Figure 9, Figure 11) |

**主张地图与证据表**：

| 主张 | 直接证据（实验/表图） | 证据强度与边界 |
| :--- | :--- | :--- |
| **主张 1（效果）**：直接复用 ML 框架源码，且模拟精度与静态模拟相当（平均误差 2.9%–3.7%）。 | Section 5.2 (Figure 9, Figure 10) | **[实验支持]** 强证据。覆盖 TorchTitan (128 GPUs) 与 Megatron-LM；边界：未在千卡规模及非 Transformer 模型上测试。 |
| **主张 2（机制）**：通过松散时间同步与时间回滚机制，正确且高效处理过去事件。 | Section 3, Section 4.2 (Figure 5, Figure 6) | **[基于文中逻辑的推断]** 机制逻辑自洽，Figure 6 拆解了工作流；边界：正文缺少回滚触发频次与开销占比的统计数据。 |
| **主张 3（必要性）**：CPU 参数共享与 CPU 时间度量消除单机模拟多卡时的内存爆表与 CPU 争抢。 | Section 4.3, Section 5.3 (Figure 12) | **[实验支持]** 强证据。Figure 12 证明 64 卡 DeepSpeed 内存从爆表 >256GB 降至 <64GB；边界：未给出不同超分配倍率下的墙上时间对比。 |
| **主张 4（适用范围）**：原生支持选择性激活重算等复杂新特性的显存与吞吐联合分析。 | Section 5.4 (Figure 13) | **[实验支持]** 效果与适用范围证据。Figure 13 展示了显存与吞吐权衡；边界：缺少真实集群开启激活重算时的 Ground Truth 实测对比曲线。 |

**关键实验设置解释**：
- 3 个 LLM 训练框架均无需修改源码即可在 Phantora 上运行。Megatron 需 0 行补丁（需禁用梯度剪裁）；DeepSpeed 需 4 行补丁；TorchTitan 需 1 行补丁；训练脚本仅需添加约 6 行代码。
- 在 Megatron 小规模测试中，TP=4, batch=1 时测试床耗时 0.30s，Phantora 耗时 0.91s，而 SimAI 耗时 56.9s（Table 1）。

## 9. 图表解读与论证关系

### 图片原件与标题

#### 原始图片 1：Figure 1: Comparison of simulators and problems of static workload simulation. Light green boxes show unmodified components; green boxes show minimally modified components; blue boxes show simulator components and pink boxes show user input. Trace-based simulation requires workload extraction (reversing framework logic) and costly trace collection on large clusters. SimAI relies on mocked ML frameworks.

![Figure 1: Comparison of simulators and problems of static workload simulation. Light green boxes show unmodified components; green boxes show minimally modified components; blue boxes show simulator components and pink boxes show user input. Trace-based simulation requires workload extraction (reversing framework logic) and costly trace collection on large clusters. SimAI relies on mocked ML frameworks.](assets/imgs/img_in_image_box_169_137_1051_665.jpg)

*来源：OCR 第 3 页。*

---

#### 原始图片 2：Figure 2: Scheduling logic needs to be reimplemented in current simulators for converting high level workload to detailed computation and communication events.

![Figure 2: Scheduling logic needs to be reimplemented in current simulators for converting high level workload to detailed computation and communication events.](assets/imgs/img_in_image_box_640_145_1111_368.jpg)

*来源：OCR 第 4 页。*

---

#### 原始图片 3：Figure 3: Phantora architecture. Components in light green are unmodified, components in green are minimally modified, and components in blue are constructed by Phantora.

![Figure 3: Phantora architecture. Components in light green are unmodified, components in green are minimally modified, and components in blue are constructed by Phantora.](assets/imgs/img_in_image_box_107_145_590_348.jpg)

*来源：OCR 第 5 页。*

---

#### 原始图片 4：Figure 4: An example workflow of Phantora with two ranks. ML system places computation and communications on different CUDA streams for flexibility, and use CUDA events to manage the synchronization between them. Phantora needs to correctly handle these synchronizations to achieve accurate simulation.

![Figure 4: An example workflow of Phantora with two ranks. ML system places computation and communications on different CUDA streams for flexibility, and use CUDA events to manage the synchronization between them. Phantora needs to correctly handle these synchronizations to achieve accurate simulation.](assets/imgs/img_in_image_box_163_142_1061_614.jpg)

*来源：OCR 第 6 页。*

---

#### 原始图片 5：Figure 5: Challenges of synchronizing time between real execution and event-driven simulation.

![Figure 5: Challenges of synchronizing time between real execution and event-driven simulation.](figure-groups/page-0007-d02782144994.png)

*来源：OCR 第 7 页。*

---

#### 原始图片 6：Figure 6: Handing past events in the event-driven simulator using time rollback. The network state at is a superposition of the states at and .

![Figure 6: Handing past events in the event-driven simulator using time rollback. The network state at is a superposition of the states at and .](assets/imgs/img_in_image_box_112_144_586_270.jpg)

*来源：OCR 第 8 页。*

---

#### 原始图片 7：Figure 8: Perfetto [3] trace exported by Phantora.

![Figure 8: Perfetto [3] trace exported by Phantora.](assets/imgs/img_in_image_box_632_140_1121_520.jpg)

*来源：OCR 第 10 页。*

---

#### 原始图片 8：Figure 9: Accuracy and speed of Phantora (large scale): Training throughput reported by TorchTitan [21] using FSDP2, simulation results and simulation speed of Phantora on the testbeds. The error bars show 95% confidence interval. “ac” means activation checkpointing in TorchTitan [21].

![Figure 9: Accuracy and speed of Phantora (large scale): Training throughput reported by TorchTitan [21] using FSDP2, simulation results and simulation speed of Phantora on the testbeds. The error bars show 95% confidence interval. “ac” means activation checkpointing in TorchTitan [21].](assets/imgs/img_in_chart_box_124_146_1099_352.jpg)

*来源：OCR 第 11 页。*

---

#### 原始图片 9：Figure 10: Accuracy of Phantora (small scale): Megatron training throughput of Llama2 7B on H200 testbed with or without optimizer, Phantora simulation results with or without optimizer, and SimAI simulation results. The error bars show 95% confidence interval. Note that SimAI currently does not include optimizer in its simulation.

![Figure 10: Accuracy of Phantora (small scale): Megatron training throughput of Llama2 7B on H200 testbed with or without optimizer, Phantora simulation results with or without optimizer, and SimAI simulation results. The error bars show 95% confidence interval. Note that SimAI currently does not include optimizer in its simulation.](assets/imgs/img_in_chart_box_108_481_585_700.jpg)

*来源：OCR 第 11 页。*

---

#### 原始图片 10：Figure 11: Speed of Phantora: Phantora simulation time of Llama2 7B training (Megatron, TP=8) using 32 CPU cores on H200 testbed.

![Figure 11: Speed of Phantora: Phantora simulation time of Llama2 7B training (Megatron, TP=8) using 32 CPU cores on H200 testbed.](assets/imgs/img_in_chart_box_638_476_1113_675.jpg)

*来源：OCR 第 11 页。*

---

#### 原始图片 11：Figure 12: CPU memory usage: Peak CPU memory usage of Llama2 7B training simulation in DeepSpeed with or without model parameter sharing.

![Figure 12: CPU memory usage: Peak CPU memory usage of Llama2 7B training simulation in DeepSpeed with or without model parameter sharing.](assets/imgs/img_in_chart_box_110_455_582_629.jpg)

*来源：OCR 第 12 页。*

---

#### 原始图片 12：Figure 13: Evaluating memory saving techniques: Phantora estimated peak memory usage per GPU and throughput of Llama2 training with different memory saving techniques (64 H100 GPUs, Megatron, DP=8, TP=8). A single number n denotes the number of batches per GPU with activation recomputation. A pair in the form denotes n batches per GPU with m gradient accumulation steps.

![Figure 13: Evaluating memory saving techniques: Phantora estimated peak memory usage per GPU and throughput of Llama2 training with different memory saving techniques (64 H100 GPUs, Megatron, DP=8, TP=8). A single number n denotes the number of batches per GPU with activation recomputation. A pair in the form denotes n batches per GPU with m gradient accumulation steps.](figure-groups/page-0013-a34fe3c626d0.png)

*来源：OCR 第 13 页。*

### 图 1 & 2：Figure 1 & Figure 2

- **图组结论**：Figure 1 对比了 Phantora 混合模拟与传统 Trace-based / SimAI 静态模拟在架构与代码复用上的根本差异；Figure 2 剖析了静态模拟在 De-scheduling 提取 Workload 及模拟器内部 Scheduler 重新下发 Events 时的双重维护负担。
- **论证关系**：**[基于文中逻辑的推断]** 该组证据直接支撑了“旧方法为何不够”的论点，证明了手写重构调度算法（Problem A）与高成本 Trace 采集（Problem C）是导致传统模拟器难以适配框架快速演进的根源，从而突出了 Phantora 拦截 API、直接复用源码的方法设计必要性。
- **适用范围**：覆盖概念与架构层面的逻辑对比；无额外证据缺口。

### 图 3 & 4：Figure 4 (架构图) & Figure 4 (Stream/Event 同步工作流)

- **图组结论**：Figure 4(1) 展示了 Phantora 容器层、拦截层（Tracer/CUDA Runtime/NCCL）与离散事件模拟后端（Computation/Network Simulator）的解耦架构；Figure 4(2) 详细拆解了 Rank 0 与 Rank 1 发起 FlashAttention 与 AllReduce 时 CUDA Stream/Event 依赖图构建及虚拟时间同步（sync clock）过程。
- **论证关系**：**[正文支持]** 属于`机制`证据。证实了 Phantora 能够忠实映射 CUDA 异步流与 Event 依赖，在不修改框架源码的前提下为上层 ML 框架提供“运行在真实 GPU 集群上”的时间与空间幻觉。
- **适用范围**：覆盖双 Rank 并发与异步重叠拦截机制；不能直接定量证明百卡规模下的时间回滚开销。

### 图 5 & 6：Figure 5 & Figure 6

- **图组结论**：Figure 5 展示了真实容器动态注入网络事件打破此前完成时间预测的“过去事件”冲突挑战；Figure 6 拆解了 Phantora 通过吞吐量历史记录与依赖图联动更新进行“时间回滚”的 4 步工作流。
- **论证关系**：**[正文支持]** 属于`机制`证据。证明了系统无需高开销的时间量子高频同步，即可精准解决过去事件碰撞，确保离散事件模拟的逻辑因果正确性。
- **适用范围**：覆盖松散时间同步与状态恢复机制；正文未给出回滚频次的定量微基准数据。

### 图 7 & 8：Perfetto Trace 导出 & Figure 9 (TorchTitan 128 GPU 扩展性与精度)

- **图组结论**：Figure 7 展示了 Phantora 导出的原生 Perfetto UI 追踪轨迹，直观呈现计算（MM/Linear）与通信（AllGather/Reduce）的重叠；Figure 9 在 8~128 GPU 规模下展示 Phantora 吞吐评估与 TorchTitan 官方报告高度吻合（平均误差 2.9%），且 128 卡单步模拟仅需 ~15 秒。
- **论证关系**：**[实验支持]** 属于`效果`与`机制`证据。证明了 Phantora 不仅具备与官方基准相当的高精度，而且能够原生支持计算通信重叠分析与数秒级的快速评估。
- **适用范围**：覆盖 TorchTitan 框架及 Llama2/Llama3 模型；未建模计算与通信并发时的物理干涉减速。

### 图 9 & 10：Figure 10 (Megatron Llama2 7B 吞吐对比) & Figure 11 (GPU 模拟扩展耗时)

- **图组结论**：Figure 10 展示在 Megatron 框架下，Phantora 的吞吐评估在不同并行配置与 Optimizer 设置下均紧密追踪 Ground Truth（平均误差 3.7%），而 SimAI 存在明显高估；Figure 11 展示在 32 CPU 核心限制下，Phantora 模拟耗时随 GPU 规模（8 至 256 卡）平滑增长，256 卡耗时约为 64 秒。
- **论证关系**：**[实验支持]** 属于`效果`与`对比基线`证据。验证了直接复用源码比 SimAI 手写 Mock 框架具有更高的保真度，同时证明了系统具备良好的多节点扩展能力。
- **适用范围**：覆盖 H200 测试床上的 Megatron Llama2 7B 训练；未展示不同 CPU 核心数对模拟速度的对比。

### 图 11 & 12：Figure 12 (CPU 参数共享消融) & Figure 13 (选择性激活重算 Case Study)

- **图组结论**：Figure 12 显示未开启参数共享时 DeepSpeed 模拟 9 卡即突破 256GB 内存上限，开启后 64 卡内存占用低于 64GB；Figure 13 展示 Phantora 能精准评估选择性激活重算使显存降低 60%、吞吐开销仅 15% 的权衡关系。
- **论证关系**：**[实验支持]** 属于`消融验证`与`适用边界`证据。Figure 12 证实了参数共享是消除内存爆表的核心必要设计；Figure 13 证实了 Phantora 开箱即用支持复杂新特性分析的实用价值。
- **适用范围**：覆盖 DeepSpeed 与 Megatron 框架；Figure 13 缺少真实集群开启激活重算时的 Ground Truth 实测对比曲线。

## 10. 完整因果推理树

- 根问题：在部署大规模 LLM 训练前精准估算系统性能（耗时与 MFU），指导并行策略与硬件采购。
  - 旧方法限制：传统静态模拟器要么依赖昂贵的大集群 Trace 采集与脆弱的 Workload 提取，要么必须在模拟器中手写重构框架调度算法（导致 7.4% 模型尺寸偏差、包级网络模拟极慢且难以适配新框架）。
  - 核心洞见/假设：提出混合 GPU 集群模拟（Hybrid Simulation），在单 GPU 容器中直接运行未经修改的 ML 框架源码；假设控制流与张量数值无关，且算子耗时由张量形状确定。
    - 方法模块：设计 Phantora 架构，包含透传拦截层（Tracer/CUDA Runtime/NCCL）、单 GPU Profiler 与缓存、流级网络模拟器与时间回滚机制，以及 CPU 参数共享与 CPU 时间度量。
      - 可验证预测 1：未经修改的 ML 框架（Megatron、DeepSpeed、TorchTitan）可直接运行并达到与静态模拟相当的精度。
        - 指标与实验：在 128 GPUs TorchTitan 与 Megatron 上测量 $wps$ / $mfu$ 模拟误差。
          - 图表证据：Figure 9 (TorchTitan 128 卡误差 2.9%)、Figure 10 (Megatron 误差 3.7%)。
            - 结论与适用边界：验证了高精度与源码复用；边界：未在千卡规模与非 Transformer 模型上验证。
      - 可验证预测 2：松散时间同步与时间回滚机制能正确处理过去事件并维持高效模拟。
        - 指标与实验：单步模拟运行耗时与依赖图更新逻辑。
          - 图表证据：Figure 6 (回滚 4 步工作流)、Figure 9/11 (128 卡耗时 ~15–23s)。
            - 结论与适用边界：验证了高效因果模拟；边界：正文缺少回滚触发频次的微基准数据。
      - 可验证预测 3：模型参数共享能消除单机模拟多卡时的 CPU 内存爆表瓶颈。
        - 指标与实验：不同 GPU 模拟规模下的 CPU 峰值内存占用（GB）。
          - 图表证据：Figure 12 (DeepSpeed 64 卡内存从 >256GB 降至 <64GB)。
            - 结论与适用边界：证实了参数共享的必要性；边界：未包含 CPU 时间超分配倍率消融。
      - 可验证预测 4：系统能原生开箱即用评估选择性激活重算等复杂新特性。
        - 指标与实验：单 GPU 显存峰值与训练吞吐量权衡分析。
          - 图表证据：Figure 13 (Llama2 13B 显存节省 60%，吞吐开销 15%)。
            - 结论与适用边界：证实了新特性评估能力；边界：图中缺少真实硬件 Ground Truth 实测对比曲线。

## 11. 结论、贡献与边界

### 核心贡献与充分证据结论
- **核心贡献**：提出了 ML 系统混合 GPU 集群模拟的新概念；设计并实现了 Phantora 模拟器；在 Megatron-LM、DeepSpeed 和 TorchTitan 3 个主流 LLM 框架上验证了开箱即用性与评估精度。
- **证据充分的结论**：**[实验支持]** Phantora 能在仅需单块物理 GPU 的前提下，在大规模集群（多达 128 GPUs）上达到 2.9%–3.7% 的评估误差；在 256GB 内存限制下通过参数共享成功将 64 卡模拟内存降至 64GB 以下；128 卡单步模拟时间控制在 15–23 秒内。

### 局限性与审稿式风险检查
1. **新意风险**：**[基于文中逻辑的推断]** 当前证据未显示该风险。混合模拟概念在 ML 性能评估领域具有显著的新颖性，成功突破了传统静态模拟的重构困境。
2. **写作与可复现性**：**[作者明确陈述]** 项目已开源（https://github.com/QDelta/Phantora）。但由于依赖 Runtime Patching，对底层 PyTorch/C++ 接口变动较为敏感。
3. **效果大小与实验覆盖**：**[实验支持]** 实验覆盖了主流 LLM 框架与模型，效果显著；但**[作者明确陈述]** 未在千卡以上超大规模集群及 MoE/非 Transformer 架构上进行验证。
4. **方法设计与假设边界**：
   - **数值依赖控制流**：**[作者明确陈述]** 若算法依赖张量数值（如专家并行路由不均、RLHF 动态长度），假定完全负载均衡会导致预测偏差。
   - **Megatron 限制**：**[作者明确陈述]** 必须禁用梯度剪裁（gradient clipping），否则 CPU 上的开方操作会因随机数值报错。
   - **物理干涉**：**[作者明确陈述]** 未物理建模计算与通信并发时的硬件物理干涉减速。

## 12. 术语与第一性原理学习路径

### 12.1 核心术语

1. **混合模拟（Hybrid Simulation）**
   - **最小定义**：将真实代码执行与离散事件模拟无缝结合的技术。
   - **第一性原理角色**：在物理资源约束（仅 1 GPU）下，通过透传拦截为真实代码创造全集群执行的因果与时间幻觉。
   - **本文位置**：Phantora 的核心顶层架构范式。
2. **运行时补丁（Runtime Patching）**
   - **最小定义**：在程序运行期动态替换函数或模块的技术。
   - **第一性原理角色**：在不修改源码约束下，拦截不可配置的系统依赖（如计时器）。
   - **本文位置**：用于替换 `time.perf_counter` 等接口，确保框架使用虚拟时钟。
3. **虚拟时钟（Virtual Clock）**
   - **最小定义**：模拟器为每个节点维护的逻辑计时器。
   - **第一性原理角色**：连接物理实际时间与事件驱动模拟逻辑时间的桥梁。
   - **本文位置**：由 Phantora 模拟器根据算子与通信评估结果统一推进。
4. **时间回滚（Time Rollback）**
   - **最小定义**：当收到过去发生的事件时，将模拟器恢复到过去状态并重新计算的操作。
   - **第一性原理角色**：解决离散事件模拟中过去事件破坏既有预测的时间因果冲突。
   - **本文位置**：网络模拟器处理动态注入网络事件的核心机制。
5. **最大最小公平性（Max-Min Fairness）**
   - **最小定义**：一种优先满足小需求流量、均分剩余带宽的网络资源分配原则。
   - **第一性原理角色**：网络物理带宽约束下的通信吞吐求解法则。
   - **本文位置**：流级网络模拟器（netsim）水填算法的理论基础。
6. **模型参数共享（Model Parameter Sharing）**
   - **最小定义**：将多个容器的模型权重映射到同一物理内存区域的技术。
   - **第一性原理角色**：突破单机物理 CPU 主存限制的资源优化手段。
   - **本文位置**：Phantora 解决单机模拟多卡内存爆表的核心模块。

### 12.2 学习路径

理解本文前建议按以下依赖顺序补充前置概念：

1. **基本对象（GPU 算子与分布式张量）**：了解 PyTorch 中 Tensor 的 shape、Dtype 以及 FlashAttention、Matmul 等算子的基本计算过程。
2. **物理约束（集群网络与 NVLink/RDMA）**：理解分布式训练中节点内 NVLink 高速互联与节点间 RDMA 网络的带宽与延迟限制。
3. **因果机制（CUDA 异步 Stream 与 Event 同步）**：理解 CPU 如何向 GPU Stream 异步下发 kernel，以及如何使用 Event 协调计算与通信重叠。
4. **系统行为（离散事件模拟与虚拟时间推进）**：理解事件队列如何按照时间戳顺序推进系统状态更新。