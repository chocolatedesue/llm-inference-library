#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[Phantora: Maximizing Code Reuse in Simulation-based Machine Learning System Performance Estimation]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Jianxing Qin, Jingrong Chen, Xinhao Kong, Yongji Wu, Tianjun Yuan, Liang Luo, Zhaodong Wang, Ying Zhang, Tingjun Chen, Alvin R. Lebeck, Danyang Zhuo]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[USENIX Symposium on Networked Systems Design and Implementation · 2026]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[ML Systems] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU Cluster Simulation] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Performance Estimation] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Code Reuse] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM Training]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[代码：https://github.com/QDelta/Phantora]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

现代机器学习（ML）训练工作负载对计算和通信资源提出了巨大需求。因此，准确的性能估算对于指导系统设计决策（例如并行化策略的选择、集群配置和硬件资源供给）变得越来越关键。现有的基于模拟的性能估算需要在模拟器中重新实现 ML 框架，这需要巨大的手动工作量，并且随着 ML 框架的快速演进难以维护。

本文提出了 Phantora，一种专门用于 ML 训练工作负载性能估算的混合 GPU 集群模拟器。Phantora 在分布式容器化环境中按原样运行未作修改的 ML 框架。每个容器模拟大规模集群中 GPU 服务器的行为，而 Phantora 则拦截并模拟与 GPU 和通信相关的操作，以提供高保真的性能估算。与模拟静态工作负载的传统方法相比，我们将这种方法称为 ML 系统的混合模拟。混合模拟的核心优势在于允许在模拟中直接复用 ML 框架的源代码，避免了重新实现的需要。我们的评估结果表明，Phantora 能够提供与静态工作负载模拟相媲美的准确性，同时开箱即用支持三种最先进的 LLM 训练框架。此外，Phantora 可以在单个 GPU 上运行，消除了传统基于 Trace 的模拟器所必需的耗费大量资源的 Trace 采集和工作负载提取步骤。Phantora 已在 #link("https://github.com/QDelta/Phantora") 开源。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [Phantora: Maximizing Code Reuse in Simulation-based Machine Learning System Performance Estimation],
    [作者], [Jianxing Qin, Jingrong Chen, Xinhao Kong, Yongji Wu, Tianjun Yuan, Liang Luo, Zhaodong Wang, Ying Zhang, Tingjun Chen, Alvin R. Lebeck, Danyang Zhuo],
    [发表场所 / 年份], [USENIX Symposium on Networked Systems Design and Implementation / 2026],
    [研究领域], [Machine Learning Systems],
    [关键词], [ML Systems, GPU Cluster Simulation, Performance Estimation, Code Reuse, LLM Training],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：#link("https://github.com/QDelta/Phantora")

#quote(block: true)[
#strong[标签（3--5 个）]：`ML Systems` · `GPU Cluster Simulation` · `Performance Estimation` · `Code Reuse` · `LLM Training`
]

#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] Phantora 提出了用于机器学习（ML）系统性能评估的"混合 GPU 集群模拟"（Hybrid Simulation，将真实系统代码执行与离散事件模拟无缝集成的技术）架构，通过在单 GPU 容器化环境中直接运行未经修改的 ML 框架源码，结合透传拦截、单卡算子性能 Profiling、流级网络模拟与时间回滚机制，在保证与静态模拟相当精度（平均误差 2.9%--3.7%）的前提下，消除了手写重构框架调度逻辑的巨大维护开销。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] OCR 覆盖了论文全文文本、算法描述、实验图表解读以及开源仓库信息。
- #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 论文未披露或无法确认的信息：未披露代码的具体 arXiv/DOI 页面链接；未建模数值依赖的控制流（如动态路由的专家并行、RLHF 动态序列长度）；未建模计算与通信重叠时硬件内部物理干涉；未给出 Figure 13 在真实集群上的 Ground Truth 实测对比数据。
- #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 本报告严格基于论文 OCR 提取出的事实与推断进行解构，涉及的背景知识已明确标注。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

- #strong[基本对象与资源约束]：在大规模大语言模型（LLM）分布式训练中，集群包含大量 GPU、NVLink 以及 RDMA 高速网络资源；上层软件必须组合混合并行策略（数据、流水线、张量、专家并行）与显存优化手段（ZeRO、FSDP、选择性激活重算）。
- #strong[根问题与重要性]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 在部署大规模训练任务前，精准评估系统性能（如单迭代耗时、模型 FLOPS 利用率 MFU）对于指导并行策略选择、集群硬件配置与采购规划至关重要。然而，现有模拟器需要手写重构 ML 框架的下发调度逻辑，面临巨大的开发与维护开销。
- #strong[困难来源]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(108, 80, 154, 13%))[#text(size: 8.1pt, weight: "bold", fill: rgb(82, 57, 126))[背景知识]] 现代 ML 框架（如 Megatron-LM、DeepSpeed、TorchTitan）演进极快，新算子与新并行策略层出不穷。#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 手写重构调度逻辑的模拟器无法跟上框架迭代更新，而在真实大集群上高成本采集 Trace（运行轨迹）又严重限制了性能估算工具的实用性。
- #strong[本文的 Story]：旧路线（静态工作负载模拟）陷入了"要么必须依赖大集群采集 Trace，要么必须在模拟器中手动 Mock/重构框架调度算法"的失效困境。本文的转折在于提出"混合 GPU 集群模拟"洞见：不重写框架调度逻辑，而是让未经修改的真实 ML 框架代码在单 GPU 容器中直接运行，拦截底层 API 并向离散事件模拟器注入事件，从而实现 100% 框架代码复用。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：根问题]
  #image("assets/source-crops/img_in_image_box_640_145_1111_368.png", width: 100%)
  #emph[Figure 2: Scheduling logic needs to be reimplemented in current simulators for converting high level workload to detailed computation and communication events.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：剖析了静态模拟在反向提取 Workload 及内部 Scheduler 重新下发 Events 时的双重维护负担。

- #strong[论证关系]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 证明传统模拟器需手动编写 De-scheduling 逻辑与重构调度算法，直接导致维护开销巨大且难以适配新框架。

- #strong[适用范围]：覆盖静态工作负载模拟器的事件转换过程分析；无额外证据缺口。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

现有静态工作负载模拟（Static Workload Simulation）主要分为两类，均存在不可忽视的技术局限：

+ #strong[基于 Trace 的模拟（Trace-based simulation）]
  - #strong[原本解决的问题]：通过在真实大集群上运行框架并收集算子 Trace，进行配置探索与事件驱动模拟。
  - #strong[前提与失效条件]：依赖昂贵的大规模物理集群 Trace 采集；依赖"工作负载提取"（Workload Extraction），这本质上是反向重构框架调度逻辑，依赖脆弱的人工启发式规则，难以跨框架泛化。
  - #strong[后果]：用户一旦更改并行配置，模拟器仍需手写重构调度逻辑将抽象 Workload 重新展开为事件。
+ #strong[SimAI 模拟器]
  - #strong[原本解决的问题]：通过编写 Mock（模仿）框架直接生成底层事件，避免 Trace 采集与工作负载提取。
  - #strong[前提与失效条件]：仍需在 Mock 框架中手写重构调度逻辑，导致与特定框架版本强绑定（如给定相同配置时，SimAI 生成的模型尺寸与 Megatron 原生结构存在 7.4% 的偏差）；不支持 TorchTitan 等新框架及选择性激活重算等新特性。
  - #strong[后果]：采用数据包级（packet-level）网络模拟，导致模拟运行速度极慢（小规模测试中比 Phantora 慢数十倍）。

#strong[批判比较工作链]：

- #strong[基于 Trace 的模拟器]：原本解决大集群性能预测 -\> 依赖真实集群 Trace 采集与反向 De-scheduling 提取 -\> 本文批判其高硬件开销与脆弱启发式规则 -\> 本文提出透传拦截层与单 GPU Profiling 缓存回应 -\> 实验 Figure 9/10 检验免 Trace 下的高精度。
- #strong[SimAI]：原本解决免 Trace 事件生成 -\> 依赖 Mock 框架重构调度算法 -\> 本文批判其模型尺寸偏差 7.4%、无法适配新框架/新特性及网络包模拟极慢 -\> 本文提出混合模拟架构与流级网络模拟器回应 -\> 实验 Table 1 和 Figure 10 检验评估速度与精度。
- #strong[Wisconsin Wind Tunnel (WWT)]：原本解决体系结构共享内存模拟 -\> 依赖固定微小时间量子高频同步 -\> 本文批判其同步开销巨大、极大地拖慢模拟速度 -\> 本文提出松散时间同步与时间回滚机制回应 -\> 实验 Figure 9/11 检验模拟运行速度与扩展性。

== 5. 核心洞见与假设
<5-核心洞见与假设>

- #strong[核心洞见（Hybrid Simulation）]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 将真实的系统执行与事件驱动模拟直接集成，为 ML 框架创造运行在真实 GPU 集群上的"时间与空间幻觉"。在容器化环境中利用单块物理 GPU 执行未经修改的 ML 框架源码，拦截 PyTorch、CUDA Runtime 和 NCCL 的 API 调用；计算 kernel 耗时在单 GPU 上 Profiling 测量并缓存，通信耗时由流级网络模拟器计算，各 rank 的虚拟时钟由模拟器统一推进。
- #strong[底层假设]：
  + #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[控制流数据无关假设]：ML 框架的控制流逻辑（决定下一个调用的算子或通信）不依赖于张量内部的具体数值（Tensor Values）。推理依据：Phantora 在显存中填充随机/垃圾数值，若控制流依赖数值，模拟将无法正常执行。
  + #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[算子耗时确定性假设]：GPU 计算 kernel 的执行时间主要由算子类型和张量形状（Tensor Shapes）决定，与具体数值无关。推理依据：Phantora 仅需对每个"算子+张量形状"组合 Profiling 一次并缓存即可复用。
  + #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[有限过去事件与回滚收敛假设]：真实系统在混合模拟中仅注入有限数量的过去事件，因此时间回滚（Time Rollback）次数有限，系统必然能向前推进。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

Phantora 从输入到输出的总流程为：用户输入未经修改的 ML 框架训练脚本与集群配置；容器层直接运行脚本，拦截层截获算子与通信 API 并推入事件队列；计算模拟器与网络模拟器协同计算逻辑时间戳并推进虚拟时钟；最终输出原生的控制台日志、吞吐量指标与 Perfetto Trace 性能轨迹。

=== 1. Phantora 环境与拦截层（Runtime Patching & Interception）
<1-phantora-环境与拦截层runtime-patching--interception>
- #strong[动机]：支持未经修改的 ML 框架直接运行，消除重写源码的需求。
- #strong[运行机制]：在容器中运行 Python 解释器。使用 Runtime Patching 动态替换不可配置依赖（如替换 `time.perf_counter`）；实现 Phantora Tracer（收集 PyTorch 算子与形状）、Phantora CUDA Runtime（模拟显存分配与追踪 Stream/Event 依赖）和 Phantora NCCL（截获通信 API）。
- #strong[优势与连接]：极低侵入性，开箱即用，将截获到的计算与通信事件推送给后端 Event Queue。

=== 2. 单 GPU 算子性能 Profiler 与缓存管理器（Operator Profiler & Performance Cache）
<2-单-gpu-算子性能-profiler-与缓存管理器operator-profiler--performance-cache>
- #strong[动机]：在无需真实大集群的前提下，精准获取单个 GPU 算子在目标张量形状下的真实耗时。
- #strong[运行机制]：截获计算算子后，在单块物理 GPU 上实际 Profiling 执行该算子；将结果存入 Performance Cache；后续相同算子及形状直接查表。
- #strong[优势与连接]：仅需单 GPU 即可完成大规模集群计算耗时评估，消除重复 Profiling 开销，输出逻辑执行耗时给离散事件模拟器。

=== 3. 网络模拟与松散时间同步/时间回滚机制（Flow-Level Netsim & Time Rollback）
<3-网络模拟与松散时间同步时间回滚机制flow-level-netsim--time-rollback>
- #strong[动机]：真实容器会动态注入网络事件，与按离散时间推进的模拟器产生"过去事件"冲突；细粒度时间量子同步开销过大。
- #strong[运行机制]：基于 NetHint 的流级模拟器（netsim）采用水填算法按最大最小公平性计算流量吞吐；保留历史吞吐状态；收到过去发生的事件时，回滚模拟器状态并重新计算受影响流的完成时间，再通过依赖图更新后续事件时间戳；当所有 rank 时间超越 $T$ 时触发垃圾回收（GC）。
- #strong[优势与连接]：避免细粒度量子同步的巨大开销，输出通信完成时间线以推进 rank 虚拟时钟。

=== 4. 扩展性优化模块：CPU 内存共享与 CPU 时间度量（Parameter Sharing & CPU Time）
<4-扩展性优化模块cpu-内存共享与-cpu-时间度量parameter-sharing--cpu-time>
- #strong[动机]：单机模拟多容器时，每个容器独立加载模型会导致 CPU 内存爆表；CPU 核心超分配会导致进程频繁上下文切换，虚高墙上时间。
- #strong[运行机制]：将同一模拟服务器上不同容器的模型参数透明映射到共享内存同一区域，单服务器仅初始化一份模型拷贝；仅统计每个进程实际消耗的 CPU 时间（CPU time），排除上下文切换干扰。
- #strong[优势与连接]：突破单机模拟节点规模瓶颈（256GB 内存下 64 GPUs 占用降至 64GB 以下），维持 CPU 资源紧张时的模拟精度。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法]
  #image("assets/source-crops/img_in_image_box_107_145_590_348.png", width: 100%)
  #emph[Figure 3: Phantora architecture. Components in light green are unmodified, components in green are minimally modified, and components in blue are constructed by Phantora.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示了 Phantora 容器层、拦截层与离散事件模拟器后端的解耦架构与事件流向。

- #strong[论证关系]：#strong[\[正文支持\]] 证明 Phantora 能通过透传拦截 API 在不修改框架源码的前提下复用代码并提供集群运行幻觉。

- #strong[适用范围]：覆盖 Phantora 混合 GPU 集群模拟器的总体架构设计与组件交互流程。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法]
  #image("assets/source-crops/img_in_image_box_163_142_1061_614.png", width: 100%)
  #emph[Figure 4: An example workflow of Phantora with two ranks. ML system places computation and communications on different CUDA streams for flexibility, and use CUDA events to manage the synchronization between them. Phantora needs to correctly handle these synchronizations to achieve accurate simulation.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：拆解了双 Rank 执行 FlashAttention 与 AllReduce 时 CUDA Stream/Event 依赖图构建及虚拟时间同步过程。

- #strong[论证关系]：#strong[\[正文支持\]] 证实 Phantora 能忠实映射 CUDA 异步流与 Event 依赖，保障并发计算与通信的仿真正确性。

- #strong[适用范围]：覆盖双 Rank 并发与异步重叠拦截机制；不能直接证明百卡规模下的时间回滚开销。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

+ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[拦截层 -\> 零源码修改 -\> 高代码复用与框架兼容性]：通过在 Python/CUDA/NCCL 层透传拦截 API 调用，ML 框架感知不到底层是虚拟环境，从而能够 100% 复用框架原生调度逻辑，天然适配新框架与新特性。
+ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[单 GPU Profiling 缓存 -\> 免大集群硬件 -\> 低物理资源开销]：基于算子耗时仅由张量形状决定的确定性假设，利用单块 GPUProfiling 并缓存结果即可准确推算全集群计算时间。
+ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[松散同步与时间回滚 -\> 消除量子同步开销 -\> 高模拟运行效率]：允许容器异步推进，仅在发生过去事件碰撞时沿着依赖图精准回滚重新计算，既保证了因果时间轴正确，又大幅降低了高频同步开销。
+ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[内存共享与 CPU 时间 -\> 消除单机资源瓶颈 -\> 大规模扩展性]：透明共享模型参数内存，避免了 N 个容器重复加载模型的内存爆表；采用 CPU 时间度量消除了超分配时的上下文切换干扰。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[问题 1（效果）]：Phantora 的模拟精度是否能达到与传统静态模拟或真实物理测试床相当的水平？判定标准：在多框架、多规模下的吞吐量评估误差是否控制在数个百分点以内。
- #strong[问题 2（机制与扩展性）]：Phantora 在单机上模拟大规模 GPU 集群时的运行速度与主存扩展能力如何？判定标准：单步模拟耗时是否在数十秒内，CPU 内存占用是否低于硬件上限。
- #strong[问题 3（适用范围）]：Phantora 是否能无缝支持复杂新特性（如选择性激活重算）的吞吐与显存联合分析？判定标准：能否开箱即用准确评估显存节省与吞吐权衡。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- #strong[硬件测试床]：
  - H200 测试床：2x AMD EPYC 9355 CPU, 4x NVIDIA H200 NVL GPU。
  - A100 测试床：2x Intel Xeon Gold 6348 CPU, 1x NVIDIA A100 40G GPU。
- #strong[评估框架与模型]：Megatron-LM、DeepSpeed、TorchTitan；模型涵盖 Llama2 (7B, 13B, 70B)、Llama3 (8B, 70B)。
- #strong[基线与统计设置]：对比真实测试床（Ground Truth）、SimAI 静态模拟器及官方公开基准报告；重复多次迭代取均值（带 95% 置信区间）。作者未报告的具体超参数在文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
+ #strong[$w p s$（Words/Tokens Per Second，每秒处理 Token 数）]

  - #strong[指标与方向]：模型训练吞吐量，单位 tokens/s。越大越好。
  - #strong[定义与公式]：`原文公式` $ w p s = frac(n t o k e n s\_s i n c e\_l a s t\_l o g, t i m e\_d e l t a times p a r a l l e l\_d i m s . m o d e l\_p a r a l l e l\_s i z e) $ 对应 Section 5.1 / Figure 7。$n t o k e n s\_s i n c e\_l a s t\_l o g$ 为日志间隔 token 数；$t i m e\_d e l t a$ 为间隔秒数；$p a r a l l e l\_d i m s . m o d e l\_p a r a l l e l\_s i z e$ 为模型并行维度。
  - #strong[实验用途]：评估 TorchTitan 训练吞吐量及 Phantora 输出一致性。
  - #strong[读数与边界]：用于衡量整体训练吞吐，不直接反映单算子延迟。

+ #strong[$m f u$（Model FLOPS Utilization，模型 FLOPS 利用率）]

  - #strong[指标与方向]：硬件算力利用率，单位 %。越大越好。
  - #strong[定义与公式]：`原文公式` $ m f u = frac(100 times n u m\_f l o p\_p e r\_t o k e n times w p s, g p u\_p e a k\_f l o p s) $ 对应 Section 5.1 / Figure 7。$n u m\_f l o p\_p e r\_t o k e n$ 为单 token 计算量；$w p s$ 为吞吐量；$g p u\_p e a k\_f l o p s$ 为理论峰值算力。
  - #strong[实验用途]：评估 GPU 硬件算力利用率与性能日志输出。
  - #strong[读数与边界]：依赖硬件理论峰值定义，无法区分通信等待与计算低效。

+ #strong[$t i m e\_e n d\_t o\_e n d$（端到端平均迭代耗时）]

  - #strong[指标与方向]：单次训练迭代平均耗时，单位秒（s）。越小越好。
  - #strong[定义与公式]：`原文公式` $ t i m e\_e n d\_t o\_e n d = frac(t i m e\_d e l t a, j o b\_c o n f i g . m e t r i c s . l o g\_f r e q) $ 对应 Section 5.1 / Figure 7。$t i m e\_d e l t a$ 为日志间隔总时间；$j o b\_c o n f i g . m e t r i c s . l o g\_f r e q$ 为日志记录步数。
  - #strong[实验用途]：评估单迭代运行耗时。
  - #strong[读数与边界]：包含计算与通信综合时间。

+ #strong[$t i m e\_d a t a\_l o a d i n g$（数据加载平均耗时）]

  - #strong[指标与方向]：训练数据加载平均耗时，单位秒（s）。越小越好。
  - #strong[定义与公式]：`原文公式` $ t i m e\_d a t a\_l o a d i n g = upright("np.mean")\(d a t a\_l o a d i n g\_t i m e s\) $ 对应 Section 5.1 / Figure 7。$d a t a\_l o a d i n g\_t i m e s$ 为数据加载耗时采样数组；$ upright("np.mean") $ 为算术平均。
  - #strong[实验用途]：评估数据加载开销。
  - #strong[读数与边界]：仅衡量 IO/数据准备阶段。

+ #strong[平均模拟误差率（Average Simulation Error）]

  - #strong[指标与方向]：模拟吞吐量与真实集群值的相对偏差，单位 %。越小越好。
  - #strong[定义与公式]：`推导关系（非原文公式）` #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 推理依据：文中多处引用 average error（如 2.9%, 3.7%）与 maximum error，基于文字描述其含义为模拟吞吐量与 Ground Truth 实测值之间的相对偏差聚合，但原文未给出正式 Eq. 编号。
  - #strong[实验用途]：验证 Phantora 模拟精度的有效性。
  - #strong[读数与边界]：TorchTitan 128 卡下平均误差 2.9%（最大 8.5%）；Megatron 下平均误差 3.7%（最大 5.3%）。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]：

#figure(
  align(center)[#table(
    columns: 5,
    align: (left,left,left,left,left,),
    table.header([比较工作 / 基线], [原本试图解决的问题 / 优势], [本文指出的具体 Limit / 失效条件], [本文对应的设计模块], [检验批判的比较实验 / 指标 / 图表],),
    table.hline(),
    [#strong[基于 Trace 的模拟器]], [基于真实运行 Trace 进行抽象工作负载提取与事件驱动模拟。], [1. 需在真实大集群高成本收集 Trace。2. 工作负载提取属反向重构调度逻辑，依赖脆弱启发式规则。3. 无法应对框架快速演进。], [混合模拟架构 + 容器内直接执行源码 + Phantora API 拦截与 Profiler], [免大集群 Trace 下，在单 GPU 运行 TorchTitan/Megatron 并测量吞吐误差 (Figure 9, Figure 10)],
    [#strong[SimAI]], [通过 Mock 框架直接生成事件，避免 Trace 收集与 Workload 提取。], [1. 仍需在 Mock 框架中重写调度逻辑（模型尺寸偏差达 7.4%）。2. 不支持 TorchTitan 与激活重算等新特性。3. 包级网络模拟运行极慢。], [流级网络模拟器 (netsim) + 依赖拦截 + CPU 内存共享], [Figure 10（精度及模型尺寸偏差对比）、Table 1（运行耗时对比）、Section 5.4（激活重算 Case Study）],
    [#strong[Wisconsin Wind Tunnel (WWT)]], [利用执行驱动模拟评估共享内存系统。], [采用固定微小时间量子在各组件间高频同步，带来巨大的同步开销，极大地拖慢模拟速度。], [松散时间同步与时间回滚机制], [模拟运行耗时与扩展性实验 (Figure 9, Figure 11)],
  )]
  , kind: table
  )

#strong[主张地图与证据表]：

#figure(
  align(center)[#table(
    columns: 3,
    align: (left,left,left,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [#strong[主张 1（效果）]：直接复用 ML 框架源码，且模拟精度与静态模拟相当（平均误差 2.9%--3.7%）。], [Section 5.2 (Figure 9, Figure 10)], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 强证据。覆盖 TorchTitan (128 GPUs) 与 Megatron-LM；边界：未在千卡规模及非 Transformer 模型上测试。],
    [#strong[主张 2（机制）]：通过松散时间同步与时间回滚机制，正确且高效处理过去事件。], [Section 3, Section 4.2 (Figure 5, Figure 6)], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 机制逻辑自洽，Figure 6 拆解了工作流；边界：正文缺少回滚触发频次与开销占比的统计数据。],
    [#strong[主张 3（必要性）]：CPU 参数共享与 CPU 时间度量消除单机模拟多卡时的内存爆表与 CPU 争抢。], [Section 4.3, Section 5.3 (Figure 12)], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 强证据。Figure 12 证明 64 卡 DeepSpeed 内存从爆表 \>256GB 降至 \<64GB；边界：未给出不同超分配倍率下的墙上时间对比。],
    [#strong[主张 4（适用范围）]：原生支持选择性激活重算等复杂新特性的显存与吞吐联合分析。], [Section 5.4 (Figure 13)], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 效果与适用范围证据。Figure 13 展示了显存与吞吐权衡；边界：缺少真实集群开启激活重算时的 Ground Truth 实测对比曲线。],
  )]
  , kind: table
  )

#strong[关键实验设置解释]：

- 3 个 LLM 训练框架均无需修改源码即可在 Phantora 上运行。Megatron 需 0 行补丁（需禁用梯度剪裁）；DeepSpeed 需 4 行补丁；TorchTitan 需 1 行补丁；训练脚本仅需添加约 6 行代码。
- 在 Megatron 小规模测试中，TP=4, batch=1 时测试床耗时 0.30s，Phantora 耗时 0.91s，而 SimAI 耗时 56.9s（Table 1）。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_169_137_1051_665.png", width: 100%)
    #emph[Figure 1: Comparison of simulators and problems of static workload simulation. Light green boxes show unmodified components; green boxes show minimally modified components; blue boxes show simulator components and pink boxes show user input. Trace-based simulation requires workload extraction (reversing framework logic) and costly trace collection on large clusters. SimAI relies on mocked ML frameworks.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：旧方法为何不够]
    - #strong[图组结论]：对比了 Phantora 混合模拟与传统 Trace-based 和 SimAI 静态模拟在架构与代码复用上的根本差异。

- #strong[论证关系]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 证明重构调度算法与高成本 Trace 采集是静态模拟的局限，突出了 Phantora 拦截 API 并直接复用源码的必要性。

- #strong[适用范围]：覆盖概念与架构层面的逻辑对比；无额外证据缺口。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0007-d02782144994.png", width: 100%)
    #emph[Figure 5: Challenges of synchronizing time between real execution and event-driven simulation.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法]
    - #strong[图组结论]：展示了真实容器动态注入网络事件打破此前完成时间预测的"过去事件"冲突挑战。

- #strong[论证关系]：#strong[\[正文支持\]] 揭示了混合模拟中真实执行与网络模拟器之间的时间同步难点，阐明了引入时间回滚机制的核心动因。

- #strong[适用范围]：覆盖动态事件注入与因果冲突挑战说明；无额外证据缺口。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_112_144_586_270.png", width: 100%)
    #emph[Figure 6: Handing past events in the event-driven simulator using time rollback. The network state at is a superposition of the states at and .]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法]
    - #strong[图组结论]：拆解了 Phantora 通过吞吐量历史记录与依赖图联动更新进行时间回滚的 4 步工作流。

- #strong[论证关系]：#strong[\[正文支持\]] 证明系统无需高开销的时间量子高频同步，即可精准解决过去事件碰撞，确保离散事件模拟的逻辑因果正确性。

- #strong[适用范围]：覆盖松散时间同步与状态恢复机制；正文未给出回滚频次的定量微基准数据。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_632_140_1121_520.png", width: 100%)
    #emph[Figure 8: Perfetto \[3\] trace exported by Phantora.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标]
    - #strong[图组结论]：展示了 Phantora 导出的原生 Perfetto UI 追踪轨迹，直观呈现计算与通信在时间轴上的并行重叠。

- #strong[论证关系]：#strong[\[正文支持\]] 证明 Phantora 无需重写框架调度逻辑即可准确捕获多 Stream 上的异步重叠，支持原生的可视化性能追踪。

- #strong[适用范围]：覆盖 TorchTitan 框架下 Perfetto Trace 导出；未物理建模计算通信重叠时的硬件干涉。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_124_146_1099_352.png", width: 100%)
    #emph[Figure 9: Accuracy and speed of Phantora (large scale): Training throughput reported by TorchTitan \[21\] using FSDP2, simulation results and simulation speed of Phantora on the testbeds. The error bars show 95% confidence interval. "ac" means activation checkpointing in TorchTitan \[21\].]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标]
    - #strong[图组结论]：在 8\~128 GPU 规模下 Phantora 吞吐评估与 TorchTitan 官方报告吻合（平均误差 2.9%），128 卡单步仅需 \~15 秒。

- #strong[论证关系]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 证明 Phantora 具备与官方基准相当的高精度，且能在数十秒内完成大集群单迭代评估。

- #strong[适用范围]：覆盖 TorchTitan 框架及 Llama2/Llama3 模型；未建模计算与通信并发时的物理干涉减速。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_108_481_585_700.png", width: 100%)
    #emph[Figure 10: Accuracy of Phantora (small scale): Megatron training throughput of Llama2 7B on H200 testbed with or without optimizer, Phantora simulation results with or without optimizer, and SimAI simulation results. The error bars show 95% confidence interval. Note that SimAI currently does not include optimizer in its simulation.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标]
    - #strong[图组结论]：在 Megatron 框架下 Phantora 评估紧密追踪实测 Ground Truth（平均误差 3.7%），而 SimAI 明显高估。

- #strong[论证关系]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 验证直接复用源码比 SimAI 手写 Mock 框架具有更高保真度，证明系统在多并行配置下的一致高精度。

- #strong[适用范围]：覆盖 H200 测试床上的 Megatron Llama2 7B 训练；未展示不同 CPU 核心数对模拟速度的影响。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_638_476_1113_675.png", width: 100%)
    #emph[Figure 11: Speed of Phantora: Phantora simulation time of Llama2 7B training (Megatron, TP=8) using 32 CPU cores on H200 testbed.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标]
    - #strong[图组结论]：在 32 CPU 核心限制下，Phantora 模拟耗时随 GPU 规模（8 至 256 卡）平滑增长，256 卡耗时约 64 秒。

- #strong[论证关系]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 验证了 Phantora 在单台物理服务器上具备良好的多节点扩展能力，可在有限算力下完成数百卡估算。

- #strong[适用范围]：覆盖 32 CPU 核心下 8\~256 GPUs 的扩展性评估；未展示不同 CPU 核心数配置的对比影响。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_110_455_582_629.png", width: 100%)
    #emph[Figure 12: CPU memory usage: Peak CPU memory usage of Llama2 7B training simulation in DeepSpeed with or without model parameter sharing.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标]
    - #strong[图组结论]：未开启参数共享时 DeepSpeed 模拟 9 卡即突破 256GB 内存上限，开启后 64 卡内存占用降至 64GB 以下。

- #strong[论证关系]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 证实 CPU 模型参数共享机制是消除单机模拟多 GPU 节点 CPU 内存爆表瓶颈的核心必要设计。

- #strong[适用范围]：覆盖 DeepSpeed 框架下 1\~64 GPUs 模拟；不能证明 CPU 超分配时的墙上时间变化。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0013-a34fe3c626d0.png", width: 100%)
    #emph[Figure 13: Evaluating memory saving techniques: Phantora estimated peak memory usage per GPU and throughput of Llama2 training with different memory saving techniques (64 H100 GPUs, Megatron, DP=8, TP=8). A single number n denotes the number of batches per GPU with activation recomputation. A pair in the form denotes n batches per GPU with m gradient accumulation steps.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：实验与指标]
    - #strong[图组结论]：展示 Phantora 能精准评估选择性激活重算使显存降低 60%、吞吐开销仅 15% 的权衡关系。

- #strong[论证关系]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 证实 Phantora 无需手写重写逻辑即可开箱即用支持复杂新特性的显存与吞吐联合分析。

- #strong[适用范围]：覆盖 64 H100 GPUs 下 Megatron 选择性激活重算评估；缺少真实集群开启该特性时的 Ground Truth 实测对比。
  ],
)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：在部署大规模 LLM 训练前精准估算系统性能（耗时与 MFU），指导并行策略与硬件采购。
  - 旧方法限制：传统静态模拟器要么依赖昂贵的大集群 Trace 采集与脆弱的 Workload 提取，要么必须在模拟器中手写重构框架调度算法（导致 7.4% 模型尺寸偏差、包级网络模拟极慢且难以适配新框架）。
  - 核心洞见/假设：提出混合 GPU 集群模拟（Hybrid Simulation），在单 GPU 容器中直接运行未经修改的 ML 框架源码；假设控制流与张量数值无关，且算子耗时由张量形状确定。
    - 方法模块：设计 Phantora 架构，包含透传拦截层（Tracer/CUDA Runtime/NCCL）、单 GPU Profiler 与缓存、流级网络模拟器与时间回滚机制，以及 CPU 参数共享与 CPU 时间度量。
      - 可验证预测 1：未经修改的 ML 框架（Megatron、DeepSpeed、TorchTitan）可直接运行并达到与静态模拟相当的精度。
        - 指标与实验：在 128 GPUs TorchTitan 与 Megatron 上测量 $w p s$ / $m f u$ 模拟误差。
          - 图表证据：Figure 9 (TorchTitan 128 卡误差 2.9%)、Figure 10 (Megatron 误差 3.7%)。
            - 结论与适用边界：验证了高精度与源码复用；边界：未在千卡规模与非 Transformer 模型上验证。
      - 可验证预测 2：松散时间同步与时间回滚机制能正确处理过去事件并维持高效模拟。
        - 指标与实验：单步模拟运行耗时与依赖图更新逻辑。
          - 图表证据：Figure 6 (回滚 4 步工作流)、Figure 9/11 (128 卡耗时 \~15--23s)。
            - 结论与适用边界：验证了高效因果模拟；边界：正文缺少回滚触发频次的微基准数据。
      - 可验证预测 3：模型参数共享能消除单机模拟多卡时的 CPU 内存爆表瓶颈。
        - 指标与实验：不同 GPU 模拟规模下的 CPU 峰值内存占用（GB）。
          - 图表证据：Figure 12 (DeepSpeed 64 卡内存从 \>256GB 降至 \<64GB)。
            - 结论与适用边界：证实了参数共享的必要性；边界：未包含 CPU 时间超分配倍率消融。
      - 可验证预测 4：系统能原生开箱即用评估选择性激活重算等复杂新特性。
        - 指标与实验：单 GPU 显存峰值与训练吞吐量权衡分析。
          - 图表证据：Figure 13 (Llama2 13B 显存节省 60%，吞吐开销 15%)。
            - 结论与适用边界：证实了新特性评估能力；边界：图中缺少真实硬件 Ground Truth 实测对比曲线。

== 11. 结论、贡献与边界
<11-结论贡献与边界>

=== 核心贡献与充分证据结论
<核心贡献与充分证据结论>
- #strong[核心贡献]：提出了 ML 系统混合 GPU 集群模拟的新概念；设计并实现了 Phantora 模拟器；在 Megatron-LM、DeepSpeed 和 TorchTitan 3 个主流 LLM 框架上验证了开箱即用性与评估精度。
- #strong[证据充分的结论]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] Phantora 能在仅需单块物理 GPU 的前提下，在大规模集群（多达 128 GPUs）上达到 2.9%--3.7% 的评估误差；在 256GB 内存限制下通过参数共享成功将 64 卡模拟内存降至 64GB 以下；128 卡单步模拟时间控制在 15--23 秒内。

=== 局限性与审稿式风险检查
<局限性与审稿式风险检查>
+ #strong[新意风险]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 当前证据未显示该风险。混合模拟概念在 ML 性能评估领域具有显著的新颖性，成功突破了传统静态模拟的重构困境。
+ #strong[写作与可复现性]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 项目已开源（#link("https://github.com/QDelta/Phantora）。但由于依赖") Runtime Patching，对底层 PyTorch/C++ 接口变动较为敏感。
+ #strong[效果大小与实验覆盖]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 实验覆盖了主流 LLM 框架与模型，效果显著；但\*\*\[作者明确陈述\]\*\* 未在千卡以上超大规模集群及 MoE/非 Transformer 架构上进行验证。
+ #strong[方法设计与假设边界]：
  - #strong[数值依赖控制流]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 若算法依赖张量数值（如专家并行路由不均、RLHF 动态序列长度），假定完全负载均衡会导致预测偏差。
  - #strong[Megatron 限制]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 必须禁用梯度剪裁（gradient clipping），否则 CPU 上的开方操作会因随机数值报错。
  - #strong[物理干涉]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 未物理建模计算与通信并发时的硬件物理干涉减速。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
+ #strong[混合模拟（Hybrid Simulation）]
  - #strong[最小定义]：将真实代码执行与离散事件模拟无缝结合的技术。
  - #strong[第一性原理角色]：在物理资源约束（仅 1 GPU）下，通过透传拦截为真实代码创造全集群执行的因果与时间幻觉。
  - #strong[本文位置]：Phantora 的核心顶层架构范式。
+ #strong[运行时补丁（Runtime Patching）]
  - #strong[最小定义]：在程序运行期动态替换函数或模块的技术。
  - #strong[第一性原理角色]：在不修改源码约束下，拦截不可配置的系统依赖（如计时器）。
  - #strong[本文位置]：用于替换 `time.perf_counter` 等接口，确保框架使用虚拟时钟。
+ #strong[虚拟时钟（Virtual Clock）]
  - #strong[最小定义]：模拟器为每个节点维护的逻辑计时器。
  - #strong[第一性原理角色]：连接物理实际时间与事件驱动模拟逻辑时间的桥梁。
  - #strong[本文位置]：由 Phantora 模拟器根据算子与通信评估结果统一推进。
+ #strong[时间回滚（Time Rollback）]
  - #strong[最小定义]：当收到过去发生的事件时，将模拟器恢复到过去状态并重新计算的操作。
  - #strong[第一性原理角色]：解决离散事件模拟中过去事件破坏既有预测的时间因果冲突。
  - #strong[本文位置]：网络模拟器处理动态注入网络事件的核心机制。
+ #strong[最大最小公平性（Max-Min Fairness）]
  - #strong[最小定义]：一种优先满足小需求流量、均分剩余带宽的网络资源分配原则。
  - #strong[第一性原理角色]：网络物理带宽约束下的通信吞吐求解法则。
  - #strong[本文位置]：流级网络模拟器（netsim）水填算法的理论基础。
+ #strong[模型参数共享（Model Parameter Sharing）]
  - #strong[最小定义]：将多个容器的模型权重映射到同一物理内存区域的技术。
  - #strong[第一性原理角色]：突破单机物理 CPU 主存限制的资源优化手段。
  - #strong[本文位置]：Phantora 解决单机模拟多卡内存爆表的核心模块。

=== 12.2 学习路径
<122-学习路径>
理解本文前建议按以下依赖顺序补充前置概念：

+ #strong[基本对象（GPU 算子与分布式张量）]：了解 PyTorch 中 Tensor 的 shape、Dtype 以及 FlashAttention、Matmul 等算子的基本计算过程。
+ #strong[物理约束（集群网络与 NVLink/RDMA）]：理解分布式训练中节点内 NVLink 高速互联与节点间 RDMA 网络的带宽与延迟限制。
+ #strong[因果机制（CUDA 异步 Stream 与 Event 同步）]：理解 CPU 如何向 GPU Stream 异步下发 kernel，以及如何使用 Event 协调计算与通信重叠。
+ #strong[系统行为（离散事件模拟与虚拟时间推进）]：理解事件队列如何按照时间戳顺序推进系统状态更新。
