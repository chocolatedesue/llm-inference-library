# 图片批次 2

## 图片 1：Figure 3: Phantora architecture. Components in light green are unmodified, components in green are minimally modified, and components in blue are constructed by Phantora.

![Figure 3: Phantora architecture. Components in light green are unmodified, components in green are minimally modified, and components in blue are constructed by Phantora.](../assets/imgs/img_in_image_box_107_145_590_348.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：作者展示 Phantora 的整体系统架构与组件交互流程，用以解释如何通过容器化环境直接运行未经修改的 ML 框架源码，并拦截计算与通信事件以实现混合 GPU 集群模拟（Hybrid Simulation）。其证据类型为 `机制`，试图解释 Phantora 如何消除重新实现 ML 框架调度逻辑的维护负担并降低硬件资源需求。`[正文支持]`
   - **图表角色**：`方法流水线`
   - **上文呼应**：对应报告中 Section 3（Overview）与 Section 4.1（Supporting Unmodified ML Frameworks），呼应主张地图中“1. Phantora 环境与拦截层”。
2. **图像类型与布局**：系统架构示意图与组件交互流程图。左侧为“Containers”（容器层），右侧为“Phantora Simulator”（模拟器层），右上方关联“Performance Estimation Cache”、“PyTorch”与“1 GPU”物理硬件。不同组件以颜色区分（浅绿/绿代表未修改或极小修改，蓝色代表 Phantora 自研构建），并通过四类不同颜色与形状的箭头线段连接。
3. **如何阅读**：按从左至右、从框架接口到模拟后端的顺序阅读。浅绿色/绿色框代表运行中的 ML 框架栈（Training Script, Framework, PyTorch）；蓝色框代表 Phantora 拦截层（Phantora Tracer, Phantora NCCL, Phantora CUDA Runtime）与模拟器组件（Event Queue, Computation Simulator, Network Simulator）。观察不同箭头的走向：蓝色实线代表计算事件（Computation Events），绿色实线代表通信事件（Communication Events），橙色虚线代表时间戳同步（Timestamp Synchronization），黑色点线代表 Phantora 控制流（Phantora Control Flow）。
4. **直接可见的结论**：
   - 训练脚本、ML 框架和 PyTorch 核心模块为浅绿/绿色（未修改或极小修改），而 Phantora Tracer、Phantora NCCL、Phantora CUDA Runtime 以及模拟器核心组件为蓝色（自研拦截与模拟组件）。`[图像直接可见]`
   - 计算事件由 PyTorch 内的 Phantora Tracer 和 Phantora CUDA Runtime 抛出至 Event Queue，通信事件由 Phantora NCCL 抛出至 Event Queue。`[图像直接可见]`
   - Computation Simulator 通过 Performance Estimation Cache 查表与更新，并在单块物理 GPU（1 GPU）上直接调用 PyTorch 执行实际 Profiling；Network Simulator 负责通信时间计算。`[图像直接可见]`
   - Event Queue 分别与 Containers、Computation Simulator 和 Network Simulator 进行双向时间戳同步（Timestamp Synchronization）。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：
   - 属于 `机制` 验证。证明了 Phantora 能够通过拦截 PyTorch、CUDA Runtime 与 NCCL 接口，在不修改 ML 框架源码的前提下，直接复用真实 ML 框架代码进行事件提取与模拟。`[正文支持]`
   - 展示了 Phantora 的解耦设计：Containers 仅负责抛出事件并同步虚拟时间，计算 Profiling 被收拢在 Computation Simulator 中并复用 1 GPU 缓存，通信由 Network Simulator 评估，从而彻底避免了重新实现框架调度逻辑的难题。`[基于文中逻辑的推断]`
   - 该架构图展示的是静态系统组成与事件流向，无法直接证明系统在大规模集群上的具体定量误差百分比或实际运行速度。`[正文支持]`
6. **适用范围与证据缺口**：本图覆盖 Phantora 混合 GPU 集群模拟器的总体架构设计与组件交互流程。`[正文支持]` 无额外证据缺口。

---

## 图片 2：Figure 4: An example workflow of Phantora with two ranks. ML system places computation and communications on different CUDA streams for flexibility, and use CUDA events to manage the synchronization between them. Phantora needs to correctly handle these synchronizations to achieve accurate simulation.

![Figure 4: An example workflow of Phantora with two ranks. ML system places computation and communications on different CUDA streams for flexibility, and use CUDA events to manage the synchronization between them. Phantora needs to correctly handle these synchronizations to achieve accurate simulation.](../assets/imgs/img_in_image_box_163_142_1061_614.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：作者展示两个 Rank（Rank 0 与 Rank 1）在 Phantora 中的具体执行工作流与 CUDA Stream/Event 同步过程，用以解释 Phantora 如何准确拦截与模拟 CUDA 异步流和事件依赖关系，以确保真实 ML 系统并发计算与通信逻辑的仿真正确性。其证据类型为 `机制`，试图解释 Phantora 如何在离散事件模拟中忠实还原 PyTorch/NCCL 的异步执行语义。`[正文支持]`
   - **图表角色**：`方法流水线`
   - **上文呼应**：对应报告中 Section 4.1（Supporting Unmodified ML Frameworks）与 Figure 4，呼应主张地图中“1. Phantora 环境与拦截层”。
2. **图像类型与布局**：时序工作流与依赖示意图。左侧为 Rank 0 的 API 调用序列，右侧为 Rank 1 的 API 调用序列，最左侧包含纵向延伸的“Time”时间轴。中间为“Phantora Simulator”大框，内置 Profiler with cache、Event Queue（包含 Rank0 与 Rank1 的 s0/s1 流事件队列）和 Network Simulator。不同操作框按颜色区分（浅蓝代表计算，浅绿代表通信，浅橙/橙代表同步）。
3. **如何阅读**：沿着最左侧时间轴自上而下阅读 Rank 0 与 Rank 1 的 API 调用步骤。蓝色实线箭头表示 Phantora 控制流（Phantora Control Flow），橙色虚线箭头表示事件依赖（Event Dependency）。观察 Rank 发起 `cudaLaunchKernel`（浅蓝）、`cudaEventCreate`/`cudaStreamWaitEvent`（浅橙）、`ncclAllReduce`（浅绿）和 `cudaStreamSynchronize`（浅橙）时，控制流如何接入中间 Phantora Simulator 内的 Profiler with cache、Event Queue 及 Network Simulator。
4. **直接可见的结论**：
   - Rank 0 和 Rank 1 分别在 stream `s0` 上发起 `flash_attn` 内核调用，控制流被送往 Phantora Simulator 顶部的 Profiler with cache 进行性能测量与缓存。`[图像直接可见]`
   - 框架通过 `cudaEventCreate` 注册事件并由 `cudaStreamWaitEvent` 创建跨 Stream 依赖后，Event Queue 中建立了 `flash_attn`（s0）与 `allReduce`（s1）之间的事件依赖关系（橙色虚线箭头）。`[图像直接可见]`
   - `ncclAllReduce` 在触发“wait for other c0 ranks”并在所有 c0 rank 就绪（all c0 ranks ready, start）后，被送入 Network Simulator 计算通信时间。`[图像直接可见]`
   - 调用的 `cudaStreamSynchronize(s1)` 触发 sync clock 操作，将计算/通信完成后推进的虚拟时间戳同步回 Rank。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：
   - 属于 `机制` 验证。证明了 Phantora 的 Event Queue 与依赖图设计能够忠实映射 CUDA 的异步 Stream 和 Event 依赖，使得 ML 框架在不同 Stream 上安排计算与通信重叠时，模拟器仍能维持严格的逻辑因果关系。`[正文支持]`
   - 说明了虚拟时钟同步（sync clock）的具体触发节点，解释了底层如何为上层 ML 框架提供“运行在真实 GPU 集群上”的时间幻觉。`[基于文中逻辑的推断]`
   - 该图为 2-Rank 典型用例示意图，不能直接证明在大规模节点下发生时间回滚（Time Rollback）时的定量频次与开销。`[正文支持]`
6. **适用范围与证据缺口**：本图覆盖 Phantora 针对双 Rank 执行 FlashAttention 计算与 AllReduce 通信重叠及 CUDA Stream/Event 同步拦截的具体流转逻辑。`[正文支持]` 无额外证据缺口。
