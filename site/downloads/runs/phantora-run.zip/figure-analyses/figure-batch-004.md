# 图片批次 4

## 图片 1：Figure 8: Perfetto [3] trace exported by Phantora.

![Figure 8: Perfetto [3] trace exported by Phantora.](../assets/imgs/img_in_image_box_632_140_1121_520.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：作者展示此图用于证明 Phantora 能够在无需修改框架代码的前提下，真实捕获机器学习训练中的计算与通信重叠（computation/communication overlap）等复杂运行期行为，并导出原生的 Perfetto UI 可视化追踪轨迹（Trace）。它验证了 Phantora 混合模拟架构在处理异步 Stream 与 Event 依赖时的机制有效性与功能完整性。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：对应论文第 5.1 节“通用性（Generalizability）”及主张地图中关于复杂运行期行为捕获与可视化调优功能的论述。`[正文支持]`
2. **图像类型与布局**：截图。展示由 Phantora 导出的 Perfetto UI 性能追踪可视化界面。顶部为带时间刻度（包含 10ms 528us 比例尺）的模拟时间轴；中部按 CUDA Stream/Event 轨道展示并行的通信算子图块（绿色/紫色）与 GPU 计算算子图块（粉色/橙色）；底部为选中事件的 Contextual 属性面板。
3. **如何阅读**：横轴代表模拟时间（Simulated Time）；纵轴按轨道区分不同的 CUDA Stream/Event 队列。绿色和紫色图块代表 NCCL 通信操作（如 `NcclReduce`、`NcclAllGather`），粉色和橙色图块代表 GPU 计算算子（如 `MM` 矩阵乘法、`Linear` 线性层）。观察不同轨道的图块在横轴上的重叠情况，并在底部面板查看选中通信事件的具体传输字节数（`bytes`）与目标节点（`dst`）。
4. **直接可见的结论**：
   - 紫色的 `NcclAllGather` 与绿色的 `NcclReduce` 通信图块与粉色的 `MM` 及橙色的 `Linear` 计算图块在相同的时间段内并行排列，直观呈现了计算与通信在时间轴上的重叠执行。`[图像直接可见]`
   - 高亮选中的 `NcclAllGather` 通信事件耗时为 `10ms 528us`，底部属性面板显示其传输数据量为 `1684569600` 字节（约 1.68 GB），目标节点为 `host-8`，ID 为 `2846907`。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：
   - 验证了 Phantora 通过 Phantora CUDA Runtime 和 Phantora NCCL 拦截底层 API 并维护事件依赖图的方法设计，能够准确再现 ML 框架（TorchTitan）在多 Stream 上的异步重叠调度逻辑。`[正文支持]`
   - 该证据属于**机制**与**效果**说明，证明模拟器无需重写框架调度逻辑即可支持原生的可视化追踪与重叠分析。`[正文支持]`
   - 尚不能由此图证明：在真实物理集群上计算与通信并发时争抢硬件内部资源造成的物理减速干涉（正文在局限中指出当前未建模计算与通信的物理干涉）。`[正文支持]`
6. **适用范围与证据缺口**：
   - 适用范围：本证据覆盖 TorchTitan 框架在 Phantora 模拟环境下的 Perfetto Trace 导出与重叠可视化分析。`[正文支持]`
   - 证据缺口：无额外证据缺口。

---

## 图片 2：Figure 9: Accuracy and speed of Phantora (large scale): Training throughput reported by TorchTitan [21] using FSDP2, simulation results and simulation speed of Phantora on the testbeds. The error bars show 95% confidence interval. “ac” means activation checkpointing in TorchTitan [21].

![Figure 9: Accuracy and speed of Phantora (large scale): Training throughput reported by TorchTitan [21] using FSDP2, simulation results and simulation speed of Phantora on the testbeds. The error bars show 95% confidence interval. “ac” means activation checkpointing in TorchTitan [21].](../assets/imgs/img_in_chart_box_124_146_1099_352.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：作者展示此图用于在大规模集群（多达 128 GPU）和 TorchTitan 框架下，验证 Phantora 模拟吞吐量的**精度**（与官方公开基准报告对比）以及模拟运行**速度与扩展性**。`[正文支持]`
   - **图表角色**：实验结论
   - **上文呼应**：对应论文第 5.2 节“模拟精度”与第 5.3 节“模拟速度与扩展性”，呼应正文中“ TorchTitan 128 GPU 规模下平均模拟误差为 2.9%（最大误差 8.5%），且 128 GPU 模拟每迭代仅需约 15 秒”的定量结论。`[正文支持]`
2. **图像类型与布局**：组合图（双 Y 轴：柱状图 + 折线图）。左 Y 轴为单 GPU 训练吞吐量（Throughput, tps/GPU）；右 Y 轴为 Phantora 每迭代平均模拟运行耗时（Avg Iter Time (s)）。X 轴包含 8 组涵盖不同模型（Llama3 8B/70B, Llama2 13B/70B）、集群规模（8×H100, 128×H100, 64×A100）、批次大小（b=2）及激活重算（ac / w/o ac）的配置。深蓝色柱代表官方公开报告（Public report），棕色柱代表 Phantora 模拟结果（带 95% 置信区间 Error Bar），紫色虚线代表 Phantora 的单迭代模拟耗时。
3. **如何阅读**：对比同一 X 轴配置下深蓝色柱与棕色柱的高度，评估吞吐量预测精度；对照右 Y 轴读取紫色虚线折线上的数据点，评估不同规模配置下的模拟耗时（秒）。
4. **直接可见的结论**：
   - 在所有 8 组配置中，Phantora 模拟的吞吐量（棕色柱）与官方公开报告（深蓝色柱）高度吻合。在 `Llama3 8B (8×H100, b=2)`、`Llama3 8B (128×H100, b=2)` 及 `Llama2 70B` 各配置下两柱高度几乎完全一致；在 `Llama2 13B (64×A100)` 下存在轻微偏差。`[图像直接可见]`
   - 模拟耗时（紫色折线）随模拟卡数与模型规模增加而平稳上升：在 `8×H100` 时低于 5 秒，在 `128×H100` 规模下约为 15 秒，在 `64×A100` 70B 模型配置下维持在约 20 秒。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：
   - 验证了主张 1（效果）：Phantora 的混合模拟架构能够在大规模 GPU 集群（多达 128 卡）和最新 LLM 框架（TorchTitan）上达到与官方基准高度一致的模拟精度（平均误差 2.9%）。`[正文支持]`
   - 验证了 Phantora 采用流级网络模拟器（flow-level netsim）与单 GPU Profiling 缓存的设计具备优异的扩展性，能在数秒至数十秒内完成大集群单迭代的性能评估。`[正文支持]`
   - 尚不能由此图证明：异质 GPU 集群或非 Transformer 模型的模拟精度。`[基于文中逻辑的推断]`
6. **适用范围与证据缺口**：
   - 适用范围：本证据覆盖 TorchTitan 框架在 8~128 GPU 规模（H100/A100）、Llama2/Llama3 (8B, 13B, 70B) 模型上的 FSDP2 及激活重算配置。`[正文支持]`
   - 证据缺口：无额外证据缺口。
