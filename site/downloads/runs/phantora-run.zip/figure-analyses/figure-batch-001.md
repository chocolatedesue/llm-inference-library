# 图片批次 1

## 图片 1：Figure 1: Comparison of simulators and problems of static workload simulation. Light green boxes show unmodified components; green boxes show minimally modified components; blue boxes show simulator components and pink boxes show user input. Trace-based simulation requires workload extraction (reversing framework logic) and costly trace collection on large clusters. SimAI relies on mocked ML frameworks.

![Figure 1: Comparison of simulators and problems of static workload simulation. Light green boxes show unmodified components; green boxes show minimally modified components; blue boxes show simulator components and pink boxes show user input. Trace-based simulation requires workload extraction (reversing framework logic) and costly trace collection on large clusters. SimAI relies on mocked ML frameworks.](../assets/imgs/img_in_image_box_169_137_1051_665.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：对比基线 `[正文支持]`
   - **上文呼应**：对应论文引言（Section 1）、背景（Section 2）与“旧方法的限制”章节，针对传统静态工作负载模拟（基于 Trace 的模拟与 SimAI）在重实现框架调度逻辑、反向工作负载提取与高硬件开销方面的局限性。 `[正文支持]`
   - **验证问题**：作者展示此图旨在通过架构级别的直接对比，解释为什么现有静态模拟器难以跟上 ML 框架的迅速演进，并突出 Phantora 的混合 GPU 集群模拟架构如何通过直接复用未经修改的框架源码，从根源上消除对 Trace 收集、反向工作负载提取及 Mock 框架重写的依赖。 `[基于文中逻辑的推断]`

2. **图像类型与布局**：架构对比与缺陷说明示意图。图像分为上下两大部分：上方对比了三种模拟架构（左侧 Phantora、右上 Trace-based simulators、右下 SimAI）的数据流与模块构成，使用浅绿色（未修改源码/组件）、深绿色（极小修改组件）、蓝色（模拟器专用模块）、粉色（用户配置输入）与粉褐色（GPU 硬件资源）矩形框以及灰色椭圆（中间产物与测量指标）区分；下方列出并定义了静态模拟的三大核心问题（Problem A、Problem B、Problem C）。

3. **如何阅读**：
   - **对比架构**：左侧为 Phantora 混合模拟架构；右侧上方为基于 Trace 的静态模拟器；右侧下方为 SimAI 静态模拟器。
   - **组件颜色含义**：浅绿框表示未修改的真实 ML 框架及脚本组件，深绿框表示极小修改组件（如 Phantora Tracer），蓝框表示模拟器逻辑模块（如 Phantora NCCL、Phantora CUDA Runtime、Scheduler、Simulator），粉框表示用户配置与硬件资源（1 GPU vs N GPUs）。
   - **标记与数据流**：图中用圈圈标记 A（重实现框架调度逻辑）、B（反向提取工作负载）与 C（N GPU 大集群 Trace 收集），箭头指引从配置与代码输入到最终 Performance Metrics 输出的全流程。

4. **直接可见的结论**：
   - 在 Phantora 中，Training Script 和 Framework 保持为未修改或极小修改状态，直接运行在单 GPU（1 GPU）与 Phantora 拦截层（Phantora Tracer、Phantora NCCL、Phantora CUDA Runtime）之上，直接生成 Performance Metrics。 `[图像直接可见]`
   - 基于 Trace 的模拟器需要使用 N GPUs 大集群通过 PyTorch Profiler 收集 Trace（标记 C），再结合 Manual Config 进行 Workload Extraction（标记 B）提取抽象 Workload，最后由 Scheduler（标记 A）生成 Events 输入 Simulator。 `[图像直接可见]`
   - SimAI 避免了 Trace 收集与 Workload Extraction，但必须在 Mocked Framework 中嵌入 Scheduler（标记 A）来直接生成 Events。 `[图像直接可见]`
   - 图下方明确定义了三大问题：Problem A 指模拟器需重实现框架调度算法（Scheduler = Framework）；Problem B 指从 Trace 提取 Workload 本质是反向重构调度逻辑（Manual Conf + Workload Extraction = reversed(Framework)）；Problem C 指 Trace 收集需要物理 GPU 集群（N GPUs）。 `[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - **主张类型**：机制与效果 `[基于文中逻辑的推断]`
   - **论点连接**：验证了论文在旧方法限制与核心洞见中的主张，即传统的静态模拟器均被绑定在重实现框架调度逻辑（Problem A）或高成本 Trace 收集（Problem C）上；而 Phantora 通过在单 GPU 容器化环境中利用透传拦截与源码直接执行，达成了极高的代码复用性。 `[正文支持]`
   - **方法设计含义**：解释了 Phantora 架构设计的必要性——利用 Phantora Tracer、Phantora NCCL 与 Phantora CUDA Runtime 在 Python/CUDA/NCCL 层做透传与测量，使得上层 ML 框架（Megatron、DeepSpeed、TorchTitan）完全无需感知模拟环境的存在，免去了复杂的反向提取与 Scheduler 重写。 `[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：
   - **适用范围**：覆盖论文中针对静态工作负载模拟（Trace-based 模拟器和 SimAI）与 Phantora 混合模拟架构概念层面的逻辑对比。 `[正文支持]`
   - **证据缺口**：无额外证据缺口。

---

---

## 图片 2：Figure 2: Scheduling logic needs to be reimplemented in current simulators for converting high level workload to detailed computation and communication events.

![Figure 2: Scheduling logic needs to be reimplemented in current simulators for converting high level workload to detailed computation and communication events.](../assets/imgs/img_in_image_box_640_145_1111_368.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：问题严重性 `[正文支持]`
   - **上文呼应**：对应论文第 2 节（Background）与“旧方法的限制”小节，具体剖析现有静态工作负载模拟器（SimAI 和基于 Trace 的模拟器）在将高层工作负载转换为底层计算与通信事件时，必须重实现框架调度逻辑（Scheduling Logic）的内部运作流程。 `[正文支持]`
   - **验证问题**：解释为什么静态工作负载模拟器在处理配置变更或跨框架迁移时存在难以克服的维护负担：从底层 Trace 中提取抽象 Workload 需要“De-scheduling”（反向调度），而在模拟器内部又必须通过 Scheduler 将高层 Workload 重新展开为具体的计算/通信 Events。 `[基于文中逻辑的推断]`

2. **图像类型与布局**：流程与机制结构示意图。按处理阶段从左到右组织：左侧分为 SimAI（输入 Training Config 到 Mocked Framework）与 Trace-based simulators（读取 rank0_trace, rank1_trace 等底层 API/算子日志）；中间为“De-scheduling”过程与生成的抽象 Workload 结构框（包含 model_layers, dp_groups, pp_groups, tp_groups 等）；右侧为 Simulator 内部的 Scheduler 调度生成 Events 最终求解得到 Result 的流程。

3. **如何阅读**：
   - **输入源**：上方 SimAI 的 Training Config 传入 Mocked Framework；下方 Trace-based 模拟器的 rank0_trace/rank1_trace （包含 AllGather, ReduceScatter, Embedding, Attention, Matmul, AllReduce 等具体 API）通过“De-scheduling”转换为 Workload。
   - **Workload 抽象**：中间灰色框表示高层工作负载表达，包含模型层结构（model_layers）及并行维度配置（dp_groups, pp_groups, tp_groups）。
   - **调度转换**：Manual Config 可对 De-scheduling 过程提供 input 或对进入 Simulator 的输入进行 partial override；右侧 Simulator 框内必须依赖一个蓝色的 Scheduler 模块将抽象 Workload 重新调度生成 Events（事件队列），再输入 Simulator 求解得到 Result。

4. **直接可见的结论**：
   - Trace-based 模拟器需要将包含具体通信（AllGather, ReduceScatter, AllReduce）和计算（Embedding, Attention, Matmul）的底层 rank Trace 通过“De-scheduling”反向提取为高层 Workload 结构。 `[图像直接可见]`
   - 高层 Workload 结构以数据结构形式显式抽象了模型层（model_layers）及并行组（dp_groups, pp_groups, tp_groups）。 `[图像直接可见]`
   - 无论是通过 SimAI 生成还是通过 Trace 反向 De-scheduling 提取的 Workload，在传入最终 Simulator 计算 Result 之前，都必须在 Simulator 内部经过一个独立的 Scheduler 模块将其重新转换为 Events。 `[图像直接可见]`
   - Manual Config（人工配置）不仅用于辅助 De-scheduling 提取，还可以作为 partial override 直接作用于 Simulator 输入。 `[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - **主张类型**：机制 `[基于文中逻辑的推断]`
   - **论点连接**：验证了论文在“旧方法的限制”中关于静态模拟器双重维护负担的主张：一方面 De-scheduling 依赖脆弱的人工启发式规则与 Manual Config；另一方面右侧 Simulator 内部必须存在一个完整的 Scheduler 重新实现框架的下发调度算法。 `[正文支持]`
   - **方法设计含义**：解释了 Phantora 为什么选择摒弃“Trace -> Workload -> Events”这种中介抽象，转而采用直接拦截 ML 框架原生 CUDA/NCCL API 调用并推入事件队列的设计——避免在模拟器中手动编写 De-scheduling 逻辑与 Scheduler 重新实现。 `[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：
   - **适用范围**：覆盖论文中针对传统静态工作负载模拟器（SimAI 与 Trace-based simulators）将高层工作负载转换为底层事件的过程分析。 `[正文支持]`
   - **证据缺口**：无额外证据缺口。
