# 图片批次 3

## 图片 1：Figure 5: Challenges of synchronizing time between real execution and event-driven simulation.

![Figure 5: Challenges of synchronizing time between real execution and event-driven simulation.](../figure-groups/page-0007-d02782144994.png)

*来源：OCR 第 7 页。*

### 解读

### 1. `figures/001-page-0007-d02782144994.png` (Figure 5)

* **图表编号与标题**：Figure 5: Challenges of synchronizing time between real execution and event-driven simulation.
* **图表结构与面板分解**：
  * **Panel 1 / (a)**：展示 Rank 0 在真实时间/逻辑时间 $T_1$ 时刻发起数据传输，事件驱动模拟器（Event-driven simulator）计算并预测其通信完成时间为 $T_1'$。此时 Rank 1 尚未发起通信。
  * **Panel 2 / (b)**：展示 Rank 0 在 $T_1$ 发起通信后，Rank 1 在随后的 $T_2$ 时刻（满足 $T_1 < T_2 < T_1'$）也发起了数据传输。由于 Rank 1 竞争网络资源减慢了 Rank 0 的流速，导致模拟器此前在未预知 $T_2$ 事件前提下计算出的完成时间 $T_1'$ 失效（图中在 Rank 0 及 Simulator 时间点 $T_1'$ 处均标注红叉 $\times$）。
* **证据与分析**：
  * 该图直观揭示了混合模拟（Hybrid Simulation）中真实系统动态执行与离散事件网络模拟器之间的时间同步挑战：真实 Rank 会在任意时刻注入网络事件，导致“过去事件”（Past Events）打破此前已做出的时间预测。

---

### 2. `figures/002-img_in_image_box_112_144_586_270.jpg` (Figure 6)

* **图表编号与标题**：Figure 6: Handling past events in the event-driven simulator using time rollback.
* **图表结构与步骤分解**：
  * **组件划分**：包含左侧的带依赖图事件队列（Event Queue with Dependency Graph）与右侧的网络模拟器（Network Simulator，内含吞吐量历史记录 `Throughput History (T_1, T_1')` 与网络事件队列 `Network Event Queue`）。
  * **步骤 1**：`(1) Trigger a network event at T_2` —— 事件队列向网络模拟器注入发生在 $T_2$ 时刻的网络事件。
  * **步骤 2**：`(2) Rollback to T_2` —— 网络模拟器根据保存的吞吐量历史记录 `Throughput History (T_1, T_1')`，将网络状态回滚（Time Rollback）至 $T_2$ 时刻。
  * **步骤 3**：`(3) Return updated completion time of affected flows` —— 网络模拟器重新计算受影响数据流的完成时间，并将更新后的时间推回事件队列。
  * **步骤 4**：`(4) Update previous events' start & completion time` —— 事件队列沿着依赖图（Dependency Graph）遍历，更新后续相关事件的开始与完成时间。
* **证据与分析**：
  * 详细拆解了 Phantora 解决过去事件冲突的核心机制（时间回滚 4 步工作流）。证明了系统无需细粒度高开销的时间量子同步，即可通过历史吞吐量重构与依赖图联动更新，保持离散事件模拟的准确性与高效推进。

---

## 图片 2：Figure 6: Handing past events in the event-driven simulator using time rollback. The network state at is a superposition of the states at and .

![Figure 6: Handing past events in the event-driven simulator using time rollback. The network state at is a superposition of the states at and .](../assets/imgs/img_in_image_box_112_144_586_270.jpg)

*来源：OCR 第 8 页。*

### 解读

模型未返回这张图片的独立解读。
