# 图片批次 5

## 图片 1：Figure 10: Accuracy of Phantora (small scale): Megatron training throughput of Llama2 7B on H200 testbed with or without optimizer, Phantora simulation results with or without optimizer, and SimAI simulation results. The error bars show 95% confidence interval. Note that SimAI currently does not include optimizer in its simulation.

![Figure 10: Accuracy of Phantora (small scale): Megatron training throughput of Llama2 7B on H200 testbed with or without optimizer, Phantora simulation results with or without optimizer, and SimAI simulation results. The error bars show 95% confidence interval. Note that SimAI currently does not include optimizer in its simulation.](../assets/imgs/img_in_chart_box_108_481_585_700.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：作者需要这张图来对比 Phantora 在小规模（H200 测试床）Megatron-LM 框架下训练 Llama2 7B 模型时的模拟吞吐量精度，将其与真实物理测试床实测值（Ground Truth）以及竞争基线 SimAI 进行定量比较。它验证了旧方法 SimAI 因手写 Mock 框架调度逻辑导致的预测偏差，并证明 Phantora 直接复用框架源码后能在包含与不包含优化器（Optimizer）的设置下均保持极高的估计精度。`[正文支持]`
   - **图表角色**：对比基线 `[正文支持]`
   - **上文呼应**：对应“旧方法的限制”中对 SimAI 重写框架逻辑导致模型及调度偏差的批判，以及“实验、指标与文字可确认的结论”中的结论 2（Megatron 训练 Llama2 7B 平均误差 3.7%，TP=4, b=1 时最大误差 5.3%）与主张 1（效果主张：与传统静态模拟精度相当）。`[正文支持]`
2. **图像类型与布局**：柱状图（Bar Chart）。包含 3 个横坐标配置分组（`TP=4,b=1`、`TP=4,b=2`、`DP=2,TP=2,b=1`）。每组包含最多 5 根柱子，分别用不同颜色（深蓝/棕色/灰色）与填充纹理（纯色/斜线阴影）区分评估方法和设置（Testbed、Phantora、SimAI、Testbed w/o optim、Phantora w/o optim）。柱顶带有 95% 置信区间的误差棒。`[图像直接可见]`
3. **如何阅读**：横轴表示 Megatron 并行策略与微批次大小配置（`TP=4,b=1`、`TP=4,b=2`、`DP=2,TP=2,b=1`）。纵轴表示单 GPU 训练吞吐量 `Throughput (tps/GPU)`，范围 0 到 8k。图例区分 5 种处理：深蓝纯色表示 Testbed（真实测试床）、棕色纯色表示 Phantora、灰色纯色表示 SimAI、深蓝斜线表示 Testbed (w/o optim)（无优化器）、棕色斜线表示 Phantora (w/o optim)（无优化器）。阅读时应对比同一配置下 Phantora 与 Testbed 的接近程度，以及 SimAI 与 Testbed 的偏差大小。`[图像直接可见]`
4. **直接可见的结论**：
   - 在所有 3 种配置下，Phantora 柱的高度（纯色棕柱与斜线棕柱）均极其接近相应的真实测试床 Testbed 柱（纯色深蓝柱与斜线深蓝柱），吞吐量数值在 3.3k ~ 4.1k tps/GPU 之间，相对偏差仅在数个百分点以内。`[图像直接可见]`
   - SimAI 的预测吞吐量（灰色柱）在所有配置下均显著高于 Testbed 真实值（例如在 TP=4,b=1 下 SimAI 约 4.3k tps/GPU，而 Testbed 约 3.4k tps/GPU；TP=4,b=2 下 SimAI 接近 4.7k tps/GPU，而 Testbed 约 3.8k tps/GPU）。`[图像直接可见]`
   - 去除优化器后（w/o optim，斜线柱），Testbed 和 Phantora 的吞吐量均比带有优化器时有明显提升（例如 TP=4,b=2 下从 ~3.8k 提升至 ~4.2k tps/GPU），Phantora (w/o optim) 依然紧密追踪 Testbed (w/o optim)。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：该图验证了主张 1（效果主张）：Phantora 直接运行未经修改的 Megatron 源码，能够在不同并行配置（TP, DP）及有无 Optimizer 的条件下均保持高精度评估（平均误差 3.7%）。同时验证了对对比基线 SimAI 的批判：SimAI 依赖 Mock 框架重写调度逻辑，无法精确建模 Megatron 的真实模型结构与算子行为（且当前未模拟 Optimizer 阶段），导致估计吞吐量出现较大偏差。方法设计上证实了 Phantora 采用直接复用源码与 Runtime Patching 拦截 CUDA/NCCL 调用的路线比手动 Mock/重构调度逻辑具有更高的保真度。该图仅覆盖小规模 Megatron 测试，尚不能单独证明百卡大规模或 TorchTitan/DeepSpeed 等其他框架的精度。`[正文支持]`
6. **适用范围与证据缺口**：
   - 适用范围：本证据覆盖论文报告的在 H200 测试床（单 GPU Profiling 模拟 4 GPU 环境）上使用 Megatron-LM 框架训练 Llama2 7B 模型的 3 种并行与 batch 设置（TP=4, b=1; TP=4, b=2; DP=2, TP=2, b=1）。`[正文支持]`
   - 证据缺口：无额外证据缺口。

---

## 图片 2：Figure 11: Speed of Phantora: Phantora simulation time of Llama2 7B training (Megatron, TP=8) using 32 CPU cores on H200 testbed.

![Figure 11: Speed of Phantora: Phantora simulation time of Llama2 7B training (Megatron, TP=8) using 32 CPU cores on H200 testbed.](../assets/imgs/img_in_chart_box_638_476_1113_675.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：作者需要这张图来评估 Phantora 模拟在 GPU 节点规模扩展时的运行耗时与扩展性（Scalability），验证在固定 CPU 资源（32 CPU 核心）限制下 Phantora 能否高效完成大规模集群训练的性能估算。`[正文支持]`
   - **图表角色**：实验结论 `[正文支持]`
   - **上文呼应**：对应“核心洞见与假设”及 Section 4.3 扩展性设计，呼应“实验、指标与文字可确认的结论”中“模拟 128 GPU 规模的 Llama3 8B 训练时每迭代仅需约 15 秒模拟时间”以及 Section 5.3 节关于 Phantora 模拟运行速度与扩展性的论述。`[正文支持]`
2. **图像类型与布局**：折线图（Line Chart）。包含一条带有圆形数据标记点的浅棕色曲线，展示模拟单步耗时随 GPU 节点数量的变化趋势。`[图像直接可见]`
3. **如何阅读**：横轴为模拟的 GPU 数量 `Number of GPUs`（从 8 到 256）。纵轴为 Phantora 单次迭代的平均模拟耗时 `Avg Iter Time (s)`（单位秒，从 0 到 80）。坐标轴与数据点清晰，阅读时观察随着 GPU 规模扩大，单步模拟耗时的增长速率与趋势。`[图像直接可见]`
4. **直接可见的结论**：
   - 在 8 到 32 个 GPU 的较小规模下，单步模拟耗时极低（低于 5 秒）。`[图像直接可见]`
   - 当 GPU 数量增加至 64、96、128 时，模拟耗时分别为约 7 秒、13-14 秒和 23 秒。`[图像直接可见]`
   - 当 GPU 数量增加到 100 以上（如 128 至 256 GPU）时，单步模拟耗时随 GPU 数量呈现近乎线性的增长，在 256 GPUs 时达到约 64 秒。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：该图验证了 Phantora 在扩展性与模拟速度方面的效果主张：Phantora 能够在单台服务器上使用有限 CPU 核心（32 核心）高效模拟多达 256 个 GPU 的分布式训练过程，单迭代模拟时间控制在 1 分钟左右（如 128 卡仅需 ~23 秒，256 卡约 64 秒）。方法设计上验证了 Phantora 的流级网络模拟器（netsim）与 CPU 时间度量/内存共享技术在解决多进程扩展时的有效性。正文解释指出，由于 Phantora 模拟器内核维持单线程，而 31 个 CPU 核心运行容器进程，当 GPU 规模增大导致进程数增多时，CPU 竞争加剧，使得耗时在 >100 GPU 时呈线性增长。该图未展示不同 CPU 核心数量配置对模拟速度的对比影响。`[正文支持]`
6. **适用范围与证据缺口**：
   - 适用范围：本证据覆盖论文报告的在 H200 测试床（分配 32 CPU 核心）上使用 Megatron 框架（固定 TP=8，每 GPU 微批次为 1）模拟 Llama2 7B 训练从 8 到 256 GPUs 扩展下的平均单步模拟时间。`[正文支持]`
   - 证据缺口：无额外证据缺口。
