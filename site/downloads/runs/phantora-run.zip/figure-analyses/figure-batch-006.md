# 图片批次 6

## 图片 1：Figure 12: CPU memory usage: Peak CPU memory usage of Llama2 7B training simulation in DeepSpeed with or without model parameter sharing.

![Figure 12: CPU memory usage: Peak CPU memory usage of Llama2 7B training simulation in DeepSpeed with or without model parameter sharing.](../assets/imgs/img_in_chart_box_110_455_582_629.jpg)

*来源：OCR 第 12 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`消融验证` `[正文支持]`
   - **上文呼应**：呼应正文第 4.3 节（扩展性优化模块）与第 5.3 节（模拟速度与扩展性评估），以及“主张地图”中的主张 3。 `[正文支持]`
   - **验证问题**：验证在单物理节点上使用 DeepSpeed 模拟大规模 GPU 集群时，Phantora 提出的“CPU 模型参数共享”（Model Parameter Sharing）设计对于降低 CPU 主存峰值占用的必要性与有效性，旨在解决不开启共享时 CPU 内存爆表导致的模拟扩展性瓶颈问题。 `[正文支持]`

2. **图像类型与布局**：
   - 折线图。x 轴表示模拟的 GPU 数量（对数刻度 1 到 64），y 轴表示 CPU 峰值内存占用（GB，范围 0 到 256 GB）。
   - 图中包含三条线：棕色带菱形标记的折线（`w/o sharing`，无参数共享）、蓝色带圆圈标记的折线（`w/ sharing`，有参数共享）以及红粉色虚线（`Memory limit`，表示 256 GB 的 CPU 内存硬件上限）。

3. **如何阅读**：
   - x 轴为模拟 GPU 数量，从 1 增加到 64；y 轴为 CPU 峰值内存（GB）。
   - 比较在相同 GPU 模拟规模下，开启（`w/ sharing`）与未开启（`w/o sharing`）模型参数共享时的 CPU 内存消耗，并对比 256 GB 内存上限虚线（`Memory limit`）。

4. **直接可见的结论**：
   - 未开启参数共享时（`w/o sharing`），随着模拟 GPU 数量增加，CPU 峰值内存占用呈陡峭上升趋势；模拟 1 个 GPU 时占用约 28 GB，模拟 4 个 GPU 时突破 100 GB，在模拟 9 个 GPU 时触及并突破 256 GB 的内存上限虚线。 `[图像直接可见]`
   - 开启参数共享后（`w/ sharing`），CPU 峰值内存占用随 GPU 数量增加增长极其平缓，在 1 到 64 个 GPU 模拟规模下均保持在较低水平；模拟 64 个 GPU 时内存占用仍低于 64 GB，远低于 256 GB 限制。 `[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - **验证主张**：验证了主张 3（必要性与鲁棒性）——CPU 模型参数共享机制是消除单机模拟多 GPU 节点 CPU 内存爆表瓶颈的核心关键设计。 `[正文支持]`
   - **方法设计含义**：Phantora 通过透明共享同一物理服务器上各容器的模型参数内存区域（基于控制流与张量具体数值无关的假设），使单服务器上只需初始化一份模型权重拷贝，将 CPU 内存开销从随 GPU 数线性剧增降至几乎常数级增长，极大提升了系统在有限硬件上的扩展能力。 `[基于文中逻辑的推断]`
   - **无法证明的内容**：该图仅证明了 CPU 内存占用的降低，不能证明 CPU 时间/算力超分配时的模拟精度与时间开销变化。 `[正文支持]`

6. **适用范围与证据缺口**：
   - **适用范围**：本证据覆盖 DeepSpeed 框架下 Llama2 7B 模型的模拟场景，模拟规模为 1 至 64 GPUs，基于 256GB CPU 内存限制。 `[正文支持]`
   - **证据缺口**：无额外证据缺口。

---

---

## 图片 2：Figure 13: Evaluating memory saving techniques: Phantora estimated peak memory usage per GPU and throughput of Llama2 training with different memory saving techniques (64 H100 GPUs, Megatron, DP=8, TP=8). A single number n denotes the number of batches per GPU with activation recomputation. A pair in the form denotes n batches per GPU with m gradient accumulation steps.

![Figure 13: Evaluating memory saving techniques: Phantora estimated peak memory usage per GPU and throughput of Llama2 training with different memory saving techniques (64 H100 GPUs, Megatron, DP=8, TP=8). A single number n denotes the number of batches per GPU with activation recomputation. A pair in the form denotes n batches per GPU with m gradient accumulation steps.](../figure-groups/page-0013-a34fe3c626d0.png)

*来源：OCR 第 13 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`适用边界` `[正文支持]`
   - **上文呼应**：呼应正文第 5.4 节（Case Study: Activation Recomputation）以及“主张地图”中的主张 4。 `[正文支持]`
   - **验证问题**：验证 Phantora 在无须模拟器开发者重构或重实现框架特定调度逻辑的前提下，能否原生支持并开箱即用评估复杂新特性（如选择性激活重算 selective activation recomputation）对显存峰值与吞吐量的联合影响。 `[正文支持]`

2. **图像类型与布局**：
   - 双 Panel 散点/折线对比图（Panel 1 针对 Llama2 7B，Panel 2 针对 Llama2 13B）。
   - 两个 Panel 的 x 轴均表示单 GPU 峰值显存占用（GB，0 到 80 GB），y 轴表示训练吞吐量（tps，0 到 250k）。
   - 图中包含两种标记：浅绿色圆圈（`Gradient accumulation` 梯度累积，标注形式如 $m \times n$，表示 $m$ 次梯度累积，每 GPU $n$ 个 micro batch）和深绿色圆点（`Activation recomputation` 激活重算，标注单个数字 $n$，表示每 GPU $n$ 个 batch）。
   - 图中包含两条带箭头的标注文本框，用于突出关键定量对比结论。

3. **如何阅读**：
   - x 轴代表显存占用（越低越好），y 轴代表吞吐量（越高越好）。理想的高性能低显存配置位于左上方。
   - 对比深绿色圆点（激活重算）与浅绿色圆圈（梯度累积）在不同 batch 配置下的显存与吞吐量权衡分布。

4. **直接可见的结论**：
   - 在 Panel 1（Llama2 7B）中，激活重算配置（如点 1、2）显著降低了显存占用；标注显示激活重算使训练可在小于 24GB 显存的 GPU 上运行（点 1 显存约 10.5 GB，吞吐量约 120k tps）。 `[图像直接可见]`
   - 在 Panel 2（Llama2 13B）中，激活重算配置（点 2，显存约 28.5 GB，吞吐量约 95k tps）相比梯度累积配置（如 `1x2` / `2x2`，显存约 72 GB，吞吐量约 120k tps），显存节省约 60%，而吞吐量开销仅约 15%（带明确文本框与箭头指向）。 `[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - **验证主张**：验证了主张 4（适用范围与效果）——Phantora 能够原生支持复杂新特性的显存与吞吐量联合分析，免除了传统模拟器需要手写重实现该特性逻辑的巨大工程负担。 `[正文支持]`
   - **方法设计含义**：由于 Phantora 直接在容器中运行未经修改的 PyTorch/Megatron 源码并依赖底层的 CUDA Runtime 拦截与 Profiler 机制，它能自动继承 ML 框架的所有新特性（如选择性激活重算和 PyTorch caching allocator 的动态显存行为），从而精准评估优化策略对显存与吞吐的权衡。 `[基于文中逻辑的推断]`
   - **无法证明的内容**：图中展示的数据均为 Phantora 模拟估计值，图中未直接提供真实硬件集群上运行该特性的 Ground Truth 实测曲线进行误差对比。 `[正文支持]`

6. **适用范围与证据缺口**：
   - **适用范围**：本证据覆盖 64 张 H100 GPU 集群下，Megatron 框架（DP=8, TP=8）训练 Llama2 7B 与 Llama2 13B 模型的激活重算与梯度累积评估。 `[正文支持]`
   - **证据缺口**：图中缺少真实 GPU 集群上开启选择性激活重算时的 Ground Truth 实测曲线，无法从本图独立验证 Phantora 对该特性的定量模拟精度。 `[正文支持]`
