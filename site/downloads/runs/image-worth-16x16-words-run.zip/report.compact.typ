#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[AN IMAGE IS WORTH 16X16 WORDS: TRANSFORMERS FOR IMAGE RECOGNITION AT SCALE]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Alexey Dosovitskiy, Lucas Beyer, Alexander Kolesnikov, Dirk Weissenborn, Xiaohua Zhai, Thomas Unterthiner, Mostafa Dehghani, Matthias Minderer, Georg Heigold, Sylvain Gelly, Jakob Uszkoreit, Neil Houlsby]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Vision Transformer] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[图像分类] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[自注意力机制] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[大规模预训练] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[计算机视觉]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-28]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

虽然 Transformer 架构已成为自然语言处理任务事实上的标准，但其在计算机视觉领域的应用仍然有限。在视觉任务中，注意力机制要么与卷积网络结合使用，要么在保持卷积网络整体结构不变的情况下用于替换其部分组件。我们证明这种对 CNN 的依赖并非必要，直接将纯 Transformer 应用于图像块序列同样可以在图像分类任务上取得优异表现。当在大量数据上进行预训练并迁移到多个中小型图像识别基准（如 ImageNet、CIFAR-100、VTAB 等）时，Vision Transformer（ViT）相比当前最先进的卷积网络取得了出色的结果，同时所需的训练计算资源大幅减少。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [AN IMAGE IS WORTH 16X16 WORDS: TRANSFORMERS FOR IMAGE RECOGNITION AT SCALE],
    [作者], [Alexey Dosovitskiy, Lucas Beyer, Alexander Kolesnikov, Dirk Weissenborn, Xiaohua Zhai, Thomas Unterthiner, Mostafa Dehghani, Matthias Minderer, Georg Heigold, Sylvain Gelly, Jakob Uszkoreit, Neil Houlsby],
    [发表场所 / 年份], [文中未说明],
    [研究领域], [计算机视觉、深度学习架构],
    [关键词], [Vision Transformer, 图像分类, 自注意力机制, 大规模预训练, 计算机视觉],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签]：`Vision Transformer` · `自注意力机制` · `大规模预训练` · `归纳偏置` · `图像分类`
]

论文提出 ViT：把图像切成固定大小的 patch 序列后直接用标准 Transformer 编码器做分类，证明在 14M--300M 图像级别的大规模预训练下、几乎不注入视觉专用归纳偏置也能达到或超越 SOTA CNN，且预训练所需算力更低 `[作者明确陈述]`；但该优势严格依赖预训练数据规模，中小数据集下反而弱于同等规模 ResNet `[实验支持]`。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

本次分析覆盖正文第 1--9 页与附录 D 部分小节（D.2--D.9），文本证据与图表证据来自同一 OCR 提取结果，图表是对文本结论的可视化补充而非独立事实源。共有 6 个图片批次、12 张图像被逐一分析，另有 1 张图片因超出批处理上限未做视觉分析，其具体内容"无法从当前 OCR 内容确认"。发表场所与年份、多处公式的 Eq. 编号、VTAB 综合得分聚合方式等字段 OCR 未能确认，均按"文中未说明"处理，不做常识补全。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

#strong[问题定义]：能否用几乎不做视觉专用修改的标准 Transformer 架构直接处理图像识别，达到有竞争力的性能 `[作者明确陈述]`。

#strong[为什么重要]：自注意力（self-attention，序列中每个元素都能直接和其他所有元素比较、加权汇总信息，不像 CNN 只看邻近像素）已是 NLP 事实标准，靠"大语料预训练+小任务微调"支撑起未见性能饱和的百亿参数模型 `[作者明确陈述]`；若视觉任务能复用这套已验证可扩展、有高效工程实现的架构，意味着视觉模型可以直接享受该生态的可扩展性红利 `[作者明确陈述]`。

#strong[难点]：图像是二维、高分辨率数据，逐像素自注意力的计算量随像素数呈二次方增长，不可扩展 `[作者明确陈述]`；此前尝试要么把注意力嫁接在 CNN 上，要么用专用局部注意力模式替代卷积，但后者难以在硬件加速器上高效实现 `[作者明确陈述]`。

#strong[成功标准]：在多个中小型图像识别基准（ImageNet、CIFAR-100、VTAB 等）上，用更少计算资源达到或超过当前 SOTA CNN `[作者明确陈述]`。

#strong[本文的 story]：以往路线要么保留 CNN 骨架、要么用专用注意力模式规避二次方开销，但专用模式在硬件上工程复杂、难以真正扩展；本文换一个技术切口------把图像切成较大的 patch（如 16×16）当作"词元"序列，使标准 Transformer 的计算模式可以直接套用，再用大规模预训练数据补偿架构中缺失的归纳偏置 `[作者明确陈述]`。

== 4. 旧方法为何不够
<4-旧方法为何不够>

+ #strong[纯 CNN 架构（LeCun 1989、Krizhevsky 2012、He 2016 等）]：作为待挑战的 SOTA 基线，正文未明确指出其具体技术缺陷（是数据效率还是可扩展性上限）`[作者明确陈述]`；对应第 8 节 Table 2 的整体性能/算力对比。
+ #strong[局部自注意力替代卷积（Parmar 2018; Hu 2019; Ramachandran 2019; Zhao 2020）]：原本试图用自注意力获得比卷积更强的表达能力，但依赖"专用注意力模式"，尚未在现代硬件加速器上被有效扩展 `[作者明确陈述]`；本文用标准全局自注意力回应这一限制 `[基于文中逻辑的推断]`；但论文未直接做 ViT 与这些模型的硬件效率对比实验，"无法从当前 OCR 内容确认"。
+ #strong[轴向/分块注意力（Weissenborn 2019; Ho 2019; Wang 2020a）]：同样受限于"需要复杂工程才能在硬件加速器上高效实现"`[作者明确陈述]`；附录 D.6 直接对比 AxialResNet 与 Axial-ViT，证实"朴素实现在 TPU 上极慢" `[实验支持]`。
+ #strong[Cordonnier et al. (2020)]：与 ViT 高度相似的 2×2 patch + 全自注意力方案，但只能用于低分辨率图像，且未证明大规模预训练下可媲美/超越 SOTA CNN `[作者明确陈述]`；本文用更大 patch 处理中等分辨率图像并系统做大规模预训练迁移实验回应 `[基于文中逻辑的推断]`，但两者无直接数值对照实验。
+ #strong[image GPT / iGPT（Chen 2020a）]：像素级无监督生成式预训练，ImageNet 最高仅 72% `[作者明确陈述]`；ViT 用有监督 patch 分类预训练回应，Table 2 中 88.55% 构成间接对比（预训练范式与数据规模均不同，非严格对照）`[实验支持]`。
+ #strong[BiT/Big Transfer（Kolesnikov 2020）]：相同数据规模下预训练算力远高于 ViT（9.9k vs 0.68k TPUv3-core-days）`[实验支持]`；4.3 节数据规模对照实验是直接检验 `[实验支持]`。

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见]："large scale training trumps inductive bias"------大规模训练可以战胜归纳偏置（inductive bias，架构里预先内置的假设，如 CNN 假设图像具有局部性和平移不变性）带来的优势 `[作者明确陈述]`。

#strong[对应假设]：ViT 在小数据集上不如 ResNet，是数据利用效率低而非架构能力上限低；预训练数据规模达到 14M--300M 图像级别后，该劣势会被抹平甚至反超 `[作者明确陈述]`。作者通过"固定架构、只变预训练数据规模"的对照实验（对应 Figure 3/4）来验证这一假设 `[作者明确陈述]`。

#strong[推断]：模型不需要人为注入 2D 空间结构信息，因为足够的数据量能让模型自己学出这类结构（位置编码自发学出行列关系）`[基于文中逻辑的推断]`------这是论文对"为何几乎不加归纳偏置也能奏效"的机制性解释，区别于作者未直接给出因果消融的相关性证据。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

#strong[总览]：原图 → 切分为 patch 并线性投影 → 拼接可学习 \[class\] token 与位置编码 → 送入标准 Transformer 编码器（L 层） → 取 \[class\] token 输出接分类头 `[作者明确陈述]`。

+ #strong[Patch 化与线性投影]：动机是 Transformer 原生只接受 1D 序列，图像却是 $upright(bold(x)) in bb(R)^(H times W times C)$ 的 2D 结构 `[作者明确陈述]`；将图像 reshape 为展平 patch 序列 $upright(bold(x))_p in bb(R)^(N times\(P^2 dot.op C\))$（$N = H W\/P^2$），经可训练投影 $upright(bold(E))$ 映射到维度 $D$（Eq.1）`[作者明确陈述]`；将序列长度从像素数降为 patch 数，规避二次方复杂度 `[基于文中逻辑的推断]`。patch 大小对精度/计算权衡由 D.2 节消融涉及 `[实验支持]`，patch 化是否丢失细粒度信息"文中未说明"。
+ #strong[\[class\] Token]：借鉴 BERT，提供与位置无关的全局读出位 `[作者明确陈述]`；附录 D.3 显示其相对全局平均池化（GAP）的早期劣势"完全由学习率不同解释"，两者性能相近 `[实验支持]`。
+ #strong[位置编码]：自注意力本身对顺序不敏感，需额外机制保留空间信息 `[基于文中逻辑的推断]`；采用标准可学习 1D 编码，Table 8 显示"有无位置编码差距大，但 1D/2D/相对编码间差异很小"`[实验支持]`。
+ #strong[Transformer 编码器（MSA+MLP，Pre-LN+残差）]：直接复用 Vaswani 2017 设计以利用已验证的可扩展实现（Eq.2、Eq.3）`[作者明确陈述]`；4.5 节 attention distance 分析证实部分头在最底层即可整合近全图信息 `[实验支持]`。
+ #strong[微调与高分辨率适配]：移除预训练分类头，接零初始化前馈层，对位置编码做 2D 插值以适配新 patch 网格 `[作者明确陈述]`；这是全模型中唯二人工注入 2D 先验之处 `[基于文中逻辑的推断]`。
+ #strong[Hybrid 架构（可选）]：用 CNN 特征图代替原始像素 patch；小算力预算下略优于纯 ViT，但优势随规模增大消失（Figure 5、Table 6）`[实验支持]`。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：方法总览与四个模块拼装]
  #image("assets/source-crops/img_in_image_box_291_161_938_494.png", width: 100%)
  #emph[Figure 1: Model overview. We split an image into fixed-size patches, linearly embed each of them, add position embeddings, and feed the resulting sequence of vectors to a standard Transformer encoder. In order to perform classification, we use the standard approach of adding an extra learnable \"classification token\" to the sequence. The illustration of the Transformer encoder was inspired by Vaswani et al. (2017).]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：patch线性投影+class token+位置编码送入编码器，内部为Norm-MSA-残差-Norm-MLP-残差堆叠L层

- #strong[论证关系]：确认架构与Eq.1--4描述一致，不证明性能或全局信息整合机制

- #strong[适用范围]：未展示Hybrid架构与分辨率适配细节
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 全局自注意力可在最底层直接整合全图信息，无需像 CNN 那样逐层堆叠扩大感受野；4.5 节 attention distance 分析显示浅层已有头覆盖近全图 `[实验支持]`。
- 归纳偏置缺失在数据少时带来泛化损失，但当数据量足够大，模型可直接从数据中学出等效结构（如位置编码自发学出行列拓扑）`[基于文中逻辑的推断]`，从而不再需要预设假设，这也是"数据规模替代归纳偏置"成立所需条件。
- 该逻辑的成立前提是预训练数据规模达到某一门槛（90M+ 图像级别），门槛以下 ViT 反而比 ResNet 更容易过拟合 `[实验支持]`。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果：ViT 在大规模预训练后能否媲美/超越 SOTA CNN？→ 对应 Table 2 与 BiT-L/Noisy Student 比较 `[实验支持]`。
- 机制：归纳偏置能否被数据规模替代？→ 对应 Figure 3/4 数据规模递增实验（相关性证据，非因果消融）`[实验支持]`。
- 必要性：\[class\] token、位置编码具体形式是否必要？→ 对应附录 D.3、D.4 消融 `[实验支持]`。
- 鲁棒性/适用范围：Hybrid 是否在任意规模都优于纯 ViT？ViT 是否会性能饱和？→ 对应 Figure 5 Scaling Study `[实验支持]`。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 数据来源：ImageNet（1.3M）、ImageNet-21k、JFT-300M（Google 内部，非公开）`[作者明确陈述]`；VTAB 19 任务、每任务 1,000 训练样本 `[作者明确陈述]`。
- 模型规模：ViT-Base/Large/Huge，patch size 变体（如 /14、/16、/32）`[作者明确陈述]`。
- 训练设置：Adam 优化器，batch size 4096，weight decay 0.1 `[作者明确陈述]`；硬件为 TPUv3；重复次数/统计方式除 Table 2 报告的均值±标准差外，"文中未说明"具体重复次数。
- 基线：BiT(ResNet)、VIVI、S4L、Noisy Student/EfficientNet `[作者明确陈述]`；各基线具体超参数"文中未说明"。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Top-1/Top-5 准确率，越高越好。#strong[定义与公式]：论文仅报告数值（如 88.55%），未给出显式定义式；#strong[来源层级]：无可核验公式------不得按常识补全。#strong[实验用途]：Table 2/5/6/9 的主结果与迁移评估比较。#strong[读数与边界]：ViT-H/14 达 ImageNet 88.55±0.04%，ImageNet-ReaL 90.72±0.05%，CIFAR-100 94.55±0.04%，VTAB 77.63±0.23% `[实验支持]`；不能证明性能来源于架构、数据规模或训练策略中的哪一项。
- #strong[指标与方向]：TPUv3-core-days，测量预训练总算力成本，越低越好。#strong[定义与公式]：作者文字定义"核心数×训练天数"；#strong[来源层级]：推导关系（非原文公式）\[基于文中逻辑的推断\]。#strong[实验用途]：比较 ViT 与 BiT-L（0.68k vs 9.9k）、Noisy Student（2.5k vs 12.3k）`[实验支持]`。#strong[读数与边界]：作者自述该对比还受训练日程、优化器等因素影响，非严格单变量对照 `[作者明确陈述]`。
- #strong[指标与方向]：5-shot linear 准确率，冻结表征做闭式最小二乘回归评估，越高越好。#strong[定义与公式]：作者文字给出优化目标与闭式解，无显式公式记号；#strong[来源层级]：推导关系（非原文公式）\[基于文中逻辑的推断\]。#strong[实验用途]：Figure 3/4/8/9 等快速评估。
- #strong[指标与方向]：Attention distance（注意力距离），衡量信息整合的空间跨度（像素），无固定优劣方向。#strong[定义与公式]：文字描述"按注意力权重加权平均查询像素与其他像素距离"；#strong[来源层级]：推导关系（非原文公式）\[基于文中逻辑的推断\]。#strong[实验用途]：回答 ViT 能否在浅层整合全局信息。
- #strong[指标与方向]：VTAB 综合得分、exaFLOPs、掩码 patch 预测损失函数：均为无可核验公式，聚合口径/计算方式"文中未说明"。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验/仍未验证边界],),
    table.hline(),
    [局部自注意力/轴向注意力], [专用注意力模式难以在硬件加速器上高效实现 `[作者明确陈述]`], [标准全局自注意力 `[基于文中逻辑的推断]`], [D.6 节 AxialResNet 实测极慢证实 `[实验支持]`；与其余专用模式的直接对比"无法从当前 OCR 内容确认"],
    [BiT/Noisy Student（CNN）], [同等/更优性能下算力成本远高于 ViT `[实验支持]`], [整体 ViT 架构], [Table 2 直接数值支持],
    [Cordonnier(2020)], [仅支持低分辨率，未验证大规模预训练可媲美 SOTA `[作者明确陈述]`], [更大 patch+系统性大规模预训练], [无直接对照实验，"无法从当前 OCR 内容确认"],
  )]
  , kind: table
  )

#strong[主张 → 证据 → 边界]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据], [证据强度与边界],),
    table.hline(),
    [大规模预训练下 ViT 媲美/超越 SOTA CNN], [Table 2 `[实验支持]`], [强，但受训练超参差异干扰，非严格单变量对照],
    [大规模训练可替代归纳偏置], [Figure 3/4 数据规模递增 `[实验支持]`], [相关性证据而非因果消融，机制解释部分为推断],
    [ViT 达同等性能所需算力显著更低], [Table 2、Figure 5 `[实验支持]`], [强，Figure 5 为受控扩展性对比],
    [Hybrid 仅小算力下优于纯 ViT], [Figure 5/Table 6 `[实验支持]`], [直接支持，原因"somewhat surprising"未展开],
    [自监督（掩码 patch 预测）有效但逊于监督预训练], [79.9% vs 落后4个百分点 `[实验支持]`], [仅 ViT-B/16 一种配置，作者自称"preliminary"],
  )]
  , kind: table
  )

- VTAB Specialized 任务组上 ViT-H/14 与 BiT-L 表现相近，非全面胜出 `[作者明确陈述]`。
- 检测、分割等其他视觉任务未在本文实验，仅援引他人工作作为"promise" `[作者明确陈述]`。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_224_572_987_742.png", width: 100%)
    #emph[Figure 2: Breakdown of VTAB performance in Natural, Specialized, and Structured task groups.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：ViT-H/14在VTAB上对比BiT-L/VIVI/S4L的效果主张]
    - #strong[图组结论]：ViT-H/14在总览/Natural/Structured三组领先，Specialized组与BiT-L接近

- #strong[论证关系]：支持效果主张，同时验证Specialized组优势不明显的适用边界

- #strong[适用范围]：仅VTAB-1k协议，不代表ImageNet全量微调表现
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0007-09e1c7b95ac4.png", width: 100%)
    #emph[Figure 3: Transfer to ImageNet. While large ViT models perform worse than BiT ResNets (shaded area) when pre-trained on small datasets, they shine when pre-trained on larger datasets. Similarly, larger ViT variants overtake smaller ones as the dataset grows.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：大规模训练替代归纳偏置的核心假设（4.3节数据规模实验）]
    - #strong[图组结论]：仅JFT-300M上ViT-Large显完整优势，ImageNet上反弱于BiT；JFT子集9M过拟合，90M+反超

- #strong[论证关系]：为数据规模是核心变量提供适用边界（Fig3）与机制侧证据（Fig4过拟合行为）

- #strong[适用范围]：ViT优于CNN的结论应限定在大规模预训练前提下
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_249_618_971_924.png", width: 100%)
    #emph[Figure 5: Performance versus pre-training compute for different architectures: Vision Transformers, ResNets, and hybrids. Vision Transformers generally outperform ResNets with the same computational budget. Hybrids improve upon pure Transformers for smaller model sizes, but the gap vanishes for larger models.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：ViT算力效率与Hybrid消融（4.4节Scaling Study）]
    - #strong[图组结论]：同算力下ViT优于ResNet；Hybrid仅小算力略优，大算力时重合；ViT曲线未见趋平

- #strong[论证关系]：支撑2-4倍更少算力达到同等性能及未出现性能饱和的适用边界

- #strong[适用范围]：图中各点未标注具体模型规格，无法逐点对应Table 6
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_803_685_992_1024.png", width: 100%)
    #emph[Figure 6: Representative examples of attention from the output token to the input space. See Appendix D.7 for details.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：自注意力聚焦语义相关区域的机制陈述（4.5节）]
    - #strong[图组结论]：三例中注意力较亮区域与主体轮廓大致重合，背景被压暗

- #strong[论证关系]：为自注意力聚焦语义区域提供定性例证，样本量仅3例不能作统计证据

- #strong[适用范围]：图注"representative"与附录"random selection"表述不一致，标准未说明
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_216_185_999_415.png", width: 100%)
    #emph[Figure 7: Left: Filters of the initial linear embedding of RGB values of ViT-L/32. Center: Similarity of position embeddings of ViT-L/32. Tiles show the cosine similarity between the position embedding of the patch with the indicated row and column and the position embeddings of all other patches. Right: Size of attended area by head and network depth. Each dot shows the mean attention distance across images for one of 16 heads at one layer. See Appendix D.7 for details.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：patch滤波器/位置编码/注意力距离机制分析（4.5节）]
    - #strong[图组结论]：滤波器呈规律纹理；位置编码相似度呈清晰行列结构；注意力距离随深度收敛

- #strong[论证关系]：分别支撑模块1/3/4，位置编码结果解释Table 8中编码方式差异很小的原因

- #strong[适用范围]：Left/Center对应ViT-L/32，Right对应ViT-L/16，配置不同不可混同
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0016-061bce0f8aca.png", width: 100%)
    #emph[Figure 8: Scaling different model dimensions of the Vision Transformer.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：附录D.2 Transformer各维度缩放消融]
    - #strong[图组结论]：Depth起点最低但斜率最陡；Width变化最平缓；All维度按比例缩放整体领先且无饱和

- #strong[论证关系]：支撑扩展时应优先深度而非宽度的方法设计建议，不能证明64层后是否有拐点

- #strong[适用范围]：图中各点未标注具体层数/宽度/patch size等参数对应关系
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_337_168_883_456.png", width: 100%)
    #emph[Figure 9: Comparison of class-token and global average pooling classifiers. Both work similarly well, but require different learning-rates.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：附录D.3 class token与GAP的必要性消融]
    - #strong[图组结论]：同学习率下GAP明显低于CLS-Token；调优GAP学习率后追平甚至反超

- #strong[论证关系]：证明性能差距的关键变量是学习率而非head类型本身

- #strong[适用范围]：仅覆盖ViT-B/16、0-7个epoch的5-shot评估
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_279_857_937_1213.png", width: 100%)
    #emph[Figure 11: Size of attended area by head and network depth. Attention distance was computed for 128 example images by averaging the distance between the query pixel and all other pixels, weighted by the attention weight. Each dot shows the mean attention distance across images for one of 16 heads at one layer. Image width is 224 pixels.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：ViT与Hybrid的局部化注意力头对比（4.5节/附录D.7）]
    - #strong[图组结论]：纯ViT低层存在明显局部化头（0-20像素），Hybrid低层缺少此类极低距离点

- #strong[论证关系]：支持ResNet前置卷积已承担早期局部特征提取、故不必再学出局部化头的解释

- #strong[适用范围]：不能证明局部化头对最终精度的贡献大小
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_217_163_1007_423.png", width: 100%)
    #emph[Figure 10: Position embeddings of models trained with different hyperparameters.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：附录D.4位置编码相似度对超参数的敏感性]
    - #strong[图组结论]：不同学习率/weight decay组合下，位置编码相似度行列结构清晰度不同

- #strong[论证关系]：为1D编码自发学出2D拓扑提供跨超参数稳健性佐证

- #strong[适用范围]：三图同时改变多个超参数，无法单独归因某一变量
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_248_443_972_751.png", width: 100%)
    #emph[Figure 12: Left: Real wall-clock timings of various architectures across input sizes. ViT models have speed comparable to similar ResNets. Right: Largest per-core batch-size fitting on device with various architectures across input sizes. ViT models are clearly more memory-efficient.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：附录D.5真实硬件推理速度与内存效率]
    - #strong[图组结论]：ViT推理速度与同量级ResNet相当，单核可容纳最大batch-size明显更优

- #strong[论证关系]：为预训练计算成本更低提供真实硬件层面的效果支撑

- #strong[适用范围]：部分曲线触顶是否为人为batch-size搜索上限，无法确认
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0020-565593998539.png", width: 100%)
    #emph[Figure 13: Performance of Axial-Attention based models, in terms of top-1 accuracy on ImageNet 5-shot linear, versus their speed in terms of number of FLOPs (left) and inference time (left).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：附录D.6 Axial Attention设计取舍验证]
    - #strong[图组结论]：AxialViT变体准确率优于对应ViT-B但算力更高；AxialResNet50推理速度远低于其余模型

- #strong[论证关系]：印证论文选用标准全局自注意力而非专用注意力模式的设计取舍

- #strong[适用范围]：不能证明速度劣化的具体底层实现原因
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 5: Top1 accuracy (in %) of Vision Transformer on various datasets when pre-trained on ImageNet, ImageNet-21k or...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：大规模预训练下ViT媲美/超越CNN的数据规模递增实验（对应Figure 3）]
  - #strong[图组结论]：给出ViT在ImageNet/ImageNet-21k/JFT-300M三级预训练数据下的Top1准确率数值

- #strong[论证关系]：为Figure 3展示的趋势提供逐模型逐数据集的精确数值支撑

- #strong[适用范围]：ImageNet结果未使用Table 2所用的Polyak平均与512分辨率技术
  #v(5pt)
  #image("table-groups/page-0015-d689f96a18bf.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 9: Breakdown of VTAB-1k performance across tasks.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：VTAB-1k细分任务表现（对应Figure 2）]
  - #strong[图组结论]：按19个VTAB子任务逐一给出ViT-H/14与基线的准确率明细

- #strong[论证关系]：为Figure 2的三组汇总柱状图提供任务级别的可核验数值细节

- #strong[适用范围]：仅覆盖VTAB-1k协议下的任务级数据，不代表其他基准表现
  #v(5pt)
  #image("table-groups/page-0022-f7386d38d3a5.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：能否用几乎不做视觉专用修改的标准 Transformer 直接处理图像识别并达到有竞争力性能 \`\`
  - 旧方法限制：局部/专用注意力模式硬件扩展性差；逐像素注意力二次方开销不可扩展；Cordonnier(2020)仅限低分辨率 \`\`
  - 核心洞见/假设：大规模训练可以战胜归纳偏置缺失 \`\`
    - 方法模块：Patch化+线性投影、\[class\] token、1D位置编码、标准Transformer编码器 \`\`
      - 可验证预测：足够大数据下 ViT 可媲美/超越 SOTA CNN，且算力更低
        - 指标与实验：Top-1准确率（Table 2）、TPUv3-core-days（Table 2）、5-shot准确率（Figure 3/4）
          - 图表证据：Figure 3/4（数据规模效应）、Figure 5（Scaling Study）
            - 结论与适用边界：结论仅在 JFT-300M 级别预训练数据下成立；中小数据集下 ViT 弱于 ResNet，属未验证条件之外的场景 `[实验支持]`

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：提出几乎不做视觉专用修改的 ViT 架构 `[作者明确陈述]`；验证归纳偏置可被数据规模替代并给出对照实验证据 `[实验支持]`；在同等或更优性能下显著降低预训练算力 `[实验支持]`。

#strong[证据充分的结论]：大规模预训练下 ViT 在 ImageNet、CIFAR-100、VTAB 等多个基准上媲美/超越 SOTA CNN，且算力消耗更低（Table 2、Figure 5）`[实验支持]`。

#strong[尚属推断的意义]：归纳偏置被数据规模"替代"的具体因果机制（而非仅相关性）未经专门消融验证 `[基于文中逻辑的推断]`。

#strong[适用条件与局限]：结论依赖 14M-300M 级预训练数据，JFT-300M 为 Google 内部非公开数据集，可复现性受限 `[作者明确陈述]`；论文仅验证图像分类任务，未覆盖检测、分割 `[作者明确陈述]`。

#strong[审稿式风险检查]：

- 贡献新意：与 Cordonnier(2020) 高度相似，本文差异在于大 patch 与系统性大规模实验，二者无直接数值对照，"无法从当前 OCR 内容确认"新意边界。
- 写作/可复现性：核心旗舰结果依赖不可公开获取的 JFT-300M，复现风险真实存在 `[作者明确陈述]`。
- 效果大小：主结果绝对提升幅度在 Table 2 中可核验，但预训练效率对比受训练超参干扰，作者自己提及此局限 `[作者明确陈述]`。
- 实验覆盖：自监督实验仅一种模型配置，消融覆盖 patch size/位置编码/head类型，未见对"归纳偏置强度"的直接控制实验，当前证据未显示该项已被覆盖。
- 方法设计：Hybrid 优势随规模消失现象作者自称"意外"但未给出机制解释，当前证据未显示该现象是设计缺陷。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：Self-Attention（自注意力）。#strong[第一性原理角色]：连接序列中任意两个元素的信息交互，不依赖空间邻近性这一约束。#strong[本文位置]：Transformer编码器核心计算单元，支撑Eq.5定义的注意力权重 \`\`。
- #strong[术语]：Inductive Bias（归纳偏置）。#strong[第一性原理角色]：架构预设的假设（如局部性、平移等变性），在数据量小时降低学习所需的信息量，是模型能力与数据需求间的权衡变量。#strong[本文位置]：贯穿核心洞见与全篇论证 \`\`。
- #strong[术语]：Patch（图像块）。#strong[第一性原理角色]：将2D图像离散为可序列化的最小处理单元，是把二次方复杂度问题转化为线性可扩展问题的关键操作对象。#strong[本文位置]：Eq.1输入构造 \`\`。
- #strong[术语]：\[class\] Token。#strong[第一性原理角色]：与位置无关的固定读出状态，连接"逐token表征"与"单一图像级别输出"这两个层级的量。#strong[本文位置]：分类头输入来源，Eq.4 \`\`。
- #strong[术语]：Position Embedding（位置编码）。#strong[第一性原理角色]：补偿自注意力对输入顺序不敏感这一数学约束，连接patch的序列索引与其空间位置。#strong[本文位置]：与patch embedding相加输入编码器 \`\`。
- #strong[术语]：Attention Distance（注意力距离）。#strong[第一性原理角色]：衡量信息整合覆盖的空间范围，连接注意力权重这一中间量与"局部/全局"这一可观测行为。#strong[本文位置]：4.5节机制分析 \`\`。
- #strong[术语]：TPUv3-core-days。#strong[第一性原理角色]：核心数×训练天数，是衡量算力资源消耗这一约束量的单位。#strong[本文位置]：Table 2 效率对比 \`\`。

=== 12.2 学习路径
<122-学习路径>
+ 先理解"序列建模"这一基本对象：模型输入被表示为一串向量而非二维网格，这是把图像"变成句子"的前提。
+ 再理解自注意力的计算约束：任意两元素间都要计算相关性，代价随序列长度呈二次方增长，这决定了图像必须先降采样为patch而非逐像素处理。
+ 然后理解归纳偏置这一机制：CNN预设的局部性/平移不变性像"提前划好重点"，数据少时省力，数据多时可能限制模型自由学习的空间。
+ 接着理解预训练-微调范式：先在海量通用数据上学一般表征，再在目标任务小数据上微调，类似先读通识课程再做专项训练。
+ 最后理解"计算量-性能"权衡这一系统行为指标：同样精度下谁耗费的算力更少，是评价架构是否"更划算"的关键观测量。
