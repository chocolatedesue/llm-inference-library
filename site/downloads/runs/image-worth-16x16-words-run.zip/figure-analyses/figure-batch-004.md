# 图片批次 4

## 图片 1：Figure 8: Scaling different model dimensions of the Vision Transformer.

![Figure 8: Scaling different model dimensions of the Vision Transformer.](../figure-groups/page-0016-061bce0f8aca.png)

*来源：OCR 第 16 页。*

### 解读

1. **论文角色与验证问题**：本图对应附录 D.2「TRANSFORMER SHAPE」消融实验，角色为**消融验证**。正文动机是"探究 Transformer 各维度（深度/宽度/MLP宽度/patch size）的缩放，哪些最适合扩展到超大模型"，验证的具体问题是"在固定计算预算下，沿哪个架构维度扩展最有效"，并支撑论文更广的"large scale training / scaling"叙事分支（而非核心的"归纳偏置被数据规模替代"主张）`[正文支持][页码：16]`。
   - **图表角色**：消融验证。
   - **上文呼应**：附录 D.2，对应"模型规模变体选择"这一实现组件背后的消融依据，非正文核心贡献本身。

2. **图像类型与布局**：两个并排的折线/散点复合图（Panel 1、Panel 2），横轴均为对数刻度的 "Relative Compute"（约 0.1–10），纵轴分别为 "ImageNet 5shot"（Panel 1，约 0.1–0.65）和 "Average 5shot"（Panel 2，约 0.4–0.8）。每个子图内有 5 条曲线，共用同一图例："All"（蓝色实线圆点）、"Depth"（橙色虚线叉号）、"Patch size"（绿色点线方块）、"Width MLP"（深红/褐色点划线菱形）、"Width"（品红色点线菱形）`[图像直接可见]`。

3. **如何阅读**：横轴为相对预训练计算量（对数刻度），纵轴为对应的 5-shot 线性评估准确率；应比较同一相对计算量下不同颜色曲线（即不同缩放维度）所能达到的准确率，以及各曲线随计算量增加的斜率（增长速度）。图例位于两子图右下方，标注一致 `[图像直接可见]`。

4. **直接可见的结论**：
   - "Depth"（橙色）曲线起点（最小相对计算量处）准确率最低（Panel 1 中明显低于其余曲线），但随相对计算量增大，其斜率最陡，快速追平并接近"All"曲线 `[图像直接可见]`。
   - "Width"（品红色）曲线整体波动范围最小、随计算量变化最平缓，是各条单维度曲线中变化幅度最小的一条 `[图像直接可见]`。
   - "Patch size"（绿色）与"Width MLP"（褐色）曲线也随计算量提升而上升，幅度介于"Depth"和"Width"之间 `[图像直接可见]`。
   - "All"（蓝色，即所有维度按比例缩放）曲线覆盖最宽的相对计算量范围（从最小到最大），且整体处于各曲线的较高/领先位置，随计算量单调上升，无饱和迹象 `[图像直接可见]`。
   - 两子图（ImageNet 5shot 与 Average 5shot）呈现相同的相对趋势模式 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图为**消融验证**类证据，直接支撑正文"scaling the depth results in the biggest improvements...clearly visible up until 64 layers, however diminishing returns are already visible after 16 layers""scaling the width...results in the smallest changes""decreasing patch size...shows surprisingly robust improvements""scaling all dimensions proportionally results in robust improvements"等具体陈述——图中"Depth"曲线低起点、陡增长与"Width"曲线的平缓变化，同论文文字对增长幅度大小的排序一致 `[正文支持][页码：16]`。这为论文"计算量可能比参数量更能预测性能，且扩展时应优先深度而非宽度"的方法设计建议提供依据，但**不能**由此图证明"深度缩放在超过64层后是否会出现性能拐点/饱和"的具体形态（正文只说"visible up until 64 layers"，图中并未标注具体层数刻度，无法用视觉确认64/16层这些具体节点位置）`[基于视觉的谨慎推断]`。

6. **适用范围与证据缺口**：本证据覆盖的设置为"以 8 层、D=1024、D_MLP=2048、patch size 32 为交点（intersection of all lines）的 ViT 配置，在 JFT 上预训练后的 ImageNet 5-shot 线性评估"`[正文支持][页码：16]`。真实缺口：图中各数据点对应的具体层数、宽度、patch size 等参数值未标注坐标刻度对应关系（仅正文提及"64 层""16 层"等数字，但图上无法逐点核对具体是哪个配置对应哪个点），此为图像本身未标出、正文亦未在图注中给出精确一一对应关系的信息缺口。

---

## 图片 2：Figure 9: Comparison of class-token and global average pooling classifiers. Both work similarly well, but require different learning-rates.

![Figure 9: Comparison of class-token and global average pooling classifiers. Both work similarly well, but require different learning-rates.](../assets/imgs/img_in_chart_box_337_168_883_456.jpg)

*来源：OCR 第 17 页。*

### 解读

1. **论文角色与验证问题**：本图对应附录 D.3「HEAD TYPE AND CLASS TOKEN」消融实验，角色为**消融验证**。验证的具体问题是："先前使用 GAP（全局平均池化）+线性分类器替代 [class] token 时效果很差，这一差距的真正原因是什么——是 GAP/无 class token 本身的架构劣势，还是训练超参数（学习率）设置不当？" `[正文支持][页码：16-17]`，直接支撑本文对模块 2（[class] Token 设计）的正当性论证。
   - **图表角色**：消融验证。
   - **上文呼应**：附录 D.3，对应"[class] Token 是否优于 GAP"这一方法设计选择的合理性论证。

2. **图像类型与布局**：单个折线图，横轴为 "Epochs of training"（0–7），纵轴为 "ImageNet linear 5-shot accuracy [%]"（约 25–58）。图中三条彩色实线，图例位于左上角："CLS-Token, lr=8e-4"（蓝色）、"GAP, lr=8e-4"（橙色）、"GAP, lr=3e-4"（绿色）`[图像直接可见]`。

3. **如何阅读**：横轴表示训练进程（epoch数），纵轴为该阶段模型在 ImageNet 上的 5-shot 线性评估准确率；应比较三条曲线在相同 epoch 下的准确率高低，以及区分"学习率相同、head类型不同"（蓝 vs 橙）与"head类型相同、学习率不同"（橙 vs 绿）两组对照关系 `[图像直接可见]`。

4. **直接可见的结论**：
   - 三条曲线均从约 26% 左右的准确率起步，随训练 epoch 增加而上升 `[图像直接可见]`。
   - 在与 CLS-Token 相同学习率（8e-4）下，"GAP, lr=8e-4"（橙色）曲线在整个训练过程中明显低于"CLS-Token, lr=8e-4"（蓝色）曲线，到第 7 个 epoch 时橙色（约 50%）仍显著低于蓝色（约 55%）`[图像直接可见]`。
   - 将 GAP 的学习率调整为 3e-4 后，"GAP, lr=3e-4"（绿色）曲线在大部分训练区间高于或接近"CLS-Token, lr=8e-4"（蓝色）曲线，两者到训练末期（约第7个epoch）非常接近，绿色略高于蓝色 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图为**消融验证**类证据，直接支撑正文"the difference in performance is fully explained by the requirement for a different learning-rate"以及图注"Both work similarly well, but require different learning-rates"的陈述——图中"GAP+同一学习率"明显更差，而"GAP+调优后学习率"追平甚至反超"CLS-Token"，说明性能差距的关键变量是学习率而非 head 类型（class token vs GAP）本身 `[正文支持][页码：16-17]`。这为主张地图中"[class] token 相对 GAP 无架构本身优势，两者表现相近"提供了直接的可见证据，支持论文选用 [class] token 设计并非因其性能显著优于 GAP，而是延续原始 Transformer/BERT 设计传统的方法选择 `[正文支持][页码：3,16-17]`。**不能**由该图证明"为何 GAP 和 CLS-Token 对学习率的敏感性不同"这一更深层机制（正文未展开该原因）`[基于视觉的谨慎推断]`。

6. **适用范围与证据缺口**：本证据覆盖的设置为"ViT-B/16 模型，训练 0–7 个 epoch 期间的 ImageNet linear 5-shot 准确率对比，对比 CLS-Token（lr=8e-4）与 GAP（分别在 lr=8e-4 和 lr=3e-4 两种学习率）"`[正文支持][页码：16-17]`。无额外证据缺口。
