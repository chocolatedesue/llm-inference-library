# 图片批次 3

## 图片 1：Figure 6: Representative examples of attention from the output token to the input space. See Appendix D.7 for details.

![Figure 6: Representative examples of attention from the output token to the input space. See Appendix D.7 for details.](../assets/imgs/img_in_image_box_803_685_992_1024.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：机制类证据。对应第4.5节"INSPECTING VISION TRANSFORMER"中紧接"attention distance"讨论之后的陈述——"Globally, we find that the model attends to image regions that are semantically relevant for classification (Figure 6)"，用于定性支撑"自注意力机制学到了聚焦语义相关区域"这一机制性论断，而非直接的精度对比或消融实验。`[正文支持]`
   - **图表角色**：实验结论（对内部机制的定性举例说明）。
   - **上文呼应**：第4.5节，紧承"self-attention integrates information globally even in lowest layers"论述之后，作为该机制主张的定性可视化佐证；方法定义见Appendix D.8（Attention Rollout）。

2. **图像类型与布局**：非曲线/柱状图，是一个2列×3行的图像网格：左列标题"Input"，右列标题"Attention"；三行分别为三组不同输入图像（一只狗、一架飞机、一个类似昆虫/毛虫的近距特写）及其各自对应的attention叠加可视化图。

3. **如何阅读**：逐行比较左侧原图与右侧对应的attention图；右图中较亮/不透明区域代表output token经Attention Rollout计算后对该输入区域的注意力权重较高，较暗区域代表权重较低。图中未附数值色标/colorbar，无法读出具体权重数值。

4. **直接可见的结论**：`[图像直接可见]` 三行样例中，attention较亮区域均与图像主体对象的轮廓大致重合，背景区域普遍被压暗：第一行狗的头部/躯干轮廓被凸显，草地背景变暗；第二行飞机机身与机翼区域被凸显，云层背景变暗；第三行毛虫状主体的条纹结构被凸显，周边背景变暗。三例中主体与背景的亮暗对比程度不完全一致。

5. **它验证的论点与方法设计含义**：`[正文支持]` 该图为机制类证据，支撑正文"the model attends to image regions that are semantically relevant for classification"这一陈述，即用Attention Rollout（Appendix D.8：对ViT-L/16各层各头的注意力权重取平均并递归相乘得到的从输出token到输入空间的映射）定性展示自注意力确实学会聚焦判别性物体区域，而非随机/均匀分布，从而为"模块4：MSA可以在无需CNN局部性/平移等变性归纳偏置的情况下整合全局且语义相关的信息"提供直觉支持。但该图仅是"representative examples"，样本量极小（3例），不能作为统计意义上的普遍性证据，也不能单独证明"large scale training trumps inductive bias"这一更宏观的核心论点，只能作为该论点的机制侧面例证。

6. **适用范围与证据缺口**：本图覆盖的设置为ViT-L/16模型、经Attention Rollout方法计算的注意力图，图注称为"representative examples"，具体挑选标准（随机抽取还是人工精选代表性案例）正文与图题均未说明——这与页脚附录中Figure 14图注"as in Figure 6 (random selection)"（该图为Figure 6的补充图）存在术语上的不一致，"representative"与"random"的具体关系"文中未说明"，构成真实的图注/正文表述缺口。除此之外，图中未标注所用输入图像的具体来源/分辨率、层数或数值权重，无法进一步核验，不臆测。

---

## 图片 2：Figure 7: Left: Filters of the initial linear embedding of RGB values of ViT-L/32. Center: Similarity of position embeddings of ViT-L/32. Tiles show the cosine similarity between the position embedding of the patch with the indicated row and column and the position embeddings of all other patches. Right: Size of attended area by head and network depth. Each dot shows the mean attention distance across images for one of 16 heads at one layer. See Appendix D.7 for details.

![Figure 7: Left: Filters of the initial linear embedding of RGB values of ViT-L/32. Center: Similarity of position embeddings of ViT-L/32. Tiles show the cosine similarity between the position embedding of the patch with the indicated row and column and the position embeddings of all other patches. Right: Size of attended area by head and network depth. Each dot shows the mean attention distance across images for one of 16 heads at one layer. See Appendix D.7 for details.](../assets/imgs/img_in_image_box_216_185_999_415.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：机制类证据，三个子面板共同支撑第4.5节对ViT内部表征的可解释性分析：(a) 验证patch线性投影（模块1）学到的滤波器是否具有可解释的结构；(b) 验证1D位置编码（模块3）是否自发学出2D空间拓扑关系，从而解释Table 8消融中"2D-aware位置编码无显著增益"的原因；(c) 验证MSA（模块4）是否能在浅层即整合全局信息，随深度增加而扩大关注范围。`[正文支持]`
   - **图表角色**：实验结论（对内部表征/注意力行为的定量与定性分析）。
   - **上文呼应**：第4.5节三段依次对应Left/Center/Right三个面板；Center面板呼应Appendix D.4（位置编码消融，Table 8）；Right面板呼应Appendix D.7（attention distance定义）。

2. **图像类型与布局**：三个并列子图。Left为网格状滤波器可视化（约7×4排列的28个小方块，标题"RGB embedding filters (first 28 principal components)"）；Center为7×7的网格热力图矩阵，每个小格内部是一个7×7的余弦相似度热力图，横轴"Input patch column"、纵轴"Input patch row"（1–7），右侧colorbar标注"Cosine similarity"，范围约-1到1，标题"Position embedding similarity"；Right为散点图，标题"ViT-L/16"，横轴"Network depth (layer)"，纵轴"Mean attention distance (pixels)"，图例区分"Head 1"（蓝）、"Head 2"（橙）、"Head 3"（绿）、"..."（红，代表其余头）。

3. **如何阅读**：Left面板逐格观察纹理/色彩模式，代表patch embedding投影矩阵E习得的基函数；Center面板需先定位某个参考行列坐标的小格子，格内热力图展示该patch位置embedding与所有其他patch位置embedding的余弦相似度，黄色接近1（高相似），紫/蓝接近-1（低相似）；Right面板每个点代表某一层某一个注意力头（16个头之一）在多张图像上的平均注意力距离，需按颜色区分head、沿x轴（深度）观察y轴（距离）的整体趋势与头间离散程度。

4. **直接可见的结论**：`[图像直接可见]`
   - Left：28个滤波器呈现条纹、色斑、边缘状等有规律的纹理模式（部分呈方向性条纹，部分呈中心-周边彩色斑块），并非随机噪声。
   - Center：每个小格内部的热力图在对应自身行列坐标处呈现最亮的黄色斑点，随行列距离增大逐渐过渡为蓝紫色；同时可见与参考patch同行或同列的其他格子在对应位置上也呈现局部偏亮的十字状分布。
   - Right：网络浅层（depth接近0）时各头（不同颜色点）的mean attention distance分布跨度很大，从接近0到100+像素都有点；随depth增大（约10层以后），各头的点普遍聚集收敛到较高的距离区间（约80–120像素），离散程度明显收窄。

5. **它验证的论点与方法设计含义**：`[正文支持]`
   - Left：支撑"the components resemble plausible basis functions for a low-dimensional representation of the fine structure within each patch"，说明模块1（Patch Embedding）学到的投影是有意义的类视觉基函数，而非随机映射；此为定性展示，不构成对精度的直接证据。
   - Center：支撑"the model learns to encode distance within the image in the similarity of position embeddings...closer patches tend to have more similar position embeddings"及"row-column structure appears"，为模块3（位置编码）提供机制解释——仅用简单1D可学习位置编码即可自发学出2D空间拓扑（距离关系与行列结构），从而解释了Table 8消融中"1D/2D/相对位置编码差异很小"的原因：因为1D方案本身已隐式表达了2D结构。这是对"为何几乎不加归纳偏置也能work"的子机制支持，但不能反过来单独证明"大规模数据替代归纳偏置"这一更宏观论点。
   - Right：支撑"Self-attention allows ViT to integrate information across the entire image even in the lowest layers...some heads attend to most of the image already in the lowest layers"以及"attention distance increases with network depth"——图中浅层已有部分头分布在较高距离区间，且整体点位随深度上移，与两条陈述均一致。此证据支撑模块4（MSA）"可在最底层整合全局信息，不同于CNN需逐层堆叠扩大感受野"的技术优势论证，但仅针对单一模型（ViT-L/16），不能推广到所有规模/patch size配置。

6. **适用范围与证据缺口**：Left与Center面板对应的模型为ViT-L/32（据图题文字说明），而Right面板图内标题明确写为"ViT-L/16"——同一张图的不同子面板对应不同的模型配置（patch size 32 vs 16），这一点由图像本身标题可直接确认，需注意不可混为同一模型的结果解读。Right面板仅展示16个头中的3个具名头（Head1/2/3），其余头合并标注为"..."，图中无法逐一区分该类别下具体头的个体数值。Center面板的patch网格为7×7（49个patch位置），对应的具体输入图像分辨率图中未标注。除以上图像标题本身已提供的信息外，无法可靠判断额外细节，不臆测。
