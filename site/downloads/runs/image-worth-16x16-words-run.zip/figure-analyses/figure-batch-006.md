# 图片批次 6

## 图片 1：Figure 12: Left: Real wall-clock timings of various architectures across input sizes. ViT models have speed comparable to similar ResNets. Right: Largest per-core batch-size fitting on device with various architectures across input sizes. ViT models are clearly more memory-efficient.

![Figure 12: Left: Real wall-clock timings of various architectures across input sizes. ViT models have speed comparable to similar ResNets. Right: Largest per-core batch-size fitting on device with various architectures across input sizes. ViT models are clearly more memory-efficient.](../assets/imgs/img_in_chart_box_248_443_972_751.jpg)

*来源：OCR 第 19 页。*

### 解读

1. **论文角色与验证问题**：本图属于**实验结论**（证据类型：效果）。作者在附录 D.5"经验计算成本"部分，用真实硬件（TPUv3）上的墙钟推理速度和单核可容纳的最大 batch-size，来补充正文基于 FLOPs 的理论对比，验证论文摘要中"ViT 预训练计算成本更低"这一效果主张在真实设备上是否成立，同时具体检验 ViT 与 ResNet 基线相比在速度和内存效率上的表现。`[正文支持]`
   - **图表角色**：实验结论（同时具有对比基线属性，比较对象为 R50x1/R50x2/R152x4 等 ResNet 基线）。
   - **上文呼应**：对应附录 D.5 "EMPIRICAL COMPUTATIONAL COSTS"，呼应正文摘要"预训练计算成本更低"的量化效果主张。

2. **图像类型与布局**：双子图折线图。左图纵轴为"Peak inference speed [img/sec/core]"（对数刻度），右图纵轴为"Largest per-core batch-size"（对数刻度），两图横轴均为"Input size [px]"，取值 64/128/224/384/512。顶部图例用颜色区分模型族（深灰=R50x1、蓝色=ViT-B/32、洋红=ViT-B/16、橙色=ViT-H/14、灰色=R152x4），用实线/虚线区分同族的不同规模（如 ViT-L/32、ViT-L/16 为虚线）。

3. **如何阅读**：横轴为输入分辨率，纵轴均为对数刻度；应比较相同颜色系（同架构族）在不同输入尺寸下曲线的相对高度和下降斜率，尤其关注 ViT 曲线与对应 ResNet 曲线（R50x1/R50x2/R152x4）在同一输入尺寸下的相对位置。图例说明线型/颜色与图注中提到的"ViT models"与"ResNets"对应关系。

4. **直接可见的结论**：随输入尺寸增大，所有模型的推理速度均下降；ViT-B/32、ViT-L/32（蓝色）曲线在各尺寸下位于或高于 R50x1/R50x2（深灰）曲线，速度相近或更快；ViT-B/16、ViT-L/16（洋红）曲线整体低于 32-patch 的 ViT，与深灰曲线在中等尺寸区间接近。右图中，ViT-B/32、ViT-L/32、ViT-B/16（蓝、洋红实线）在较小到中等输入尺寸下维持在纵轴顶部（触顶）更久，而 R152x4（浅灰）曲线下降最早、最陡，在 512px 时降至明显低于其余曲线的位置；ViT-H/14（橙色）与部分洋红曲线仅在最大尺寸（384/512px）才出现明显下降。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为"效果"类证据，直接支持图注所述"ViT models have speed comparable to similar ResNets"（左图）与"ViT models are clearly more memory-efficient"（右图）。结合正文，这说明 ViT 不仅在准确率上具有竞争力，其推理速度与同量级 ResNet 相当，且在单核可容纳的最大 batch-size 上明显优于 ResNet，为"预训练计算成本更低"的整体主张提供了真实硬件层面的效果支撑，而非仅停留在理论 FLOPs 对比。该图不能证明速度差异背后的具体硬件/实现机制（正文也未展开），只能证明"存在"这种效果差异。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本证据覆盖论文在 TPUv3 加速器、单核（per-core）设置下，对多种规模 ViT/ResNet 模型在 64–512px 输入尺寸范围内测得的峰值推理速度和最大 batch-size；正文明确说明"推理与反向传播速度的差异是一个与模型无关的常数因子"，因此该图代表的效率结论可视为对训练效率的间接支持。真实缺口：右图部分曲线（如 ViT-B/32、ViT-L/32、ViT-B/16）在纵轴顶部呈现平线，是否存在实验中人为设置的 batch-size 搜索上限，还是模型确实未触及内存瓶颈，无法从当前 OCR 内容确认。

---

## 图片 2：Figure 13: Performance of Axial-Attention based models, in terms of top-1 accuracy on ImageNet 5-shot linear, versus their speed in terms of number of FLOPs (left) and inference time (left).

![Figure 13: Performance of Axial-Attention based models, in terms of top-1 accuracy on ImageNet 5-shot linear, versus their speed in terms of number of FLOPs (left) and inference time (left).](../figure-groups/page-0020-565593998539.png)

*来源：OCR 第 20 页。*

### 解读

1. **论文角色与验证问题**：本图属于**消融验证**（证据类型：机制与必要性权衡）。作者在附录 D.6 中将 Axial Attention（一种此前在 Related Work 中被归类为"需要复杂工程才能在硬件加速器上高效实现"的专用注意力模式）整合进 ViT（AxialViT）以及作为 ResNet 变体（AxialResNet），验证"用轴向自注意力替代全局自注意力"是否能在准确率-算力/速度权衡上优于原版 ViT，从而检验该类专用注意力方案在 ViT 框架下的实际必要性与代价。`[正文支持]`
   - **图表角色**：消融验证（设计变体对比）。
   - **上文呼应**：对应附录 D.6 "AXIAL ATTENTION"，呼应 Related Work 中对"专用注意力架构在硬件加速器上效率受限"这一旧方法限制的讨论。

2. **图像类型与布局**：两个并列散点图（Panel 1、Panel 2），纵轴均为"ImageNet 5-shot linear top-1 accuracy"；Panel 1 横轴为"Total compute [exaFLOPs]"（对数刻度，正常递增方向），Panel 2 横轴为"Peak inference speed [img/sec/core]"（对数刻度，但刻度从左到右为 10³→10²，即数值递减方向）。六个点用颜色区分模型：蓝色 AxialViT-B/16、绿色 ViT-B/16、橙色 AxialViT-B/32、红棕色 ViT-B/32、浅棕色 AxialResNet50、粉色 ResNet50。

3. **如何阅读**：两图纵轴相同，应分别对照横轴"算力代价"（Panel 1，向右代价更高）与"推理速度"（Panel 2，向右速度更低，因刻度递减）比较各模型准确率与代价/速度的位置关系；重点比较 Axial 变体与其非 Axial 对应模型（如 AxialViT-B/16 对 ViT-B/16、AxialViT-B/32 对 ViT-B/32）的相对位置。

4. **直接可见的结论**：Panel 1 中，AxialViT-B/16 准确率最高（约 0.66）且总算力也最高（图中最靠右）；ViT-B/16 准确率次高（约 0.635）但算力低于 AxialViT-B/16；AxialViT-B/32 准确率（约 0.585）高于 ViT-B/32（约 0.565），且算力也更高；AxialResNet50 与 ViT-B/32 算力相近但准确率略低（约 0.55）；ResNet50 算力最低、准确率最低（约 0.495）。Panel 2 中，ViT-B/32、ViT-B/16、AxialViT-B/32 及 ResNet50 均位于坐标图左侧（速度较高区域），而 AxialViT-B/16 位置明显偏右（速度较低），AxialResNet50 位于图中最右侧（速度最低）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为"机制/必要性"类证据，直接支持正文所述"AxialViT-B/32 和 AxialViT-B/16 在性能上优于各自的 ViT-B 对应版本，但代价是更多计算量"——Panel 1 的准确率-算力关系可见验证。Panel 2 进一步显示这种性能提升在实际推理速度上打了折扣：AxialViT-B/16 的速度低于同精度区间的 ViT-B/16，而 AxialResNet50 的推理速度远低于所有其他模型，与正文"AxialResNet 朴素实现在 TPU 上极慢"的陈述一致。这为方法设计提供的含义是：轴向自注意力这类专用注意力模式即使整合进 ViT 框架、在准确率-算力权衡上"看似合理"，其真实硬件推理速度仍可能显著劣化，从而印证论文选择标准全局自注意力（而非专用注意力模式）作为 ViT 主方案的设计取舍。该图不能证明速度劣化的具体底层实现原因（如是否为 TPU 编译/算子层面的问题），正文也未展开。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本证据覆盖论文在 JFT 数据集预训练、ImageNet 5-shot linear 评估下，对 ViT-B/32、ViT-B/16、AxialViT-B/32、AxialViT-B/16、ResNet50、AxialResNet50 六个模型的准确率与算力（exaFLOPs）、峰值推理速度（img/sec/core，TPU 上测得）的对比。无额外证据缺口。
