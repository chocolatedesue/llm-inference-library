# 图片批次 2

## 图片 1：Figure 3: Transfer to ImageNet. While large ViT models perform worse than BiT ResNets (shaded area) when pre-trained on small datasets, they shine when pre-trained on larger datasets. Similarly, larger ViT variants overtake smaller ones as the dataset grows.

![Figure 3: Transfer to ImageNet. While large ViT models perform worse than BiT ResNets (shaded area) when pre-trained on small datasets, they shine when pre-trained on larger datasets. Similarly, larger ViT variants overtake smaller ones as the dataset grows.](../figure-groups/page-0007-09e1c7b95ac4.png)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：该图组对应第 4.3 节"PRE-TRAINING DATA REQUIREMENTS"，作者提出的问题是"ViT 相较 ResNet 视觉归纳偏置更少，数据集规模究竟有多关键"`[作者明确陈述][页码：6]`。图组用两组独立实验回答该问题：Panel 1（Figure 3）固定架构、逐步增大预训练数据集（ImageNet→ImageNet-21k→JFT-300M），检验大模型是否只有在大数据下才发挥优势；Panel 2（Figure 4）用 JFT 的随机子集（9M/30M/90M/300M）做线性 few-shot 评估，剥离正则化影响，检验"数据量"这一内在因素本身如何影响 ViT 与 ResNet 的过拟合/欠拟合行为`[作者明确陈述][页码：6-7]`。
   - **图表角色**：实验结论（兼具适用边界，界定 ViT 优于/劣于 CNN 的数据规模阈值）。
   - **上文呼应**：第 4.3 节"预训练数据需求"，对应论文核心假设"大规模预训练数据是 ViT 摆脱卷积归纳偏置劣势的前提条件"。

2. **图像类型与布局**：本图为一张页面渲染图，包含两个并列子图（Panel 1、Panel 2），均为散点/趋势图。Panel 1 是散点图：横轴为预训练数据集（ImageNet、ImageNet-21k、JFT-300M 三个离散点位），纵轴为 ImageNet Top1 准确率，六种模型（BiT、ViT-B/32、ViT-B/16、ViT-L/32、ViT-L/16、ViT-H/14）用不同颜色/形状的点表示，BiT 点之间以灰色阴影带连接表示不同规模 BiT 构成的性能区间，同色点之间也用细线连接表示同一模型随数据集增大的变化趋势。Panel 2 是折线图：横轴为 JFT 预训练样本数（10M/30M/100M/300M，对数尺度），纵轴为 Linear 5-shot ImageNet Top1 准确率，六条不同颜色线分别代表 ViT-L/16、ViT-B/32、ViT-L/32、ViT-b/32 及两种 ResNet(BiT)（ResNet50x1、ResNet152x2）。

3. **如何阅读**：Panel 1 应沿横轴从左到右比较同一模型随预训练数据集增大时纵轴（准确率）的变化，并与灰色 BiT 阴影带比较高低；图例列出六个模型名称与对应颜色/形状。Panel 2 应比较不同颜色曲线在同一横轴取值下的纵轴高度，以及曲线随样本量增大的爬升/趋平斜率；ResNet(BiT) 用灰色方块系列表示，ViT 系列用蓝/绿色系列表示，图例位于图内下方。

4. **直接可见的结论**：Panel 1 中，在最左侧（ImageNet）数据点上，灰色 BiT 阴影带位置高于多数 ViT 点（尤其 ViT-L/32、ViT-B/16），且 ViT-L/32（浅绿）低于 ViT-B/32（浅蓝）；随着横轴右移至 ImageNet-21k，各 ViT 点与灰色阴影带高度趋近；到最右侧 JFT-300M，ViT-H/14（橙色最大点）明显高于灰色阴影带上沿，ViT-L/16 次之，且各模型点整体高于左侧两个数据点位置`[图像直接可见]`。Panel 2 中，灰色 ResNet 曲线（尤其 ResNet152x2）在最左侧（10M）取值高于同期 ViT 曲线，但从 30M 起多数 ViT 曲线（ViT-L/16、ViT-B/32 等）已升至与 ResNet152x2 相近或更高的位置，且随样本量继续增大到 100M、300M，ViT 曲线继续上升，而 ResNet 曲线（尤其 ResNet50x1）在中段以后趋于平缓，最终 ViT-L/16 曲线位置高于所有 ResNet 曲线`[图像直接可见]`。

5. **它验证的论点与方法设计含义**：Panel 1 直接支撑正文"仅在 JFT-300M 这一最大数据集上，才能看到大模型（ViT-Large 系列乃至 ViT-H/14）相对小模型和相对 BiT 的完整优势；在最小数据集 ImageNet 上 ViT-Large 反而弱于 BiT/ViT-Base"这一表述，证据类型为**适用边界**：它划定了"不依赖卷积归纳偏置的纯 Transformer 要达到/超越 SOTA CNN"这一核心主张成立所需要的最低数据规模条件`[正文支持][页码：6]`。Panel 2 进一步支撑"卷积归纳偏置在小数据集上有用、但数据量足够大时直接从数据学习即可甚至更优"的解释，证据类型为**机制**（剥离正则化后观察模型内在的过拟合倾向）：ViT 在 9M 子集上过拟合明显（few-shot 准确率低于同等算力的 ResNet），但在 90M+ 子集上反超，说明 ViT 优势的来源并非架构本身在任何数据量下都占优，而是需要数据量跨过某一门槛以补偿归纳偏置的缺失`[正文支持][页码：7]`。两图合并读出的方法设计含义是：论文后续所有"ViT 优于/媲美 CNN"的结论都应限定在大规模预训练数据（JFT-300M 级别）前提下，小数据场景不能直接套用该结论。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 ImageNet/ImageNet-21k/JFT-300M 三级数据集全量预训练（Panel 1，微调后 ImageNet 准确率）与 JFT-300M 的 9M/30M/90M/300M 随机子集（Panel 2，线性 5-shot 评估，未做额外正则化，使用早停）`[作者明确陈述][页码：6-7]`。Panel 2 中 ViT-b/32 依据图注为"ViT-B 所有隐藏维度减半"的变体，未在正文中给出具体动机说明`[正文支持][页码：7]`。无额外证据缺口。

---

## 图片 2：Figure 5: Performance versus pre-training compute for different architectures: Vision Transformers, ResNets, and hybrids. Vision Transformers generally outperform ResNets with the same computational budget. Hybrids improve upon pure Transformers for smaller model sizes, but the gap vanishes for larger models.

![Figure 5: Performance versus pre-training compute for different architectures: Vision Transformers, ResNets, and hybrids. Vision Transformers generally outperform ResNets with the same computational budget. Hybrids improve upon pure Transformers for smaller model sizes, but the gap vanishes for larger models.](../assets/imgs/img_in_chart_box_249_618_971_924.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 4.4 节"SCALING STUDY"，作者要回答的问题是"在剥离数据规模瓶颈（均用 JFT-300M 预训练）后，Vision Transformer、ResNet(BiT)、以及二者混合（Hybrid）三类架构在性能-算力权衡上的可扩展性谁更优"`[作者明确陈述][页码：8]`。图为受控扩展性研究的核心结果，横向比较 7 个 ResNet、6 个 ViT、5 个 Hybrid 共 18 个模型的迁移性能与预训练总算力关系`[作者明确陈述][页码：8]`。
   - **图表角色**：实验结论（兼具对比基线：ViT vs ResNet(BiT) vs Hybrid 三类架构的算力效率对照）。
   - **上文呼应**：第 4.4 节"扩展性研究"，对应论文主张"预训练计算成本更低"（摘要中的核心声明之一）。

2. **图像类型与布局**：两个并列散点图，左侧标题"Average-5"（5 个数据集上的平均迁移准确率），右侧标题"ImageNet"（单独在 ImageNet 上的迁移准确率）；两图横轴均为"Total pre-training compute [exaFLOPs]"，对数尺度；纵轴分别为"Transfer accuracy [%]"（左）和未单独标注但同为迁移准确率（右）。三类模型用不同颜色/形状标记：蓝色圆点为 Transformer (ViT)，灰色方块为 ResNet (BiT)，橙色十字为 Hybrid，图例位于右侧子图内。

3. **如何阅读**：应在同一横轴取值（即相近算力预算）附近比较三类点在纵轴上的高度差异，以及各类点随横轴（算力）增大时纵轴的爬升趋势和是否出现平台期；蓝色、灰色、橙色三个系列需分别追踪其散点云的整体走向。

4. **直接可见的结论**：两个子图中，在同一算力（横轴）取值区间，蓝色（ViT）点普遍高于同等横轴位置的灰色（ResNet）点，或者说达到同一纵轴高度所需的蓝色点横轴取值明显小于灰色点`[图像直接可见]`。在图的左侧（较小算力区间），橙色（Hybrid）点与蓝色点高度接近甚至略高于蓝色点；但在图右侧（较大算力区间），橙色点与蓝色点几乎重合，三者中灰色点持续位于蓝色和橙色点下方`[图像直接可见]`。随横轴（算力）增大，蓝色点在图右端仍呈上升趋势，未见明显趋平的平台段`[图像直接可见]`。Average-5 与 ImageNet 两个子图呈现的相对位置关系一致`[图像直接可见]`。

5. **它验证的论点与方法设计含义**：本图直接支撑正文"Vision Transformer 在性能/算力权衡上全面优于 ResNet，约用 2-4× 更少算力达到同等性能（5 数据集平均）"这一定量主张，证据类型为**效果**对比`[正文支持][页码：8]`；同时支撑"Hybrid 仅在较小算力预算下略优于纯 ViT，模型增大后差距消失"这一**消融验证**式结论（用于排除"卷积局部特征处理在任意规模下都有帮助"这一预期）`[正文支持][页码：8]`；此外支撑"ViT 在已测试范围内未出现性能饱和"这一**适用边界**表述，为后续扩大规模的研究动机提供依据`[正文支持][页码：8]`。这些结论共同强化摘要中"预训练所需计算资源更少"的核心主张，并说明该主张是在与 BiT 及 Hybrid 同预算受控比较下得出，而非仅来自与个别历史 SOTA 模型的非受控比较（后者已由 Table 2 单独支持）。

6. **适用范围与证据缺出**：本证据覆盖论文报告的受控扩展性研究：18 个模型（7 ResNet、6 ViT、5 Hybrid）均在 JFT-300M 上预训练，评估其在 5 个数据集平均（Average-5）及单独 ImageNet 上的迁移准确率随预训练总算力（exaFLOPs）的变化`[作者明确陈述][页码：8]`。图中各点对应的具体模型规格（如哪个点是 ViT-H/14、哪个点是 R50x1 等）未在图上标注文字，仅能通过颜色/形状区分架构大类，无法从本图直接对应到 Table 6 中的具体行`[图像直接可见]`。无额外证据缺口。
