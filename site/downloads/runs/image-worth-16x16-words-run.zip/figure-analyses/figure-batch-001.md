# 图片批次 1

## 图片 1：Figure 1: Model overview. We split an image into fixed-size patches, linearly embed each of them, add position embeddings, and feed the resulting sequence of vectors to a standard Transformer encoder. In order to perform classification, we use the standard approach of adding an extra learnable "classification token" to the sequence. The illustration of the Transformer encoder was inspired by Vaswani et al. (2017).

![Figure 1: Model overview. We split an image into fixed-size patches, linearly embed each of them, add position embeddings, and feed the resulting sequence of vectors to a standard Transformer encoder. In order to perform classification, we use the standard approach of adding an extra learnable "classification token" to the sequence. The illustration of the Transformer encoder was inspired by Vaswani et al. (2017).](../assets/imgs/img_in_image_box_291_161_938_494.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：本图是论文提出核心方法（ViT 架构）的整体示意图，作者需要用它把"图像切成 patch 序列 + 标准 Transformer 编码器"这一几乎不做视觉专用修改的架构设计一次性可视化，对应根问题"能否用尽可能接近 NLP 标准 Transformer 的架构处理图像识别"`[正文支持]`。
   - **图表角色**：方法流水线
   - **上文呼应**：第 3 节 METHOD / 3.1 节 VISION TRANSFORMER (ViT)，对应 Figure 1 图注"We split an image into fixed-size patches, linearly embed each of them, add position embeddings, and feed the resulting sequence of vectors to a standard Transformer encoder..."

2. **图像类型与布局**：示意图（架构流程图），分两个并列面板。左侧标题"Vision Transformer (ViT)"，自下而上为：一张原图被切成 3×3 共 9 个小方块（patch）→ 箭头指向"Linear Projection of Flattened Patches"粉色条带 → 上方一排编号 0*、1–9 的紫色椭圆（token embedding），其中"0*"为橙色标注的"Extra learnable [class] embedding"→ 灰色大框"Transformer Encoder"→ 绿色"MLP Head"→ 橙色框"Class"给出示例类别列表（Bird、Ball、Car…）。右侧标题"Transformer Encoder"，是对左侧灰色框内部结构的放大：自下而上为"Embedded Patches"→黄色"Norm"→绿色"Multi-Head Attention"→ 一个"+"残差汇合点 → 黄色"Norm"→蓝色"MLP"→ 另一个"+"残差汇合点，整个模块外围标注"L×"表示循环堆叠 L 层。

3. **如何阅读**：应沿左图从下到上的箭头顺序阅读，把它当作数据流：原图→分块→展平投影→拼接 class token 与位置编号→送入编码器→分类头→输出类别；右图则是把左图中"Transformer Encoder"这一黑箱展开后的内部子流程图，两图之间通过颜色和名称（灰色"Transformer Encoder"框）对应，"L×"是需要与右图中残差连接位置对照理解的堆叠次数标记。

4. **直接可见的结论**：图中确实显示原图被均匀切分为 9 个方块，每个方块经线性投影后变为一个编号 token，并在序列最前面额外拼接了一个标为"0*"的可学习 class 向量；该 token 序列输入同一个灰色"Transformer Encoder"模块后接 MLP Head 输出分类结果；右图显示编码器内部为"Norm→Multi-Head Attention→残差相加→Norm→MLP→残差相加"的重复堆叠结构，两个残差连接（"+"）分别环绕注意力子层和 MLP 子层 `[图像直接可见]`。图中位置编码以"0*,1,2,...,9"的数字标签体现在 patch+position embedding 阶段，但图中未展示位置编码是如何与 patch embedding 相加的具体运算细节 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图是效果与机制类主张的方法载体图解，直接对应模块 1（Patch 化与线性投影）、模块 2（[class] Token）、模块 3（位置编码）、模块 4（Transformer 编码器 MSA+MLP+Pre-LN+残差）四个方法模块的整体拼装关系：图像证据确认了 patch 序列化、class token 前置拼接、位置编号、以及编码器内 Norm-Attention-残差-Norm-MLP-残死的结构安排与正文 Eq.1–Eq.4 描述的架构完全一致 `[正文支持]`。该图只能证明"架构设计如此实现"，不能证明该架构在具体数据集上的性能（性能主张需由 Table 2、Figure 3/4/5 等实验图表提供），也不能证明"全局自注意力在最底层即可整合全局信息"这一机制性主张（该主张需由 4.5 节 attention distance 分析验证，图中未涉及）。

6. **适用范围与证据缺口**：本图覆盖的是论文正文 3.1 节描述的标准 ViT 架构总览（patch 化、class token、位置编码、编码器堆叠），未包含 Hybrid 架构（CNN 特征图替代原始 patch）或微调时的分辨率适配细节，这些属于论文其他小节（3.1 末尾 Hybrid 段、3.2 节）单独描述、本图未展示的部分。无额外证据缺口。

---

## 图片 2：Figure 2: Breakdown of VTAB performance in Natural, Specialized, and Structured task groups.

![Figure 2: Breakdown of VTAB performance in Natural, Specialized, and Structured task groups.](../assets/imgs/img_in_chart_box_224_572_987_742.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图用于将 ViT-H/14 与此前 VTAB 基准上的 SOTA/相关方法（BiT-L、VIVI、S4L）按 VTAB 三大任务组（Natural/Specialized/Structured）拆解对比，验证"ViT 在低数据迁移（VTAB）上是否全面优于此前方法，还是仅在部分任务组占优"这一效果类主张，并为"VTAB Specialized 组优势不明显"这一适用边界提供细粒度支持 `[正文支持]`。
   - **图表角色**：对比基线
   - **上文呼应**：第 4.2 节 COMPARISON TO STATE OF THE ART，对应 Figure 2 图注"Breakdown of VTAB performance in Natural, Specialized, and Structured task groups"及正文"ViT-H/14 outperforms BiT-R152x4, and other methods, on the Natural and Structured tasks. On the Specialized the performance of the top two models is similar."

2. **图像类型与布局**：并列的 4 个分组柱状图子面板，从左到右依次标题为"VTAB (19 tasks)"、"Natural (7 tasks)"、"Specialized (4 tasks)"、"Structured (8 tasks)"；共享一个图例（位于顶部）区分四种颜色柱子：蓝色 ViT-H/14、粉色 BiT-L (R152x4)、绿色 VIVI-Ex-100% (R50x3)、黄色 S4L (R50x1)；纵轴均为"Accuracy [%]"，但每个子面板的纵轴数值范围不同（各自局部放大）。

3. **如何阅读**：应先看最左侧"VTAB (19 tasks)"子图得到总体排名，再逐一对比右侧三个任务组子图，观察同一方法（同色柱）在不同任务组间排名是否发生变化；由于各子图纵轴范围不同，柱高差异需结合各自坐标刻度判断，不能跨子图直接比较绝对柱高。

4. **直接可见的结论**：在"VTAB (19 tasks)"总览、"Natural"、"Structured"三个子图中，蓝色 ViT-H/14 柱均为四者中最高；在"Specialized"子图中，蓝色 ViT-H/14 与粉色 BiT-L 柱高非常接近（明显比另两个子图中的差距小），二者均明显高于绿色 VIVI 与黄色 S4L；绿色 VIVI 与黄色 S4L 两柱在四个子面板中始终低于蓝、粉两色，且在 Natural 与 Structured 组内二者相对高低有所交替 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图为效果类主张提供细粒度证据，支持"ViT-H/14 在 VTAB 整体及 Natural、Structured 任务组上超越 BiT-L、VIVI、S4L 等此前方法"的结论，同时也验证了论文自己承认的适用边界——"在 Specialized 任务组上，ViT-H/14 与最佳基线（BiT-L）表现相近，并非全面胜出" `[正文支持]`。BiT-L 原本要解决的问题是用大型 ResNet 做监督迁移学习；VIVI 原本目标是用 ResNet 在图像+视频联合训练获得更好表征；S4L 原本目标是用监督+半监督学习提升 ImageNet 表征质量——三者在 VTAB 任务组上被拿来整体对比准确率，但正文未具体说明本文对这三者各自方法论上的技术性 limit（"文中未说明"），因此本图检验的仅是"整体准确率排名"，不能被解读为对 VIVI/S4L 方法论本身的一般性技术批判。该图不能证明性能差异的来源（架构、数据规模、训练策略等各自贡献），也不能替代 Table 2 中的整体 ImageNet/CIFAR 等主线对比。

6. **适用范围与证据缺口**：本图覆盖范围为 VTAB-1k 协议下（每任务 1000 训练样本）ViT-H/14（JFT-300M 预训训练）与 BiT-L、VIVI-Ex-100%、S4L 四个模型在 19 个 VTAB 任务按三组的平均准确率对比，不代表这些方法在非 VTAB 基准（如 ImageNet 全量微调）上的相对表现。各子面板纵轴具体刻度值因图像分辨率限制无法精确读出，只能判断相对高低和大致接近程度，此为图像裁剪/像素层面的真实证据缺口；除此之外无额外证据缺口。
