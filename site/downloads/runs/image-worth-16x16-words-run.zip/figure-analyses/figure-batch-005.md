# 图片批次 5

## 图片 1：Figure 11: Size of attended area by head and network depth. Attention distance was computed for 128 example images by averaging the distance between the query pixel and all other pixels, weighted by the attention weight. Each dot shows the mean attention distance across images for one of 16 heads at one layer. Image width is 224 pixels.

![Figure 11: Size of attended area by head and network depth. Attention distance was computed for 128 example images by averaging the distance between the query pixel and all other pixels, weighted by the attention weight. Each dot shows the mean attention distance across images for one of 16 heads at one layer. Image width is 224 pixels.](../assets/imgs/img_in_chart_box_279_857_937_1213.jpg)

*来源：OCR 第 18 页。*

### 解读

1. **论文角色与验证问题**：该图对应 4.5 节与附录 D.7 关于"ViT 能否在最底层就整合全局信息"这一机制主张，并同时承担了 ViT（纯 patch 输入）与 Hybrid（ResNet 特征图输入）架构对比的功能。图表角色：**实验结论**（机制类，兼有**对比基线**成分）。上文呼应：第 8 节"4.5 INSPECTING VISION TRANSFORMER"及附录 D.7"ATTENTION DISTANCE"——正文陈述"部分注意力头在最底层就已关注几乎整幅图像""这种高度局部化的注意力在应用了 ResNet 前置的 hybrid 模型中不那么明显" `[正文支持]`。

2. **图像类型与布局**：两个并列的散点图。左图标题"ViT-L/16"，右图标题"R50x1 + ViT-L/16"（hybrid 架构）。每个散点图横轴为网络深度（layer），纵轴为平均注意力距离（像素）；图例标注 Head 1（蓝）、Head 2（橙）、Head 3（绿）、"…"（红，代表其余头，按图注共 16 头/层）。

3. **如何阅读**：横轴 Network depth (layer)，范围约 0–23；纵轴 Mean attention distance (pixels)，范围约 0–130。应比较同一横坐标（层数）下两个子图中纵向散布的范围，尤其关注低层（layer 0–5 附近）纵向分布的下界，以判断"局部化注意力头"在两种架构中是否同样明显。图例按头编号着色，但由于每层有 16 个头且只标出前 3 个加省略号，无法从图上逐一区分具体是哪个头。

4. **直接可见的结论**：左图（纯 ViT-L/16）在低层（约 layer 0–5）纵向散布很宽，既有接近 0–20 像素的低值点（局部化头），也有接近 100+ 像素的高值点（全局化头）；右图（hybrid）在相同低层区间，点的下界明显更高（大致从 30–40 像素起），低于 20 像素的点很少见。两图在较深层（约 layer 15 以后）均收敛到约 110–120 像素附近的较窄带状分布 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图为"自注意力使 ViT 能在最底层即整合全局信息，但部分头仍保持局部化"这一机制主张提供直接可见证据（左图存在低距离点即局部化头）`[正文支持]`；同时左右图对比支持正文"hybrid 模型中局部化注意力头现象不那么明显"的论断——右图低层缺少极低距离点，与"ResNet 前置卷积已承担了类似早期卷积层的局部特征提取功能，使 Transformer 部分不必再学出高度局部化的头"这一解释性论点相符 `[正文支持]`。该图不能证明局部化头对最终分类精度的贡献大小，也不能证明这种"局部/全局"分工是精度提升的因果原因，仅提供了架构行为层面的描述性证据。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 ViT-L/16 与 R50x1+ViT-L/16 两种配置，基于 128 张示例图像（图像宽度 224 像素）计算的平均注意力距离，覆盖网络全部层数与 16 个注意力头。无额外证据缺口。

---

## 图片 2：Figure 10: Position embeddings of models trained with different hyperparameters.

![Figure 10: Position embeddings of models trained with different hyperparameters.](../assets/imgs/img_in_chart_box_217_163_1007_423.jpg)

*来源：OCR 第 18 页。*

### 解读

1. **论文角色与验证问题**：该图对应附录 D.4"POSITIONAL EMBEDDING"末尾陈述——"the specific pattern of position embedding similarity learned by the network depends on the training hyperparameters (Figure 10)"，用于展示位置编码学出的相似度模式并非固定，而是随训练超参数变化。图表角色：**消融验证**（机制类，超参数敏感性说明）。上文呼应：附录 D.4 位置编码消融部分，与正文 4.5 节"位置编码自发学出行列结构和距离关系"的机制性观察相呼应，但本图本身聚焦于展示该模式对超参数的敏感性，而非验证 1D/2D/相对编码之间精度差异（精度差异由 Table 8 数值给出）`[正文支持]`。

2. **图像类型与布局**：三个并列的热力图矩阵（tile-of-tiles 结构），标题分别为"ViT-L16 / 7 epochs, LR=0.0002, WD=0.01"、"ViT-L16 / 7 epochs, LR=0.0004, WD=0.1"、"ViT-L16 / 14 epochs, LR=0.0004, WD=0.1"。每个大图由 14×14 个小格拼成，每个小格自身又是一张 14×14 的热力图，颜色条标注"Cosine similarity"，范围 -1 到 1（紫→黄）。横轴"Input patch column"，纵轴"Input patch row"（大格与小格坐标一致，对应 14×14 的 patch 网格）。

3. **如何阅读**：每个大格（行 i、列 j）内部的小热力图表示"位置 (i,j) 处 patch 的位置编码"与"所有其他 patch 位置编码"的余弦相似度分布；应比较三张大图中"十字形高亮（黄色）图案"的清晰度和对比度，以及该十字图案随大格坐标移动的规律性。三图对应不同训练超参数（学习率、weight decay、训练轮数），应横向对比同一网格位置在三种设置下的视觉清晰度差异。

4. **直接可见的结论**：最左图（LR=0.0002, WD=0.01）中每个小格内可见清晰的黄色十字形高亮图案，且该十字随大格行列坐标平移，呈现明显的行列结构；中间图与最右图（均为 LR=0.0004, WD=0.1，分别 7/14 epochs）整体色调更趋均匀（偏青绿色），十字形高亮图案明显较暗淡、对比度更低，行列结构仍隐约可辨但不如最左图鲜明 `[图像直接可见]`。三图之间，中间图与最右图彼此的视觉差异小于它们与最左图的差异 `[基于视觉的谨慎推断]`。

5. **它验证的论点与方法设计含义**：该图直接支持附录 D.4"位置编码相似度模式的具体清晰程度依训练超参数而变化"这一论断——不同学习率/weight decay 组合下，模型学出的行列结构清晰度不同 `[正文支持]`。这为"1D 位置编码能自发学出图像 2D 拓扑关系"（4.5 节机制性论点）提供了跨超参数的稳健性佐证：即便清晰度不同，三种设置下都能观察到某种行列结构，而非完全随机。但该图**不能**用于判断超参数差异是否影响下游分类精度（这是 Table 8 的任务），也不能确定具体是哪个超参数（学习率还是 weight decay）主导了清晰度差异，因为三图同时改变了两个变量（LR 与 WD 从左图到中/右图同时变化，仅 epoch 数在中右图间变化）。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 ViT-L/16 模型、14×14 patch 网格，在三种具体超参数组合（7 epochs/LR=0.0002/WD=0.01；7 epochs/LR=0.0004/WD=0.1；14 epochs/LR=0.0004/WD=0.1）下的位置编码相似度可视化。真实缺口：图中同时改变了学习率、weight decay 与训练轮数等多个变量，无法从图本身或正文单独归因于某一具体超参数对相似度模式清晰度的影响，此为正文未拆分说明的实验设计细节。
