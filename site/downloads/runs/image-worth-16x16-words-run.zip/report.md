# 论文解构报告

### 论文元数据

| 字段 | 内容 |
|---|---|
| 标题 | AN IMAGE IS WORTH 16X16 WORDS: TRANSFORMERS FOR IMAGE RECOGNITION AT SCALE |
| 作者 | Alexey Dosovitskiy, Lucas Beyer, Alexander Kolesnikov, Dirk Weissenborn, Xiaohua Zhai, Thomas Unterthiner, Mostafa Dehghani, Matthias Minderer, Georg Heigold, Sylvain Gelly, Jakob Uszkoreit, Neil Houlsby |
| 发表场所 / 年份 | 文中未说明 |
| 研究领域 | 计算机视觉、深度学习架构 |
| 关键词 | Vision Transformer, 图像分类, 自注意力机制, 大规模预训练, 计算机视觉 |

### 资源链接

- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

> **标签**：`Vision Transformer` · `自注意力机制` · `大规模预训练` · `归纳偏置` · `图像分类`

## 1. 一句话总览

论文提出 ViT：把图像切成固定大小的 patch 序列后直接用标准 Transformer 编码器做分类，证明在 14M–300M 图像级别的大规模预训练下、几乎不注入视觉专用归纳偏置也能达到或超越 SOTA CNN，且预训练所需算力更低 `[作者明确陈述][页码：1]`；但该优势严格依赖预训练数据规模，中小数据集下反而弱于同等规模 ResNet `[实验支持][页码：1-2]`。

## 2. 阅读范围与证据状态

本次分析覆盖正文第 1–9 页与附录 D 部分小节（D.2–D.9），文本证据与图表证据来自同一 OCR 提取结果，图表是对文本结论的可视化补充而非独立事实源。共有 6 个图片批次、12 张图像被逐一分析，另有 1 张图片因超出批处理上限未做视觉分析，其具体内容“无法从当前 OCR 内容确认”。发表场所与年份、多处公式的 Eq. 编号、VTAB 综合得分聚合方式等字段 OCR 未能确认，均按“文中未说明”处理，不做常识补全。

## 3. 根问题：论文究竟要解决什么

**问题定义**：能否用几乎不做视觉专用修改的标准 Transformer 架构直接处理图像识别，达到有竞争力的性能 `[作者明确陈述][页码：1-2]`。

**为什么重要**：自注意力（self-attention，序列中每个元素都能直接和其他所有元素比较、加权汇总信息，不像 CNN 只看邻近像素）已是 NLP 事实标准，靠“大语料预训练+小任务微调”支撑起未见性能饱和的百亿参数模型 `[作者明确陈述][页码：1]`；若视觉任务能复用这套已验证可扩展、有高效工程实现的架构，意味着视觉模型可以直接享受该生态的可扩展性红利 `[作者明确陈述][页码：3]`。

**难点**：图像是二维、高分辨率数据，逐像素自注意力的计算量随像素数呈二次方增长，不可扩展 `[作者明确陈述][页码：2]`；此前尝试要么把注意力嫁接在 CNN 上，要么用专用局部注意力模式替代卷积，但后者难以在硬件加速器上高效实现 `[作者明确陈述][页码：1-2]`。

**成功标准**：在多个中小型图像识别基准（ImageNet、CIFAR-100、VTAB 等）上，用更少计算资源达到或超过当前 SOTA CNN `[作者明确陈述][页码：1]`。

**本文的 story**：以往路线要么保留 CNN 骨架、要么用专用注意力模式规避二次方开销，但专用模式在硬件上工程复杂、难以真正扩展；本文换一个技术切口——把图像切成较大的 patch（如 16×16）当作“词元”序列，使标准 Transformer 的计算模式可以直接套用，再用大规模预训练数据补偿架构中缺失的归纳偏置 `[作者明确陈述][页码：1-3]`。

## 4. 旧方法为何不够

1. **纯 CNN 架构（LeCun 1989、Krizhevsky 2012、He 2016 等）**：作为待挑战的 SOTA 基线，正文未明确指出其具体技术缺陷（是数据效率还是可扩展性上限）`[作者明确陈述][页码：1]`；对应第 8 节 Table 2 的整体性能/算力对比。
2. **局部自注意力替代卷积（Parmar 2018; Hu 2019; Ramachandran 2019; Zhao 2020）**：原本试图用自注意力获得比卷积更强的表达能力，但依赖“专用注意力模式”，尚未在现代硬件加速器上被有效扩展 `[作者明确陈述][页码：1-2]`；本文用标准全局自注意力回应这一限制 `[基于文中逻辑的推断][页码：3]`；但论文未直接做 ViT 与这些模型的硬件效率对比实验，“无法从当前 OCR 内容确认”。
3. **轴向/分块注意力（Weissenborn 2019; Ho 2019; Wang 2020a）**：同样受限于“需要复杂工程才能在硬件加速器上高效实现”`[作者明确陈述][页码：2]`；附录 D.6 直接对比 AxialResNet 与 Axial-ViT，证实“朴素实现在 TPU 上极慢” `[实验支持][页码：19-20]`。
4. **Cordonnier et al. (2020)**：与 ViT 高度相似的 2×2 patch + 全自注意力方案，但只能用于低分辨率图像，且未证明大规模预训练下可媲美/超越 SOTA CNN `[作者明确陈述][页码：2]`；本文用更大 patch 处理中等分辨率图像并系统做大规模预训练迁移实验回应 `[基于文中逻辑的推断][页码：2-3]`，但两者无直接数值对照实验。
5. **image GPT / iGPT（Chen 2020a）**：像素级无监督生成式预训练，ImageNet 最高仅 72% `[作者明确陈述][页码：2]`；ViT 用有监督 patch 分类预训练回应，Table 2 中 88.55% 构成间接对比（预训练范式与数据规模均不同，非严格对照）`[实验支持][页码：2,6]`。
6. **BiT/Big Transfer（Kolesnikov 2020）**：相同数据规模下预训练算力远高于 ViT（9.9k vs 0.68k TPUv3-core-days）`[实验支持][页码：6]`；4.3 节数据规模对照实验是直接检验 `[实验支持][页码：5-7]`。

## 5. 核心洞见与假设

**核心洞见**：“large scale training trumps inductive bias”——大规模训练可以战胜归纳偏置（inductive bias，架构里预先内置的假设，如 CNN 假设图像具有局部性和平移不变性）带来的优势 `[作者明确陈述][页码：2]`。

**对应假设**：ViT 在小数据集上不如 ResNet，是数据利用效率低而非架构能力上限低；预训练数据规模达到 14M–300M 图像级别后，该劣势会被抹平甚至反超 `[作者明确陈述][页码：2]`。作者通过“固定架构、只变预训练数据规模”的对照实验（对应 Figure 3/4）来验证这一假设 `[作者明确陈述][页码：8-9]`。

**推断**：模型不需要人为注入 2D 空间结构信息，因为足够的数据量能让模型自己学出这类结构（位置编码自发学出行列关系）`[基于文中逻辑的推断][页码：8]`——这是论文对“为何几乎不加归纳偏置也能奏效”的机制性解释，区别于作者未直接给出因果消融的相关性证据。

## 6. 方法：从洞见到可执行系统

**总览**：原图 → 切分为 patch 并线性投影 → 拼接可学习 [class] token 与位置编码 → 送入标准 Transformer 编码器（L 层） → 取 [class] token 输出接分类头 `[作者明确陈述][页码：3-4]`。

1. **Patch 化与线性投影**：动机是 Transformer 原生只接受 1D 序列，图像却是 $\mathbf{x}\in\mathbb{R}^{H\times W\times C}$ 的 2D 结构 `[作者明确陈述][页码：3]`；将图像 reshape 为展平 patch 序列 $\mathbf{x}_p\in\mathbb{R}^{N\times(P^2\cdot C)}$（$N=HW/P^2$），经可训练投影 $\mathbf{E}$ 映射到维度 $D$（Eq.1）`[作者明确陈述][页码：3-4]`；将序列长度从像素数降为 patch 数，规避二次方复杂度 `[基于文中逻辑的推断][页码：2-3]`。patch 大小对精度/计算权衡由 D.2 节消融涉及 `[实验支持][页码：16]`，patch 化是否丢失细粒度信息“文中未说明”。
2. **[class] Token**：借鉴 BERT，提供与位置无关的全局读出位 `[作者明确陈述][页码：3]`；附录 D.3 显示其相对全局平均池化（GAP）的早期劣势“完全由学习率不同解释”，两者性能相近 `[实验支持][页码：16-17]`。
3. **位置编码**：自注意力本身对顺序不敏感，需额外机制保留空间信息 `[基于文中逻辑的推断][页码：3]`；采用标准可学习 1D 编码，Table 8 显示“有无位置编码差距大，但 1D/2D/相对编码间差异很小”`[实验支持][页码：17-18]`。
4. **Transformer 编码器（MSA+MLP，Pre-LN+残差）**：直接复用 Vaswani 2017 设计以利用已验证的可扩展实现（Eq.2、Eq.3）`[作者明确陈述][页码：3-4]`；4.5 节 attention distance 分析证实部分头在最底层即可整合近全图信息 `[实验支持][页码：8]`。
5. **微调与高分辨率适配**：移除预训练分类头，接零初始化前馈层，对位置编码做 2D 插值以适配新 patch 网格 `[作者明确陈述][页码：4]`；这是全模型中唯二人工注入 2D 先验之处 `[基于文中逻辑的推断][页码：4]`。
6. **Hybrid 架构（可选）**：用 CNN 特征图代替原始像素 patch；小算力预算下略优于纯 ViT，但优势随规模增大消失（Figure 5、Table 6）`[实验支持][页码：8,14-15]`。

## 7. 为什么它可能有效

- 全局自注意力可在最底层直接整合全图信息，无需像 CNN 那样逐层堆叠扩大感受野；4.5 节 attention distance 分析显示浅层已有头覆盖近全图 `[实验支持][页码：8]`。
- 归纳偏置缺失在数据少时带来泛化损失，但当数据量足够大，模型可直接从数据中学出等效结构（如位置编码自发学出行列拓扑）`[基于文中逻辑的推断][页码：8]`，从而不再需要预设假设，这也是“数据规模替代归纳偏置”成立所需条件。
- 该逻辑的成立前提是预训练数据规模达到某一门槛（90M+ 图像级别），门槛以下 ViT 反而比 ResNet 更容易过拟合 `[实验支持][页码：7]`。

## 8. 实验与指标：证据是否支撑主张

### 8.1 实验问题与判定标准

- 效果：ViT 在大规模预训练后能否媲美/超越 SOTA CNN？→ 对应 Table 2 与 BiT-L/Noisy Student 比较 `[实验支持][页码：5-6]`。
- 机制：归纳偏置能否被数据规模替代？→ 对应 Figure 3/4 数据规模递增实验（相关性证据，非因果消融）`[实验支持][页码：6-7]`。
- 必要性：[class] token、位置编码具体形式是否必要？→ 对应附录 D.3、D.4 消融 `[实验支持][页码：16-18]`。
- 鲁棒性/适用范围：Hybrid 是否在任意规模都优于纯 ViT？ViT 是否会性能饱和？→ 对应 Figure 5 Scaling Study `[实验支持][页码：8]`。

### 8.2 数据、任务、对比与运行设置

- 数据来源：ImageNet（1.3M）、ImageNet-21k、JFT-300M（Google 内部，非公开）`[作者明确陈述][页码：4]`；VTAB 19 任务、每任务 1,000 训练样本 `[作者明确陈述][页码：5-6]`。
- 模型规模：ViT-Base/Large/Huge，patch size 变体（如 /14、/16、/32）`[作者明确陈述][页码：4-5]`。
- 训练设置：Adam 优化器，batch size 4096，weight decay 0.1 `[作者明确陈述][页码：4-5]`；硬件为 TPUv3；重复次数/统计方式除 Table 2 报告的均值±标准差外，“文中未说明”具体重复次数。
- 基线：BiT(ResNet)、VIVI、S4L、Noisy Student/EfficientNet `[作者明确陈述][页码：5-6]`；各基线具体超参数“文中未说明”。

### 8.3 指标字典与对应公式

- **指标与方向**：Top-1/Top-5 准确率，越高越好。**定义与公式**：论文仅报告数值（如 88.55%），未给出显式定义式；**来源层级**：无可核验公式——不得按常识补全。**实验用途**：Table 2/5/6/9 的主结果与迁移评估比较。**读数与边界**：ViT-H/14 达 ImageNet 88.55±0.04%，ImageNet-ReaL 90.72±0.05%，CIFAR-100 94.55±0.04%，VTAB 77.63±0.23% `[实验支持][页码：5-6]`；不能证明性能来源于架构、数据规模或训练策略中的哪一项。
- **指标与方向**：TPUv3-core-days，测量预训练总算力成本，越低越好。**定义与公式**：作者文字定义“核心数×训练天数”；**来源层级**：推导关系（非原文公式）[基于文中逻辑的推断][页码：5]。**实验用途**：比较 ViT 与 BiT-L（0.68k vs 9.9k）、Noisy Student（2.5k vs 12.3k）`[实验支持][页码：5-6]`。**读数与边界**：作者自述该对比还受训练日程、优化器等因素影响，非严格单变量对照 `[作者明确陈述][页码：6]`。
- **指标与方向**：5-shot linear 准确率，冻结表征做闭式最小二乘回归评估，越高越好。**定义与公式**：作者文字给出优化目标与闭式解，无显式公式记号；**来源层级**：推导关系（非原文公式）[基于文中逻辑的推断][页码：5]。**实验用途**：Figure 3/4/8/9 等快速评估。
- **指标与方向**：Attention distance（注意力距离），衡量信息整合的空间跨度（像素），无固定优劣方向。**定义与公式**：文字描述“按注意力权重加权平均查询像素与其他像素距离”；**来源层级**：推导关系（非原文公式）[基于文中逻辑的推断][页码：8,19]。**实验用途**：回答 ViT 能否在浅层整合全局信息。
- **指标与方向**：VTAB 综合得分、exaFLOPs、掩码 patch 预测损失函数：均为无可核验公式，聚合口径/计算方式“文中未说明”。

### 8.4 主结果、消融与证据边界

**比较工作与被批判限制的呼应**

| 比较工作/基线 | 核心限制或失效条件 | 本文对应模块 | 直接实验/仍未验证边界 |
|---|---|---|---|
| 局部自注意力/轴向注意力 | 专用注意力模式难以在硬件加速器上高效实现 `[作者明确陈述][页码：1-2]` | 标准全局自注意力 `[基于文中逻辑的推断]` | D.6 节 AxialResNet 实测极慢证实 `[实验支持][页码：19-20]`；与其余专用模式的直接对比“无法从当前 OCR 内容确认” |
| BiT/Noisy Student（CNN） | 同等/更优性能下算力成本远高于 ViT `[实验支持][页码：6]` | 整体 ViT 架构 | Table 2 直接数值支持 |
| Cordonnier(2020) | 仅支持低分辨率，未验证大规模预训练可媲美 SOTA `[作者明确陈述][页码：2]` | 更大 patch+系统性大规模预训练 | 无直接对照实验，“无法从当前 OCR 内容确认” |

**主张 → 证据 → 边界**

| 主张 | 直接证据 | 证据强度与边界 |
|---|---|---|
| 大规模预训练下 ViT 媲美/超越 SOTA CNN | Table 2 `[实验支持][页码：5-6]` | 强，但受训练超参差异干扰，非严格单变量对照 |
| 大规模训练可替代归纳偏置 | Figure 3/4 数据规模递增 `[实验支持][页码：6-7]` | 相关性证据而非因果消融，机制解释部分为推断 |
| ViT 达同等性能所需算力显著更低 | Table 2、Figure 5 `[实验支持][页码：6,8]` | 强，Figure 5 为受控扩展性对比 |
| Hybrid 仅小算力下优于纯 ViT | Figure 5/Table 6 `[实验支持][页码：8,14-15]` | 直接支持，原因“somewhat surprising”未展开 |
| 自监督（掩码 patch 预测）有效但逊于监督预训练 | 79.9% vs 落后4个百分点 `[实验支持][页码：8-9]` | 仅 ViT-B/16 一种配置，作者自称“preliminary” |

- VTAB Specialized 任务组上 ViT-H/14 与 BiT-L 表现相近，非全面胜出 `[作者明确陈述][页码：6]`。
- 检测、分割等其他视觉任务未在本文实验，仅援引他人工作作为“promise” `[作者明确陈述][页码：9]`。

## 9. 图表解读与论证关系

### 图片原件与标题

#### 原始图片 1：Figure 1: Model overview. We split an image into fixed-size patches, linearly embed each of them, add position embeddings, and feed the resulting sequence of vectors to a standard Transformer encoder. In order to perform classification, we use the standard approach of adding an extra learnable "classification token" to the sequence. The illustration of the Transformer encoder was inspired by Vaswani et al. (2017).

![Figure 1: Model overview. We split an image into fixed-size patches, linearly embed each of them, add position embeddings, and feed the resulting sequence of vectors to a standard Transformer encoder. In order to perform classification, we use the standard approach of adding an extra learnable "classification token" to the sequence. The illustration of the Transformer encoder was inspired by Vaswani et al. (2017).](assets/imgs/img_in_image_box_291_161_938_494.jpg)

*来源：OCR 第 3 页。*

---

#### 原始图片 2：Figure 2: Breakdown of VTAB performance in Natural, Specialized, and Structured task groups.

![Figure 2: Breakdown of VTAB performance in Natural, Specialized, and Structured task groups.](assets/imgs/img_in_chart_box_224_572_987_742.jpg)

*来源：OCR 第 6 页。*

---

#### 原始图片 3：Figure 3: Transfer to ImageNet. While large ViT models perform worse than BiT ResNets (shaded area) when pre-trained on small datasets, they shine when pre-trained on larger datasets. Similarly, larger ViT variants overtake smaller ones as the dataset grows.

![Figure 3: Transfer to ImageNet. While large ViT models perform worse than BiT ResNets (shaded area) when pre-trained on small datasets, they shine when pre-trained on larger datasets. Similarly, larger ViT variants overtake smaller ones as the dataset grows.](figure-groups/page-0007-09e1c7b95ac4.png)

*来源：OCR 第 7 页。*

---

#### 原始图片 4：Figure 5: Performance versus pre-training compute for different architectures: Vision Transformers, ResNets, and hybrids. Vision Transformers generally outperform ResNets with the same computational budget. Hybrids improve upon pure Transformers for smaller model sizes, but the gap vanishes for larger models.

![Figure 5: Performance versus pre-training compute for different architectures: Vision Transformers, ResNets, and hybrids. Vision Transformers generally outperform ResNets with the same computational budget. Hybrids improve upon pure Transformers for smaller model sizes, but the gap vanishes for larger models.](assets/imgs/img_in_chart_box_249_618_971_924.jpg)

*来源：OCR 第 7 页。*

---

#### 原始图片 5：Figure 6: Representative examples of attention from the output token to the input space. See Appendix D.7 for details.

![Figure 6: Representative examples of attention from the output token to the input space. See Appendix D.7 for details.](assets/imgs/img_in_image_box_803_685_992_1024.jpg)

*来源：OCR 第 8 页。*

---

#### 原始图片 6：Figure 7: Left: Filters of the initial linear embedding of RGB values of ViT-L/32. Center: Similarity of position embeddings of ViT-L/32. Tiles show the cosine similarity between the position embedding of the patch with the indicated row and column and the position embeddings of all other patches. Right: Size of attended area by head and network depth. Each dot shows the mean attention distance across images for one of 16 heads at one layer. See Appendix D.7 for details.

![Figure 7: Left: Filters of the initial linear embedding of RGB values of ViT-L/32. Center: Similarity of position embeddings of ViT-L/32. Tiles show the cosine similarity between the position embedding of the patch with the indicated row and column and the position embeddings of all other patches. Right: Size of attended area by head and network depth. Each dot shows the mean attention distance across images for one of 16 heads at one layer. See Appendix D.7 for details.](assets/imgs/img_in_image_box_216_185_999_415.jpg)

*来源：OCR 第 9 页。*

---

#### 原始图片 7：Figure 8: Scaling different model dimensions of the Vision Transformer.

![Figure 8: Scaling different model dimensions of the Vision Transformer.](figure-groups/page-0016-061bce0f8aca.png)

*来源：OCR 第 16 页。*

---

#### 原始图片 8：Figure 9: Comparison of class-token and global average pooling classifiers. Both work similarly well, but require different learning-rates.

![Figure 9: Comparison of class-token and global average pooling classifiers. Both work similarly well, but require different learning-rates.](assets/imgs/img_in_chart_box_337_168_883_456.jpg)

*来源：OCR 第 17 页。*

---

#### 原始图片 9：Figure 11: Size of attended area by head and network depth. Attention distance was computed for 128 example images by averaging the distance between the query pixel and all other pixels, weighted by the attention weight. Each dot shows the mean attention distance across images for one of 16 heads at one layer. Image width is 224 pixels.

![Figure 11: Size of attended area by head and network depth. Attention distance was computed for 128 example images by averaging the distance between the query pixel and all other pixels, weighted by the attention weight. Each dot shows the mean attention distance across images for one of 16 heads at one layer. Image width is 224 pixels.](assets/imgs/img_in_chart_box_279_857_937_1213.jpg)

*来源：OCR 第 18 页。*

---

#### 原始图片 10：Figure 10: Position embeddings of models trained with different hyperparameters.

![Figure 10: Position embeddings of models trained with different hyperparameters.](assets/imgs/img_in_chart_box_217_163_1007_423.jpg)

*来源：OCR 第 18 页。*

---

#### 原始图片 11：Figure 12: Left: Real wall-clock timings of various architectures across input sizes. ViT models have speed comparable to similar ResNets. Right: Largest per-core batch-size fitting on device with various architectures across input sizes. ViT models are clearly more memory-efficient.

![Figure 12: Left: Real wall-clock timings of various architectures across input sizes. ViT models have speed comparable to similar ResNets. Right: Largest per-core batch-size fitting on device with various architectures across input sizes. ViT models are clearly more memory-efficient.](assets/imgs/img_in_chart_box_248_443_972_751.jpg)

*来源：OCR 第 19 页。*

---

#### 原始图片 12：Figure 13: Performance of Axial-Attention based models, in terms of top-1 accuracy on ImageNet 5-shot linear, versus their speed in terms of number of FLOPs (left) and inference time (left).

![Figure 13: Performance of Axial-Attention based models, in terms of top-1 accuracy on ImageNet 5-shot linear, versus their speed in terms of number of FLOPs (left) and inference time (left).](figure-groups/page-0020-565593998539.png)

*来源：OCR 第 20 页。*

### 图/表：Figure 1（架构总览图）

- **图组结论**：图像被切为方块经线性投影为编号 token，序列前拼接可学习 [class] token（标 0*），送入由 Norm→MSA→残差→Norm→MLP→残差堆叠 L 层的编码器 `[图像直接可见][页码：3]`。
- **论证关系**：该图确认架构实现与 Eq.1–Eq.4 描述一致，支撑方法模块 1–4 的整体拼装关系，但不能证明性能或“最底层整合全局信息”的机制主张 `[正文支持]`。
- **适用范围**：未展示 Hybrid 架构或分辨率适配细节。

### 图/表：Figure 2（VTAB 任务组对比）

- **图组结论**：ViT-H/14 在 VTAB 总览、Natural、Structured 三组均领先；Specialized 组与 BiT-L 十分接近 `[图像直接可见][页码：6]`。
- **论证关系**：为效果主张提供细粒度支持，同时验证“Specialized 组优势不明显”这一适用边界 `[正文支持]`。
- **适用范围**：仅覆盖 VTAB-1k 协议，不代表 ImageNet 全量微调等其他基准表现。

### 图/表：Figure 3 与 Figure 4（预训练数据规模效应）

- **图组结论**：仅在 JFT-300M 上，大模型才显示完整优势；ImageNet 上 ViT-Large 反弱于 BiT；JFT 子集实验显示 ViT 在 9M 上过拟合明显，90M+ 反超 ResNet `[图像直接可见][页码：6-7]`。
- **论证关系**：为“数据规模是核心变量”的假设提供适用边界证据（Figure 3）与机制侧证据（Figure 4，剥离正则化后的过拟合行为）`[正文支持]`。
- **适用范围**：论文后续“ViT 优于/媲美 CNN”结论应限定在大规模预训练前提下。

### 图/表：Figure 5（Scaling Study）

- **图组结论**：同等算力下 ViT 点普遍高于 ResNet；Hybrid 仅小算力区间略优于 ViT，大算力时重合；ViT 曲线在测试范围内未见趋平 `[图像直接可见][页码：8]`。
- **论证关系**：直接支撑“2-4×更少算力达到同等性能”的效果主张，及“未出现性能饱和”的适用边界表述 `[正文支持]`。
- **适用范围**：图中各点未标注具体模型规格，无法逐点对应 Table 6。

### 图/表：Figure 6（Attention Rollout 示例）

- **图组结论**：三个样例中注意力较亮区域与主体对象轮廓大致重合，背景被压暗 `[图像直接可见][页码：8]`。
- **论证关系**：为“自注意力聚焦语义相关区域”提供定性机制例证，但样本量仅 3 例，不能作统计性证据，也不能单独证明“数据规模替代归纳偏置”这一宏观论点 `[正文支持]`。
- **适用范围**：图注“representative”与附录 Figure 14 图注“random selection”表述不一致，具体挑选标准“文中未说明”。

### 图/表：Figure 7（Patch滤波器/位置编码相似度/注意力距离三联图）

- **图组结论**：patch 投影滤波器呈现有规律纹理（非随机）；位置编码相似度呈现清晰行列结构；注意力距离随深度增大而收敛，浅层部分头已覆盖较大距离 `[图像直接可见][页码：8]`。
- **论证关系**：分别为模块1（patch embedding）、模块3（位置编码）、模块4（MSA全局整合）提供机制解释，其中位置编码结果解释了 Table 8 中“不同编码方式差异很小”的原因 `[正文支持]`。
- **适用范围**：Left/Center 面板对应 ViT-L/32，Right 面板对应 ViT-L/16，同图不同子面板模型配置不同，不可混同解读。

### 图/表：Figure 11（ViT vs Hybrid 注意力距离对比）

- **图组结论**：纯 ViT-L/16 低层存在明显局部化头（距离低至 0-20 像素），Hybrid 架构低层缺少此类极低距离点 `[图像直接可见][页码：19]`。
- **论证关系**：支持“ResNet 前置卷积已承担早期局部特征提取，故 Transformer 部分不必再学出高度局部化头”的解释性论点 `[正文支持]`。
- **适用范围**：不能证明局部化头对最终精度的贡献大小。

### 图/表：Figure 10（位置编码相似度对超参数的敏感性）

- **图组结论**：不同学习率/weight decay 组合下，位置编码相似度的行列结构清晰度不同 `[图像直接可见][页码：18]`。
- **论证关系**：为“1D 编码自发学出2D拓扑”提供跨超参数稳健性佐证 `[正文支持]`。
- **适用范围**：三图同时改变多个超参数，无法单独归因某一变量。

### 图/表：Figure 12（真实硬件推理速度与内存效率，附录D.5）

- **图组结论**：ViT 推理速度与同量级 ResNet 相当，且单核可容纳的最大 batch-size 明显更优 `[图像直接可见][页码：19]`。
- **论证关系**：为“预训练计算成本更低”提供真实硬件层面的效果支撑 `[正文支持]`。
- **适用范围**：部分曲线触顶是否为人为 batch-size 搜索上限，“无法从当前 OCR 内容确认”。

### 图/表：Figure 13（Axial Attention 消融，附录D.6）

- **图组结论**：AxialViT 变体准确率优于对应 ViT-B，但算力更高；AxialResNet50 推理速度远低于其余模型 `[图像直接可见][页码：19-20]`。
- **论证关系**：印证论文选用标准全局自注意力而非专用注意力模式的设计取舍 `[正文支持]`。
- **适用范围**：不能证明速度劣化的具体底层实现原因。

## 10. 完整因果推理树

- 根问题：能否用几乎不做视觉专用修改的标准 Transformer 直接处理图像识别并达到有竞争力性能 `[页码：1-2]`
  - 旧方法限制：局部/专用注意力模式硬件扩展性差；逐像素注意力二次方开销不可扩展；Cordonnier(2020)仅限低分辨率 `[页码：1-2]`
  - 核心洞见/假设：大规模训练可以战胜归纳偏置缺失 `[页码：2]`
    - 方法模块：Patch化+线性投影、[class] token、1D位置编码、标准Transformer编码器 `[页码：3-4]`
      - 可验证预测：足够大数据下 ViT 可媲美/超越 SOTA CNN，且算力更低
        - 指标与实验：Top-1准确率（Table 2）、TPUv3-core-days（Table 2）、5-shot准确率（Figure 3/4）
          - 图表证据：Figure 3/4（数据规模效应）、Figure 5（Scaling Study）
            - 结论与适用边界：结论仅在 JFT-300M 级别预训练数据下成立；中小数据集下 ViT 弱于 ResNet，属未验证条件之外的场景 `[实验支持][页码：6-7]`

## 11. 结论、贡献与边界

**贡献**：提出几乎不做视觉专用修改的 ViT 架构 `[作者明确陈述][页码：1,3]`；验证归纳偏置可被数据规模替代并给出对照实验证据 `[实验支持][页码：2,8-9]`；在同等或更优性能下显著降低预训练算力 `[实验支持][页码：5-6]`。

**证据充分的结论**：大规模预训练下 ViT 在 ImageNet、CIFAR-100、VTAB 等多个基准上媲美/超越 SOTA CNN，且算力消耗更低（Table 2、Figure 5）`[实验支持]`。

**尚属推断的意义**：归纳偏置被数据规模“替代”的具体因果机制（而非仅相关性）未经专门消融验证 `[基于文中逻辑的推断][页码：6-7]`。

**适用条件与局限**：结论依赖 14M-300M 级预训练数据，JFT-300M 为 Google 内部非公开数据集，可复现性受限 `[作者明确陈述][页码：4]`；论文仅验证图像分类任务，未覆盖检测、分割 `[作者明确陈述][页码：9]`。

**审稿式风险检查**：
- 贡献新意：与 Cordonnier(2020) 高度相似，本文差异在于大 patch 与系统性大规模实验，二者无直接数值对照，“无法从当前 OCR 内容确认”新意边界。
- 写作/可复现性：核心旗舰结果依赖不可公开获取的 JFT-300M，复现风险真实存在 `[作者明确陈述][页码：4]`。
- 效果大小：主结果绝对提升幅度在 Table 2 中可核验，但预训练效率对比受训练超参干扰，作者自己提及此局限 `[作者明确陈述][页码：6]`。
- 实验覆盖：自监督实验仅一种模型配置，消融覆盖 patch size/位置编码/head类型，未见对“归纳偏置强度”的直接控制实验，当前证据未显示该项已被覆盖。
- 方法设计：Hybrid 优势随规模消失现象作者自称“意外”但未给出机制解释，当前证据未显示该现象是设计缺陷。

## 12. 术语与第一性原理学习路径

### 12.1 核心术语

- **术语**：Self-Attention（自注意力）。**第一性原理角色**：连接序列中任意两个元素的信息交互，不依赖空间邻近性这一约束。**本文位置**：Transformer编码器核心计算单元，支撑Eq.5定义的注意力权重 `[页码：3-4,12]`。
- **术语**：Inductive Bias（归纳偏置）。**第一性原理角色**：架构预设的假设（如局部性、平移等变性），在数据量小时降低学习所需的信息量，是模型能力与数据需求间的权衡变量。**本文位置**：贯穿核心洞见与全篇论证 `[页码：1-2]`。
- **术语**：Patch（图像块）。**第一性原理角色**：将2D图像离散为可序列化的最小处理单元，是把二次方复杂度问题转化为线性可扩展问题的关键操作对象。**本文位置**：Eq.1输入构造 `[页码：3-4]`。
- **术语**：[class] Token。**第一性原理角色**：与位置无关的固定读出状态，连接“逐token表征”与“单一图像级别输出”这两个层级的量。**本文位置**：分类头输入来源，Eq.4 `[页码：3-4]`。
- **术语**：Position Embedding（位置编码）。**第一性原理角色**：补偿自注意力对输入顺序不敏感这一数学约束，连接patch的序列索引与其空间位置。**本文位置**：与patch embedding相加输入编码器 `[页码：3-4]`。
- **术语**：Attention Distance（注意力距离）。**第一性原理角色**：衡量信息整合覆盖的空间范围，连接注意力权重这一中间量与“局部/全局”这一可观测行为。**本文位置**：4.5节机制分析 `[页码：8,19]`。
- **术语**：TPUv3-core-days。**第一性原理角色**：核心数×训练天数，是衡量算力资源消耗这一约束量的单位。**本文位置**：Table 2 效率对比 `[页码：5-6]`。

### 12.2 学习路径

1. 先理解“序列建模”这一基本对象：模型输入被表示为一串向量而非二维网格，这是把图像“变成句子”的前提。
2. 再理解自注意力的计算约束：任意两元素间都要计算相关性，代价随序列长度呈二次方增长，这决定了图像必须先降采样为patch而非逐像素处理。
3. 然后理解归纳偏置这一机制：CNN预设的局部性/平移不变性像“提前划好重点”，数据少时省力，数据多时可能限制模型自由学习的空间。
4. 接着理解预训练-微调范式：先在海量通用数据上学一般表征，再在目标任务小数据上微调，类似先读通识课程再做专项训练。
5. 最后理解“计算量-性能”权衡这一系统行为指标：同样精度下谁耗费的算力更少，是评价架构是否“更划算”的关键观测量。