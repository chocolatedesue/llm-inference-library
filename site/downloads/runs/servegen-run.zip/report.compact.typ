#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[ServeGen: Workload Characterization and Generation of Large Language Model Serving in Production]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yuxing Xiang, Xue Li, Kun Qian, Yan Zhang, Wenyuan Yu, Ennan Zhai, Xin Jin, Jingren Zhou]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[23rd USENIX Symposium on Networked Systems Design and Implementation (NSDI '26) · 2026]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM推理服务] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[工作负载表征] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[工作负载生成] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[生产环境追踪] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[多模态与推理模型]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[代码：https://github.com/alibaba/ServeGen]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

随着大语言模型（LLM）的广泛采用，为LLM推理请求提供服务已成为一项日益重要的任务，吸引了大量研究进展。实际工作负载在这一过程中发挥着关键作用：它们对于激励和评测服务技术与系统至关重要。然而，由于缺乏全面的工作负载表征，业界对真实世界LLM服务工作负载的理解仍然有限。已有分析在规模和范围上均显不足，未能充分捕捉复杂的工作负载特征。本文通过对来自我们全球云LLM服务的工作负载进行深入表征来填补这一空白，不仅涵盖语言模型，还涵盖新兴的多模态和推理模型，在每种情形下都揭示了重要的新发现。此外，基于这些发现，我们提出了ServeGen------一个通过按客户端组合来生成真实LLM服务工作负载的原则性框架。实际应用案例验证了，相较于朴素的工作负载生成方法，ServeGen能够实现更准确的性能评测，并揭示出若干原本可能被忽视的新设计启示。ServeGen已开源，地址为 #link("https://github.com/alibaba/ServeGen。")

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [ServeGen: Workload Characterization and Generation of Large Language Model Serving in Production],
    [作者], [Yuxing Xiang, Xue Li, Kun Qian, Yan Zhang, Wenyuan Yu, Ennan Zhai, Xin Jin, Jingren Zhou],
    [发表场所 / 年份], [23rd USENIX Symposium on Networked Systems Design and Implementation (NSDI \'26), 2026],
    [研究领域], [计算机系统（LLM 推理服务）],
    [关键词], [LLM推理服务, 工作负载表征, 工作负载生成, 生产环境追踪, 多模态与推理模型],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：#link("https://github.com/alibaba/ServeGen")

#quote(block: true)[
#strong[标签（3--5 个）]：`LLM推理服务` · `工作负载刻画` · `负载生成` · `客户端因果建模` · `PD分离评测`
]

本文基于阿里云 Model Studio 生产环境四个月、超35亿条请求的真实调用日志，对语言、多模态、推理三类大模型服务负载做了迄今规模最大的实证刻画，并提出以\"客户端\"为基本建模单位的负载生成框架 ServeGen，其在实例配置与 PD 分离评测中比朴素生成方法（NAIVE）更贴近真实系统表现 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

OCR 文本覆盖论文第2--13页的正文论述，含 Findings 1--11 的文字表述及方法、实验、局限章节；图表证据分析覆盖第5--9页共约12组图片（部分图注文字或坐标刻度因像素/裁剪限制无法逐一核实精确数值），另有8张图片因超出处理上限未做视觉分析 #strong[\[文中未说明，OCR 提示信息\]]。KS 检验 p 值、CV 计算公式等标准统计量的计算式，论文本身未显式列出，只标注了判定基准或方法名 #strong[\[文中未说明\]]。以下论文事实均标注证据类型，区别于本文补充的背景知识（如 prefill/decoding、Zipf 分布等通识性解释）。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

- #strong[问题定义]：LLM 推理服务系统的设计、优化与评测都依赖\"负载（workload，即请求的到达节奏与输入输出长度分布等统计特征）\"，但业界对真实生产负载的理解严重不足，缺乏全面的规模化刻画 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[为什么重要]：负载理解不足会同时损害\"研究动机来源\"与\"评测可信度\"------新兴的多模态、推理模型场景的许多特性从未被刻画过，研究者可能错失创新方向；而对于研究较多的普通语言模型场景，使用不真实的负载评测系统（论文称为 NAIVE：泊松/伽马过程采样到达 + ShareGPT 等公开数据集），会导致\"看起来很好用\"的系统上线后表现骤降，论文引用了已有文献报道的这类真实劣化案例 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[难点来源]：真实生产负载规模巨大、跨客户端异质、随时间漂移，采集与规模化分析本身需要长期、大范围的生产环境访问权限，这是既有研究（多为局部、短期分析）难以做到的 #strong[\[基于文中逻辑的推断，依据 Table 2 对比结构\]]。
- #strong[本文的 story]：旧路线在\"规模不足\"与\"把负载当整体随机过程建模\"两个技术原因上失效，本文的转折点是发现真实负载的复杂性可归约为\"少数头部客户端的行为波动\"，并据此把生成负载的最小单元从\"全局分布\"下沉到\"客户端\"。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：多模态输入分布与不规则漂移]
  #image("figure-groups/page-0008-9dac689f7a93.png", width: 100%)
  #emph[Figure 7. Characterization of multimodal inputs in mm-image, mm-audio, and mm-video (Rows). Columns: (a) \#multimodal inputs per request; (b) length distribution of inputs; (c) correlation between text and multimodal tokens; (d) overall arrival rate of multimodal and text tokens.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：多模态输入长度呈多峰非幂律形态，且不同时段分布存在可见偏移。

- #strong[论证关系]：支撑 Finding 6，说明模态负载无法用文本长度替代，需独立参数化。

- #strong[适用范围]：覆盖三种多模态负载，个别子图时间段标签较模糊。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：全模态负载变异性]
  #image("figure-groups/page-0008-89c74b0d74e0.png", width: 100%)
  #emph[Figure 8. Characterization of omni-modal inputs in mm-omni. Left: number of multimodal inputs per request. Right: arrival rate of multimodal and text tokens, normalized by the total input rate.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：全模态请求单请求携带多模态输入数多，模态间到达速率呈现差异化时序漂移。

- #strong[论证关系]：支撑 Finding 6，说明当请求混合多种模态时负载变异性进一步复杂化。

- #strong[适用范围]：仅覆盖 mm-omni 工作负载，部分曲线图例缺失模糊。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

这些旧方法的共同技术局限可归纳为：要么在\"规模\"（时长、请求数、模型数）上不足，要么在\"范围\"（多模态/推理/客户端异质性/时序漂移）上不足 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。

#critique-card(
  [NAIVE（\[33,49,50,55\]）],
  [在无真实负载或隐私限制下简便生成评测负载。假设到达可用泊松/伽马过程近似、数据可用公开对话数据集替代。],
  [生成负载变异性不足、无法体现速率与数据分布的相关性，产生\"虚假易服务\"假象。],
  [Client Generator + Timestamp/Request Data Sampler],
  [§6.2 生成精度对比、§6.3 实例配置案例],
)

#critique-card(
  [BurstGPT \[46\]],
  [用参数化 Gamma 过程刻画到达突发性。仅 2 个模型、529 万请求、仅语言模态。],
  [规模远小于本文，且不覆盖多模态/推理/客户端分解。],
  [本文整体三类负载刻画+客户端分解方法学],
  [无法从当前 OCR 内容确认具体对比实验，仅 Table 2 范围对比],
)

#critique-card(
  [LMM \[38\]],
  [刻画图文模型的图像数据分布。仅 2 天数据，单一模态维度。],
  [缺失到达模式、漂移、对话等维度。],
  [本文多模态刻画（§4）],
  [无法从当前 OCR 内容确认，仅范围对比],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见/贡献]：真实负载中看似复杂的非确定性模式（到达突发性波动、长度分布随时间漂移）并非\"整体随机过程\"的产物，而是由少数\"头部客户端\"的行为波动驱动；绝大多数客户端行为本身稳定、可预测 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

- #strong[为落地该洞见所需的实现组件]：Client Generator、Timestamp Sampler、Request Data Sampler 等（属于实现组成，不单独作为贡献声明）。
- #strong[可行性依据]：
  + M-small 中 2,412 个客户端，前29个（按速率降序）贡献90%请求 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；
  + 头部客户端在突发性、输入/输出长度上表现稳定（误差条窄），仅速率本身波动 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；
  + 该因果建模在多模态（mm-image，1,036客户端）与推理（deepseek-r1，25,913客户端）场景中被重复验证 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。
- #strong[前提可能不成立的场景]：该假设建立在阿里云 Model Studio 存在\"大量 API 批量调用型头部客户端\"这一客户结构上；若目标环境高度去中心化、无头部客户端，该因果建模的适用性尚待验证 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

ServeGen 的总体流程是：先由 Client Generator 依据真实速率/CV 分布采样出一组异质客户端，再由 Timestamp Sampler 为每个客户端生成时变到达时间戳，最后由 Request Data Sampler（含 conversation-aware mocking）为每个请求填充长度等数据特征，三者叠加输出可直接用于评测系统的完整负载 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

+ #strong[Client Generator（客户端生成器）]------动机：Finding 5/8/11 显示客户端速率高度倾斜，若不能生成同样倾斜的客户端集合就无法复现真实突发性 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；过程：从预置 Client Pool 中按真实速率/CV分布采样，或使用用户自定义客户端；输出：带各自 trace/dataset 描述的客户端集合；技术优势：保留客户端异质性而非把整体当单一随机过程 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；其有效性未单独设消融，仅通过§6.2整体生成精度间接验证 #strong[\[文中未说明单独验证\]]。
+ #strong[Timestamp Sampler（到达时间采样器）]------动机：Finding 1/2 要求到达模型能表达\"时变\"特性 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；过程：依据每客户端 trace 参数与总速率的时间函数\"缩放客户端速率\"，具体缩放算法文中未给出 #strong[\[文中未说明\]]；输出：各客户端及汇总到达时间戳序列；技术优势：可生成随时间变化的速率与突发性 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
+ #strong[Request Data Sampler（含 conversation-aware mocking）]------动机：Finding 3/4/6/9 表明长度分布因客户端与时间而异，Finding 10 表明多轮对话会重塑到达节奏 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；过程：为客户端生成长度数据，并通过保留共享对话历史维持多轮结构，具体隐私保护实现文中未说明；技术优势：对照图16，Naive上采样会产生过度突发，而遵循真实ITT分布的方法更接近真实稳定性 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制→收益]：以客户端为单位联合建模速率与数据分布，能保留\"速率突变常伴随数据分布变化\"这一真实关联，NAIVE 因缺乏该关联而系统性低估真实负载压力 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。
- #strong[所需条件]：该机制生效的前提是 Client Pool 中的客户端参数（速率、CV、长度分布）能代表目标部署场景的真实客户端结构；若目标场景客户端结构与阿里云平台显著不同，效果需重新验证 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。
- #strong[时变建模的收益]：允许 Timestamp/Request Data Sampler 按时间参数化，理论上能复现 Finding 2/4 中观测到的漂移现象，但缩放算法细节未公开，实际保真度依赖未披露的实现 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[效果]：真实到达是否具突发性、ServeGen 生成负载是否更贴近真实分布------对应图1(d)拟合优度、§6.2生成精度对比。
- #strong[机制]：头部客户端速率波动是否是整体漂移的驱动因------对应§3.3客户端分解（图5、图6）。
- #strong[必要性]：ITT保真、按客户端建模是否为负载真实感所必需------对应图16对比实验。
- #strong[鲁棒性/适用范围]：ServeGen 优势能否推广到不同模型/负载规模------论文仅在单一模型/单一片段验证，未做跨规模鲁棒性实验 #strong[\[文中未说明\]]。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 数据来源：阿里云 Model Studio 全球云 LLM 服务日志，四个月、超35亿条请求 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- 任务/模型版本：覆盖12个语言/多模态/推理模型工作负载（如M-large、M-small、mm-image、deepseek-r1等），各自采样窗口从一天到一个月不等（Table 1）。
- 硬件/软件、重复次数、统计方式：文中未说明。
- 基线：NAIVE（Poisson/Gamma+ShareGPT）；对比系统案例中的基线为 vLLM 默认配置策略与不同 PD 配置。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：CV（变异系数）；测量到达间隔时间(IAT)离散程度，无量纲；CV=1对应泊松过程，越大越突发。#strong[定义与公式]：来源层级为无可核验公式------文中仅给出判定基准\"CV=1对应泊松\"，未列出标准差/均值的具体计算式。#strong[实验用途]：判定 Finding 1/2/10/11 中的突发性。#strong[读数与边界]：M-large/M-small/M-mid在图2中CV分别约1.29/1.12/1.07，均大于1，但精确统计方式不可验证 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。
- #strong[指标与方向]：过/欠配比例；测量实例配置数相对实际所需数的偏差，越接近0越好。#strong[定义与公式]：来源层级为推导关系（非原文公式）------作者给出\"ServeGen多配4%、NAIVE少配50%\"的文字描述，推理依据：由此可凝练出 (配置数−实际所需数)/实际所需数×100% #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。#strong[实验用途]：评估图20热力图中两种方法的配置准确性。#strong[读数与边界]：仅在M-large配Qwen2.5-14B的单一10分钟窗口验证，能否推广到其他模型文中未说明 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。
- #strong[指标与方向]：长度漂移倍数（如1.63×）；测量一天内平均长度的最大/最小值之比，无固定方向。#strong[定义与公式]：来源层级为推导关系（非原文公式）------作者文字定义\"最大平均长度除以最小平均长度\"，推理依据：可凝练为 $upright("Shift") = frac(max\(macron(L)_t\), min\(macron(L)_t\))$ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。#strong[实验用途]：量化 Finding 4 的时变漂移幅度。#strong[读数与边界]：具体数值仅描述性给出，未提供置信区间。
- #strong[指标与方向]：P99 TTFT/TBT；测量首字延迟/逐字延迟的第99百分位，单位毫秒，越低越好。#strong[定义与公式]：无可核验公式，作者仅描述用途未给出百分位计算式。#strong[实验用途]：判定§6.3 SLO是否达标。#strong[读数与边界]：具体数值文中未在OCR文本给出，需图表核实。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制/失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [NAIVE], [变异性不足、无速率-数据分布关联、导致欠配假象], [Client Generator+Sampler], [§6.2/§6.3已验证；能否推广到多模态/推理场景负载生成文中未说明],
    [BurstGPT/LMM], [规模/范围不足], [三类负载整体刻画框架], [无直接定量对比实验，仅Table 2范围对比],
    [PD-disaggregation相关工作], [真实部署性能\"难以充分刻画\"], [用ServeGen作更真实评测输入], [§6.4验证；因果解释用\"likely\"表述，非确定性结论],
  )]
  , kind: table
  )

#strong[主张与证据强度]

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据], [证据强度与边界],),
    table.hline(),
    [到达具超越单一随机过程的突发性], [图1(d) KS检验], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；无逐一p值数值表],
    [头部客户端速率波动驱动整体漂移], [§3.3客户端分解、图2/图6对应], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]；时序精确重合度需视觉核实],
    [ServeGen比NAIVE更贴近真实统计特征], [§6.2文字描述、图19], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；无量化误差指标(如MAE)],
    [NAIVE导致资源欠配假象], [§6.3，\"少配50%\"], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；单一场景，非统计意义普适结论],
  )]
  , kind: table
  )

- 论文未给出与 BurstGPT/LMM 的同数据集定量对比实验，属证据缺口而非补造 #strong[\[文中未说明\]]。
- §6.3、§6.4 案例均基于单一模型/单一负载片段，能否推广到多模态或推理场景文中未说明 #strong[\[文中未说明\]]。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 2 节：覆盖工作负载与模型版本]
  - #strong[图组结论]：汇总了语言、多模态、推理三大类 12 个生产级工作负载与采样窗口特征。

- #strong[论证关系]：确立本文实证刻画的覆盖范围，为各 Finding 提供数据支持背景。

- #strong[适用范围]：基于阿里云 Model Studio 日志，未包含插件与前缀缓存场景。
  #v(5pt)
  #image("table-groups/page-0003-c1e697cdd15b.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2. Comparison between our work and prior characterizations of LLM serving workloads. Dashes indicate unavailabl...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：既有刻画工作与本文对比]
  - #strong[图组结论]：本文在时长、请求规模、模型数及模态覆盖上显著超越 BurstGPT 和 LMM 等既有工作。

- #strong[论证关系]：突出旧路线在规模与范围上的局限，论证建立生产级全面刻画的必要性。

- #strong[适用范围]：特征维度对比，无同数据集定量实验。
  #v(5pt)
  #image("table-groups/page-0004-b47b79859391.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0005-a0bc69659dbe.png", width: 100%)
    #emph[Figure 1. Inter-arrival time characterization.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：到达间隔时间突发性与拟合优度]
    - #strong[图组结论]：三个工作负载 CV 均大于 1，且无统一参数化分布在所有负载上普遍最优。

- #strong[论证关系]：支撑 Finding 1，为到达时间采样器允许每客户端灵活选择分布提供直接依据。

- #strong[适用范围]：覆盖 M-large/small/mid 单一 20 分钟窗口，不证明分布异质的因果机制。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_131_468_555_714.jpg", width: 100%)
    #emph[Figure 2. Long-term rate and CV shifts.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：到达速率与突发性随时间漂移]
    - #strong[图组结论]：M-large 持续突发两日后转稳定，M-rp 全程平稳，M-code 仅日内特定时刻剧烈尖峰。

- #strong[论证关系]：支撑 Finding 2 速率与突发性随时间多样化漂移，为动态调度设计提供依据。

- #strong[适用范围]：仅覆盖四个语言模型负载，不含 M-mid，不解释漂移成因。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0006-b943b2b54dff.png", width: 100%)
    #emph[Figure 3. Input and output length distribution. x-axis: \# tokens; y-axis: frequency. Each subfigure corresponds to a specific workload and time period, split to two consecutive x-scales to show both the shift in average lengths (left) as well as the tail distribution (right).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：输入输出长度分布与漂移]
    - #strong[图组结论]：各模型长度直方图形态差异显著，不同时段存在明显位移，输入输出长度相关性弱。

- #strong[论证关系]：支撑 Finding 3 和 Finding 4，说明请求数据采样器需按时间参数化数据分布。

- #strong[适用范围]：无法读出精确漂移倍数，不证明漂移由客户端行为驱动。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0007-b80ca85e156c.png", width: 100%)
    #emph[Figure 5. Client heterogeneity in terms of rate, etc. All CDFs are weighted by client rates.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 5 节：客户端异质性与头部集中]
    - #strong[图组结论]：客户端速率呈高度倾斜分布，CV 与平均长度在客户端间呈现显著异质性。

- #strong[论证关系]：直接支撑 Finding 5 客户端异质性主张，证实整体漂移源于头部客户端速率波动。

- #strong[适用范围]：覆盖 M-small 工作负载，无法证明该机制自动延伸至多模态或推理场景。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0007-212d5ecc0a8c.png", width: 100%)
    #emph[Figure 6. Characterization of the top four clients in the M-small workload in isolation, using the first 48-hour data from Figure 2. Vertical lines in the last-row subfigures indicate average input/output lengths, and error bars show the range of average lengths in 1-hour windows.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：客户端速率倾斜与稳定性]
    - #strong[图组结论]：前 29 个客户端贡献约 90% 请求，头部客户端 A/D 长度分布误差条窄、表现稳定。

- #strong[论证关系]：支撑核心洞见 Finding 5，为客户端生成器按真实速率/CV 异质采样提供实验依据。

- #strong[适用范围]：基于 M-small 前 48 小时数据，Client B/C 长度稳定性未在图中标出。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0008-134408fd9c7d.png", width: 100%)
    #emph[Figure 9. Ratio of multimodal input tokens per request in mm-image, mm-audio, and mm-video. Numbers indicate the average ratio.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：多模态请求异质性]
    - #strong[图组结论]：mm-image/audio/video 三种模态输入占比呈全区间连续分布而非单峰集中。

- #strong[论证关系]：支撑 Finding 7，说明多模态请求存在结构异质性，是导致 TTFT 延长的原因。

- #strong[适用范围]：覆盖三个多模态负载，纵轴未标绝对频数刻度。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0009-31f2fcc5f6aa.png", width: 100%)
    #emph[Figure 10. Breakdown of first-token time when serving requests with image or video inputs (mm-image and mm-video).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：多模态首 token 延迟分解]
    - #strong[图组结论]：视频请求下载/归一化/编码耗时中位数显著高于图像，编码开销为主要瓶颈。

- #strong[论证关系]：支撑 Finding 7 机制，为编码器解耦与弹性扩缩容提供必要性依据。

- #strong[适用范围]：基于采样请求预处理耗时，未验证具体调度优化算法效果。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0009-6b390da900c3.png", width: 100%)
    #emph[Figure 11. Clients in mm-image. CDFs are weighted by rates.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 5 节：多模态客户端异质性]
    - #strong[图组结论]：mm-image 中 35 个客户端即贡献 90% 加权累计请求，头部集中效应极显著。

- #strong[论证关系]：支撑 Finding 8，将客户端分解因果建模从语言模型扩展至多模态场景。

- #strong[适用范围]：覆盖 mm-image 工作负载，未证明泛化至去中心化客户结构。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_751_445_1076_545.jpg", width: 100%)
    #emph[Figure 12. Behavior of top clients in mm-image. Vertical lines in the last-row subfigures indicate average lengths, and error bars show the range of average lengths within a day.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 5 节：多模态头部客户端行为分解]
    - #strong[图组结论]：mm-image 头部客户端图像长度与图文占比分布高度集中、误差条窄。

- #strong[论证关系]：支撑 Finding 8，证实头部客户端速率波动而非速率维度稳定的因果建模成立。

- #strong[适用范围]：覆盖 mm-image 单一客户端快照，不证明适用于其他多模态负载。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0009-6a8216916f90.png", width: 100%)
    #emph[Figure 13 characterizes request lengths in the deepseek-r1 workload, depicting also the reason and answer parts of outputs. In the upper part of Figure 13(a), we observe similar power-law distributions and shifting patterns (Finding 3 and 4) in terms of input and output lengths, as indicated by the fitting]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：推理负载 Reason 与 Answer 长度与比值]
    - #strong[图组结论]：Reason 长度整体更长且跨度更大，Answer/Output 占比呈显著双峰分布。

- #strong[论证关系]：支撑 Finding 9，为推理负载包含两种主导任务模式的推断提供分布证据。

- #strong[适用范围]：基于 deepseek-r1 单日数据，未做任务细分验证。
  ],
)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：真实生产 LLM 服务负载缺乏全面刻画，导致新场景研究动机不足、评测系统不可信
  - 旧方法限制：局部/短期分析规模范围不足（BurstGPT/LMM）；NAIVE生成方法产生\"虚假易服务\"负载
  - 核心洞见/假设：负载复杂性可归约为少数头部客户端的行为波动（Finding 5/8/11）
    - 方法模块：Client Generator（按真实速率/CV异质采样）
      - 可验证预测：以客户端为单位生成的负载在速率-数据分布关联上优于NAIVE
        - 指标与实验：§6.2生成精度对比（图19）
          - 图表证据：图19定性显示\"匹配更好\"，无量化误差指标 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]
            - 结论与适用边界：仅定性验证，缺MAE/RMSE等量化读数，未覆盖多模态/推理场景生成
    - 方法模块：Timestamp Sampler（时变到达建模）
      - 可验证预测：时变速率函数可复现 Finding 1/2 的漂移与突发特征
        - 指标与实验：CV、拟合优度（KS检验）对比
          - 图表证据：图1、图2显示原始负载存在多样化漂移与非统一最优分布
            - 结论与适用边界：Timestamp Sampler具体缩放算法未公开，保真度未被当前证据直接验证 #strong[\[文中未说明\]]
    - 方法模块：Request Data Sampler + conversation-aware mocking
      - 可验证预测：ITT保真的数据采样比Naive上采样更接近真实突发性
        - 指标与实验：§5.2图16对比
          - 图表证据：图16显示遵循真实ITT分布方法更稳定 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]
            - 结论与适用边界：仅在deepseek-r1单一工作负载验证，其他推理模型适用性文中未说明
  - 应用验证：ServeGen在实例配置（§6.3）与PD分离（§6.4）案例中暴露NAIVE导致的欠配与配置分歧
    - 图表证据：图20热力图（欠配50% vs 多配4%）、图21 SLO对比
      - 结论与适用边界：单一模型/单一负载片段验证，跨模型/跨规模的鲁棒性未被当前证据直接验证 #strong[\[文中未说明\]]

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- #strong[贡献总结]：(1) 迄今规模最大范围最全的生产级LLM服务负载刻画；(2) 发现客户端分解揭示的因果建模；(3) 开源ServeGen负载生成框架 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- #strong[证据充分的结论]：真实负载短期到达具突发性且无统一最优分布（图1、图2实验支持）；客户端速率高度倾斜且头部客户端可解释整体漂移（图5、图6实验支持）；NAIVE生成负载会导致资源欠配（§6.3实验支持）。
- #strong[尚属推断的意义]：长尾请求导致PD分离性能不均衡是作者用\"likely\"表述的推断，非确定性因果证明 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]；Answer/Output比值双峰源于两类任务模式也是推断，未做任务细分验证 #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]。
- #strong[适用条件与局限]（作者自述）：未覆盖插件调用场景；因保密义务未覆盖前缀缓存特性；纵向研究时长不足以支持跨月度趋势分析。
- #strong[审稿式风险检查]：
  - 贡献新意：核心发现（客户端分解因果建模）建立在特定平台客户结构上，泛化性依赖未验证的前提，当前证据未覆盖去中心化客户结构场景。
  - 写作/可复现性：Timestamp Sampler具体缩放算法、conversation-aware mocking实现细节均未公开，复现存在障碍 #strong[\[文中未说明\]]。
  - 效果大小：ServeGen对NAIVE的优势多为定性描述（\"匹配更好\"），缺少统一的量化误差指标，效果幅度不易独立核实。
  - 实验覆盖：§6.3/§6.4案例均为单一模型/单一时间片段，未做跨模型跨规模重复实验，当前证据未显示鲁棒性风险已被排除或已被证实存在。
  - 方法设计：与BurstGPT/LMM无同数据集定量对比，仅特征范围对比，当前证据未显示该省略导致结论错误，但确属证据缺口。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：到达间隔时间(IAT)与变异系数(CV)。#strong[第一性原理角色]：IAT是相邻两请求到达时间差这一基本状态量，CV=标准差/均值，是连接\"到达随机性\"与\"系统突发压力\"的因果桥梁。#strong[本文位置]：贯穿Finding 1/2/10/11判定突发性。
- #strong[术语]：客户端(client)。#strong[第一性原理角色]：本文的基本建模单位，是\"请求生成主体\"这一基本对象，其速率、CV、长度分布构成负载异质性的资源约束来源。#strong[本文位置]：Finding 5核心洞见及Client Generator设计基础。
- #strong[术语]：Pareto+Log-normal混合分布/指数分布。#strong[第一性原理角色]：描述输入/输出长度这一状态量的统计约束形态，决定了负载生成时应采样何种分布族。#strong[本文位置]：Finding 3。
- #strong[术语]：prefill与decoding阶段。#strong[第一性原理角色]：LLM推理的两种基本计算机制，分别受并行计算能力与内存带宽约束，是TTFT/TBT等指标的物理成因。#strong[本文位置]：贯穿全文延迟相关讨论。
- #strong[术语]：PD分离(PD-disaggregation)。#strong[第一性原理角色]：一种资源分配机制，将两种不同资源约束（计算密集vs带宽受限）的阶段物理隔离，以避免相互抢占。#strong[本文位置]：§6.4案例研究。
- #strong[术语]：conversation-aware mocking。#strong[第一性原理角色]：在生成数据时保留多轮对话历史结构这一约束，以维持ITT分布不被破坏。#strong[本文位置]：Request Data Sampler模块。
- #strong[术语]：SLO/TTFT/TBT/P99。#strong[第一性原理角色]：延迟类可观测指标，P99作为尾部统计量刻画最坏情况约束。#strong[本文位置]：§6.3实例配置SLO判定。

=== 12.2 学习路径
<122-学习路径>
+ 先理解\"请求\"这一基本对象及其属性（到达时刻、输入/输出长度）------这是负载刻画的最小单元。
+ 再理解 prefill/decoding 两阶段的计算资源约束------这是延迟指标（TTFT/TBT）产生的物理根源。
+ 掌握 IAT/CV 与常见分布族（泊松、Gamma、Pareto、指数）的机制含义------这是判断\"负载有多随机/多突发\"的数学工具。
+ 理解\"客户端\"作为异质性来源的角色------这是本文核心洞见（头部客户端驱动漂移）的因果链起点。
+ 最后理解 SLO/P99 等系统行为指标如何把上述机制转化为可评测的系统表现------这是连接负载特征与工程决策（如PD配置）的桥梁。
