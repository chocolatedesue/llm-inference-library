# 图片批次 6

## 图片 1：Figure 13 characterizes request lengths in the deepseek-r1 workload, depicting also the reason and answer parts of outputs. In the upper part of Figure 13(a), we observe similar power-law distributions and shifting patterns (Finding 3 and 4) in terms of input and output lengths, as indicated by the fitting

![Figure 13 characterizes request lengths in the deepseek-r1 workload, depicting also the reason and answer parts of outputs. In the upper part of Figure 13(a), we observe similar power-law distributions and shifting patterns (Finding 3 and 4) in terms of input and output lengths, as indicated by the fitting](../figure-groups/page-0009-6a8216916f90.png)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：本图为 Figure 13（deepseek-r1 推理负载的输入/输出/reason/answer 长度刻画），角色属于**实验结论**（对 Finding 9 的直接可视化证据），验证的具体问题是：推理负载的输出长度是否因 reason token 的存在而变得更长、更多变，以及 reason 与 answer 长度之间的关系与比值分布形态 [正文支持]。
   - **图表角色**：实验结论。
   - **上文呼应**：对应第 5.1 节"Understanding Reason & Answer Lengths"与 Finding 9（页码：9）。

2. **图像类型与布局**：三个 Panel 均为曲线/柱状统计图组合。Panel 1（左上，对应 Figure 13(a)）为双层长度分布图：上层是 Input（蓝色）与 Output（橙色）的频率-token数曲线（对数纵轴），带拟合曲线（虚线/实线）及均值范围标注 Range(μ(Input))=(883, 2598)、Range(μ(Output))=(838, 3497)；下层是 Reason（灰色）与 Answer（绿色）的对应分布，Range(μ(Reason))=(560, 3051)、Range(μ(Answer))=(274, 490)，并有竖直虚线和误差条标出均值范围。Panel 2（右上，对应 Figure 13(b)）为 Reason Length（x轴）对 Answer Length（y轴）的关系图，浅绿色阴影带表示90%区间，深绿色实线表示中位数。Panel 3（左下，对应 Figure 13(c)）为 Answer/Output(%) 的频率直方图，深绿（Midnight）与浅绿（Noon）两组柱状叠加对比。

3. **如何阅读**：Panel 1 横轴为 token 数，纵轴为频率（对数刻度），四条曲线/直方图分别代表 Input、Output、Reason、Answer 的长度分布，配合拟合曲线判断分布形态及均值区间宽窄；Panel 2 横轴为 Reason Length，纵轴为 Answer Length，通过中位数曲线走势和阴影带宽度判断二者相关性强弱及离散度；Panel 3 横轴为 Answer 占 Output 的百分比，纵轴为频率，比较 Midnight 与 Noon 两个时间段的柱状分布形状是否一致（是否均呈双峰）。

4. **直接可见的结论**：
   - Panel 1 中 Reason 与 Answer 的均值范围（560–3051 vs 274–490）显示 Reason 长度整体更长且跨度更大，Output 整体分布（838–3497）跨度也大于 Input（883–2598）[图像直接可见]。
   - Panel 2 中随 Reason Length 增大，Answer Length 中位数先经历短暂波动随后趋于在约 400–600 token 区间内相对平稳,且90%区间阴影带在 Reason Length 较小时更窄、较大时略有展宽，整体存在但不算陡峭的正向关联趋势 [基于视觉的谨慎推断]。
   - Panel 3 中 Midnight 与 Noon 两条柱状分布均呈现明显的双峰形态，峰值分别位于约 5–15% 与约 55–65% 附近，两个时间段的整体形状高度相似，但 Noon 在低比例区间（约0–10%）的柱高略高于 Midnight [图像直接可见]。

5. **它验证的论点与方法设计含义**：Panel 1、2 共同支持 Finding 9 的**效果类**主张——"推理负载输出更长更多变，因推理段 token 导致，且 reason 与 answer 长度存在比 Figure 4（普通语言模型 input/output 相关性弱）更清晰的关联" [正文支持，页码：9]。Panel 3 的双峰分布直接支撑 Finding 9 中"per-request ratio exhibits a consistent bimodal distribution"的**机制类**主张，即比值双峰源于两种主导任务模式（更完整回答 vs 更简洁回答）[正文支持，页码：9]；同时 Midnight/Noon 两组分布形状高度相似但存在轻微比例差异，为第5.3节"day-and-night shift of the answer length ratio is attributed to the fluctuation of client rates"（该论断对应 Figure 17(c) 的客户端分解，而非本图）提供了整体层面（非客户端分解层面）的先导观察，但本图本身不能证明该比例变化的客户端归因机制，该因果链需结合 Figure 17(c) 才能确认 [正文支持，页码：10]。

6. **适用范围与证据缺口**：本图证据覆盖范围为 deepseek-r1 workload、一天时间窗口内的统计（Figure 13 图注："for the deepseek-r1 workload in one day"）[页码：9]。无额外证据缺口。

---

## 图片 2：Figure 11. Clients in mm-image. CDFs are weighted by rates.

![Figure 11. Clients in mm-image. CDFs are weighted by rates.](../figure-groups/page-0009-6b390da900c3.png)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：本图合并了 Figure 11（"Clients in mm-image. CDFs are weighted by rates."）与 Figure 12（"Behavior of top clients in mm-image"）的内容，角色属于**机制**类证据，用于验证 Finding 5 提出的"因果建模"（少数头部客户端驱动整体负载模式）是否在多模态（mm-image）场景下同样成立，对应 Finding 8："Top clients in multimodal workloads exhibit diverse behaviors, and characterizing them helps explain the overall workload patterns" [正文支持]。
   - **图表角色**：机制（因果建模的跨场景验证）。
   - **上文呼应**：第 4.3 节"Multimodal Client Decomposition"，对应 Finding 8（页码：8）。

2. **图像类型与布局**：三个 Panel。Panel 1（左上，对应 Figure 11）为 2×2 排列的加权 CDF 曲线图：Rate Rank（对数横轴，标注 35）、CV（标注 48%处对应 CV≈1附近）、Avg. Image Length、Avg. Image/Input(%)，均为单条蓝色阶梯状曲线，纵轴为 Weighted CDF(%)。Panel 2（右上，对应 Figure 12 的时序部分）为四条彩色折线图（Client A/B/C/D，各标注其速率占比 11.7%/11.2%/10.7%/9.1%），横轴为一天内的小时（0–24），纵轴为 Rate(req/s)，展示各客户端速率随时间的波动。Panel 3（左下，对应 Figure 12 的分布部分）为蓝色方框标注的"Client A"专属双直方图：左为 Image Tokens 频率分布（对数纵轴），右为 Image/Input(%) 频率分布，均带竖直虚线（均值标注）及误差条。

3. **如何阅读**：Panel 1 四张 CDF 图需分别读横轴（客户端按速率排名的对数刻度、CV 值、平均图像长度、平均图像占比）与纵轴（按速率加权的累计客户端占比），判断分布的陡峭程度（越陡表示越集中/头部效应越强）；Panel 2 需对比四条折线的峰谷时刻和波动幅度，判断哪个客户端在何时段主导速率突增；Panel 3 需结合竖直虚线（均值）与误差条宽度判断 Client A 的图像长度和图像占比在一天内的稳定性。

4. **直接可见的结论**：
   - Panel 1 的 Rate Rank CDF 在约排名35处已接近90%的加权累计占比，曲线在低排名区间极陡峭，随后迅速趋平，显示速率高度集中于少数客户端 [图像直接可见]。CV、Avg. Image Length、Avg. Image/Input(%) 三张 CDF 均呈阶梯状（非平滑曲线），表明客户端在这些维度上取值离散、分布不均匀 [图像直接可见]。
   - Panel 2 中四条客户端速率曲线波动幅度和节奏各不相同：绿色曲线（Client C 或类似标注）在多个时间点出现尖峰（如约8–10时、14时附近），而其余曲线相对平稳，表明不同客户端的速率波动模式存在明显异质性 [图像直接可见]。
   - Panel 3 中 Client A 的 Image Tokens 分布在低值区间（约0–100）和约1200附近各有一个峰值，中间大范围内频率较低但分布连续；Image/Input(%) 分布在约20–40%区间内相对集中，误差条较窄 [图像直接可见]。

5. **它验证的论点与方法设计含义**：Panel 1（Figure 11）的强头部集中现象（35个客户端即达90%加权累计）直接支撑 Finding 5/8 所述"真实负载由异质、速率高度倾斜的客户端组成"这一**机制**主张在多模态场景下的延伸验证，呼应正文"1,036 multimodal clients...heterogeneous in terms of rate, burstiness, image length distributions, and image-to-input ratios"的描述 [正文支持，页码：8]。Panel 2、3（Figure 12）中 Client A 等头部客户端在图像长度/占比上的窄误差条（相对稳定）与速率的显著波动共同印证"头部客户端速率波动、非速率维度保持稳定"的因果建模在多模态场景的成立，支撑该机制类主张可推广至 mm-image 而不仅限于语言模型（M-small）[正文支持，页码：8]。这些证据共同为 ServeGen 的 Client Generator 模块（对客户端速率与 CV 进行异质采样）提供跨场景（语言+多模态）的方法设计依据 [基于文中逻辑的推断，依据：正文指出 Finding 5 的因果建模在 §4.3 被重新验证，页码：8]。本图不能证明该机制在 mm-audio/mm-video/mm-omni 等其他多模态负载中同样成立，因为正文该部分分析仅针对 mm-image [正文支持，页码：8]。

6. **适用范围与证据缺口**：本图证据覆盖范围为 mm-image workload（正文：1,036 个多模态客户端，Figure 12 图注注明分析时长为24小时/一天）[页码：8]。需要说明的缺口：正文提及"Client B...exclusively sends images of the same size (around 1,200 tokens each)"作为代表性头部客户端案例，但 Panel 2/3 中实际标注和突出展示的是 Client A（而非文中重点举例的 Client B），图中无法确认 Client A 与正文描述的 Client B 是否为同一客户端或具有相同行为特征，此为 OCR/图注与视觉内容之间的对应关系缺口 [该缺口属于图像与图题对应关系无法确认，非泛化性缺口]。
