# 图片批次 1

## 图片 1：Figure 2. Long-term rate and CV shifts.

![Figure 2. Long-term rate and CV shifts.](../assets/imgs/img_in_chart_box_131_468_555_714.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：该图为**效果（现象描述）证据**，用于支撑 Finding 2——LLM 服务请求到达的速率与突发性（CV）随时间呈现多样化漂移模式，而非静态过程 [正文支持，页码：5-6]。
   - **图表角色**：实验结论。
   - **上文呼应**：对应 §3.1 "Shifting rate and burstiness" 段落，紧接 Finding 1 之后、Finding 2 之前，是该 Finding 的直接可视化证据 [正文支持，页码：5-6]。

2. **图像类型与布局**：双行×双列组的曲线图。上行为速率（Rate, req/s，对数坐标），下行为变异系数（CV，线性坐标）；左列 x 轴为"星期几"（Mon–Sun，跨周视角），右列 x 轴为"一天中的小时数"（0–24，跨日视角）。四条彩色曲线分别代表 M-large（红）、M-small（蓝）、M-code（橙）、M-rp（紫），以图例统一标注于顶部。

3. **如何阅读**：纵向比较同一工作负载在上下两行（速率 vs CV）的对应走势；横向比较左侧"周视图"与右侧"日视图"，右侧日视图主要突显 M-code 的日内极端波动。应重点关注不同颜色曲线之间幅度、波动频率及峰值时刻的差异。

4. **直接可见的结论**：
   - M-small（蓝）在速率上整体最高且波动最大，周三附近出现明显尖峰 [图像直接可见]；
   - M-large（红）速率相对较低且更平缓，但其 CV 曲线在周一、周二维持在约1.4–1.6的较高水平，至周四、周五回落到接近1.0–1.2 [图像直接可见]，与正文"M-large was continuously bursting for two days (Mon. and Tue.) before turning stable (Thu. and Fri.)"的表述吻合；
   - M-rp（紫）速率与CV均全程低而平稳，右侧日视图中CV曲线几乎贴近1.0水平线 [图像直接可见]，与正文"M-rp remain non-bursty for the entire day"吻合；
   - M-code（橙）仅在右侧日视图中速率出现两次剧烈尖峰（正午前后），对应CV也在相同时刻出现陡峭尖峰 [图像直接可见]，与正文"potentially extreme rate shifts (as shown for M-code)"吻合。

5. **它验证的论点与方法设计含义**：该图为效果类证据，直接可视化验证 Finding 2 关于"到达速率与突发性随时间呈多样化漂移"的主张 [正文支持，页码：6]。图中不同工作负载呈现出彼此独立、形态各异的漂移模式（部分负载持续突发后转稳定，部分负载全程稳定，部分负载仅在特定时段爆发），支持论文提出的"系统需具备自适应设计（自动扩缩容、突发感知调度）"这一必要性主张 [正文支持，页码：6]。该图本身不解释这些漂移的成因（成因由 §3.3 客户端分解给出），故不能据此图判断驱动漂移的具体机制。

6. **适用范围与证据缺口**：本图覆盖 Table 1 中 M-large、M-small、M-code、M-rp 四个语言模型工作负载，以5分钟窗口计算速率和CV，左侧为跨周（M-large/M-small）视角、右侧为跨日（M-code等任务特定负载）视角 [正文支持，页码：5]。该图未包含 M-mid（在其他图中呈现），符合正文表述范围，非视觉缺口。无额外证据缺口。

---

## 图片 2：Figure 1. Inter-arrival time characterization.

![Figure 1. Inter-arrival time characterization.](../figure-groups/page-0005-a0bc69659dbe.png)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：该图组是**机制证据**，用于验证 Finding 1——真实到达间隔时间（IAT）具有超越单一随机过程的复杂突发性（CV>1），且不存在对所有工作负载都最优的统一分布假设 [正文支持，页码：4-5]。
   - **图表角色**：实验结论。
   - **上文呼应**：对应 §3.1 "Bursty short-term arrival patterns" 段落，是该段落及 Finding 1 的直接可视化证据 [正文支持，页码：4-5]。

2. **图像类型与布局**：四宫格组合图。Panel 1–3 为曲线图，分别对应 M-large、M-small、M-mid 在20分钟窗口内的 IAT 频率分布（y轴对数坐标，x轴为 IAT，单位毫秒），每个 panel 内叠加 Actual（实际数据，绿色实线）与三条参数化分布拟合曲线：Expon（蓝虚线）、Gamma（橙虚线）、Weibull（红点线），并标注该窗口的 rate 与 cv 数值。Panel 4 为分组柱状图，x 轴为工作负载（M-large、M-small、M-mid），每组含 Expon/Gamma/Weibull 三色柱，y 轴为 KS 检验 p 值（对数坐标）。

3. **如何阅读**：Panel 1–3 内比较 Actual 曲线与三条拟合曲线的贴合程度（尤其在 IAT 较小、频率较高区域）；Panel 4 内比较同一工作负载下三种分布何者 p 值最高（拟合优度最佳），并跨三个工作负载比较"最佳拟合分布"是否一致。

4. **直接可见的结论**：
   - Panel 1（M-large, rate=80.0, cv=1.29）：Actual 曲线明显偏离 Expon（蓝虚线在小IAT处显著低估、随后交叉），而更贴近 Gamma/Weibull [图像直接可见]；
   - Panel 2（M-small, rate=230.8, cv=1.12）：Actual 曲线与 Expon、Gamma、Weibull 三条拟合曲线几乎重合 [图像直接可见]；
   - Panel 3（M-mid, rate=697.2, cv=1.07）：Actual 曲线整体贴近三条拟合曲线，但尾部存在噪声波动 [图像直接可见]；
   - Panel 4：M-large 组中 Gamma 柱最高（约10⁻²量级），高于 Expon 和 Weibull；M-small 组中三色柱高度相近（约10⁻³量级）；M-mid 组三色柱整体最低（约10⁻⁶–10⁻⁷量级），其中 Weibull 略高于其余两者 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图组是机制类证据，直接支撑 Finding 1 的两层主张：(1) 三个工作负载的 CV 均大于1（Panel 1–3 标注数值1.29/1.12/1.07），验证"短期到达具有突发性"[正文支持，页码：5]；(2) Panel 4 显示"没有一种分布在所有工作负载上 p 值都最高"——M-large 更适合 Gamma、M-mid 的 Weibull 柱略占优、M-small 三者相近（Exponential 已可用）[图像直接可见，对应正文"Gamma for M-large, Weibull for M-mid, and even Exponential can be a good fit for M-small"]。这为 ServeGen 中 Timestamp Sampler 允许"每个客户端灵活选择参数化分布（Gamma/数据样本等）而非固定单一分布"的设计提供了直接依据 [正文支持，页码：11]。该图不能证明具体是何种因素导致不同工作负载最优分布不同，此因果解释由后续 §3.3 客户端分解给出。

6. **适用范围与证据缺口**：本图组覆盖 M-large、M-small、M-mid 三个语言模型工作负载在单一20分钟观测窗口内的 IAT 分布及 KS 检验结果 [正文支持，页码：4-5]。无额外证据缺口。
