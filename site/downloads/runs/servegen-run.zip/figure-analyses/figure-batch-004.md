# 图片批次 4

## 图片 1：Figure 8. Characterization of omni-modal inputs in mm-omni. Left: number of multimodal inputs per request. Right: arrival rate of multimodal and text tokens, normalized by the total input rate.

![Figure 8. Characterization of omni-modal inputs in mm-omni. Left: number of multimodal inputs per request. Right: arrival rate of multimodal and text tokens, normalized by the total input rate.](../figure-groups/page-0008-89c74b0d74e0.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图对应 §4.1 "Load variance in omni-modality"，是一项**效果/现象刻画类**证据，用于验证 Finding 6（多模态数据分布呈不规则且独立的漂移，模态间负载差异显著）在 mm-omni（可同时含多种模态输入的全模态工作负载）场景下的表现，是 mm-image/audio/video（图7）分析的延伸对照，用来说明"当请求可同时携带多种模态时，负载变异性进一步复杂化" [正文支持]。
   - **图表角色**：问题严重性 + 机制说明。
   - **上文呼应**："Figure 8 presents the same analysis on mm-omni... featuring a greater number of multimodal inputs per request and more diverse shifting patterns in input load (e.g., audio load rises during the day, while image load becomes prominent past midnight)"（§4.1，页码：8）。

2. **图像类型与布局**：并列两个曲线图（非表格）。左图：CDF曲线图（多条曲线，对数x轴 #Items，y轴 CDF% 80–100），以彩色虚线标出不同曲线的最大值（"max 7""max 24""max 36"）。右图：多条时间序列曲线图，x轴 Time (hour) 0–24，y轴 Normalized Rate 0–0.6，图例含 "Audio"（粉色）、"Video"（紫色），另有一条深灰/黑色曲线及一条青色曲线未能确认对应图例文字。

3. **如何阅读**：左图应比较不同颜色曲线到达 CDF≈100% 所需的 #Items 数量及其虚线标注的最大值，判断"每请求携带的多模态输入数量"在不同模态间的分布差异；右图应比较各颜色曲线随时间(小时)的归一化速率走势与相对高低，判断哪类模态输入在一天中的哪个时段占比更高。因图例文字部分不完整（右图左上角仅见孤立文字"Image"，深灰色与青色曲线的图例归属无法从像素中确认），无法完全确定右图深灰色曲线和青色曲线各自代表的模态/文本序列。

4. **直接可见的结论**：
   - 左图三条彩色曲线（紫、青、粉）在达到CDF=100%前所需的#Items数量明显不同，虚线标注最大值分别为7、24、36，表明不同模态在"每请求携带数量"上的分布形态差异较大 [图像直接可见]。
   - 右图中至少四条曲线（深灰、粉、紫、青）在0–24小时内呈现彼此不同步、非单调的波动模式：紫色曲线在时间早段（约0–8小时）维持相对较高水平后明显下降并在其余时段维持低位；粉色与深灰/青色曲线则在全程呈现不同幅度的起伏，彼此走势不完全同步 [图像直接可见]。
   - 无法从当前视觉像素可靠判定深灰色和青色曲线各自对应"Text"或"Image"中的哪一个 [基于视觉的谨慎推断，图例文字不完整]。

5. **它验证的论点与方法设计含义**：左图的多峰值差异直接支持 Finding 6 中"多模态数据分布呈不规则且独立漂移"的现象描述，属于效果类主张——不同模态请求所携带的输入项数量本身具有异质分布，无法用单一分布刻画 [正文支持]。右图曲线间的非同步波动，对应正文所述"audio load rises during the day, while image load becomes prominent past midnight"这一具体机制陈述，用以说明 mm-omni 场景下各模态负载的独立漂移比单模态工作负载（图7）更复杂多变 [正文支持]。这类证据支撑了 ServeGen 中 Client Generator/Request Data Sampler 需要按模态分别参数化数据分布、而非把多模态输入当作单一整体建模的设计动机（§6.1）[基于文中逻辑的推断]。该图不能证明具体的调度优化方案效果，也未给出量化误差指标，这些不应从此图直接推出。

6. **适用范围与证据缺口**：本图证据覆盖论文报告的 mm-omni workload（Qwen2.5-Omni-7B，8.7M 请求，一周数据，见 Table 1），不代表其他多模态或语言、推理工作负载。真实剩余缺口：右图深灰色曲线与青色曲线在图例中缺少可辨认的文字标签，无法确认其对应的具体模态/文本类别（图例文字被裁切/像素不清晰，OCR 图题未逐一列出四条曲线的图例名称）。

---

## 图片 2：Figure 7. Characterization of multimodal inputs in mm-image, mm-audio, and mm-video (Rows). Columns: (a) #multimodal inputs per request; (b) length distribution of inputs; (c) correlation between text and multimodal tokens; (d) overall arrival rate of multimodal and text tokens.

![Figure 7. Characterization of multimodal inputs in mm-image, mm-audio, and mm-video (Rows). Columns: (a) #multimodal inputs per request; (b) length distribution of inputs; (c) correlation between text and multimodal tokens; (d) overall arrival rate of multimodal and text tokens.](../figure-groups/page-0008-9dac689f7a93.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图对应 §4.1（Load variance in different modalities）与部分呼应 §4.2/§4.3 的前置铺垫，属于**效果/现象刻画类**证据，是本文对多模态工作负载刻画的核心图之一，直接支撑 Finding 6（"多模态数据分布呈不规则且独立的漂移，模态间负载差异显著"）。它逐一验证：(a) 每请求携带多模态输入数量的分布，(b) 多模态输入长度分布是否符合传统幂律形态，(c) 文本与多模态 token 之间的相关性强弱，(d) 模态与文本负载随时间的到达速率关系 [正文支持]。
   - **图表角色**：问题严重性 + 机制说明。
   - **上文呼应**：§4.1 "Figure 7 characterizes data distributions in mm-image, mm-audio, and mm-video, focusing specifically on the multimodal inputs...tokenized lengths of multimodal inputs exhibit irregularly shaped distributions...highly varied load on modality encoders"（页码：8）。

2. **图像类型与布局**：3行×4列共12个子图的组合曲线/柱状图矩阵，行对应三种模态工作负载（第1行 Image/mm-image，第2行 Audio/mm-audio，第3行 Video/mm-video），列对应四类分析：(a) CDF of #multimodal inputs per request（对数x轴），(b) 长度分布直方图（区分 Midnight vs Noon/Morning 两个时间段，颜色深浅区分），(c) 文本token vs 多模态token的相关性图（含90%区间阴影带与P50虚线），(d) 模态与文本token的到达速率时序曲线（0–24小时）。

3. **如何阅读**：每行内部按列顺序阅读，比较同一模态在"输入数量分布→长度分布→与文本长度相关性→时序负载"四个维度上的特征；同时可跨行比较三种模态之间在同一列维度上的差异（例如比较三个(a)列 CDF 曲线达到饱和所需的输入数量，或比较三个(d)列速率曲线的相对幅度）。(b)列直方图中深浅两色代表不同时间段采样，虚线标注对应众数值（如"573""197/219""9297/9038"）。

4. **直接可见的结论**：
   - (a)列：Image 在约10个输入项内CDF迅速接近100%（max=49，为该行标注上限），Audio 几乎恒为100%且max=2，Video 恒为100%且max=1，说明三种模态在"每请求携带输入数量"上差异巨大：Image请求可携带多个输入，Audio/Video几乎总是仅携带1个输入 [图像直接可见]。
   - (b)列：三种模态长度分布均非平滑单峰，而是呈现多个离散尖峰（如 Image 在约250附近及约1200附近各有明显峰值，Audio 集中在约200–300附近的窄峰，Video 呈多峰宽分布，跨度可达30000+），且 Midnight 与 Noon/Morning 两个时段的直方图形状/众数存在可见差异（虚线标注值不同，如 Image 的 573 对应某一时段峰值，Audio 的 197 与 219 分别对应不同时段峰值，Video 的 9297 与 9038 类似）[图像直接可见]。
   - (c)列：三种模态的"多模态token数—文本token数"关系图中，P50虚线曲线并无单调趋势，且90%阴影区间很宽，覆盖高低跨度极大（如 Video 该列 y 轴可达20000+），显示多模态与文本长度之间没有稳定的强相关模式 [图像直接可见]。
   - (d)列：Image 的多模态token到达速率曲线在时间轴上出现一次明显尖峰（约在早期某小时骤增至远高于其余时段和文本曲线的水平），随后回落到略高于文本曲线的水平；Audio 的多模态速率整体远低于文本速率，仅在中段出现一段明显突起；Video 的多模态速率在起始阶段维持很高水平，之后经历明显下降再逐渐回升，全程与文本曲线的相对高低发生变化 [图像直接可见]。

5. **它验证的论点与方法设计含义**：(a)列证据支持"多模态输入数量因模态而异"这一现象性主张，说明 Image 请求结构远比 Audio/Video 复杂，为后续 §4.2 请求异质性（Finding 7）埋下基础 [正文支持]。(b)列多峰、非幂律的分布形态直接对应正文所述"多模态输入的 token 化长度呈现不规则形状，聚集在特定值附近，而非遵循文本模态的典型幂律分布"，是 Finding 6 前半部分（"数据分布不规则")的直接图像证据 [正文支持]。(b)列中 Midnight/Noon 两时段分布形状差异，直接对应 Finding 6 后半部分"多模态数据分布也随时间漂移"（正文举例 mm-image 图像平均长度一天内变化达19%）[正文支持]。(c)列宽阴影带与非单调 P50，支持正文"缺乏文本与多模态token之间相关性"的机制描述，说明模态负载不能通过文本长度间接推断，需要独立建模——这直接指向 ServeGen 中 Request Data Sampler 必须对每个模态维度分别参数化数据分布，而非借助文本长度做联合推断 [正文支持，基于因果链的方法设计推断]。(d)列中 Image 序列的骤增尖峰，对应正文明确举例"nine hours into the mm-image workload, the image token rate sees an abrupt increase, while the text token rate remains constant"，直接证明"多模态负载的变异可独立于文本负载"这一机制主张 [正文支持]。这些证据共同构成 Table 2 中本文相对 LMM [38] 的范围优势（LMM 仅覆盖"Image data distribution"单一维度，而本图同时覆盖数量分布、长度分布、相关性与时序速率四个维度）——但该图本身并未与 LMM 做同数据集/同指标的正面定量对比，只能作为本文覆盖范围更广的间接证据。

6. **适用范围与证据缺口**：本图证据覆盖论文报告的 mm-image（28M请求/一月）、mm-audio（420K请求/一月）、mm-video（1.2M请求/一月）三个工作负载（均使用各自模型 Qwen2.5-VL-72B/Qwen2-Audio-7B/Qwen2.5-VL-72B，见 Table 1），不代表 mm-omni 或语言/推理负载的等价结论。真实剩余缺口：(b)列个别子图的时间段划分标签（如 Video 行对应 "Midnight/Noon" 还是其他时段组合）因图例文字与坐标轴刻度较小、像素分辨率限制难以逐一精确核对每个虚线数值与其所属时段的严格对应关系；此外(d)列图中 Image 曲线的骤增尖峰具体发生的确切小时数（正文只称"nine hours into the workload"）无法从当前图像像素精确读出峰值坐标，只能确认存在该尖峰这一定性事实。
