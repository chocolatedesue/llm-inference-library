# 图片批次 3

## 图片 1：Figure 5. Client heterogeneity in terms of rate, etc. All CDFs are weighted by client rates.

![Figure 5. Client heterogeneity in terms of rate, etc. All CDFs are weighted by client rates.](../figure-groups/page-0007-b80ca85e156c.png)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：该图组对应正文 §3.3 "Client Decomposition"，核心论证核心洞见 Finding 5——真实负载由异质客户端组成，客户端速率高度倾斜，头部客户端的速率波动可解释整体漂移模式。证据类型为**机制**（因果建模：少数头部客户端驱动整体负载模式）。Panel 1-3 对应 Figure 5（"Client heterogeneity in terms of rate, etc."），用于证明"2,412 个客户端中前 29 个贡献 90% 请求"这一速率偏斜事实，以及客户端在 CV、长度上的整体异质性分布；Panel 4 对应 Figure 6（"Characterization of the top four clients... in isolation"）中的速率子图，用于展示头部客户端 A/B/C/D 各自的速率轨迹，支持"头部客户端速率波动导致整体负载漂移"这一因果链条。`[正文支持]`
   - **图表角色**：机制（因果建模的直接证据）。
   - **上文呼应**：对应报告"核心洞见与假设"一节中第 1、2 条证据（§3.3 客户端分解，页码：6）。

2. **图像类型与布局**：四个曲线图 Panel，均为折线/CDF 图。Panel 1：横轴 "Rate Rank"（对数刻度 1–~300），纵轴 "Weighted CDF (%)"，蓝色阶梯状曲线，图中有虚线标注在 x=29 处对应 y≈90。Panel 2：横轴 "CV"（0 到 ~15），纵轴 "Weighted CDF (%)"，蓝色曲线，虚线标注在 y=50 处、x 接近 1 附近有陡峭跃升。Panel 3：双 x 轴（下方蓝色 "Avg. Input Length" 对数刻度 10–10000，上方橙色 "Avg. Output Length" 对数刻度 10–1000），纵轴 "Weighted CDF (%)"，两条曲线（蓝色对应输入长度，橙色对应输出长度）。Panel 4：横轴为时间（小时，0–48+），纵轴 "Rate (req/s)"，四条不同颜色曲线，图例标注 "Client A (33.6%)"（蓝）、"Client B (13.4%)"（橙）、"Client C (9.6%)"（绿/红）、"Client D (8.8%)"（红），蓝色曲线波动幅度明显大于其余三条。

3. **如何阅读**：Panel 1-3 均为按客户端速率加权的 CDF（图注说明"All CDFs are weighted by client rates"），阅读时应关注曲线的陡峭/平缓程度：陡峭代表少数对象集中了大部分权重（偏斜），平缓代表分布均匀。Panel 1 应关注 x=29 处对应的纵轴读数；Panel 2 应关注 CV=1（泊松基准）附近曲线是否已经接近饱和；Panel 3 应比较蓝、橙两条曲线的陡峭程度差异。Panel 4 应比较四条客户端速率曲线的时间走势与波动幅度差异，尤其关注是否存在局部尖峰。

4. **直接可见的结论**：Panel 1 显示曲线在 x≈29 处已达到约 90% 的加权 CDF，此后迅速趋于平坦直至 100%，说明少数客户端（Rate Rank 前 29 名）占据了绝大多数加权请求量 `[图像直接可见]`。Panel 2 显示在 CV 略大于 1 处曲线已达到约 50%，且此前有一段陡峭跃升，之后曲线延伸至 CV 远大于 10 才趋于 100%，说明客户端 CV（突发性）分布本身也有相当离散，一部分客户端接近泊松（CV≈1），另一部分远超 `[图像直接可见]`。Panel 3 中蓝色（输入长度）与橙色（输出长度）两条曲线形态不同、跨越数量级范围广（输入长度覆盖 10 到超过 10000，输出长度覆盖 10 到超过 1000），且未在同一位置陡峭上升，说明客户端间长度特征差异大 `[图像直接可见]`。Panel 4 中蓝色曲线（Client A，占比 33.6%）在约第 20–24 小时和第 40 小时附近呈现明显的速率尖峰（波峰），而橙、绿/红曲线（Client B/C/D）整体波动幅度较小、走势相对平稳 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：Panel 1-3 直接支持 Finding 5 中"真实负载由异质客户端组成，客户端速率高度倾斜"这一效果类主张——少数头部客户端（前 29/2412）贡献 90% 请求量，属于机制层面的偏斜证据 `[正文支持]`。Panel 4 中 Client A 呈现的显著速率尖峰而其余客户端相对稳定，直接支持"头部客户端的速率波动是整体负载漂移模式的因果驱动因素"这一机制类主张（对应正文所述 Client A 的突发峰值与 M-small 整体负载在周二夜间的突发时刻相吻合）`[正文支持]`。这些证据共同为 ServeGen 的 Client Generator 模块设计提供了直接依据：即必须按真实的速率/CV 分布对客户端异质性建模，而非把整体负载当作单一随机过程处理。该图本身不能证明"头部客户端在长度、突发性上保持稳定"（该主张由 Figure 6 中未在本图出现的长度/CV 时序子图及误差棒支撑，本图 Panel 4 只展示了速率轨迹），也不能证明该因果机制在多模态/推理负载中同样成立（该点由 Figure 11/12、Figure 17 提供，不在本图范围）。

6. **适用范围与证据缺口**：本图覆盖范围为 M-small 工作负载前 48 小时的数据（2,412 个客户端，Figure 2 所示同一时间窗口）`[正文支持]`。Panel 4 仅展示了 Figure 6 中的速率子图，正文提到 Figure 6 "last-row subfigures" 还包含突发性（CV）与输入/输出长度的误差棒子图，用以证明头部客户端在这些维度上的稳定性，但这些子图未包含在当前图像中，无法据此图直接核实"Client A/D 长度稳定、误差棒窄"这一具体细节——此为图像裁剪导致的真实证据缺口。除此之外无额外证据缺口。

---

## 图片 2：Figure 9. Ratio of multimodal input tokens per request in mm-image, mm-audio, and mm-video. Numbers indicate the average ratio.

![Figure 9. Ratio of multimodal input tokens per request in mm-image, mm-audio, and mm-video. Numbers indicate the average ratio.](../figure-groups/page-0008-134408fd9c7d.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：该图对应正文 §4.2 "Request Heterogeneity"，即 Figure 9（"Ratio of multimodal input tokens per request in mm-image, mm-audio, and mm-video"），用于验证 Finding 7——多模态请求在模态输入占比上高度异质（从文本主导到多模态主导连续分布），从而为后续论证"该异质性导致 TTFT 延长、需要专门调度优化"提供前提证据。证据类型为**机制**（请求级异质性的分布形态），是效果类主张（Finding 7 中"导致 TTFT 延长"）成立的前置事实基础。`[正文支持]`
   - **图表角色**：机制（请求异质性的直接统计证据）。
   - **上文呼应**：对应报告"实验、指标与文字可确认的结论"中的 Finding 7（§4.2，页码：8-9），以及"主张地图"中"多模态请求的异质性会导致TTFT延长"一行。

2. **图像类型与布局**：三个直方图（柱状分布图）Panel，分别对应 mm-image、mm-audio、mm-video 三个工作负载。Panel 1（浅蓝色）：横轴 "Image/Input (%)"，纵轴 "Frequency"；Panel 2（粉红色）：横轴 "Audio/Input (%)"；Panel 3（紫色）：横轴 "Video/Input (%)"。三图纵轴均为 "Frequency"，横轴范围均为 0–100%。每个 Panel 顶部有一条虚线标注一个数值（Panel 1: 67，Panel 2: 66，Panel 3: 86），对应图注所述"Numbers indicate the average ratio"。

3. **如何阅读**：横轴表示单个请求中该模态输入 token 数占总输入 token 数的百分比，纵轴为落在各区间的请求频数（未标定具体数值刻度，只呈现相对高度）。阅读时应关注柱状分布在 0–100% 区间上的整体形状（是否集中在某一端还是分散在全区间），以及虚线标注的平均值位置与分布形态的关系。

4. **直接可见的结论**：三个直方图在 0% 到 100% 的整个区间上都有柱状分布，并非集中于单一区间：Panel 1（mm-image）在低比例区间（0–10% 附近）有一个较高的柱子，随后中段分布较低，在 70–100% 区间又出现多根较高的柱子，平均值虚线标注在 67 附近 `[图像直接可见]`。Panel 2（mm-audio）整体柱高普遍偏低且较为分散，在 50–60% 附近及 80–90% 附近各有局部较高的柱子，平均值虚线标注在 66 附近 `[图像直接可见]`。Panel 3（mm-video）柱状分布随比例增大逐渐升高，在 90–100% 区间出现全图最高的柱子，分布明显偏向高比例一端，平均值虚线标注在 86 附近 `[图像直接可见]`。三者均呈现出图注与正文所述的"flat distribution"特征，即请求在模态占比谱系上广泛分布而非集中于单一峰值（尤其 mm-image、mm-audio），而 mm-video 则表现出偏向视频主导的分布倾向 `[基于视觉的谨慎推断]`（具体是否严格符合"flat"用语见第6项）。

5. **它验证的论点与方法设计含义**：该图直接支持 Finding 7 的机制类主张——"multimodal requests are heterogeneous with diverse ratios of multimodal inputs per request"，即三个工作负载的请求都天然地从"文本主导"到"多模态主导"连续分布，而非集中于某个典型比例，这一异质性构成后续论证"该异质性导致 TTFT 延长（Figure 10）、需要专门调度优化"的直接前提证据 `[正文支持]`。方法设计上，这一发现要求 ServeGen 的 Request Data Sampler 模块必须对每个客户端/请求单独刻画其模态占比分布，而不能用单一固定比例代表整个负载。需要注意，该图本身不能证明"异质性导致 TTFT 延长"这一因果结论，该结论需结合 Figure 10（未在本图范围）的分阶段耗时数据；本图仅提供异质性存在的统计证据。

6. **适用范围与证据缺口**：本图覆盖论文报告的 mm-image（28M 请求/一月）、mm-audio（420K 请求/一月）、mm-video（1.2M 请求/一月）三个工作负载的整体请求级模态占比统计（Table 1）`[正文支持]`。纵轴 "Frequency" 未标注具体数值刻度或总请求数分母，无法从图中判断绝对频数或各区间占比的精确数值，仅能读出相对高度关系；这是图像本身呈现方式导致的真实缺口。除此之外无额外证据缺口。
