# 图片批次 5

## 图片 1：Figure 10. Breakdown of first-token time when serving requests with image or video inputs (mm-image and mm-video).

![Figure 10. Breakdown of first-token time when serving requests with image or video inputs (mm-image and mm-video).](../figure-groups/page-0009-31f2fcc5f6aa.png)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文第4.2节"Request Heterogeneity"与Finding 7，属于**机制**类证据（兼有"问题严重性"成分）。作者需要证明"多模态请求异质性导致TTFT延长"这一因果链条的具体机制：多模态输入（尤其图像/视频）在prefill之前要经历下载(download)、归一化(normalize)、编码(encode)三个阶段，这些阶段合计构成了显著的首token延迟开销。该图试图回答的具体问题是："这些预处理阶段各自耗时多少？它们在总TTFT中占多大比例？"，从而为"需要更先进的调度/批处理策略"这一必要性主张提供量化依据 [正文支持]。
   - **图表角色**：机制（辅以问题严重性）。
   - **上文呼应**：第4.2节 Request Heterogeneity → Finding 7（多模态请求异质性导致TTFT延长）；正文引用"half of the mm-image requests spend 75% of their TTFT before LLM prefilling"直接对应本图。

2. **图像类型与布局**：五个CDF曲线图组成的图表组（对应Figure 10的(a)与(b)两部分）。上排三个子图（Panel 1-3）为(a) "Per-stage time during first-token generation"，分别展示Download Time、Normalize Time、Encoder Time的CDF，每图内用青色（Image）与紫色（Video）两条曲线对比，并以虚线标注中位数（如293ms/498ms、22ms/440ms、249ms/1022ms）。下排两个子图（Panel 4-5）为(b) "CDF of cumulative time after each stage"，分别对应mm-image和mm-video请求，横轴为TTFT中各预处理阶段（Downloaded/Normalized/Encoded）累计耗时占总TTFT的百分比，纵轴为CDF(%)，用不同深浅的同色系曲线区分三个阶段。

3. **如何阅读**：上排三图横轴为绝对耗时（毫秒），纵轴为CDF(%)，比较同一阶段下Image与Video两条曲线的位置（曲线越靠右表示耗时越长，虚线标注中位数）；下排两图横轴为"该阶段累计耗时占TTFT总时长的百分比"，纵轴为CDF(%)，比较Downloaded/Normalized/Encoded三条曲线在同一累计百分比下的CDF值差异，反映各阶段对TTFT的贡献比例。Panel 4（mm-image）图上可辨识两条主曲线（浅色圆点=Downloaded，深色方块=Encoded），Normalized曲线因图像归一化耗时极短可能与Downloaded曲线高度重合、难以单独区分 [基于视觉的谨慎推断]；Panel 5（mm-video）三条曲线（浅紫、中紫、深紫）区分明显。

4. **直接可见的结论**：
   - 三个预处理阶段（下载、归一化、编码）视频耗时均明显长于图像：编码耗时中位数视频约1022ms vs 图像约249ms，归一化视频约440ms vs 图像约22ms，下载视频约498ms vs 图像约293ms [图像直接可见]。
   - 图像与视频的耗时分布均呈现长尾（CDF曲线在高值区域有拖尾，未在中位数附近陡峭截止）[图像直接可见]。
   - 在mm-image的TTFT累计耗时分解中，Encoded曲线在CDF≈50%处对应横轴约70-80%区间，即约半数请求中"已编码完成时刻"占TTFT总时长约75%左右，与正文"half of the mm-image requests spend 75% of their TTFT before LLM prefilling"的表述在数值量级上一致 [基于视觉的谨慎推断]。
   - mm-video的三条曲线（Downloaded/Normalized/Encoded）依次右移，表明视频请求中三个预处理阶段依次占用递增的TTFT比例，阶段划分比图像更清晰可辨 [图像直接可见]。

5. **它验证的论点与方法设计含义**：本图属于**机制**类证据，把Finding 7中"多模态请求异质性→TTFT延长"这一效果主张具体化为可拆解的因果链：下载/归一化/编码三个前处理阶段各自贡献了显著且长尾分布的延迟，尤其对视频等"multimodal-heavy"请求影响更大 [正文支持]。这为方法设计含义提供依据——正文在§7 Discussion中据此提出"应对modality encoder做解耦并独立弹性扩缩容"的优化方向，本图是该建议的直接实验支撑 [正文支持]。但本图**不能**证明具体的调度/批处理优化方案的效果（论文仅提出必要性，未给出优化方案实验），也不能说明该开销是否受限于特定硬件配置。

6. **适用范围与证据缺口**：本证据覆盖论文报告的mm-image和mm-video两个工作负载（Qwen2.5-VL-72B模型）中随机采样请求的预处理阶段耗时统计。无额外证据缺口。

---

## 图片 2：Figure 12. Behavior of top clients in mm-image. Vertical lines in the last-row subfigures indicate average lengths, and error bars show the range of average lengths within a day.

![Figure 12. Behavior of top clients in mm-image. Vertical lines in the last-row subfigures indicate average lengths, and error bars show the range of average lengths within a day.](../assets/imgs/img_in_chart_box_751_445_1076_545.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文第4.3节"Multimodal Client Decomposition"与Finding 8，属于**机制**类证据。作者需要证明"头部客户端行为的稳定性/结构性可解释整体多模态负载模式"这一因果建模在多模态场景下同样成立，具体问题是："某个头部客户端（Client B）的图像数据是否表现出高度集中、可预测的结构？" [正文支持]。
   - **图表角色**：机制。
   - **上文呼应**：第4.3节 Multimodal Client Decomposition → Finding 8（多模态头部客户端行为多样，刻画后有助解释整体负载模式）；正文明确点名"Client B in Figure 12, who exclusively sends images of the same size (around 1,200 tokens each)"直接对应本图。

2. **图像类型与布局**：两个并列的频率直方图（对数纵轴），标题为"Client B"，构成Figure 12中该客户端对应的一组子面板。左图横轴为Image Tokens（图像token数），右图横轴为Image/Input(%)（图像token占输入总token的比例）；纵轴均为Frequency，采用对数刻度。

3. **如何阅读**：横轴表示具体数值区间（左图为token数绝对值，右图为百分比），纵轴对数刻度的Frequency表示该区间内请求出现的相对频次高低；需要关注柱状分布是否集中在少数区间（尖峰）还是分散（宽分布）。

4. **直接可见的结论**：
   - 左图（Image Tokens）的频率质量高度集中在约1000-1250 token区间的一根或两根高柱，其余区间柱高极低（对数尺度下仍明显低两个数量级以上），显示图像token数几乎固定在同一数值附近 [图像直接可见]，与正文所述"约1,200 tokens each"在数量级上吻合。
   - 右图（Image/Input %）的频率质量同样高度集中在90-95%区间的高柱，其余区间（如80-85%附近有一根次高柱）频次明显更低，显示该客户端请求中图像token占输入的比例也高度集中、结构稳定 [图像直接可见]。

5. **它验证的论点与方法设计含义**：本图属于**机制**类证据，直接支持Finding 8"头部客户端行为多样但内部稳定，有助解释整体负载模式"中的"稳定性"部分——Client B展示出图像大小与图文比例的高度一致性，印证正文"top-client behaviors remain stable and predictable"的具体化实例 [正文支持]。方法设计含义：该证据支撑ServeGen中Client Generator/Client Pool"以客户端为单位刻画trace和dataset"的合理性——因为像Client B这样的头部客户端确实可用少数固定参数（而非复杂随机过程）来刻画其数据分布 [基于文中逻辑的推断]。但本图**仅呈现单一客户端（Client B）的数据分布快照**，不能单独证明"该客户端速率突增与整体图像负载激增在时间上重合"这一时序因果论点（该论点需要Figure 12中的时序/误差棒子面板，未在本次提供的裁剪范围内）。

6. **适用范围与证据缺口**：本证据覆盖mm-image工作负载中头部客户端之一（Client B）在测量期间（24小时）的图像token数与图文比例分布快照。真实缺口：本图为Figure 12的局部裁剪，仅含该客户端的两个直方图面板，缺少Figure 12中用于验证"稳定性"（误差棒/时间范围）及其他客户端（如Client A/C/D）、以及速率随时间变化的子面板，无法据此单独核实"该客户端行为在48小时/24小时内保持稳定"或"其速率变化与整体负载峰值重合"的时序论断，这部分需依赖论文中未提供给本次裁剪的Figure 12其余面板 [OCR/图题冲突——图题标注为完整Figure 12，但实际裁剪仅含Client B的两个直方图]。
