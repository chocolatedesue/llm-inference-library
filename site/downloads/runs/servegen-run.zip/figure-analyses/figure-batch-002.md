# 图片批次 2

## 图片 1：Figure 3. Input and output length distribution. x-axis: # tokens; y-axis: frequency. Each subfigure corresponds to a specific workload and time period, split to two consecutive x-scales to show both the shift in average lengths (left) as well as the tail distribution (right).

![Figure 3. Input and output length distribution. x-axis: # tokens; y-axis: frequency. Each subfigure corresponds to a specific workload and time period, split to two consecutive x-scales to show both the shift in average lengths (left) as well as the tail distribution (right).](../figure-groups/page-0006-b943b2b54dff.png)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：该图组对应 §3.2 "Input and Output Length Distribution"，是效果类证据：验证 Finding 3（输入长度可用 Pareto+Log-normal 混合分布建模、输出长度可用指数分布建模，输入输出相关性弱）与 Finding 4（输入输出长度分布随时间独立漂移）。正文明确将其定位为"我们现在通过考察图 3 中的分布来刻画请求的输入输出长度"，并进一步用图 4 展示输入输出长度的相关性以支持 Finding 4 中"漂移相互独立"的论证。`[正文支持]`
   - **图表角色**：实验结论（分布拟合效果 + 时变漂移的定量证据）。
   - **上文呼应**：第 3.2 节，Finding 3、Finding 4；页码 5-6。

2. **图像类型与布局**：本图为同一页面渲染出的两组曲线/分布图（Panel 1 对应 Figure 3，Panel 2 对应 Figure 4），未拆分为独立组。Panel 1 顶部为图例（Input/Output 直方图、Input Fit/Input Tail Fit/Output Fit 拟合曲线、μ(Input)/μ(Output) 均值线），下方是 4 列（(a) M-mid、(b) M-small、(c) M-long、(d) M-code）× 3 行（Midnight/Morning/Afternoon）的直方图网格，每个子图为双 x 轴（左侧线性刻度看整体均值偏移，右侧对数/长尾刻度看尾部）。Panel 2 顶部图例为"90%"阴影带与"Median"橙色虚线，下方为 3 行（Midnight/Morning/Afternoon）× 2 列的散点/带状图，横轴推测为输入长度、纵轴为输出长度。

3. **如何阅读**：Panel 1 中每个子图需比较 Input（蓝/紫直方图）与 Output（橙直方图）的形状差异，以及三行（Midnight/Morning/Afternoon）之间同一模型的分布是否发生整体偏移或尾部变化；虚线/实线拟合曲线表示 Pareto/Log-normal/Exponential 等候选分布的拟合优度。Panel 2 中应比较不同时间段的阴影带宽度（代表 90% 分位区间的离散程度）与中位数曲线走势，判断输入-输出长度相关性强弱及其随时间是否稳定。

4. **直接可见的结论**：Panel 1 中四个模型的 Input/Output 直方图形状确有差异（如某些列输出直方图更集中于左侧、部分列有明显长尾延伸到右侧对数区域），且同一列内 Midnight/Morning/Afternoon 三行的直方图峰值位置/宽度存在可见移动，表明分布并非静止不变。Panel 2 中各时间段的 90% 阴影带随横轴（输入长度增大）呈现一定的宽度变化，中位数曲线大致呈现轻微上升趋势但波动较大，不同行（时间段）之间的带状范围/中位线走势有可见差异。`[图像直接可见]` 具体数值（如 1.63×、1.46×漂移倍数）在当前图像分辨率下无法逐一读出精确刻度值，只能确认存在可见的分布形状与位置差异。`[基于视觉的谨慎推断]`

5. **它验证的论点与方法设计含义**：Panel 1 的跨模型（M-mid/M-small/M-long/M-code）直方图差异与拟合曲线不一致，直接支持 Finding 3 中"不同工作负载的最佳拟合分布不同、需灵活建模"的效果类主张；同一模型内三个时间段直方图的可见偏移，支持 Finding 4 中"输入输出长度分布随时间发生偏移"的效果类主张，读者应据此理解为何 ServeGen 的 Request Data Sampler 需要按时间参数化数据分布而非使用单一静态分布。Panel 2 中相关性强弱的可见证据（阴影带较宽、中位线非严格单调）支持正文"输入输出长度相关性较弱，且该相关性看起来与时间无关"的表述，但该图本身不能证明本文推测的"漂移由客户端行为驱动"这一因果链条，该因果论证需依赖图 6（客户端分解）等其他证据。`[正文支持]`

6. **适用范围与证据缺口**：本证据覆盖论文报告的 M-mid、M-small、M-long、M-code 四类语言模型工作负载，在 Midnight/Morning/Afternoon 三个时间窗口内的抽样分析（具体窗口时长正文未明确逐条给出，只说"one day"内不同时段采样）。由于当前图像分辨率有限，无法逐一确认子图上具体的坐标刻度数值、拟合曲线的具体分布类型标签（如无法区分某条虚线是 Pareto 还是 Log-normal 拟合），这属于像素/裁剪导致的真实缺口。

---

## 图片 2：Figure 6. Characterization of the top four clients in the M-small workload in isolation, using the first 48-hour data from Figure 2. Vertical lines in the last-row subfigures indicate average input/output lengths, and error bars show the range of average lengths in 1-hour windows.

![Figure 6. Characterization of the top four clients in the M-small workload in isolation, using the first 48-hour data from Figure 2. Vertical lines in the last-row subfigures indicate average input/output lengths, and error bars show the range of average lengths in 1-hour windows.](../figure-groups/page-0007-212d5ecc0a8c.png)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：该图组对应 §3.3 "Client Decomposition"，是机制类证据：验证核心洞见/Finding 5，即"真实负载的复杂漂移模式可归因于少数头部客户端的行为波动，而非整体随机过程"。正文明确用图 6 展示 M-small 前四大客户端（A/B/C/D）在 48 小时内各自的突发性（CV）与输入/输出长度稳定性，以论证"头部客户端在速率之外的各方面均保持稳定"。`[正文支持]`
   - **图表角色**：机制（因果建模的直接实验支持）。
   - **上文呼应**：第 3.3 节，Finding 5；页码 6。

2. **图像类型与布局**：Panel 1 为折线图：横轴为小时（0–48），纵轴为 CV，四条曲线分别对应 Client A（标注速率 2.1）、Client B（1.1）、Client C（1.0）、Client D（1.0）。Panel 2 为直方图组：左侧为 "Client A" 标题下的 Input Length / Output Length 两个对数频率直方图，右侧为 "Client D" 标题下对应的 Input Length / Output Length 直方图，图中带竖线/误差条标注平均长度及其波动范围。

3. **如何阅读**：Panel 1 中应比较四条 CV 曲线随时间的波动幅度：曲线越平直表示该客户端突发性越稳定，曲线出现尖峰或低谷（尤其在凌晨时段）则表示突发性发生变化。Panel 2 中应对比 Client A 与 Client D 的 Input/Output 长度直方图形状、峰值位置及误差条宽度，判断各客户端的数据分布是否集中、稳定。

4. **直接可见的结论**：Panel 1 中 Client A（蓝色，速率最高 2.1）的 CV 曲线明显比 Client B/C/D 更剧烈地上下波动，尤其在图中段（约第 8–16 小时附近）出现较高峰值区域，而 Client B/C/D（速率较低，1.1/1.0/1.0）的曲线基本贴近底部、波动很小。`[图像直接可见]` Panel 2 中 Client A 与 Client D 的 Input Length 直方图均呈现较集中的单峰形态，误差条（竖线附近的短横线范围）看起来较窄；Output Length 直方图均呈现从左侧陡降的长尾形态，两者形状相似但峰值位置和数值范围不同（Client D 的横轴范围小于 Client A）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：Panel 1 中"仅速率最高的 Client A 表现出显著的 CV 波动，而其余三个客户端 CV 曲线近乎平稳"这一可见对比，直接支持 Finding 5 中"头部客户端的行为波动（而非全体客户端）解释了整体负载的突发性变化"这一机制类主张；Panel 2 中 Client A、D 输入/输出长度直方图的窄误差条，支持"头部客户端在长度分布上保持稳定、仅速率本身波动"的机制主张。这两组视觉证据共同构成 ServeGen 中 Client Generator 模块"以客户端为单位建模、按真实速率/CV 分布采样"设计选择的实验依据。该图本身不能证明这一因果结构可推广到多模态或推理场景（那分别由图 11/12、图 17 单独验证），也不能证明具体的"漂移传导到整体负载"的定量贡献比例。`[正文支持]`

6. **适用范围与证据缺口**：本证据覆盖论文报告的 M-small 工作负载中前四大客户端（A/B/C/D），基于图 2 相同的前 48 小时数据窗口。由于当前渲染图像中未见到 Client B、C 的输入/输出长度直方图（Panel 2 仅呈现 Client A 与 D 两个客户端的长度分布，且未见到速率子图行），无法确认 Client B、C 在长度维度上是否同样具备图注所述的"稳定误差条"，这是图像裁剪导致的真实缺口；此外 Panel 1 中标注的数字（如"Client A (2.1)"）具体代表的量（是否为平均速率 req/s）正文图注未明确定义，OCR 与图题也未说明，属于图注与图像内容之间的关联缺口。
