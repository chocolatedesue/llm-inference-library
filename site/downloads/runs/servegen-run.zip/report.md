# 论文解构报告

### 论文元数据

| 字段 | 内容 |
|---|---|
| 标题 | ServeGen: Workload Characterization and Generation of Large Language Model Serving in Production |
| 作者 | Yuxing Xiang, Xue Li, Kun Qian, Yan Zhang, Wenyuan Yu, Ennan Zhai, Xin Jin, Jingren Zhou |
| 发表场所 / 年份 | 23rd USENIX Symposium on Networked Systems Design and Implementation (NSDI '26), 2026 |
| 研究领域 | 计算机系统（LLM 推理服务） |
| 关键词 | LLM推理服务, 工作负载表征, 工作负载生成, 生产环境追踪, 多模态与推理模型 |

### 资源链接

- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：https://github.com/alibaba/ServeGen

> **标签（3–5 个）**：`LLM推理服务` · `工作负载刻画` · `负载生成` · `客户端因果建模` · `PD分离评测`

## 1. 一句话总览

本文基于阿里云 Model Studio 生产环境四个月、超35亿条请求的真实调用日志，对语言、多模态、推理三类大模型服务负载做了迄今规模最大的实证刻画，并提出以"客户端"为基本建模单位的负载生成框架 ServeGen，其在实例配置与 PD 分离评测中比朴素生成方法（NAIVE）更贴近真实系统表现 [作者明确陈述，页码：2]。

## 2. 阅读范围与证据状态

OCR 文本覆盖论文第2–13页的正文论述，含 Findings 1–11 的文字表述及方法、实验、局限章节；图表证据分析覆盖第5–9页共约12组图片（部分图注文字或坐标刻度因像素/裁剪限制无法逐一核实精确数值），另有8张图片因超出处理上限未做视觉分析 [文中未说明具体页码分布，OCR 提示信息]。KS 检验 p 值、CV 计算公式等标准统计量的计算式，论文本身未显式列出，只标注了判定基准或方法名 [文中未说明]。以下论文事实均标注证据类型，区别于本文补充的背景知识（如 prefill/decoding、Zipf 分布等通识性解释）。

## 3. 根问题：论文究竟要解决什么

- **问题定义**：LLM 推理服务系统的设计、优化与评测都依赖"负载（workload，即请求的到达节奏与输入输出长度分布等统计特征）"，但业界对真实生产负载的理解严重不足，缺乏全面的规模化刻画 [作者明确陈述，页码：2]。
- **为什么重要**：负载理解不足会同时损害"研究动机来源"与"评测可信度"——新兴的多模态、推理模型场景的许多特性从未被刻画过，研究者可能错失创新方向；而对于研究较多的普通语言模型场景，使用不真实的负载评测系统（论文称为 NAIVE：泊松/伽马过程采样到达 + ShareGPT 等公开数据集），会导致"看起来很好用"的系统上线后表现骤降，论文引用了已有文献报道的这类真实劣化案例 [作者明确陈述，页码：2]。
- **难点来源**：真实生产负载规模巨大、跨客户端异质、随时间漂移，采集与规模化分析本身需要长期、大范围的生产环境访问权限，这是既有研究（多为局部、短期分析）难以做到的 [基于文中逻辑的推断，依据 Table 2 对比结构，页码：4]。
- **本文的 story**：旧路线在"规模不足"与"把负载当整体随机过程建模"两个技术原因上失效，本文的转折点是发现真实负载的复杂性可归约为"少数头部客户端的行为波动"，并据此把生成负载的最小单元从"全局分布"下沉到"客户端"。

## 4. 旧方法为何不够

| 旧方法/来源 | 它原本解决什么 | 依赖的前提/遗留限制 | 本文批判的具体 limit | 本文回应模块 | 检验实验 |
|---|---|---|---|---|---|
| NAIVE（[33,49,50,55]） | 在无真实负载或隐私限制下简便生成评测负载 [页码：2] | 假设到达可用泊松/伽马过程近似、数据可用公开对话数据集替代 | 生成负载变异性不足、无法体现速率与数据分布的相关性，产生"虚假易服务"假象 [页码：2,11] | Client Generator + Timestamp/Request Data Sampler | §6.2 生成精度对比、§6.3 实例配置案例 [页码：11-12] |
| BurstGPT [46] | 用参数化 Gamma 过程刻画到达突发性 [页码：4] | 仅2个模型、529万请求、仅语言模态 | 规模远小于本文，且不覆盖多模态/推理/客户端分解 [页码：4] | 本文整体三类负载刻画+客户端分解方法学 | 无法从当前 OCR 内容确认具体对比实验，仅 Table 2 范围对比 |
| LMM [38] | 刻画图文模型的图像数据分布 [页码：4] | 仅2天数据，单一模态维度 | 缺失到达模式、漂移、对话等维度 [页码：4] | 本文多模态刻画（§4） | 无法从当前 OCR 内容确认，仅范围对比 |

这些旧方法的共同技术局限可归纳为：要么在"规模"（时长、请求数、模型数）上不足，要么在"范围"（多模态/推理/客户端异质性/时序漂移）上不足 [基于文中逻辑的推断，页码：4]。

## 5. 核心洞见与假设

**核心洞见/贡献**：真实负载中看似复杂的非确定性模式（到达突发性波动、长度分布随时间漂移）并非"整体随机过程"的产物，而是由少数"头部客户端"的行为波动驱动；绝大多数客户端行为本身稳定、可预测 [作者明确陈述，页码：3,6]。

- **为落地该洞见所需的实现组件**：Client Generator、Timestamp Sampler、Request Data Sampler 等（属于实现组成，不单独作为贡献声明）。
- **可行性依据**：
  1. M-small 中 2,412 个客户端，前29个（按速率降序）贡献90%请求 [实验支持，页码：6]；
  2. 头部客户端在突发性、输入/输出长度上表现稳定（误差条窄），仅速率本身波动 [实验支持，页码：6]；
  3. 该因果建模在多模态（mm-image，1,036客户端）与推理（deepseek-r1，25,913客户端）场景中被重复验证 [实验支持，页码：8-9]。
- **前提可能不成立的场景**：该假设建立在阿里云 Model Studio 存在"大量 API 批量调用型头部客户端"这一客户结构上；若目标环境高度去中心化、无头部客户端，该因果建模的适用性尚待验证 [基于文中逻辑的推断，页码：6-10]。

## 6. 方法：从洞见到可执行系统

ServeGen 的总体流程是：先由 Client Generator 依据真实速率/CV 分布采样出一组异质客户端，再由 Timestamp Sampler 为每个客户端生成时变到达时间戳，最后由 Request Data Sampler（含 conversation-aware mocking）为每个请求填充长度等数据特征，三者叠加输出可直接用于评测系统的完整负载 [作者明确陈述，页码：11]。

1. **Client Generator（客户端生成器）**——动机：Finding 5/8/11 显示客户端速率高度倾斜，若不能生成同样倾斜的客户端集合就无法复现真实突发性 [作者明确陈述，页码：11]；过程：从预置 Client Pool 中按真实速率/CV分布采样，或使用用户自定义客户端；输出：带各自 trace/dataset 描述的客户端集合；技术优势：保留客户端异质性而非把整体当单一随机过程 [作者明确陈述]；其有效性未单独设消融，仅通过§6.2整体生成精度间接验证 [文中未说明单独验证]。
2. **Timestamp Sampler（到达时间采样器）**——动机：Finding 1/2 要求到达模型能表达"时变"特性 [作者明确陈述，页码：11]；过程：依据每客户端 trace 参数与总速率的时间函数"缩放客户端速率"，具体缩放算法文中未给出 [文中未说明]；输出：各客户端及汇总到达时间戳序列；技术优势：可生成随时间变化的速率与突发性 [作者明确陈述]。
3. **Request Data Sampler（含 conversation-aware mocking）**——动机：Finding 3/4/6/9 表明长度分布因客户端与时间而异，Finding 10 表明多轮对话会重塑到达节奏 [作者明确陈述，页码：9-11]；过程：为客户端生成长度数据，并通过保留共享对话历史维持多轮结构，具体隐私保护实现文中未说明；技术优势：对照图16，Naive上采样会产生过度突发，而遵循真实ITT分布的方法更接近真实稳定性 [实验支持，页码：10]。

## 7. 为什么它可能有效

- **机制→收益**：以客户端为单位联合建模速率与数据分布，能保留"速率突变常伴随数据分布变化"这一真实关联，NAIVE 因缺乏该关联而系统性低估真实负载压力 [基于文中逻辑的推断，页码：11]。
- **所需条件**：该机制生效的前提是 Client Pool 中的客户端参数（速率、CV、长度分布）能代表目标部署场景的真实客户端结构；若目标场景客户端结构与阿里云平台显著不同，效果需重新验证 [基于文中逻辑的推断，页码：6-10]。
- **时变建模的收益**：允许 Timestamp/Request Data Sampler 按时间参数化，理论上能复现 Finding 2/4 中观测到的漂移现象，但缩放算法细节未公开，实际保真度依赖未披露的实现 [基于文中逻辑的推断，页码：11]。

## 8. 实验与指标：证据是否支撑主张

### 8.1 实验问题与判定标准

- **效果**：真实到达是否具突发性、ServeGen 生成负载是否更贴近真实分布——对应图1(d)拟合优度、§6.2生成精度对比 [页码：4-5,11]。
- **机制**：头部客户端速率波动是否是整体漂移的驱动因——对应§3.3客户端分解（图5、图6）[页码：6]。
- **必要性**：ITT保真、按客户端建模是否为负载真实感所必需——对应图16对比实验 [页码：10]。
- **鲁棒性/适用范围**：ServeGen 优势能否推广到不同模型/负载规模——论文仅在单一模型/单一片段验证，未做跨规模鲁棒性实验 [文中未说明]。

### 8.2 数据、任务、对比与运行设置

- 数据来源：阿里云 Model Studio 全球云 LLM 服务日志，四个月、超35亿条请求 [作者明确陈述，页码：2]。
- 任务/模型版本：覆盖12个语言/多模态/推理模型工作负载（如M-large、M-small、mm-image、deepseek-r1等），各自采样窗口从一天到一个月不等（Table 1）[页码：3]。
- 硬件/软件、重复次数、统计方式：文中未说明。
- 基线：NAIVE（Poisson/Gamma+ShareGPT）；对比系统案例中的基线为 vLLM 默认配置策略与不同 PD 配置 [页码：11-13]。

### 8.3 指标字典与对应公式

- **指标与方向**：CV（变异系数）；测量到达间隔时间(IAT)离散程度，无量纲；CV=1对应泊松过程，越大越突发。**定义与公式**：来源层级为无可核验公式——文中仅给出判定基准"CV=1对应泊松"，未列出标准差/均值的具体计算式 [页码：4-5]。**实验用途**：判定 Finding 1/2/10/11 中的突发性。**读数与边界**：M-large/M-small/M-mid在图2中CV分别约1.29/1.12/1.07，均大于1，但精确统计方式不可验证 [实验支持，页码：4-5]。
- **指标与方向**：过/欠配比例；测量实例配置数相对实际所需数的偏差，越接近0越好。**定义与公式**：来源层级为推导关系（非原文公式）——作者给出"ServeGen多配4%、NAIVE少配50%"的文字描述，推理依据：由此可凝练出 (配置数−实际所需数)/实际所需数×100% [基于文中逻辑的推断，页码：12]。**实验用途**：评估图20热力图中两种方法的配置准确性。**读数与边界**：仅在M-large配Qwen2.5-14B的单一10分钟窗口验证，能否推广到其他模型文中未说明 [实验支持，页码：12]。
- **指标与方向**：长度漂移倍数（如1.63×）；测量一天内平均长度的最大/最小值之比，无固定方向。**定义与公式**：来源层级为推导关系（非原文公式）——作者文字定义"最大平均长度除以最小平均长度"，推理依据：可凝练为 $\text{Shift}=\dfrac{\max(\bar L_t)}{\min(\bar L_t)}$ [基于文中逻辑的推断，页码：6]。**实验用途**：量化 Finding 4 的时变漂移幅度。**读数与边界**：具体数值仅描述性给出，未提供置信区间。
- **指标与方向**：P99 TTFT/TBT；测量首字延迟/逐字延迟的第99百分位，单位毫秒，越低越好。**定义与公式**：无可核验公式，作者仅描述用途未给出百分位计算式 [页码：11-12]。**实验用途**：判定§6.3 SLO是否达标。**读数与边界**：具体数值文中未在OCR文本给出，需图表核实。

### 8.4 主结果、消融与证据边界

**比较工作与被批判限制的呼应**

| 比较工作/基线 | 核心限制/失效条件 | 本文对应模块 | 直接实验与仍未验证的边界 |
|---|---|---|---|
| NAIVE | 变异性不足、无速率-数据分布关联、导致欠配假象 [页码：11-12] | Client Generator+Sampler | §6.2/§6.3已验证；能否推广到多模态/推理场景负载生成文中未说明 |
| BurstGPT/LMM | 规模/范围不足 [页码：4] | 三类负载整体刻画框架 | 无直接定量对比实验，仅Table 2范围对比 |
| PD-disaggregation相关工作 | 真实部署性能"难以充分刻画" [页码：12] | 用ServeGen作更真实评测输入 | §6.4验证；因果解释用"likely"表述，非确定性结论 |

**主张与证据强度**

| 主张 | 直接证据 | 证据强度与边界 |
|---|---|---|
| 到达具超越单一随机过程的突发性 | 图1(d) KS检验 | [实验支持]，页码4-5；无逐一p值数值表 |
| 头部客户端速率波动驱动整体漂移 | §3.3客户端分解、图2/图6对应 | [作者明确陈述]，页码6；时序精确重合度需视觉核实 |
| ServeGen比NAIVE更贴近真实统计特征 | §6.2文字描述、图19 | [实验支持]，页码11；无量化误差指标(如MAE) |
| NAIVE导致资源欠配假象 | §6.3，"少配50%" | [实验支持]，页码12；单一场景，非统计意义普适结论 |

- 论文未给出与 BurstGPT/LMM 的同数据集定量对比实验，属证据缺口而非补造 [文中未说明]。
- §6.3、§6.4 案例均基于单一模型/单一负载片段，能否推广到多模态或推理场景文中未说明 [文中未说明]。

## 9. 图表解读与论证关系

### 图片原件与标题

#### 原始图片 1：Figure 2. Long-term rate and CV shifts.

![Figure 2. Long-term rate and CV shifts.](assets/imgs/img_in_chart_box_131_468_555_714.jpg)

*来源：OCR 第 5 页。*

---

#### 原始图片 2：Figure 1. Inter-arrival time characterization.

![Figure 1. Inter-arrival time characterization.](figure-groups/page-0005-a0bc69659dbe.png)

*来源：OCR 第 5 页。*

---

#### 原始图片 3：Figure 3. Input and output length distribution. x-axis: # tokens; y-axis: frequency. Each subfigure corresponds to a specific workload and time period, split to two consecutive x-scales to show both the shift in average lengths (left) as well as the tail distribution (right).

![Figure 3. Input and output length distribution. x-axis: # tokens; y-axis: frequency. Each subfigure corresponds to a specific workload and time period, split to two consecutive x-scales to show both the shift in average lengths (left) as well as the tail distribution (right).](figure-groups/page-0006-b943b2b54dff.png)

*来源：OCR 第 6 页。*

---

#### 原始图片 4：Figure 6. Characterization of the top four clients in the M-small workload in isolation, using the first 48-hour data from Figure 2. Vertical lines in the last-row subfigures indicate average input/output lengths, and error bars show the range of average lengths in 1-hour windows.

![Figure 6. Characterization of the top four clients in the M-small workload in isolation, using the first 48-hour data from Figure 2. Vertical lines in the last-row subfigures indicate average input/output lengths, and error bars show the range of average lengths in 1-hour windows.](figure-groups/page-0007-212d5ecc0a8c.png)

*来源：OCR 第 7 页。*

---

#### 原始图片 5：Figure 5. Client heterogeneity in terms of rate, etc. All CDFs are weighted by client rates.

![Figure 5. Client heterogeneity in terms of rate, etc. All CDFs are weighted by client rates.](figure-groups/page-0007-b80ca85e156c.png)

*来源：OCR 第 7 页。*

---

#### 原始图片 6：Figure 9. Ratio of multimodal input tokens per request in mm-image, mm-audio, and mm-video. Numbers indicate the average ratio.

![Figure 9. Ratio of multimodal input tokens per request in mm-image, mm-audio, and mm-video. Numbers indicate the average ratio.](figure-groups/page-0008-134408fd9c7d.png)

*来源：OCR 第 8 页。*

---

#### 原始图片 7：Figure 8. Characterization of omni-modal inputs in mm-omni. Left: number of multimodal inputs per request. Right: arrival rate of multimodal and text tokens, normalized by the total input rate.

![Figure 8. Characterization of omni-modal inputs in mm-omni. Left: number of multimodal inputs per request. Right: arrival rate of multimodal and text tokens, normalized by the total input rate.](figure-groups/page-0008-89c74b0d74e0.png)

*来源：OCR 第 8 页。*

---

#### 原始图片 8：Figure 7. Characterization of multimodal inputs in mm-image, mm-audio, and mm-video (Rows). Columns: (a) #multimodal inputs per request; (b) length distribution of inputs; (c) correlation between text and multimodal tokens; (d) overall arrival rate of multimodal and text tokens.

![Figure 7. Characterization of multimodal inputs in mm-image, mm-audio, and mm-video (Rows). Columns: (a) #multimodal inputs per request; (b) length distribution of inputs; (c) correlation between text and multimodal tokens; (d) overall arrival rate of multimodal and text tokens.](figure-groups/page-0008-9dac689f7a93.png)

*来源：OCR 第 8 页。*

---

#### 原始图片 9：Figure 10. Breakdown of first-token time when serving requests with image or video inputs (mm-image and mm-video).

![Figure 10. Breakdown of first-token time when serving requests with image or video inputs (mm-image and mm-video).](figure-groups/page-0009-31f2fcc5f6aa.png)

*来源：OCR 第 9 页。*

---

#### 原始图片 10：Figure 12. Behavior of top clients in mm-image. Vertical lines in the last-row subfigures indicate average lengths, and error bars show the range of average lengths within a day.

![Figure 12. Behavior of top clients in mm-image. Vertical lines in the last-row subfigures indicate average lengths, and error bars show the range of average lengths within a day.](assets/imgs/img_in_chart_box_751_445_1076_545.jpg)

*来源：OCR 第 9 页。*

---

#### 原始图片 11：Figure 13 characterizes request lengths in the deepseek-r1 workload, depicting also the reason and answer parts of outputs. In the upper part of Figure 13(a), we observe similar power-law distributions and shifting patterns (Finding 3 and 4) in terms of input and output lengths, as indicated by the fitting

![Figure 13 characterizes request lengths in the deepseek-r1 workload, depicting also the reason and answer parts of outputs. In the upper part of Figure 13(a), we observe similar power-law distributions and shifting patterns (Finding 3 and 4) in terms of input and output lengths, as indicated by the fitting](figure-groups/page-0009-6a8216916f90.png)

*来源：OCR 第 9 页。*

---

#### 原始图片 12：Figure 11. Clients in mm-image. CDFs are weighted by rates.

![Figure 11. Clients in mm-image. CDFs are weighted by rates.](figure-groups/page-0009-6b390da900c3.png)

*来源：OCR 第 9 页。*

### 图1：速率与CV随时间漂移（页5）

- **图组结论**：M-large 持续突发两日后转稳定，M-rp 全程平稳，M-code 仅日内特定时刻剧烈尖峰，四条负载曲线漂移模式各异 [图像直接可见，页码：5-6]。
- **论证关系**：该证据→支撑 Finding 2"速率与突发性随时间多样化漂移"→与后续§3.3客户端分解（图5/6）互补，共同构成漂移现象与其成因的证据链 [正文支持]。
- **适用范围**：本图不解释漂移成因，仅覆盖四个语言模型负载，不含 M-mid。

### 图2：IAT分布与分布拟合优度（页5）

- **图组结论**：三个工作负载CV均>1，且没有一种参数化分布（Expon/Gamma/Weibull）在所有工作负载上普遍最优 [图像直接可见，页码：4-5]。
- **论证关系**：该证据→支撑 Finding 1→为 Timestamp Sampler"允许每客户端灵活选择分布"的设计提供直接依据。
- **适用范围**：不能证明何种因素导致最优分布因负载而异，该因果解释由后续客户端分解图给出。

### 图3/图4：输入输出长度分布与相关性（页6-7）

- **图组结论**：四个模型的长度直方图形态各异，且同一模型内不同时间段的直方图峰值/宽度存在可见位移；输入输出长度相关性弱、无稳定强相关模式 [图像直接可见，页码：5-6]。
- **论证关系**：该证据→支撑 Finding 3/4→说明 Request Data Sampler 需按时间参数化数据分布。
- **适用范围**：无法逐一读出精确漂移倍数数值；不证明漂移由客户端行为驱动，该因果需依赖图6。

### 图5/图6：客户端速率倾斜与头部客户端稳定性（页6-7）

- **图组结论**：前29个客户端（2,412个中）贡献约90%加权请求；Client A（速率最高）CV波动剧烈，其余客户端CV近乎平稳；Client A/D长度分布误差条窄 [图像直接可见，页码：6]。
- **论证关系**：该证据→直接支撑核心洞见 Finding 5→为 Client Generator"按真实速率/CV异质采样"设计提供实验依据。
- **适用范围**：Client B/C的长度稳定性未在裁剪图中出现，无法逐一核实；不证明该机制可推广至多模态/推理场景（由后续图验证）。

### 图9/图10：多模态请求异质性与TTFT分解（页8-9）

- **图组结论**：mm-image/audio/video三种模态输入占比呈全区间分布而非单峰集中；视频请求的下载/归一化/编码耗时中位数均显著高于图像（如编码1022ms vs 249ms）[图像直接可见，页码：8-9]。
- **论证关系**：该证据→支撑 Finding 7"多模态异质性导致TTFT延长"→为§7讨论"编码器解耦弹性扩缩容"提供机制依据。
- **适用范围**：不能证明具体调度优化方案的效果，论文仅提出必要性未做优化实验。

### 图7/图8：多模态数据分布与漂移（页8）

- **图组结论**：Image/Audio/Video在"每请求携带输入数量"上差异巨大（如Image max=49，Video max=1）；长度分布呈多峰非幂律形态，且Midnight/Noon时段分布存在可见偏移 [图像直接可见，页码：8]。
- **论证关系**：该证据→支撑 Finding 6→说明模态负载无法用文本长度间接推断，需独立参数化。
- **适用范围**：图例中部分曲线（深灰/青色）无法辨认所属模态，属图像本身缺口。

### 图11/图12：多模态客户端分解（页8-9）

- **图组结论**：mm-image中35个客户端即达90%加权累计占比，Client A/B图像长度与占比高度集中（窄误差条）[图像直接可见，页码：8]。
- **论证关系**：该证据→支撑 Finding 8→将 Finding 5 的因果建模从语言模型场景扩展到多模态场景。
- **适用范围**：图中突出的Client A与正文举例的Client B是否为同一客户端无法确认；不证明该机制适用于mm-audio/video/omni。

### 图13：推理负载长度与比值分布（页9）

- **图组结论**：Reason长度整体更长、跨度更大于Answer；Answer/Output占比呈双峰分布，Midnight/Noon两时段形状高度相似 [图像直接可见，页码：9]。
- **论证关系**：该证据→支撑 Finding 9→为"两种主导任务模式"的机制类推断提供分布层面的先导观察。
- **适用范围**：不证明双峰确由两类任务导致，该分类未做细分实验验证。

## 10. 完整因果推理树

- 根问题：真实生产 LLM 服务负载缺乏全面刻画，导致新场景研究动机不足、评测系统不可信
  - 旧方法限制：局部/短期分析规模范围不足（BurstGPT/LMM）；NAIVE生成方法产生"虚假易服务"负载 [页码：2,4]
  - 核心洞见/假设：负载复杂性可归约为少数头部客户端的行为波动（Finding 5/8/11）[页码：6-10]
    - 方法模块：Client Generator（按真实速率/CV异质采样）[页码：11]
      - 可验证预测：以客户端为单位生成的负载在速率-数据分布关联上优于NAIVE
        - 指标与实验：§6.2生成精度对比（图19）
          - 图表证据：图19定性显示"匹配更好"，无量化误差指标 [实验支持，页码：11]
            - 结论与适用边界：仅定性验证，缺MAE/RMSE等量化读数，未覆盖多模态/推理场景生成
    - 方法模块：Timestamp Sampler（时变到达建模）[页码：11]
      - 可验证预测：时变速率函数可复现 Finding 1/2 的漂移与突发特征
        - 指标与实验：CV、拟合优度（KS检验）对比
          - 图表证据：图1、图2显示原始负载存在多样化漂移与非统一最优分布
            - 结论与适用边界：Timestamp Sampler具体缩放算法未公开，保真度未被当前证据直接验证 [文中未说明]
    - 方法模块：Request Data Sampler + conversation-aware mocking [页码：11]
      - 可验证预测：ITT保真的数据采样比Naive上采样更接近真实突发性
        - 指标与实验：§5.2图16对比
          - 图表证据：图16显示遵循真实ITT分布方法更稳定 [实验支持，页码：10]
            - 结论与适用边界：仅在deepseek-r1单一工作负载验证，其他推理模型适用性文中未说明
  - 应用验证：ServeGen在实例配置（§6.3）与PD分离（§6.4）案例中暴露NAIVE导致的欠配与配置分歧
    - 图表证据：图20热力图（欠配50% vs 多配4%）、图21 SLO对比
      - 结论与适用边界：单一模型/单一负载片段验证，跨模型/跨规模的鲁棒性未被当前证据直接验证 [文中未说明]

## 11. 结论、贡献与边界

- **贡献总结**：(1) 迄今规模最大范围最全的生产级LLM服务负载刻画；(2) 发现客户端分解揭示的因果建模；(3) 开源ServeGen负载生成框架 [作者明确陈述，页码：2]。
- **证据充分的结论**：真实负载短期到达具突发性且无统一最优分布（图1、图2实验支持）；客户端速率高度倾斜且头部客户端可解释整体漂移（图5、图6实验支持）；NAIVE生成负载会导致资源欠配（§6.3实验支持）。
- **尚属推断的意义**：长尾请求导致PD分离性能不均衡是作者用"likely"表述的推断，非确定性因果证明 [基于文中逻辑的推断，页码：12]；Answer/Output比值双峰源于两类任务模式也是推断，未做任务细分验证 [基于文中逻辑的推断，页码：9]。
- **适用条件与局限**（作者自述，页码：13）：未覆盖插件调用场景；因保密义务未覆盖前缀缓存特性；纵向研究时长不足以支持跨月度趋势分析。
- **审稿式风险检查**：
  - 贡献新意：核心发现（客户端分解因果建模）建立在特定平台客户结构上，泛化性依赖未验证的前提，当前证据未覆盖去中心化客户结构场景。
  - 写作/可复现性：Timestamp Sampler具体缩放算法、conversation-aware mocking实现细节均未公开，复现存在障碍 [文中未说明]。
  - 效果大小：ServeGen对NAIVE的优势多为定性描述（"匹配更好"），缺少统一的量化误差指标，效果幅度不易独立核实。
  - 实验覆盖：§6.3/§6.4案例均为单一模型/单一时间片段，未做跨模型跨规模重复实验，当前证据未显示鲁棒性风险已被排除或已被证实存在。
  - 方法设计：与BurstGPT/LMM无同数据集定量对比，仅特征范围对比，当前证据未显示该省略导致结论错误，但确属证据缺口。

## 12. 术语与第一性原理学习路径

### 12.1 核心术语

- **术语**：到达间隔时间(IAT)与变异系数(CV)。**第一性原理角色**：IAT是相邻两请求到达时间差这一基本状态量，CV=标准差/均值，是连接"到达随机性"与"系统突发压力"的因果桥梁。**本文位置**：贯穿Finding 1/2/10/11判定突发性 [页码：4]。
- **术语**：客户端(client)。**第一性原理角色**：本文的基本建模单位，是"请求生成主体"这一基本对象，其速率、CV、长度分布构成负载异质性的资源约束来源。**本文位置**：Finding 5核心洞见及Client Generator设计基础 [页码：6,11]。
- **术语**：Pareto+Log-normal混合分布/指数分布。**第一性原理角色**：描述输入/输出长度这一状态量的统计约束形态，决定了负载生成时应采样何种分布族。**本文位置**：Finding 3 [页码：6]。
- **术语**：prefill与decoding阶段。**第一性原理角色**：LLM推理的两种基本计算机制，分别受并行计算能力与内存带宽约束，是TTFT/TBT等指标的物理成因。**本文位置**：贯穿全文延迟相关讨论 [页码：3]。
- **术语**：PD分离(PD-disaggregation)。**第一性原理角色**：一种资源分配机制，将两种不同资源约束（计算密集vs带宽受限）的阶段物理隔离，以避免相互抢占。**本文位置**：§6.4案例研究 [页码：12]。
- **术语**：conversation-aware mocking。**第一性原理角色**：在生成数据时保留多轮对话历史结构这一约束，以维持ITT分布不被破坏。**本文位置**：Request Data Sampler模块 [页码：11]。
- **术语**：SLO/TTFT/TBT/P99。**第一性原理角色**：延迟类可观测指标，P99作为尾部统计量刻画最坏情况约束。**本文位置**：§6.3实例配置SLO判定 [页码：11-12]。

### 12.2 学习路径

1. 先理解"请求"这一基本对象及其属性（到达时刻、输入/输出长度）——这是负载刻画的最小单元。
2. 再理解 prefill/decoding 两阶段的计算资源约束——这是延迟指标（TTFT/TBT）产生的物理根源。
3. 掌握 IAT/CV 与常见分布族（泊松、Gamma、Pareto、指数）的机制含义——这是判断"负载有多随机/多突发"的数学工具。
4. 理解"客户端"作为异质性来源的角色——这是本文核心洞见（头部客户端驱动漂移）的因果链起点。
5. 最后理解 SLO/P99 等系统行为指标如何把上述机制转化为可评测的系统表现——这是连接负载特征与工程决策（如PD配置）的桥梁。

---

*本报告由 paper-pipeline 生成 · prompt `v11` · backend `cli_agent` · model `claude-sonnet-5` · 2026-07-26T11:08:51*
