# 图片批次 4

## 图片 1：Figure 7. Left: default preemptive auto-scaling process for an inference engine. Middle and Right: typical composition of an LLM inference engine, and the latency breakdown of its initialization (both before and after our optimization).

![Figure 7. Left: default preemptive auto-scaling process for an inference engine. Middle and Right: typical composition of an LLM inference engine, and the latency breakdown of its initialization (both before and after our optimization).](../assets/imgs/img_in_image_box_106_142_1117_302.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`消融验证` `[正文支持]`
   - **上文呼应**：对应报告中第 4 节“高效抢占式自动扩缩容引擎优化”与§5.1“Component Reuse” `[正文支持]`。针对默认推理引擎抢占式扩缩容开销高（高达 26.9 秒）的机制瓶颈，验证其具体耗时构成及通过组件复用（Component Reuse）削减引擎初始化开销的有效性 `[正文支持]`。

2. **图像类型与布局**：
   - 多 Panel 组合图，包含时序阶段流程图、结构组成框图和堆叠柱状图。
   - 左图为默认抢占式扩缩容的时序阶段流程图，纵轴为 Stages（分为 Scale Down 与 Scale Up 阶段），横轴为 Time，展示从 `KVout`、`gc` 到引擎初始化 `Inference Engine Initialization`（包含 `Misc`、`DistExec_init`、`Model_in`、`Profile`、`KV_init`）再到 `KVin` 的完整串行流程，底部红条标明总开销 $T_0$。
   - 中图为推理引擎结构图，展开展示 Inference Engine 中 Worker（含 Tokenizer/Comm Group、Model Weights、GPU/CPU KV Cache）以及底层的 Distributed Executor (Ray/NCCL)、Profiling & Opt.、Other Components 等模块。
   - 右图为初始化耗时对比堆叠柱状图，纵轴为 Time (seconds)（0–30s），横轴对比 vLLM 默认初始化与 Aegaeon 优化后的耗时及 5 个子项（Dist. Executor、Profiling & Opt.、Model Loading、KV Cache、Other）的分解。

3. **如何阅读**：
   - 左图按从上至下（Scale Down 到 Scale Up）与从左至右（时间推进）顺序阅读各阶段耗时叠加；
   - 中图识别推理引擎中通用可复用组件与模型特异性组件；
   - 右图对比 vLLM 柱体与 Aegaeon 柱体的总高度（26.9s 对比 0.8s）及 5 种纹理代表的子项耗时。

4. **直接可见的结论**：
   - 左图显示未优化的抢占式扩缩容在切换模型时必须依次经历 KV Cache 卸载、垃圾回收、引擎初始化（多项子步骤串行）及 KV Cache 加载，总耗时为 $T_0$ `[图像直接可见]`。
   - 中图显示推理引擎包含 Tokenizer、Comm Group、Distributed Executor (Ray/NCCL)、Profiling & Opt. 等多个独立于特定模型的通用系统组件 `[图像直接可见]`。
   - 右图显示 vLLM 默认初始化总耗时为 26.9s，其中 Dist. Executor 占 ~8.4s，Profiling & Opt. 占 ~11.8s，Model Loading 占 ~4.6s，KV Cache 占 ~1.8s，Other 占 ~0.3s；而 Aegaeon 通过组件复用将总初始化耗时削减至 0.8s，移除了 Dist. Executor 和 Profiling & Opt. 等绝大部分耗时 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：
   - 验证了论文中“引擎初始化开销占抢占式扩缩容延迟的大头（超 80%），且绝大部分开销非模型权重加载本身”的机制诊断（属于`机制主张`，`[正文支持]`）。
   - 支持了组件复用（Component Reuse）的方法设计：通过在实例启动时一次性初始化并缓存分布式执行器、算子 Profiling 与 Tokenizer 等通用组件，避免每次模型切换时重复初始化，成功将扩缩容开销降低了 97%（从 26.9s 降至 0.8s），使 Token 粒度抢占式扩缩容在工程上成为可能 `[正文支持]`。

6. **适用范围与证据缺口**：
   - **实际覆盖范围**：覆盖论文在 13B 模型（TP=2）和 PCIe 4.0 环境下对 vLLM 引擎初始化开销的微基准拆解与 Aegaeon 组件复用优化测试 `[正文支持]`。
   - **真实证据缺口**：无额外证据缺口。

---

---

## 图片 2：Figure 9. Explicitly managed memory in Aegaeon, with exemplar memory sizes in brackets. Relevant steps for scaling up a model and operations on the unified KV cache are also illustrated.

![Figure 9. Explicitly managed memory in Aegaeon, with exemplar memory sizes in brackets. Relevant steps for scaling up a model and operations on the unified KV cache are also illustrated.](../assets/imgs/img_in_image_box_633_146_1114_490.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`方法流水线` `[正文支持]`
   - **上文呼应**：对应报告中第 4 节“高效抢占式自动扩缩容引擎优化”与§5.2“Explicit Memory Management” `[正文支持]`。阐明 Aegaeon 如何通过自研 VRAM/DRAM 内存池、模型预取与统一 KV Cache Slab 分配器解决内存碎片和 GC 停顿问题 `[正文支持]`。

2. **图像类型与布局**：
   - 内存架构与数据流示意图，分为顶部 Monkey-patch、GPU VRAM 缓冲区、CPU DRAM 缓冲区及底部 Unified KV Cache 4 个部分。
   - 左上展示 Python 类 Patch 替换关系 (`aegaeon.Parameter` 替换 `torch.nn.Parameter`)；
   - 右上与中部分别展示 GPU #1 (VRAM) 与 CPU (DRAM) 的内存划分及 PCIe 传输关系，标注 Bump Allocated、Page-Locked 等图标及 1. Monkey-patch, 2. Allocate, 3.a Direct load, 3.b Prefetch/Copy 操作步骤；
   - 底部展示 Unified KV Cache 的 Slab 块切分（Full Slab、Unallocated Slab、Allocated Slab w/ Free Blocks）及 `alloc`/`free` 操作动态过程。

3. **如何阅读**：
   - 参照左侧图例理解 Bump Allocated（堆叠图标）、Page-Locked（锁图标）和 Python Class（文件图标）含义；
   - 按照编号步骤（1 $\rightarrow$ 2 $\rightarrow$ 3.a/3.b）观察模型权重从 CPU DRAM 到 GPU VRAM 的 Direct load 或 Prefetch & Copy 路径；
   - 底部按从上至下的三状态变化观察执行 `alloc`（分配 3 个 block）与 `free`（释放 3 个 block）时 Slab 内部块的状态更新。

4. **直接可见的结论**：
   - Aegaeon 在 GPU VRAM 中预先分配连续的 Self-Managed Buffer，划分为 Model Weights (14 GB)、Prefetched Weights (28 GB, optional) 与 Unified GPU KV Cache (30 GB)，并通过 Monkey-patch 使用 `aegaeon.Parameter` 替换 `torch.nn.Parameter` `[图像直接可见]`。
   - CPU DRAM 中划分 Page-Locked Stage Buffer (2 GB)、Model Cache (640 GB) 和 Unified CPU KV Cache (320 GB)，支持模型权重 Direct load 以及 Prefetch 到 GPU 预取区再做内部 Copy `[图像直接可见]`。
   - 底部 Unified KV Cache 采用固定 Slab 切分（蓝色的 Full Slab、灰色的 Unallocated Slab、黄色的 Allocated Slab w/ Free Blocks），分配 (`alloc`) 和释放 (`free`) 均在 Slab 内部以 block 粒度完成 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：
   - 验证了 Aegaeon 显式内存管理（Explicit Memory Management）机制的设计完整性 `[正文支持]`。
   - 方法设计含义：Self-Managed Buffer 绕过 PyTorch 默认分配器，消除了 `empty_cache()` 和 GC 停顿耗时；DRAM Model Cache 与 Page-Locked Stage Buffer 确保了稳定的 PCIe 传输与模型预取能力；统一 KV Cache Slab 分配器解决了不同模型 KV Cache Shape 差异带来的 DRAM/VRAM 内存碎片，将显存碎片率控制在 20% 以下，保障了亚秒级扩缩容的稳定性 `[正文支持]`。

6. **适用范围与证据缺口**：
   - **实际覆盖范围**：覆盖论文在单 GPU 实例及 Host 内存环境下的显式内存分配与 KV Cache Slab 管理架构设计 `[正文支持]`。
   - **真实证据缺口**：无额外证据缺口。
