# 图片批次 6

## 图片 1：Figure 12. End-to-end SLO attainment under varying RPS with alternative datasets. x-axis: number of models.

![Figure 12. End-to-end SLO attainment under varying RPS with alternative datasets. x-axis: number of models.](../assets/imgs/img_in_chart_box_108_435_1115_646.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：作者展示 Figure 12 旨在验证 Aegaeon 在输入/输出 Prompt/Token 长度翻倍变体数据集（ShareGPT-ix2 与 ShareGPT-ox2）下端到端 SLO 达成率（SLO Attainment）与 Goodput 表现对通用数据集结果的泛化性 `[正文支持]`。该图试图验证 Core Claim 1 中的“效果主张”，即 Token 粒度抢占式扩缩容与 Prefill/Decoding 解耦调度在不同负载特征（长输入或长输出）下依然能够突破请求级扩缩容与静态多路复用的池化瓶颈 `[基于文中逻辑的推断]`。
   - **图表角色**：实验结论
   - **上文呼应**：对应报告“实验、指标与文字可确认的结论”第 1 节“池化能力与 Goodput 提升”以及“主张地图与证据计划”中的“效果主张 (Effectiveness)”。
2. **图像类型与布局**：4 Panel 2x2 结构折线图。分为 (a) RPS = 0.1, ShareGPT-ix2、(b) RPS = 0.1, ShareGPT-ox2、(c) RPS = 0.5, ShareGPT-ix2 和 (d) RPS = 0.5, ShareGPT-ox2。顶部包含统一图例（Aegaeon 蓝色、ServerlessLLM 橙色、ServerlessLLM+ 绿色、MuxServe 红色）。
3. **如何阅读**：横坐标为模型数量（#Models），纵坐标为端到端 SLO 达成率（SLO Attainment (%)，范围 0-100%）。灰色水平虚线表示 90% SLO 达成率目标线；各方法折线对应的垂直虚线标记满足 90% SLO 门槛的最大模型承载量（Goodput 上限）。
4. **直接可见的结论**：
   - 在 (a) RPS = 0.1, ShareGPT-ix2 下，Aegaeon 的 90% SLO 垂直虚线达到 70 个模型，ServerlessLLM+ 约 53 个，ServerlessLLM 约 36 个，MuxServe 止于 32 个；80 个模型时 Aegaeon 的 SLO 达成率依然保持在 ~80% `[图像直接可见]`。
   - 在 (b) RPS = 0.1, ShareGPT-ox2（输出长度翻倍）下，Aegaeon 的 90% SLO 门槛到达 60 个模型，而 ServerlessLLM 在 29 个模型处即跌破 90%，ServerlessLLM+ 在 ~39 个模型处跌破 90% `[图像直接可见]`。
   - 在 (c) RPS = 0.5, ShareGPT-ix2 下，高到达率加剧排队，ServerlessLLM+ 表现劣于 ServerlessLLM（在 17 个模型处即跌破 90%），而 Aegaeon 在 ~45 个模型处仍满足 90% SLO `[图像直接可见]`。
   - 在 (d) RPS = 0.5, ShareGPT-ox2 下，ServerlessLLM 和 ServerlessLLM+ 的 SLO 达成率迅速崩塌（16 个模型时已分别低于 80% 和 50%），而 Aegaeon 在 52 个模型全范围内均维持在 90% 以上 `[图像直接可见]`。
   - MuxServe 在所有 4 个子图中均于 32 个模型处终止绘制 `[图像直接可见]`。
5. **它验证的论点与方法设计含义**：
   - 验证了 Aegaeon 在变体数据集（长输入/长输出）下具备强鲁棒性，证明了 Token 级调度与全栈扩缩容优化可以在长文本/高 RPS 条件下有效掩盖扩缩容延迟 `[基于文中逻辑的推断]`。
   - 解释了 MuxServe 的静态显存瓶颈（单 GPU 最多放置 2 个模型，16 GPU 只能承载 32 个模型） `[正文支持]`；同时也验证了定理 3.1 对请求级扩缩容（ServerlessLLM）在长输出场景下活跃模型过多导致队头阻塞（HOL Blocking）的理论推导 `[基于文中逻辑的推断]`。
   - 解释了 ServerlessLLM+（SJF 调度）在高 RPS / 长输出下因频繁无意义扩缩容导致开销激增、性能反低于 ServerlessLLM 的现象，反衬出 Aegaeon 中 Grouped FCFS 和 Weighted Round-Robin 抑制无效扩缩容设计的重要性 `[正文支持]`。
6. **适用范围与证据缺口**：本实验覆盖 16 张 H800 GPU（6 Prefill + 10 Decoding），评估 ShareGPT 变体数据集（ix2 与 ox2）在 RPS=0.1 及 0.5 下的表现 `[正文支持]`。无额外证据缺口。

---

## 图片 2：Figure 11. End-to-end SLO attainment under varying RPS with the ShareGPT dataset.

![Figure 11. End-to-end SLO attainment under varying RPS with the ShareGPT dataset.](../assets/imgs/img_in_chart_box_108_139_1117_392.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：作者展示 Figure 11 旨在评估 Aegaeon 在标准 ShareGPT 数据集上的端到端性能表现，对比现有 SOTA 池化系统（ServerlessLLM、ServerlessLLM+、MuxServe）在不同模型数量与单模型请求到达率（RPS）下的 SLO 达成率（SLO Attainment）与 Goodput 容量 `[正文支持]`。该图试图验证 Core Claim 1 中的“效果主张”，即 Aegaeon 支持单 GPU 承载多达 7 个模型，并能承受 2-2.5 倍的请求到达率提升或 1.5-9 倍的 Goodput 提升 `[正文支持]`。
   - **图表角色**：实验结论
   - **上文呼应**：对应报告“实验、指标与文字可确认的结论”第 1 节“池化能力与 Goodput 提升”以及“比较工作与受批判限制地图”。
2. **图像类型与布局**：3 Panel 1x3 结构折线图。分别包含 (a) RPS = 0.1（横轴为模型数 #Models，范围 20-80）、(b) RPS = 0.5（横轴为模型数 #Models，范围 16-52）、(c) 40 models（横轴为平均请求到达率 Average Arrival Rate (req/s)，范围 0.0-0.75）。顶部包含统一图例（Aegaeon 蓝色、ServerlessLLM 橙色、ServerlessLLM+ 绿色、MuxServe 红色）。
3. **如何阅读**：纵坐标均为端到端 SLO 达成率（SLO Attainment (%)，范围 0-100%）。灰色水平虚线代表 90% SLO 目标线；垂直虚线标注各基线在 90% SLO 约束下的容量上限（最大模型数或最大 RPS）。
4. **直接可见的结论**：
   - 在 (a) RPS = 0.1 下，仅有 10 张 Decoding GPU 的系统，Aegaeon 满足 90% SLO 目标的模型数量上限达 70 个（垂直蓝色虚线），相当于 7 模型/GPU；ServerlessLLM+ 上限为 ~53 个，ServerlessLLM 上限为 ~36 个，MuxServe 在 32 个模型时因显存限制终止 `[图像直接可见]`。
   - 在 (b) RPS = 0.5 下，Aegaeon 满足 90% SLO 目标的模型数量上限达 50 个；而 ServerlessLLM 降至 ~19 个，ServerlessLLM+ 降至 ~17 个，Aegaeon 支持的模型数达到 ServerlessLLM 的 2.5 倍以上 `[图像直接可见]`。
   - 在 (c) 40 models 场景下，随着单模型 RPS 从 0.05 增加到 0.75，ServerlessLLM 的 SLO 达成率在 ~0.1 RPS 处跌破 90%，ServerlessLLM+ 在 ~0.16 RPS 处跌破 90%，而 Aegaeon 的 SLO 达成率在整个 0.05-0.75 req/s 范围内始终维持在 ~95% 以上 `[图像直接可见]`。
5. **它验证的论点与方法设计含义**：
   - 证实了 Aegaeon 在并发 LLM serving 中的显著效果主张：通过 Token 粒度扩缩容与 Prefill/Decoding 物理解耦，突破了传统多路复用（MuxServe 受限于 80GB 显存只能硬性放置 2 模型/GPU，16 GPU 只能放置 32 模型）和请求级自动扩缩容（ServerlessLLM 受到定理 3.1 活跃模型数高导致的 HOL Blocking 限制）的瓶颈 `[正文支持]`。
   - 图 (b) 中 ServerlessLLM+ 表现劣于 ServerlessLLM 的现象，验证了纯请求级 SJF 调度在密集到达时会因频繁触发扩缩容而产生巨大 overhead 的机理批判，支持了 Aegaeon 引入 Grouped FCFS 和 Weighted Round-Robin 算法以掩盖扩缩容开销的设计必要性 `[正文支持]`。
   - 图 (c) 验证了 Aegaeon 对突发流量和不同 RPS 的极强鲁棒性 `[基于文中逻辑的推断]`。
6. **适用范围与证据缺口**：本实验覆盖 16 张 H800 GPU（6 Prefill + 10 Decoding），使用 ShareGPT 数据集，TTFT SLO 设为 10s，TBT SLO 设为 100ms `[正文支持]`。无额外证据缺口。
