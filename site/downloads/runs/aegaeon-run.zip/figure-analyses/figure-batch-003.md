# 图片批次 3

## 图片 1：Figure 5. System overview of Aegaeon.

![Figure 5. System overview of Aegaeon.](../assets/imgs/img_in_image_box_108_148_589_455.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：作者需要这张图来展示 Aegaeon 系统的整体硬件与软件架构设计，说明如何解决 Token 粒度自动扩缩容与调度的系统复杂性及开销挑战。`[正文支持]`
   - **图表角色**：`方法流水线`
   - **上文呼应**：对应第 3.3 节“系统概览”（§3.3 System Overview）及第 4、5 节。
   - **主张/类型与验证的具体问题**：属于 `机制主张 (Mechanism)` `[正文支持]`。具体验证 Aegaeon 如何通过控制面 Proxy Layer、Prefill 与 Decoding 解耦的 Serving 实例池、抢占式自动扩缩容引擎（Preemptive Auto-Scaling）以及 DRAM 与 GPU VRAM 的统一内存/缓存管理架构，支撑多模型并发的高效 GPU 池化 `[正文支持]`。
2. **图像类型与布局**：系统架构图 / 流程示意图。整体分为三层：顶部为请求输入层（Request A/B/C）与 `Proxy Layer (Load Balancer)`（连接 Redis 进行状态同步）；中部为 `Serving Instances` 区域（包含 `Decode Instance 1/2` 和 `Prefill Instance 1`，内置 GPU、VRAM Buffer 和 Scheduler）；底部为 `Host Memory / DRAM` 区域（包含 Model Cache 和 Unified CPU KV Cache），右侧连接 Remote Registry。带圈数字标号 ① 至 ⑨ 和不同颜色箭头标注了数据请求、状态同步、抢占扩缩容及远程加载流向。
3. **如何阅读**：按自上而下的数据与控制流顺序阅读。顶部图例标明了箭头类型（Data Request, Status Sync, Preemptive Auto-Scaling, Remote Loading）。①②⑥表示 Proxy 转发请求到 Prefill/Decode 实例；③⑤表示 Prefill 实例向 Decode 实例传输 KV Cache；④⑦⑨表示触发抢占式扩缩容，在 GPU VRAM Buffer 与 DRAM 的 Model Cache / Unified CPU KV Cache 之间搬运权重与 KV 状态。
4. **直接可见的结论**：
   - `[图像直接可见]` 系统将 Serving 实例按功能划分为独立的 Prefill Instance 和 Decode Instance。
   - `[图像直接可见]` Proxy Layer 可将不同模型的请求分发至同一个 Prefill 实例（如 Request A 和 B 被发送至 Prefill Instance 1）。
   - `[图像直接可见]` Prefill Instance 与 Decode Instance 之间存在 KV Cache 跨实例传输通道（箭头 ③ 和 ⑤）。
   - `[图像直接可见]` DRAM 中划分了 Model Cache 与 Unified CPU KV Cache，通过抢占式扩缩容箭头（④, ⑦, ⑨）与 GPU 显存 Buffer 保持动态交换。
   - `[图像直接可见]` 远程模型仓库（Remote Registry）支持将模型加载至 DRAM 的 Model Cache。
5. **它验证的论点与方法设计含义**：属于 `机制主张 (Mechanism)` `[正文支持]`。它验证了 Aegaeon 解决 Token 级调度与扩缩容开销（Challenge #1 & #2）的全栈系统架构设计 `[正文支持]`。Prefill 与 Decoding 的物理解耦消除了计算密集型与访存密集型任务在同一 GPU 上的相互干涉，为调度器（§4）按 Token 粒度独立优化 TTFT 和 TBT 提供了物理基础 `[正文支持]`；DRAM 层的 Model Cache 与 Unified CPU KV Cache 配合显存 Buffer 则为 Token 粒度的快速抢占式 Scale-up/Scale-down 提供了内存层支撑 `[正文支持]`。
6. **适用范围与证据缺口**：覆盖论文设计的 Aegaeon 系统整体架构及单节点/多节点部署场景 `[正文支持]`。无额外证据缺口。

---

## 图片 2：Figure 6. Exemplar token-level schedules on two GPUs. Prefill-first scheduling (a) and decoding-first scheduling (b) both lead to SLO violations. Disaggregated scheduling (c) separates prefill and decoding jobs to enable balanced token generation.

![Figure 6. Exemplar token-level schedules on two GPUs. Prefill-first scheduling (a) and decoding-first scheduling (b) both lead to SLO violations. Disaggregated scheduling (c) separates prefill and decoding jobs to enable balanced token generation.](../assets/imgs/img_in_image_box_644_137_1109_688.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：作者需要这张图来对比不同 Token 级调度策略在两张 GPU 上的执行时序，解释为什么单一 GPU 混合处理 Prefill 和 Decoding 会导致严重违约，进而阐明 Prefill/Decoding 解耦调度的必要性。`[正文支持]`
   - **图表角色**：`问题严重性`、`方法流水线`
   - **上文呼应**：对应第 4 节“Token-Level Scheduling”与第 5 页正文 Figure 6。
   - **主张/类型与验证的具体问题**：属于 `必要性主张 (Necessity)` 与 `机制主张 (Mechanism)` `[正文支持]`。具体验证在多模型并发场景下，传统 Prefill 优先与 Decoding 优先调度策略分别会导致 TBT 和 TTFT 的严重 SLO 违约，证明 Prefill/Decoding 解耦调度（Disaggregated scheduling）对于消除违约、实现平衡 Token 生成的必要性与有效性 `[正文支持]`。
2. **图像类型与布局**：甘特图 / 调度时序对比图。顶部为图例说明（$P_i$ 为 Prefill，$D_i$ 为 Decoding，点状框为 Switching 切换开销，红色斜线框为 SLO Violation，不同颜色代表 Model A/B/C，蓝色/黑色箭头分别代表 Request Arrival 与 KV Cache Transfer）。下方由三个子图组成：(a) Prefill-prioritized scheduling、(b) Decoding-prioritized scheduling、(c) Disaggregated scheduling，各自对比 GPU 0 和 GPU 1 随着时间演进的执行时序。
3. **如何阅读**：自上而下对比 (a)、(b)、(c) 在完全相同的请求到达序列（$R_1, R_2$ 开头到达，$R_3, R_4$ 随后到达，$R_5, R_6$ 再次到达）下 GPU 0 与 GPU 1 的调度行为。横轴代表时间演进，观察任务执行顺序、模型切换开销（Switching）以及红色斜线阴影区段（SLO Violation）的出现与面积大小。
4. **直接可见的结论**：
   - `[图像直接可见]` 在 (a) Prefill-prioritized scheduling 中，新请求 Prefill 优先抢占 GPU 执行，导致正在进行 Decoding 的请求（如 $R_1, R_3$）被长久推迟，产生大面积的 $TBT_{R1}$ 和 $TBT_{R3}$ 违约（红色斜线阴影）。
   - `[图像直接可见]` 在 (b) Decoding-prioritized scheduling 中，Decoding 任务持续占用 GPU，导致后到达请求（如 $R_3, R_4, R_6$）的 Prefill 阶段长时间无法运行，产生大面积的 $TTFT_{R3}$ 和 $TTFT_{R6}$ 违约（红色斜线阴影）。
   - `[图像直接可见]` 在 (c) Disaggregated scheduling 中，GPU 0 作为专用 Prefill 实例、GPU 1 作为专用 Decoding 实例独立运行并通过 KV Cache Transfer 协同，图中完全没有出现红色斜线阴影（即零 SLO Violation）。
5. **它验证的论点与方法设计含义**：属于 `必要性主张 (Necessity)` 与 `机制主张 (Mechanism)` `[正文支持]`。证明了在并发多模型 Token 级调度中，简单采用 Prefill 或 Decoding 优先策略均无法避免 SLO 违约（必要性），验证了 Prefill 与 Decoding 物理解耦是兼顾 TTFT 和 TBT SLO 的核心机制 `[正文支持]`。该结果支撑了 Aegaeon 将 GPU 池划分为独立 Prefill 实例池与 Decoding 实例池（§3.3, §4）的设计决策，确保 Prefill 阶段采用 Grouped FCFS 优化 TTFT，Decoding 阶段采用 Weighted Round-Robin 优化 TBT `[正文支持]`。
6. **适用范围与证据缺口**：覆盖论文报告的 2 卡 GPU 多模型 Token 级调度示意场景 `[正文支持]`。无额外证据缺口。
