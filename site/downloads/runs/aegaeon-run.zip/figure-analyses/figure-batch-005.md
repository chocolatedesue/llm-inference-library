# 图片批次 5

## 图片 1：Figure 8. Preemptive scaling with optimizations in §5.1 and §5.2. (a) w/ component reuse; (b) also w/ explicit memory management.

![Figure 8. Preemptive scaling with optimizations in §5.1 and §5.2. (a) w/ component reuse; (b) also w/ explicit memory management.](../assets/imgs/img_in_image_box_102_338_589_485.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`消融验证` `[正文支持]`
   - **上文呼应**：对应报告中“消融验证 / 模块 4：高效抢占式自动扩缩容引擎优化”及 §5.1、§5.2 节关于组件复用（Component Reuse）与显式内存管理（Explicit Memory Management）的开销消融分析 `[正文支持]`。
   - **验证问题**：用于验证在仅进行组件复用 (a) 与进一步叠加自研 VRAM 凸块分配器及异步模型预取等显式内存管理 (b) 条件下，抢占式自动扩缩容的时序阶段构成及其关键路径延迟开销的变化 `[正文支持]`。

2. **图像类型与布局**：
   - **图像类型**：对比式时序流水线图（Timeline Diagram），包含 (a) 和 (b) 两个并列 Panel `[图像直接可见]`。
   - **布局组织**：
     - 横轴代表时间推移（Time 箭头向右），纵轴代表操作阶段/流（Stages 箭头向下） `[图像直接可见]`。
     - Panel (a) 展示了单流顺序执行阶段：Inference（灰色）、$\text{KV}_{\text{out}}$（蓝色）、gc（垃圾回收，黄色）、$\text{Model}_{\text{in}}$（模型加载，黄色）、$\text{KV}_{\text{in}}$（蓝色）及恢复 Inference（灰色），底部标注红色横条 Cost: $T_1$ `[图像直接可见]`。
     - Panel (b) 拆分为 Default Stream 与 Prefetch Stream 双 CUDA 流；Prefetch Stream 中的 $\text{Model}_{\text{in}}$ 与先前的 Inference 异步重叠执行；Default Stream 上仅保留 $\text{KV}_{\text{out}}$ 与 $\text{KV}_{\text{in}}$，消除了 gc 阶段，底部标注红色横条 Cost: $T_2$ `[图像直接可见]`。

3. **如何阅读**：
   - **坐标与方向**：从左至右观察各阶段的时间推移，从上至下观察不同 CUDA 流及阶段的划分 `[图像直接可见]`。
   - **颜色含义**：灰色框代表模型推理阶段（Inference）；蓝色框代表 KV Cache 的换出（$\text{KV}_{\text{out}}$）与换入（$\text{KV}_{\text{in}}$）；黄色框代表显存垃圾回收（gc）与模型权重加载（$\text{Model}_{\text{in}}$）；底部红色横条代表扩缩容的关键路径延迟（Cost: $T_1$ 与 Cost: $T_2$） `[图像直接可见]`。
   - **对比方法**：比较 (a) 与 (b) 在关键路径上保留的阶段数量以及 Cost: $T_2$ 相较于 Cost: $T_1$ 的长度缩短程度 `[图像直接可见]`。

4. **直接可见的结论**：
   - 在 (a) 中，抢占扩缩容的关键路径由 $\text{KV}_{\text{out}} \rightarrow \text{gc} \rightarrow \text{Model}_{\text{in}} \rightarrow \text{KV}_{\text{in}}$ 严格串行组成，关键路径耗时为 $T_1$ `[图像直接可见]`。
   - 在 (b) 中，通过将 $\text{Model}_{\text{in}}$ 移至 Prefetch Stream 与先前的 Inference 异步重叠，同时完全移除了 gc 阶段，Default Stream 上的扩缩容关键路径仅剩 $\text{KV}_{\text{out}}$ 与 $\text{KV}_{\text{in}}$ 的串行执行，使得总延迟 $T_2$ 显著短于 $T_1$（$T_2 < T_1$） `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：
   - **验证主张**：验证了“机制主张 (Mechanism)”——显式内存管理（凸块分配器消除 PyTorch 显存碎片造成的 gc 停顿）与基于 CUDA 流的模型预取可进一步消除关键路径上的模型加载与垃圾回收开销 `[正文支持]`。
   - **方法设计含义**：
     - 组件复用已将原始无优化的扩缩容开销 $T_0$（26.9 秒）削减 80%+ 至 $T_1$ `[正文支持]`。
     - (b) 图进一步展示了自研 VRAM 凸块分配器与预取机制将 $T_1$ 压缩至 $T_2$ 的逻辑：凸块分配器通过重置指针避开了 `torch.cuda.empty_cache()` 和 `gc.collect()` 耗时，预取流将模型权重搬运隐藏在解码轮次的时间配额内，从而使主流仅需承受 KV Cache 换入换出的开销 `[正文支持]`。

6. **适用范围与证据缺口**：
   - **适用范围**：覆盖论文 §5.1 与 §5.2 节在 80GB A100/H800 等具备足够显存容纳预取模型的 GPU 上的抢占式扩缩容优化机制 `[正文支持]`。
   - **真实缺口**：图中仅标注了符号化的 Cost $T_1$ 与 $T_2$，未直接在图上标出 $T_1$ 和 $T_2$ 的具体毫秒级或秒级绝对数值 `[基于视觉的谨慎推断]`。

---

## 图片 2：Figure 10. Efficient scaling in Aegaeon, with fine-grained KV cache synchronization. Dotted boxes indicate non-critical operations, and striped boxes indicate cache blocks in move lists.

![Figure 10. Efficient scaling in Aegaeon, with fine-grained KV cache synchronization. Dotted boxes indicate non-critical operations, and striped boxes indicate cache blocks in move lists.](../assets/imgs/img_in_image_box_636_144_1116_402.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`方法流水线` `[正文支持]`
   - **上文呼应**：对应报告中“方法流水线 / 模块 4：高效抢占式自动扩缩容引擎优化”及 §5.3 节关于细粒度 KV Cache 同步机制（Fine-Grained KV Cache Synchronization）的架构与流水线设计 `[正文支持]`。
   - **验证问题**：用于解释 Aegaeon 如何通过多 CUDA 流重叠（Default Stream、KV-In Stream、KV-Out Stream、Prefetch Stream）以及基于 CUDA Event 与 IPC 的无锁细粒度异步同步，解决 Prefill 实例与 Decoding 实例之间 KV Cache 跨进程/跨设备传输时的复杂数据依赖，将关键路径延迟压缩至 $T_3$ `[正文支持]`。

2. **图像类型与布局**：
   - **图像类型**：多流异步重叠时序图与系统数据面/控制面同步机制结构示意图组合图 `[图像直接可见]`。
   - **布局组织**：
     - 左上角：四 CUDA 流（Default Stream、KV-In Stream、KV-Out Stream、Prefetch Stream）的时序重叠图，虚线圈标出 $\text{KV}_{\text{in}}$ 的异步重叠，底部标注绿色横条 Cost: $T_3$ `[图像直接可见]`。
     - 右侧及下方：详细展示 Decoding Instance、Prefill Instance、Events 事件队列、Unified CPU Cache 以及 Daemon Thread 之间的交互机制 `[图像直接可见]`。
     - 底部说明：包含序号 ① 至 ⑧ 的具体 CUDA API 与底层操作映射图例 `[图像直接可见]`。

3. **如何阅读**：
   - **时序与流重叠**：左上图从左至右观察四流并行执行，$\text{KV}_{\text{out}}$ 在 KV-Out Stream 执行，$\text{KV}_{\text{in}}$ 在 KV-In Stream 执行，$\text{Model}_{\text{in}}$ 在 Prefetch Stream 执行，显著缩短 Default Stream 的停顿时间 `[图像直接可见]`。
   - **控制与数据交互**：右图分为 Prefill 实例（下方）与 Decoding 实例（上方）；实线/虚线带圈数字 ①~⑧ 对应底部图例的操作步骤（如 ①④ 记录/传递 CUDA Event、②⑤ 异步内存拷贝、③ 流等待 Event、⑥ 查询 Event 状态、⑦ 模型前向计算、⑧ 移入 move list 并由守护线程回收 CPU 缓存块） `[图像直接可见]`。
   - **统一 CPU 缓存与 move list**：观察 Unified CPU Cache 中带有斜纹线（striped boxes）的 R1 缓存块，代表已加入 move list 但异步传输尚未完成的过渡状态 `[图像直接可见]`。

4. **直接可见的结论**：
   - 左上图显示，通过将 $\text{KV}_{\text{in}}$、$\text{KV}_{\text{out}}$ 和 $\text{Model}_{\text{in}}$ 彻底解耦并分配至独立的 CUDA Stream 异步执行，关键路径开销被进一步缩减至极短的 $T_3$（$T_3 < T_2$） `[图像直接可见]`。
   - 右图显示，Prefill Instance 在完成 $R_1$ 的 Prefill 和 KV Cache 写入后，通过 CUDA Event/IPC（步骤 ①③⑤⑥）通知 Decoding Instance，允许 Decoding Instance 在 KV Cache 仍处于异步传输过程中即按 Token 细粒度启动 Decode（步骤 ⑦） `[图像直接可见]`。
   - Unified CPU Cache 中通过 move list 标记（斜纹块）和 Daemon Thread 异步回收（步骤 ⑧），避免了跨进程传输中的数据竞争与无效等待 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：
   - **验证主张**：验证了“机制主张 (Mechanism)”——细粒度 KV Cache 异步同步与多流流水线化能够彻底消除数据面阻塞，支撑 Token 粒度抢占式扩缩容达到亚秒级（< 1s）甚至近零延迟 `[正文支持]`。
   - **方法设计含义**：
     - 针对 Challenge #2（扩缩容开销），证明了单靠权重预取不够，必须解除 KV Cache 传输的全局同步锁 `[正文支持]`。
     - 提出了满足三大物理依赖（设备上 KV 可用、源块传输完成、目标块无旧传输占用）的无锁控制逻辑：利用 CUDA Event 记录传输进度，使用 IPC 跨进程共享 Event 句柄，从而实现 Prefill 到 Decoding 阶段 KV Cache 的渐进式、Token 级流水化移交 `[正文支持]`。

6. **适用范围与证据缺口**：
   - **适用范围**：覆盖论文 §5.3 节在 NVIDIA CUDA 架构下利用多 Stream、CUDA Event 和 CUDA IPC 实现的跨进程/跨 GPU KV Cache 细粒度同步方案 `[正文支持]`。
   - **真实缺口**：图中的 $T_3$ 为相对符号表达，未直接给出在具体 KV Cache 尺寸下的具体传输微秒/毫秒数值 `[基于视觉的谨慎推断]`。
