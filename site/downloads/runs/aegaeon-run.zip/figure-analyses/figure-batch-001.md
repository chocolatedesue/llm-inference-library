# 图片批次 1

## 图片 1：Figure 1. Concurrent LLM serving workloads. (a) CDF of model invocations. Less-used models (average arrival rate

![Figure 1. Concurrent LLM serving workloads. (a) CDF of model invocations. Less-used models (average arrival rate](../figure-groups/page-0002-58bfb2f38fb1.png)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：针对云端大模型服务市场中并发 LLM 推理请求高度稀疏与突发导致的 GPU 资源严重浪费问题，作者需要展示真实生产负载的分布特征 `[正文支持]`。
   - **图表角色**：问题严重性 `[正文支持]`
   - **上文呼应**：对应“根问题与重要性”章节中“1. 现实物理约束与基本对象定义”与“2. 根问题机制推导链”的主张 `[正文支持]`。
   - **论证与验证问题**：验证并发 LLM 服务中请求调度的极度倾斜性（长尾效应）与热门模型请求量的短时剧烈波动性（突发流量），揭示预留专属 GPU 实例导致整体利用率极低（<0.1 RPS/GPU）且 17.7% 的 GPU 处于闲置状态这一根问题 `[正文支持]`。证据类型：必要性 `[基于文中逻辑的推断]`。

2. **图像类型与布局**：双 Panel 曲线图与折线趋势图组合 `[图像直接可见]`。左图 Panel 1 (a) 为累积分布函数（CDF）图，X 轴为最热门模型比例（Top Popular Models (%)），Y 轴为请求量占比（Request Percentage (%)），内部带有浅绿色高亮框及统计文字标注 `[图像直接可见]`。右图 Panel 2 (b) 为随时间变化的请求速率波动折线图，X 轴为时间 Time (seconds, 0~600)，Y 轴为请求速率 Rate (req/s, 600~800+)，包含深绿色波动的 Reserved 曲线与顶部橙色高亮的 Burst 突发请求折线 `[图像直接可见]`。

3. **如何阅读**：
   - Panel 1 (a)：从左到右沿 X 轴观察热门模型比例，比较长尾非热门模型（右侧浅绿色区域）所占比例与其产生的累积请求量占比 `[图像直接可见]`。
   - Panel 2 (b)：从左向右按时间线（0-600 秒）观察，对比绿线（预留资源可承载速率 Reserved）与超出预留水平线的橙色尖峰（突发请求 Rate Burst） `[图像直接可见]`。

4. **直接可见的结论**：
   - Panel 1 (a) 中 CDF 曲线在头部极小比例（<5%）内迅速上升至接近 100%，浅绿色阴影区域标注 94.1% 的 779 个长尾模型仅消耗 167.6M 总请求中的 1.35%，但占用了 30K GPUs 中的 17.7% `[图像直接可见]`。
   - Panel 2 (b) 中，在 600 秒监测时间内，热门模型的请求速率在 600~800 req/s 频繁波动，且频繁产生超出预留容量（Horizontal orange line / Burst area）的短时突发流量 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：验证了云端多模型并发 Serving 场景下资源浪费的物理根源（必要性主张）：专属 GPU 分配在冷模型上导致长期低利用率，在热模型上又难以应对突发流量 `[正文支持]`。直接导出了引入 GPU 池化（GPU Pooling）与动态扩缩容（Auto-scaling）的必要性，促使 Aegaeon 设计 Token 粒度的抢占式扩缩容与 Prefill/Decoding 解耦调度机制 `[正文支持]`。图上无法直接证明 Token 粒度扩缩容优于请求粒度扩缩容，需要后续图 2 和端到端性能实验进一步验证 `[基于文中逻辑的推断]`。

6. **适用范围与证据缺口**：
   - 适用范围：本证据覆盖阿里巴巴模型百炼平台（Alibaba Cloud Model Studio）实际生产集群中 779 个模型、1.676 亿次请求及超 2K-30K GPU 的真实负载数据 `[正文支持]`。
   - 证据缺口：无额外证据缺口 `[基于文中逻辑的推断]`。

---

## 图片 2：Figure 2. Different auto-scaling granularities for sharing one GPU instance between three models.

![Figure 2. Different auto-scaling granularities for sharing one GPU instance between three models.](../figure-groups/page-0002-fe1ec4a8cbd6.png)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：针对现有自动扩缩容系统仅在请求粒度执行导致队头阻塞的问题，作者需要展示不同扩缩容粒度的机制差异与设计动机 `[正文支持]`。
   - **图表角色**：对比基线 `[正文支持]`
   - **上文呼应**：对应“旧方法限制”中“2. 自动扩缩容路线（Auto-scaling）”以及“核心洞见与假设”中“1. Token 粒度抢占洞见”的论述 `[正文支持]`。
   - **论证与验证问题**：验证请求级自动扩缩容（Request-level auto-scaling）导致严重的队头阻塞（HOL Blocking）与高 TTFT 违约问题（定理 3.1），解释 Aegaeon 如何通过 Token 粒度抢占式扩缩容（Token-level auto-scaling）降低挂起模型的 TTFT `[正文支持]`。证据类型：机制 `[基于文中逻辑的推断]`。

2. **图像类型与布局**：机制原理对比示意图 / 调度时序对比图 `[图像直接可见]`。包含上下两个 Panel，上方 Panel 1 (a) 为请求级自动扩缩容（Request-level auto-scaling），下方 Panel 2 (b) 为 Token 粒度自动扩缩容（Token-level auto-scaling (ours)） `[图像直接可见]`。顶部带有图例：P 表示 Prefill（预填），D 表示 Decode（解码）；淡黄色代表 Model A，淡绿色代表 Model B，淡蓝色代表 Model C `[图像直接可见]`。每个 Panel 包含从左到右的时间轴（Timeline）及 GPU 执行块序列，下方标注各模型的首 Token 响应时间 TTFT（绿色网格表示合格/极短，红色斜线阴影表示严重延迟/违约） `[图像直接可见]`。

3. **如何阅读**：比较 Panel 1 (a) 与 Panel 2 (b) 在相同请求到达序列（Model A 到达 $\rightarrow$ Model B 到达 $\rightarrow$ Model C 到达）下的 GPU 执行调度逻辑与 $TTFT_A, TTFT_B, TTFT_C$ 的时间长度差异 `[图像直接可见]`。

4. **直接可见的结论**：
   - Panel 1 (a) 中，在请求级扩缩容下，当 Model B 到达时，必须等待 Model A 完成其整个请求（包含所有解码步骤 D...D）；Model C 到达时必须等待 Model B 完成全部解码。导致 $TTFT_B$ 和 $TTFT_C$ 被极其拉长（图中呈长红色斜线阴影框） `[图像直接可见]`。
   - Panel 2 (b) 中，在 Token 粒度抢占式扩缩容下，Model B 到达后系统在 Token 粒度下抢占 Model A，立即插队执行 Model B 的 Prefill (P)，之后多模型（Model A, B, C）交叉轮流执行 Decode (D)，使 $TTFT_A, TTFT_B, TTFT_C$ 均保持极短水平（图中均显示为绿色网格框） `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：直观解释并验证了定理 3.1 导出的结论：请求级自动扩缩容在 LLM 长生成请求下必定面临严重队头阻塞，导致等待模型违反 TTFT SLO；而 Token 粒度抢占式自动扩缩容能够从机制上消除队头阻塞（必要性与机制主张） `[正文支持]`。支持了 Aegaeon 在调度器中将 Prefill 与 Decoding 解耦，并在 Token 级别动态抢占下线/上线模型的架构设计 `[正文支持]`。该示意图作为原理图，未直接展示真实系统中的扩缩容切换延迟（overhead）或端到端 Goodput 数值，其实际开销掩盖能力与性能表现需由第 7 节的实验进一步支持 `[基于文中逻辑的推断]`。

6. **适用范围与证据缺口**：
   - 适用范围：本证据覆盖 3 个模型共享单张 GPU 实例的抢占调度概念模型 `[正文支持]`。
   - 证据缺口：无额外证据缺口 `[基于文中逻辑的推断]`。
