# 图片批次 2

## 图片 1：Figure 3. Overall token generation process of a request. SLO attainment is defined as the percentage of token generation times that meet their deadlines, i.e., the proportion of the green area.

![Figure 3. Overall token generation process of a request. SLO attainment is defined as the percentage of token generation times that meet their deadlines, i.e., the proportion of the green area.](../assets/imgs/img_in_chart_box_639_139_1105_334.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：作者展示 Figure 3 旨在明确 Token 粒度下 LLM 推理的整体生成流程与服务等级目标（SLO）达成率的计算标准。它针对现有系统单纯依赖整体请求延迟指标无法精准反映用户体感卡顿的问题，提出以每个 Token 是否按时生成（满足 TTFT 与 TBT 截止时间）来量化 SLO 达成率 `[正文支持]`。
   - **图表角色**：`方法流水线`
   - **上文呼应**：对应报告中 §2.1 节“基本 LLM 推理与 SLO 定义”及指标字典中“SLO 达成率”的主张。
2. **图像类型与布局**：示意图/时间线图。顶部包含图例说明（绿色斜线框表示 Deadline Met，灰色斜线框表示 Deadline Missed，黑色下箭头表示 Token Deadline，蓝色圆头针表示 Token Generation）。下方为横向时间轴，从左侧的 Request Arrival 标记开始，依次划分为 TTFT Deadline、TBT Deadline 和 Buffered Output 阶段，时间轴下方标注截止时间窗口，上方标注实际 Token 生成时刻。
3. **如何阅读**：阅读顺序为从左至右沿时间轴方向。对比项为黑色下箭头（Token 期望生成截止时间 Deadline）与蓝色圆头针（实际 Token 生成时刻 Token Generation）的位置关系。若 Token 在 Deadline 之前或按时生成，对应的背景区间显示为绿色斜线（Deadline Met）；若超时生成或延迟过大，背景区间显示为灰色斜线（Deadline Missed）。SLO Attainment 即计算绿色区域占比。
4. **直接可见的结论**：
   - 请求到达（Request Arrival）后，首个 Token 的生成时刻落在了 TTFT Deadline 之后，导致 TTFT 阶段背景显示为灰色斜线（Deadline Missed） `[图像直接可见]`。
   - 在后续解码阶段，部分 Token 生成时刻紧跟在 TBT Deadline 之前或符合周期，背景显示为绿色斜线（Deadline Met）；但在经历 Buffered Output 暂存后，若出现长停顿跨越了截止时间，对应的生成区间会再次变为灰色斜线（Deadline Missed） `[图像直接可见]`。
   - 绿色区域（Deadline Met）与灰色区域（Deadline Missed）在时间轴上交替出现，且首 Token 延迟与 Token 间延迟被明确解耦表述 `[图像直接可见]`。
5. **它验证的论点与方法设计含义**：该图验证了论文关于“SLO 应按 Token 粒度进行精准评估”的机制主张 `[正文支持]`。方法设计含义在于：因 Prefill 阶段（TTFT）与 Decoding 阶段（TBT）在计算特征、延迟敏感度及容忍度上存在本质差异（如 Decoding 阶段可以通过客户端缓冲区 Buffered Output 暂存来掩盖短期卡顿），系统必须在架构上将 Prefill 与 Decoding 解耦调度（Prefill/Decoding Disaggregation），并在 Decoding 阶段利用松弛时间（Slack Time）掩盖模型抢占式扩缩容开销 `[正文支持]` `[基于文中逻辑的推断]`。注意：该图仅为概念与评估机制示意图，无法单独证明 Aegaeon 在实际运行中的真实 SLO 达成率数值 `[正文支持]`。
6. **适用范围与证据缺口**：适用范围为适用于论文提出的基于 Token 粒度的 TTFT（默认 10s 目标）与 TBT（默认 100ms 目标）SLO 评估模型 `[正文支持]`。无额外证据缺口。

---

## 图片 2：Figure 4. Active model count over time (M = 100, , T = 16.79s). The estimated value is .

![Figure 4. Active model count over time (M = 100, , T = 16.79s). The estimated value is .](../assets/imgs/img_in_chart_box_654_143_1090_343.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：作者展示 Figure 4 旨在验证 Theorem 3.1 提出的活跃模型数期望值公式 $\mathbb{E}[m] = M \cdot (1 - e^{-\lambda T})$，并揭示现有“请求粒度（Request-level）自动扩缩容”方法在处理并发多模型服务时的理论性能瓶颈 `[正文支持]`。它针对现有自动扩缩容方案试图通过按需加载模型来减少 GPU 预留的假设，证明由于 LLM 请求服务时间较长，活跃模型数 $m$ 在时间维度上始终维持在较高水平，从而导致严重的队头阻塞（HOL Blocking），导出了采取 Token 粒度自动扩缩容的必要性 `[正文支持]`。
   - **图表角色**：`问题严重性`
   - **上文呼应**：对应报告中 §3.1 节“权衡分析与定理 3.1”及指标字典中“预期活跃模型数期望值 $\mathbb{E}[m]$”的主张。
2. **图像类型与布局**：折线图/仿真趋势图。包含带有虚线网格的单组坐标系。纵轴为活跃模型数量（Active Model Count，范围 0–100），横轴为时间（Time (s)，范围 0–2000 秒）。图中包含一条绿色的波动态线条（表示随时间变化的实时活跃模型数 $m$）和一条位于 $y \approx 46.55$ 处的灰色横向虚线参考线（右侧标注为 $\mathbb{E}[m]$）。
3. **如何阅读**：纵轴代表系统在某一时刻至少有一个请求正在被服务的模型总数；横轴代表仿真运行的时间（0 到 2000 秒）。应比较绿色的实际活跃模型数波动曲线与灰色虚线表示的理论期望值 $\mathbb{E}[m]$。初始时刻从 0 快速上升，随后观察曲线是否围绕理论期望线上下起伏。
4. **直接可见的结论**：
   - 在仿真初始（$t=0$ 至 $t \approx 50$s）阶段，活跃模型数从 0 迅速攀升至 45 左右 `[图像直接可见]`。
   - 在 50 秒至 2000 秒的整个测试时间内，绿色曲线持续在 30 至 65 的区间内剧烈上下波动，但其整体中心趋势始终紧密围绕在灰色虚线参考线 $\mathbb{E}[m]$（约 46.55）上下 `[图像直接可见]`。
   - 在总模型数 $M=100$ 的情况下，实时活跃模型数从未降至极低水平（如低于 30），且大部分时间维持在 40–50 个之间 `[图像直接可见]`。
5. **它验证的论点与方法设计含义**：该图验证了论文的必要性主张（Theorem 3.1 与请求级扩缩容的局限性） `[正文支持]`。理论与方法设计含义为：即使单模型的请求到达率极其稀疏（$\lambda = 0.037$ RPS），由于 LLM 请求平均服务时间较长（$T = 16.79$s），在请求粒度下系统平均仍有高达 46.55% 的模型处于活跃状态。如果使用请求级自动扩缩容，要避免队头阻塞就必须为约 46.55 个模型预留 GPU 实例（$N = O(m)$），导致池化效率被硬性限制在 $< 3$ 个模型/GPU。这有力地证明了“单纯依赖请求级自动扩缩容无法实现高效 GPU 池化”，从而为 Aegaeon 引入 Token 粒度抢占式扩缩容提供了坚实的理论依据与设计动机 `[正文支持]` `[基于文中逻辑的推断]`。注意：该图通过数值仿真验证了 Poisson 到达假设下的期望活跃模型数理论，但不能直接展现真实生产环境复杂流量下的具体波动情况 `[正文支持]`。
6. **适用范围与证据缺口**：适用范围为本仿真覆盖 $M = 100$ 个模型、单模型到达率 $\lambda = 0.037$ requests/s、平均服务时间 $T = 16.79$s 的设定 `[正文支持]`。无额外证据缺口。
