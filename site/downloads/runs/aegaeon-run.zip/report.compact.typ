#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[Aegaeon: Effective GPU Pooling for Concurrent LLM Serving on the Market]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Yuxing Xiang, Xue Li, Kun Qian, Yufan Yang, Diwen Zhu, Wenyuan Yu, Ennan Zhai, Xuanzhe Liu, Xin Jin, Jingren Zhou]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[SOSP '25 · 2025]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Multi-Model Serving] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Large Language Models] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Serverless Computing] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU Pooling] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[Token-Level Auto-Scaling]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：https://ennanzhai.github.io/pub/sosp25-aegaeon.pdf]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[DOI：https://doi.org/10.1145/3731569.3764815]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

模型市场（如 Hugging Face）包含种类繁多、具有独特特征和不同受欢迎程度的模型。在并发推理工作负载中，使用专用 GPU 实例响应零散且不可预测的请求会导致严重的资源浪费。尽管现有的多模型服务解决方案利用 GPU 池化和无服务器计算来提高资源利用效率，但其效果仅限于每块 GPU 最多支持两到三个模型，不足以充分利用 GPU 资源。

我们提出了 Aegaeon，这是一个在 token 粒度上执行模型自动扩缩容的多模型服务系统，以实现有效的 GPU 池化。Aegaeon 按 token 粒度调度多模型请求并制定自动扩缩容决策，以最大化服务质量。通过组件复用、显式内存管理和细粒度 KV 缓存同步，它将自动扩缩容开销降低了 97%。实验表明，与现有解决方案相比，Aegaeon 可承受 2--2.5 倍更高的请求到达率，或提供 1.5--9 倍更多的有效吞吐量（goodput）。Aegaeon 已在我们的模型市场中进行测试部署，目前服务于数十个模型。部署结果表明，Aegaeon 将服务这些模型所需的 GPU 数量从 1,192 块减少到 213 块，显著节省了 82% 的 GPU 资源。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [Aegaeon: Effective GPU Pooling for Concurrent LLM Serving on the Market],
    [作者], [Yuxing Xiang, Xue Li, Kun Qian, Yufan Yang, Diwen Zhu, Wenyuan Yu, Ennan Zhai, Xuanzhe Liu, Xin Jin, Jingren Zhou],
    [发表场所 / 年份], [SOSP \'25, 2025],
    [研究领域], [LLM Serving, GPU Pooling],
    [关键词], [Multi-Model Serving, Large Language Models, Serverless Computing, GPU Pooling, Token-Level Auto-Scaling],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：#link("https://ennanzhai.github.io/pub/sosp25-aegaeon.pdf")
- arXiv：文中未说明
- DOI：#link("https://doi.org/10.1145/3731569.3764815")
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（3--5 个）]：`Multi-Model Serving` · `GPU Pooling` · `Token-Level Auto-Scaling` · `Serverless Computing` · `LLM Serving`
]

\[作者明确陈述\] 针对云端大模型服务市场（Model Market）中并发 LLM 推理请求高度稀疏与突发导致的 GPU 资源严重浪费问题，Aegaeon 首次提出了 Token 粒度（Token-level，按单个生成字符计算）的抢占式自动扩缩容与 Prefill/Decoding 解耦调度系统。\[实验支持\] 系统通过全栈优化将抢占式扩缩容延迟降低 97%（控制在 1 秒以内），在满足服务等级目标（SLO，服务质量承诺）的前提下实现单 GPU 承载多达 7 个模型，并在阿里云百炼生产部署中节省了 82% 的 GPU 资源。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

\[作者明确陈述\] 本报告基于论文全文本及系统解析得到的文本与图表证据分析（涵盖第 1 至 14 页）。\[实验支持\] 论文提供了完整的理论证明（定理 3.1）、微基准消融实验（初始化、内存分配、KV Cache 同步开销）、端到端 Goodput/SLO 达成率实验以及 70 小时生产环境真实集群部署证据。\[基于文中逻辑的推断\] 文中涉及的扩展硬件架构（如非 NVIDIA GPU 平台）、跨节点管线并行（PP）场景下的细粒度 KV Cache 同步以及代码开源仓库地址在当前文本中明确标注为"文中未说明"。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

\[背景知识\] 在云端大模型服务市场（如 Hugging Face 或阿里云百炼）中，系统需同时服务少量热门模型（Hot models）与海量尾部冷门模型（Cold models，长尾模型占比超 90%）。显存（VRAM，如 80GB）与 PCIe 总线带宽属于有限的强物理约束资源。用户请求受到服务等级目标（SLO）的严格限定，包括首 Token 响应时间（TTFT，从发送请求到显示第一个字的时间）与 Token 间生成延迟（TBT，打印相邻两个字之间的停顿）。

\[作者明确陈述\] 核心困难在于请求的极度稀疏性与不可预测性：94.1% 的长尾模型仅消耗 1.35% 的总请求，单模型平均请求到达率 $< 0.2$ RPS（Requests Per Second）。\[基于文中逻辑的推断\] 若按照传统方式为每个模型预留专属 GPU 实例（Dedicated instances），将导致 17.7% 的 GPU 长期处于完全闲置状态，整体 GPU 利用率小于 0.1 RPS/GPU。因为成熟单模型专属服务的吞吐可达数 RPS/GPU，这表明存在超过 10 倍未被探索的资源利用率提升空间。

\[作者明确陈述\] #strong[本文的 Story 核心转折]：现有 GPU 池化路线中，"静态多路复用"受限于 GPU 显存容量硬性上限；而"请求级自动扩缩容"由于 LLM 生成任务属于持续几秒至几十秒的长请求，新到达模型必须等待正在运行的模型完成整个请求才能下线，从而引发严重的队头阻塞（HOL Blocking，排在最前的长任务阻塞后续所有短任务）。本文的突破性洞见在于：将扩缩容与调度的粒度从"请求级别"精细化拆解到"Token 级别"，在不打断整体语义的前提下按 Token 抢占式切换模型，从而用松弛时间（Slack time，SLO 容许的时间余量）掩盖扩缩容开销，打破显存容量与队头阻塞的双重枷锁。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：具体主张]
  #image("figure-groups/page-0002-58bfb2f38fb1.png", width: 100%)
  #emph[Figure 1. Concurrent LLM serving workloads. (a) CDF of model invocations. Less-used models (average arrival rate]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：94.1%的长尾模型仅消耗1.35%请求却占用17.7%GPU资源，热门模型存在剧烈突发流量。

- #strong[论证关系]：揭示了专属GPU分配导致严重资源浪费的物理根源，证明了引入GPU池化与动态扩缩容的必要性。

- #strong[适用范围]：覆盖阿里云百炼平台779个模型、1.676亿次真实请求记录。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：具体主张]
  #image("assets/source-crops/img_in_chart_box_654_143_1090_343.png", width: 100%)
  #emph[Figure 4. Active model count over time (M = 100, , T = 16.79s). The estimated value is .]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：仿真曲线紧密围绕理论期望值 $bb(E)\[m\]approx 46.55$ 波动，证明 100 个模型的池中平均有 46.55% 始终处于活跃状态。

- #strong[论证关系]：验证了定理 3.1 的理论准确性，直接证明单纯依赖请求级自动扩缩容无法消除排队与队头阻塞。

- #strong[适用范围]：本仿真覆盖 $M = 100$ 个模型、$lambda = 0.037$ RPS、平均服务时间 $T = 16.79$s 的设定。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

\[作者明确陈述\] 论文将现有的 GPU 池化（GPU Pooling）解决方案归纳为两大技术路线：静态多路复用（Multiplexing）与请求级自动扩缩容（Request-level Auto-scaling）。

#critique-card(
  [静态多路复用路线（Multiplexing）],
  [原本解决什么：MuxServe \[20\]、S-LoRA \[28\] 等工作试图将多个模型实例同时预装在同一块 GPU 显存内，通过显存空间切分或时间分片实现共享。依赖的前提与限制：依赖 GPU 显存能够同时放下所有目标模型的权重。],
  [受到 GPU 物理显存容量的死板硬性限制（Hard-limited）。在单张 80GB 显存的 A100/H800 GPU 上，仅能同时放下 2 个 14B (FP16) 模型（单个模型参数占用 25.1 GB 显存），每 GPU 承载模型上限为 2 到 3 个，无法服务长尾市场中的数十上百个模型。],
  [引入 Token 粒度抢占式自动扩缩容，模型权重保存在主机内存（DRAM），按需上线。],
  [图 11 与图 12 端到端实验展示，MuxServe 在每 GPU 超过 2 个模型时拒绝配置，总模型数被硬性锁定在 32 个（16 张 GPU）。],
)

#critique-card(
  [请求级自动扩缩容路线（Auto-scaling）],
  [原本解决什么：ServerlessLLM \[21\]、BlitzScale \[49\]、ParaServe \[31\] 等系统通过按需将非活跃模型下线、将目标模型从 Host DRAM 动态加载至 GPU 显存，试图突破显存容量限制。依赖的前提与限制：假设单模型请求稀疏时，绝大部分模型均处于非活跃（Idle）状态。],
  [本文批判的具体 Limit（定理 3.1 导出的理论上限）：现有系统均在"请求粒度"执行扩缩容。由于 LLM 请求平均服务时间较长（$T = 16.79$ 秒），即使单模型到达率很低（$lambda = 0.037$ RPS），在时刻 $t$ 至少有一个请求处于服务状态的活跃模型数期望值 $bb(E)\[m\]= M dot.op\(1 - e^(- lambda T)\)$ 依然居高不下（100 个模型中平均有 46.55 个处于活跃状态）。队头阻塞后果：在请求粒度下，挂起模型的请求必须在队列中等待活跃模型处理完包含 Prefill 和全部 Decoding 的长请求。这引发严重的队头阻塞，导致等待模型的 TTFT 和 TBT 严重超时，系统要满足 SLO 所需的 GPU 数量 $N = O\(m\)$，池化效率被硬性限制在 $< 3$ 个模型/GPU。ServerlessLLM+ (Oracle SJF) 的特殊失效：\[实验支持\] ServerlessLLM+ 试图通过神谕信息采用最短作业优先（SJF）调度来缓解排队，但在密集到达时，频繁触发的模型抢占式扩缩容带来了巨额开销（每次耗时数十秒），导致其 SLO 达成率甚至低于未经优化排队的 ServerlessLLM。],
  [Prefill/Decoding 物理解耦架构 + Grouped FCFS (Prefill) + Weighted Round-Robin (Decoding) 调度算法，结合全栈亚秒级扩缩容引擎。],
  [图 11(b) 实验显示，高 RPS (0.5) 下 Aegaeon 承载模型数为 ServerlessLLM 的 2.5 倍，Goodput 提升 1.5--9 倍。],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

\[作者明确陈述\] Aegaeon 的成功建立在以下四个相互支撑的最小核心洞见与假设之上：

+ #strong[Token 粒度抢占洞见]：\[作者明确陈述\] 将自动扩缩容与调度的操作粒度下沉至"Token 级别"。系统无需等待整个长请求结束，即可在任意生成 Token 的间隙抢占式（Preemptively）下线当前模型并上线挂起模型，彻底消除请求级队头阻塞。
+ #strong[生成阶段物理解耦洞见]：\[背景知识\] LLM 推理包含 Prefill（首 Token 生成，计算密集型）与 Decoding（后续 Token 生成，访存密集型）两个阶段。\[作者明确陈述\] 统一混合调度会导致 Prefill 突发流量破坏 Decoding 的 TBT，或长 Decoding 任务拉长 Prefill 的 TTFT。必须将 GPU 物理资源池划分为 Prefill 实例池与 Decoding 实例池进行独立解耦调度。
+ #strong[松弛时间（Slack Time）可利用假设]：\[基于文中逻辑的推断\] 在 Decoding 阶段，客户端可以通过缓冲区暂存输出 Token 流。当单个解码步耗时（$t$）小于 TBT SLO 目标（$d$）时，每连续执行 $n$ 步即可积累 $n\(d - t\)$ 的松弛时间。假设此松弛时间可用于完全掩盖模型抢占式扩缩容与跨模型轮询的开销。
+ #strong[组件复用与显式内存管理假设]：\[作者明确陈述\] 推理引擎初始化的大部分开销（如分布式执行器、 Ray/NCCL 通信组、算子 Profiling、内存页 Pinning）在不同模型间通用；显存 GC 停顿由 PyTorch 默认分配器导致。通过全局一次性初始化与自定义 VRAM/DRAM 内存池（Bump Allocator & Slab Allocation），假设可将数十秒的扩缩容开销削减至亚秒级（\< 1s）。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

\[作者明确陈述\] Aegaeon 的架构由 Proxy 层、解耦的 Prefill/Decoding Serving 实例池、全局控制器（Redis 状态同步）以及底层 VRAM/DRAM 显式内存管理组件构成。从输入到输出的总流程为：用户请求到达 Proxy 转发给 Prefill 实例进行首 Token 计算 $arrow.r$ 生成的 KV Cache 通过 CUDA Event / IPC 传输至 Decoding 实例 $arrow.r$ Decoding 实例在 Token 粒度下通过加权轮询调度模型执行，并在需要时触发亚秒级抢占扩缩容 $arrow.r$ 生成 Token 经缓冲区返回客户端。

```
[根目标: 最小化并发多模型 serving 的 GPU 数量 N 并满足 SLO]
  │
  ├── [模块 1: Prefill / Decoding 物理解耦架构]
  │     ├── 动机: 混合调度中 Prefill 突发破坏 TBT, 长 Decoding 破坏 TTFT
  │     ├── 机制: 划分 Prefill GPU 池与 Decoding GPU 池, 通过 IPC 异步传输 KV Cache
  │     └── 优势: 消除计算密集与访存密集任务的物理干涉
  │
  ├── [模块 2: Prefill 阶段分组 FCFS 调度 (Algorithm 1)]
  │     ├── 动机: Prefill 扩缩容开销(~0.81s)与计算耗时相当, 频繁切换破坏 TTFT
  │     ├── 机制: 优先合并至同模型现有 Group(MAX_GPSIZE=8) -> 否则追加至最小负载队列
  │     └── 优势: 抑制无意义扩缩容, 保持 FCFS 公平性并降低等待时间
  │
  ├── [模块 3: Decoding 阶段加权轮询调度 (Algorithm 2)]
  │     ├── 动机: 利用 Decoding 积累的松弛时间 n(d-t) 掩盖扩缩容开销
  │     ├── 机制: 维护旋转工作列表 -> 公式(2)(3)计算时间配额 q_i -> 轮询解码 q_i 秒
  │     └── 优势: 动态平衡多模型 TBT SLO 与扩缩容开销
  │
  └── [模块 4: 高效抢占式自动扩缩容引擎优化]
        ├── 1. 组件复用 (Component Reuse): 一次性初始化引擎/Executor, 缓存 Tokenizer/Profiling, 消除 80%+ 启动延迟
        ├── 2. 自研 VRAM 凸块分配器 (Bump Allocator): 预分配单块 VRAM, Monkey-patching 绕过 PyTorch 分配器, 消除 GC 停顿
        ├── 3. 显存/内存级模型缓存与预取: Model Cache 共享内存 + Stage Buffer 管道传输 + CUDA 流异步预取
        ├── 4. 统一 KV Cache Slab 分配器: 按 Slab 切分固定块, 解决多模型不同 Cache Shape 导致的 DRAM/VRAM 碎片
        └── 5. 细粒度 KV Cache 同步: 使用 CUDA Event 异步跟踪状态与 IPC 跨进程传递, Move List 解耦 Swap-out
```

=== 6.1 核心算法说明
<61-核心算法说明>
+ #strong[Prefill 阶段分组 FCFS 算法（Algorithm 1）]：\[作者明确陈述\] 当新 Prefill 请求到达时，调度器首先检查当前 Prefill 实例上是否已有相同模型的 Group 正在运行；若存在且未超过最大批大小 `MAX_GPSIZE`（默认 8），则合并处理。否则追加至负载最小的 Prefill 实例队列中，按批大小为 1 顺序执行，从而避免在 Prefill 阶段触发频繁的模型频繁切换。
+ #strong[Decoding 阶段加权轮询算法（Algorithm 2）]：\[作者明确陈述\] 调度器维护一个动态旋转的模型工作列表。每个模型批次 $i$ 分配一个连续解码时间配额 $q_i$。配额计算依据公式 (2) 与 (3)，由全局扩缩容开销 $c$、各模型单步耗时 $t_k$ 以及 TBT SLO 截止时间 $d$ 共同决定，确保在配额 $q_i$ 内生成的 Token 能在客户端缓冲区支持下不发生 SLO 违约，同时释放出的松弛时间用于掩盖下一个模型的上线开销。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/source-crops/img_in_chart_box_639_139_1105_334.png", width: 100%)
  #emph[Figure 3. Overall token generation process of a request. SLO attainment is defined as the percentage of token generation times that meet their deadlines, i.e., the proportion of the green area.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：将请求延迟解耦为TTFT与TBT，按每个Token是否按时完成计算SLO达成率。

- #strong[论证关系]：建立了全文端到端评估判定标准，支撑了Prefill与Decoding阶段物理解耦调度的合理性。

- #strong[适用范围]：适用于基于Token粒度的TTFT（默认10s）与TBT（默认100ms）SLO评估模型。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/source-crops/img_in_image_box_108_148_589_455.png", width: 100%)
  #emph[Figure 5. System overview of Aegaeon.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：系统架构清晰划分为Proxy层、解耦的Prefill/Decoding Serving实例池以及Host DRAM端的Model Cache与Unified CPU KV Cache。

- #strong[论证关系]：展示了解决Token级调度与扩缩容开销的全栈系统架构实现，支撑了机制主张。

- #strong[适用范围]：覆盖Aegaeon单节点与多节点部署架构。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/source-crops/img_in_image_box_644_137_1109_688.png", width: 100%)
  #emph[Figure 6. Exemplar token-level schedules on two GPUs. Prefill-first scheduling (a) and decoding-first scheduling (b) both lead to SLO violations. Disaggregated scheduling (c) separates prefill and decoding jobs to enable balanced token generation.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：传统Prefill优先会导致大面积TBT违约，Decoding优先会导致大面积TTFT违约，而解耦调度实现了零SLO违约。

- #strong[论证关系]：证明了将GPU池解耦为独立Prefill实例与Decoding实例的必要性与技术优势。

- #strong[适用范围]：覆盖2卡GPU多模型Token级调度示意场景。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/source-crops/img_in_image_box_633_146_1114_490.png", width: 100%)
  #emph[Figure 9. Explicitly managed memory in Aegaeon, with exemplar memory sizes in brackets. Relevant steps for scaling up a model and operations on the unified KV cache are also illustrated.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示了VRAM中的Bump Allocator缓冲区、Host DRAM中的Page-Locked Stage Buffer及底层的统一Slab分配器切分。

- #strong[论证关系]：说明了如何消除PyTorch GC停顿并将显存碎片控制在20%以下，支撑了机制主张。

- #strong[适用范围]：覆盖单GPU实例及Host内存环境下的内存管理设计。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  #image("assets/source-crops/img_in_image_box_636_144_1116_402.png", width: 100%)
  #emph[Figure 10. Efficient scaling in Aegaeon, with fine-grained KV cache synchronization. Dotted boxes indicate non-critical operations, and striped boxes indicate cache blocks in move lists.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：利用4个独立CUDA Stream、CUDA Event以及IPC跨进程传递，实现Prefill到Decoding阶段KV Cache的无锁细粒度同步。

- #strong[论证关系]：证实了数据面全异步流水线化的设计有效性，解释了如何实现亚秒级上线。

- #strong[适用范围]：基于NVIDIA CUDA架构的多Stream与CUDA IPC同步场景。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

\[基于文中逻辑的推断\] 下表连接 Aegaeon 的核心机制、预期技术收益以及生效所需的必要前提：

#figure(
  align(center)[#table(
    columns: 3,
    align: (left,left,left,),
    table.header([机制设计], [预期技术收益], [需满足的物理/逻辑条件],),
    table.hline(),
    [#strong[Prefill / Decoding 物理解耦]], [消除 Prefill 突发对 Decoding TBT 的干涉，让 TTFT 与 TBT 可以分别独立优化。], [PCIe / 跨节点网络具备足够的带宽传输 KV Cache 状态。],
    [#strong[Token 粒度加权轮询调度]], [消除队头阻塞，让挂起模型获得极低的 TTFT 排队延迟。], [客户端具备缓冲区暂存 Token，且 TBT SLO 允许积累松弛时间 $n\(d - t\)$。],
    [#strong[组件复用 (Component Reuse)]], [削减 80% 以上的推理引擎初始化延迟（从 26.9 秒降至 0.8 秒）。], [模型架构在算子与 Executor 层面具有通用性（如均基于 Transformer 库）。],
    [#strong[VRAM 凸块分配器 (Bump Allocator)]], [重置指针代替 `empty_cache()`，完全消除 Python 显存 GC 停顿。], [模型权重与 KV Cache 的内存生命周期严格可预测。],
    [#strong[统一 KV Cache Slab 分配器]], [将多模型混用下的 DRAM/VRAM 内存碎片率控制在 20% 以下。], [KV Cache 块尺寸可按固定 Block/Slab 规格归一化切分。],
    [#strong[CUDA Event 细粒度同步]], [跨进程/跨 GPU 传输 KV Cache 无锁流水线化，实现亚秒级甚至近零延迟上线。], [硬件支持 CUDA Event API 与 CUDA IPC 句柄跨进程传递。],
  )]
  , kind: table
  )

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
\[作者明确陈述\] 实验部分设计了三类主要验证路线，旨在回答四个核心问题：

+ #strong[池化效果问题（Goodput / SLO 达成率）]：在相同 GPU 数量下，Aegaeon 能否比现有系统支持更高倍数的 RPS 和更多数量的模型？\[判定标准：SLO 达成率保持在 $gt.eq 90 %$ 时的最大模型数与最大 RPS\]
+ #strong[开销削减问题（Microbenchmarks）]：Aegaeon 的全栈优化是否真正将抢占式扩缩容开销降低至亚秒级？\[判定标准：扩缩容延迟 CDF 分布与显存碎片率\]
+ #strong[鲁棒性与扩展性问题]：在变体数据集、低端硬件及超大模型上，系统优势是否依旧存在？\[判定标准：不同数据集与硬件上的 Goodput 曲线\]
+ #strong[生产实用性问题]：真实生产集群中能否大幅节省 GPU 硬件开销？\[判定标准：阿里云百炼部署的 GPU 数量缩减比例与利用率变化\]

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- #strong[测试数据集]：ShareGPT 真实对话数据集；变体数据集 ShareGPT-ix2（输入长度翻倍）、ShareGPT-ox2（输出长度翻倍）；生产环境真实请求日志。
- #strong[硬件测试床]：
  - #emph[实验室主集群]：2 个节点共 16 张 NVIDIA H800 80GB GPU，PCIe 4.0 总线，2TB DDR5 Host 内存，192 CPU 核心。
  - #emph[实验室补充集群]：4 张 NVIDIA A10 24GB GPU（测试低显存扩展性）。
  - #emph[生产集群]：阿里云百炼跨区域集群，213 张 NVIDIA H20 GPU，托管 47 个模型（参数量 1.8B 至 72B）。
- #strong[对比基线系统]：
  - #emph[ServerlessLLM]：SOTA 请求级自动扩缩容系统。
  - #emph[ServerlessLLM+]：引入 Oracle SJF（最短作业优先）调度的扩展变体。
  - #emph[MuxServe]：SOTA 静态多路复用 GPU 池化系统。
- #strong[服务 SLO 设置]：默认设置 TTFT SLO 为 10 秒，TBT SLO 为 100ms。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
==== \(1) 预期活跃模型数期望值 $bb(E)\[m\]$
<1-预期活跃模型数期望值-mathbbem>
- #strong[指标与方向]：预期活跃模型数期望值，$bb(E)\[m\]$，测量系统在任意时刻至少有一个请求在运行的模型总数，单位：个，取值范围 $\[0\,M\]$，越低越好。
- #strong[定义与公式]： $ bb(E)\[m\]= M dot.op\(1 - e^(- lambda T)\) $
- #strong[来源层级]：`原文公式`（编号：Eq. 1 / 第 4 页）。
- #strong[实验用途]：用于理论证明"请求级自动扩缩容方法存在资源池化理论上限"。
- #strong[读数与边界]：在 $M = 100\,lambda = 0.037\,T = 16.79 upright("s")$ 条件下，理论值与仿真值均落于 46.55 个模型，证明请求级扩缩容需预留大量 GPU。

==== \(2) 解码阶段轮询时间配额 $q_i$
<2-解码阶段轮询时间配额-q_i>
- #strong[指标与方向]：解码阶段轮询时间配额，$q_i$，测量调度器分配给第 $i$ 个模型批次的连续解码时间，单位：秒，取值范围 $\(0\,Q_(upright("MAX"))\]$，需按 SLO 动态调整。
- #strong[定义与公式]： $ q_i = frac(c, n_i dot.op (alpha - sum_k 1 / n_k)) $
- #strong[来源层级]：`原文公式`（编号：Eq. 2 / 第 7 页）。
- #strong[实验用途]：用于 Decoding 阶段 weighted round-robin 调度器确定各模型批次单次连续运行时间。
- #strong[读数与边界]：根据实时扩缩容开销 $c$ 与容忍步数 $n_k$ 动态计算，上限 $Q_(upright("MAX")) = 4$ 秒。

==== \(3) SLO 达成率倒数估计值 $alpha$
<3-slo-达成率倒数估计值-alpha>
- #strong[指标与方向]：SLO 达成率倒数估计值，$alpha$，评估当前模型集合在给定开销下的 SLO 达成倒数，无量纲，取值范围 $\[0.5\,+ oo\)$，越小越好。
- #strong[定义与公式]： $ alpha = max (frac(c, min_k\(n_k\)dot.op Q_(upright("MAX"))) + sum_k 1 / n_k \, 0.5) $
- #strong[来源层级]：`原文公式`（编号：Eq. 3 / 第 7 页）。
- #strong[实验用途]：作为控制变量参与时间配额 $q_i$ 的实时计算。
- #strong[读数与边界]：当 $alpha = 0.5$ 时表明系统拥有极高的延迟容忍裕度。

==== \(4) 端到端 SLO 达成率（SLO Attainment）
<4-端到端-slo-达成率slo-attainment>
- #strong[指标与方向]：端到端 SLO 达成率，SLO Attainment，测量满足 TTFT 与 TBT 截止时间的 Token 生成百分比，单位：%，取值范围 $\[0 %\,100 %\]$，越高越好（合格线 $gt.eq 90 %$）。
- #strong[定义与公式]：
  - 推理依据：原文事实：作者定义"SLO attainment as the percentage of token generation times that meet their deadlines" $arrow.r$ 推导关系 $arrow.r$ 指标含义。 $ upright("SLO Attainment") = frac(upright("Count")\(upright("TTFT") lt.eq upright("TTFT")_(upright("target"))\)+ upright("Count")\(upright("TBT") lt.eq upright("TBT")_(upright("target"))\), upright("Total Generation Steps")) times 100 % $
- #strong[来源层级]：`推导关系（非原文公式）` `[基于文中逻辑的推断]`。
- #strong[实验用途]：作为端到端性能与容量评估的核心主指标（图 11、12、13）。
- #strong[读数与边界]：在 RPS=0.1 下，Aegaeon 在 70 个模型时依然维持 90% 以上的达成率。

==== \(5) GPU 资源节省率（GPU Resource Saving）
<5-gpu-资源节省率gpu-resource-saving>
- #strong[指标与方向]：GPU 资源节省率，测量部署 Aegaeon 后减少的 GPU 数量比例，单位：%，取值范围 $\[0 %\,100 %\]$，越高越好。
- #strong[定义与公式]：
  - 推理依据：原文事实：作者陈述"reduces the number of GPUs required from 1,192 to 213, highlighting an 82% GPU resource saving" $arrow.r$ 推导关系 $arrow.r$ 指标含义。 $ upright("GPU Resource Saving") = frac(N_(upright("baseline")) - N_(upright("Aegaeon")), N_(upright("baseline"))) times 100 % $
- #strong[来源层级]：`推导关系（非原文公式）` `[基于文中逻辑的推断]`。
- #strong[实验用途]：评估生产环境部署收益（§7.5）。
- #strong[读数与边界]：生产实际读数为 82.13%（节省 979 张 GPU）。

==== \(6) 内存/显存碎片率（Memory Fragmentation）
<6-内存显存碎片率memory-fragmentation>
- #strong[指标与方向]：内存/显存碎片率，测量系统未利用显存与峰值分配显存的比值，单位：%，取值范围 $\[0 %\,100 %\]$，越低越好。
- #strong[定义与公式]：
  - 推理依据：原文事实：作者说明"calculated as the ratio of unused memory to peak allocated memory" $arrow.r$ 推导关系 $arrow.r$ 指标含义。 $ upright("Fragmentation") = upright("Unused Memory") / upright("Peak Allocated Memory") times 100 % $
- #strong[来源层级]：`推导关系（非原文公式）` `[基于文中逻辑的推断]`。
- #strong[实验用途]：评估统一 KV Cache Slab 分配器的显存空间利用效率（图 16）。
- #strong[读数与边界]：Aegaeon 的显存碎片率控制在 20% 以下，显著优于 vLLM 默认分配器。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
==== 比较工作与受批判限制地图
<比较工作与受批判限制地图>
#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([比较工作 / 路线], [本文指出的具体 Limit / 失效条件], [本文对应的设计模块], [检验批判的实验 / 指标 / 图表],),
    table.hline(),
    [#strong[MuxServe \[20\]] #emph[\(静态多路复用)]], [受限于 GPU 显存容量硬限制，单卡只能放置 2 个 14B 模型，16 GPU 场景下无法承载超过 32 个模型。], [Token 粒度抢占式自动扩缩容，模型权重从 Host DRAM 按需上线。], [#strong[图 11 / 图 12]：MuxServe 在每 GPU 超过 2 个模型时拒绝配置，折线终止于 32 个模型。],
    [#strong[ServerlessLLM \[21\]] #emph[\(请求级自动扩缩容)]], [仅在请求粒度扩缩容，引发严重队头阻塞（HOL Blocking），在密集到达或长生成场景下 SLO 大面积违约。], [Token 粒度抢占式扩缩容 + Prefill/Decoding 解耦调度。], [#strong[图 11 / 图 12]：Aegaeon 承载 RPS 为 ServerlessLLM 的 2.5 倍，Goodput 提升 1.5--9 倍。],
    [#strong[ServerlessLLM+] #emph[\(Oracle SJF 变体)]], [依靠 SJF 虽缓解排队，但在密集到达时频繁触发扩缩容，带来巨大的开销，性能甚至劣于普通 ServerlessLLM。], [Grouped FCFS (Prefill) + Weighted Round-Robin (Decoding) 抑制无意义扩缩容。], [#strong[图 11(b)]：高 RPS (0.5) 下 ServerlessLLM+ 的 SLO 达成率崩塌最快。],
    [#strong[通用 vLLM 引擎] #emph[\(未优化后端)]], [重复初始化开销大（26.9s），显存碎片引发频繁 GC 停顿，KV Cache 同步阻塞。], [组件复用 + Bump Allocator + Slab Allocator + CUDA Event 细粒度同步。], [#strong[图 7 / 图 15]：将扩缩容总开销削减 97%（降至 1 秒以内）。],
  )]
  , kind: table
  )

==== 主张地图与证据计划
<主张地图与证据计划>
#figure(
  align(center)[#table(
    columns: 3,
    align: (left,left,left,),
    table.header([主张类型], [论文提出的核心主张与证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [#strong[效果主张 (Effectiveness)]], [Aegaeon 实现单 GPU 承载多达 7 个模型，Goodput 提高 1.5--9 倍。（证据：图 11、图 12 端到端实验）], [#strong[文本与图表证据充分]。16 GPU 承载 70 模型且满足 90% SLO。],
    [#strong[效果主张 (Production)]], [阿里云百炼部署节省 82% GPU 资源（1,192 降至 213 张 H20），GPU 平均利用率提升至 48.1%。（证据：§7.5 生产部署数据）], [#strong[生产实测证据充分]。包含 70 小时、47 个模型的真实运行监控。],
    [#strong[机制主张 (Mechanism)]], [扩缩容全栈优化消除 97% 开销；预取机制使 50% 的扩缩容达到接近零延迟。（证据：图 7、图 15 开销消融与 CDF）], [#strong[微基准证据充分]。CDF 图直观展示亚秒级开销分布。],
    [#strong[必要性主张 (Necessity)]], [请求级自动扩缩容受限于定理 3.1 的活跃模型期望数 $bb(E)\[m\]$，必须使用 Token 粒度扩缩容。（证据：图 4 仿真与定理 3.1）], [#strong[理论+仿真证据充分]。公式推导与实验对比互相印证。],
    [#strong[鲁棒性主张 (Robustness)]], [在 A10 24GB 低端 GPU 以及 72B (TP=4) 超大模型上均表现出强拓展性。（证据：§7.4 图 17 扩展性实验）], [#strong[文本证据充分]。覆盖不同硬件配置与并行度。],
    [#strong[适用范围 (Scope/Limit)]], [在极严苛延迟场景（TTFT 2s / TBT 20ms）下，Aegaeon 收益下降，静态多路复用重获优势。（证据：图 13(c) SLO 敏感性实验）], [#strong[作者明确陈述并由实验证明]。清晰给出了方法生效的下限边界。],
  )]
  , kind: table
  )

- #strong[实验设置关键补充]：实验室实验使用 16 张 H800 80GB GPU，按 6 张 Prefill + 10 张 Decoding 划分为物理解耦池。
- #strong[指标与判定补充]：SLO Attainment 门槛固定为 90%，在 RPS=0.1 时 Aegaeon 解码池（10 GPUs）成功承载 70 个模型，达到 7 模型/GPU 的密度。
- #strong[证据缺口说明]：跨节点管线并行（PP）场景下的细粒度 KV Cache 同步表现文中未说明。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0002-fe1ec4a8cbd6.png", width: 100%)
    #emph[Figure 2. Different auto-scaling granularities for sharing one GPU instance between three models.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：旧方法为何不够]
    - #strong[图组结论]：请求级自动扩缩容在长生成请求下导致大面积TTFT违约，而Token粒度扩缩容能在Token步级别抢占，使TTFT保持极短。

- #strong[论证关系]：直观验证了定理3.1导出的机理，支撑了必要性与机制主张，说明必须将扩缩容粒度精细化至Token级别。

- #strong[适用范围]：展示3个模型共享单张GPU实例的抢占调度概念模型。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_106_142_1117_302.png", width: 100%)
    #emph[Figure 7. Left: default preemptive auto-scaling process for an inference engine. Middle and Right: typical composition of an LLM inference engine, and the latency breakdown of its initialization (both before and after our optimization).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：性能主张]
    - #strong[图组结论]：vLLM默认初始化耗时26.9秒，Aegaeon通过组件复用将总初始化耗时削减至0.8秒。

- #strong[论证关系]：提供了微基准消融证据，支撑了"组件复用能消除80%+启动开销"的机制主张。

- #strong[适用范围]：覆盖13B模型（TP=2）在PCIe 4.0环境下的初始化消融测试。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_102_338_589_485.png", width: 100%)
    #emph[Figure 8. Preemptive scaling with optimizations in §5.1 and §5.2. (a) w/ component reuse; (b) also w/ explicit memory management.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：性能主张]
    - #strong[图组结论]：相比于串行路径T1，叠加凸块分配器与CUDA流异步模型预取后，扩缩容关键路径耗时缩短至仅剩KV Cache换入换出的T2。

- #strong[论证关系]：消融验证了预取机制与显式内存管理对缩短关键路径的独立贡献。

- #strong[适用范围]：适用于具备足够显存容纳预取模型的GPU环境。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_108_139_1117_392.png", width: 100%)
    #emph[Figure 11. End-to-end SLO attainment under varying RPS with the ShareGPT dataset.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：性能主张]
    - #strong[图组结论]：在RPS=0.1下，Aegaeon承载模型上限达70个（7模型/GPU）；在RPS=0.5下，容量为ServerlessLLM的2.5倍。

- #strong[论证关系]：为效果主张提供了最核心的端到端对比证据，证明系统超越现有SOTA。

- #strong[适用范围]：16张H800 GPU（6 Prefill + 10 Decoding），标准的ShareGPT数据集。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_108_435_1115_646.png", width: 100%)
    #emph[Figure 12. End-to-end SLO attainment under varying RPS with alternative datasets. x-axis: number of models.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：性能主张]
    - #strong[图组结论]：在长输入（ix2）与长输出（ox2）数据集上，Aegaeon的90% SLO模型承载上限依旧保持在50--70个，而ServerlessLLM+发生严重崩塌。

- #strong[论证关系]：验证了系统在不同工作负载特征下的强鲁棒性与抑制无效扩缩容算法的正确性。

- #strong[适用范围]：ShareGPT-ix2和ShareGPT-ox2变体数据集。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  - #strong[图组结论]：展示不同模型架构下单Token在16位精度下的KV Cache Shapes与内存尺寸差异。

- #strong[论证关系]：支撑了统一KV Cache Slab分配器设计，证明需要Slab架构解决异构模型内存碎片问题。

- #strong[适用范围]：覆盖vLLM支持的多种典型开源LLM模型架构。
  #v(5pt)
  #image("table-groups/page-0008-d1e347df1fb8.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2. CUDA event APIs used in Aegaeon.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：具体主张]
  - #strong[图组结论]：汇总了Aegaeon中用于跨进程/跨Stream无锁同步的各类CUDA Event API及其功能用途。

- #strong[论证关系]：证明了细粒度KV Cache同步机制的底层硬件/驱动接口实现可行性。

- #strong[适用范围]：基于NVIDIA CUDA架构的GPU集群与多进程Serving环境。
  #v(5pt)
  #image("table-groups/page-0010-4ffaf3908ddd.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1. Symbols used in the latency modeling.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：性能主张]
  - #strong[图组结论]：定义并汇总了延迟建模与时间配额计算用到的数学符号及其物理意义。

- #strong[论证关系]：为Algorithm 2解码配额与SLO达成率计算公式提供了严谨的符号与理论定义基础。

- #strong[适用范围]：适用于Aegaeon延迟建模与算法推导。
  #v(5pt)
  #image("table-groups/page-0016-64e3a7b95a73.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：并发 LLM 服务中专属 GPU 分配在冷模型上导致严重资源浪费，在热模型上无法应对突发流量。
  - 旧方法限制：
    - 静态多路复用受限于物理显存容量，单 GPU 最多承载 2--3 个模型。
    - 请求级自动扩缩容受限于定理 3.1 导出的高活跃模型数 $bb(E)\[m\]$，引发严重的队头阻塞。
  - 核心洞见/假设：
    - 洞见 1：按 Token 粒度执行抢占式自动扩缩容可消除队头阻塞。
    - 洞见 2：Prefill/Decoding 物理解耦可消除计算密集与访存密集任务的相互干涉。
    - 假设 1：Decoding 阶段积累的松弛时间可用于掩盖扩缩容开销。
    - 假设 2：引擎组件复用与显式内存管理可将扩缩容开销降至亚秒级。
    - 方法模块：
      - 模块 1：Prefill / Decoding 物理解耦Serving 实例池。
      - 模块 2：Prefill 阶段 Grouped FCFS 调度算法（Algorithm 1）。
      - 模块 3：Decoding 阶段加权轮询调度算法（Algorithm 2）。
      - 模块 4：高效抢占式扩缩容引擎（组件复用 + Bump Allocator + Model Cache/Prefetch + Slab Allocator + CUDA Event 细粒度同步）。
      - 可验证预测：
        - 预测 1：扩缩容开销大幅削减 90% 以上，达到亚秒级。
        - 预测 2：单 GPU 承载模型数量大幅提升至 5--7 个，Goodput 提升 1.5--9 倍。
        - 预测 3：生产集群可用更少 GPU 服务相同数量的模型。
        - 指标与实验：
          - 评估指标：扩缩容延迟 CDF、端到端 SLO Attainment、Goodput、GPU 资源节省率、显存碎片率。
          - 实验设置：16 张 H800 GPU 测试床（ShareGPT 数据集）与 213 张 H20 生产集群。
          - 图表证据：
            - 图 7 / 9 / 15：证实扩缩容延迟从 26.9s 降至 1s 以内（削减 97%）。
            - 图 11 / 12：证实单 Decoding GPU 承载 7 个模型， Goodput 提升 1.5--9 倍。
            - §7.5 部署数据：证实生产环境显卡节省 82%（1,192 降至 213 张）。
            - 结论与适用边界：
              - 结论：Token 粒度抢占式扩缩容与解耦调度成功破解了并发多模型 Serving 的池化难题。
              - 适用边界：在极端低延迟（TTFT 2s / TBT 20ms）场景下收益下降；小显存 GPU（如 A10 24GB）上需禁用模型预取。

== 11. 结论、贡献与边界
<11-结论贡献与边界>

=== 11.1 核心贡献与边界划分
<111-核心贡献与边界划分>
+ #strong[理论与机制创新]：\[作者明确陈述\] 首次量化了并发 LLM 服务中请求级自动扩缩容的理论限制（定理 3.1），并提出了 Token 粒度自动扩缩容与 Prefill/Decoding 物理解耦调度的系统架构。
+ #strong[工程与全栈优化]：\[作者明确陈述\] 针对 Token 级调度的开销挑战，设计了包含组件复用、VRAM 凸块分配器、模型预取、统一 Slab 管理以及 CUDA Event 异步同步的全栈优化方案，将扩缩容延迟削减 97%。
+ #strong[真实落地验证]：\[实验支持\] 在实验室测试床中实现了单 GPU 承载 7 个模型与 1.5--9 倍 Goodput 提升；在阿里云百炼生产部署中实现了 82% 的 GPU 硬件节省。

=== 11.2 审稿式风险检查
<112-审稿式风险检查>
- #strong[贡献新意 (Novelty)]：强。将 Serverless 自动扩缩容推进到 Token 细粒度，且提出了针对 LLM 引擎全栈开销的完整系统化解答 \[基于文中逻辑的推断\]。
- #strong[写作/可复现性 (Reproducibility)]：中等偏强。论文公式推导严谨，算法细节（Algorithm 1 & 2）与内存结构图解详尽；但底层大量使用了 PyTorch 内部 Monkey-patching 与 CUDA IPC 私有接口，文中未说明代码开源仓库，复现门槛较高 \[基于文中逻辑的推断\]。
- #strong[效果大小 (Effect Size)]：极强。实验室 1.5--9 倍 Goodput 提升与生产集群 82% 的物理显卡节约均属于重大突破 \[实验支持\]。
- #strong[实验覆盖 (Experimental Coverage)]：强。覆盖了微基准、变体数据集、扩展硬件（A10）、72B 大模型以及 70 小时生产实测 \[实验支持\]。
- #strong[方法设计与假设风险]：\[作者明确陈述\] 在 SLO 极度严苛（TTFT 2s / TBT 20ms）的场景下，松弛时间不足以掩盖开销，导致系统优势丧失。当前证据未显示其他重大设计缺陷。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
==== \(1) Token 粒度自动扩缩容 (Token-Level Auto-Scaling)
<1-token-粒度自动扩缩容-token-level-auto-scaling>
- #strong[最小定义]：在 LLM 生成单个字符/词单元（Token）的微观时间步上执行模型的下线与上线抢占操作。
- #strong[第一性原理角色]：打破模型服务时间 $T$ 在宏观时间轴上的连续物理约束，将排队时间从 $O\(T\)$ 压缩至 $O\(t_(upright("step"))\)$。
- #strong[本文位置]：本文最核心的创新点与系统设计基石。

==== \(2) Prefill 与 Decoding 解耦 (Prefill/Decoding Disaggregation)
<2-prefill-与-decoding-解耦-prefilldecoding-disaggregation>
- #strong[最小定义]：将 GPU 实例池物理拆分为专门处理 Prompt 的 Prefill 池与专门处理字符生成的 Decoding 池。
- #strong[第一性原理角色]：隔离计算密集型任务（矩阵乘法计算界）与访存密集型任务（显存带宽访存界）对 GPU 执行单元的争抢。
- #strong[本文位置]：本文调度架构（§4）的核心设计选择。

==== \(3) 凸块分配器 (Bump Allocator)
<3-凸块分配器-bump-allocator>
- #strong[最小定义]：通过单向移动线性指针来连续分配显存，并通过一次性重置指针来全量释放显存的分配器。
- #strong[第一性原理角色]：利用内存分配的单调性约束，消除复杂链表查找与显存碎片垃圾回收（GC）停顿。
- #strong[本文位置]：用于接管 PyTorch 默认显存分配，消除扩缩容过程中的 GC 延迟。

==== \(4) 统一 KV Cache Slab 分配器 (Unified KV Cache Slab Allocator)
<4-统一-kv-cache-slab-分配器-unified-kv-cache-slab-allocator>
- #strong[最小定义]：将 DRAM/VRAM 划分为固定尺寸的 Slab 块，按 Block 粒度统一管理不同模型 Attention KV Cache 的内存分配器。
- #strong[第一性原理角色]：解决多模型混合运行下由于 KV Cache Shape（头数、维度）差异造成的内存空间碎片化。
- #strong[本文位置]：用于将多模型并发下的显存碎片率降至 20% 以下。

==== \(5) CUDA Event 异步同步 (CUDA Event Asynchronous Synchronization)
<5-cuda-event-异步同步-cuda-event-asynchronous-synchronization>
- #strong[最小定义]：利用 NVIDIA CUDA 驱动层的 Event API 与 IPC 句柄，在不同进程或 Stream 之间实现无锁通知与依赖等待。
- #strong[第一性原理角色]：解耦 CPU 控制流与 GPU 数据流，实现异步流水线完全重叠。
- #strong[本文位置]：用于 Prefill 到 Decoding 阶段 KV Cache 的细粒度、亚秒级移交。

=== 12.2 第一性原理学习路径
<122-第一性原理学习路径>
理解本文前建议补充的 4 个基础概念，按物理与逻辑依赖顺序排列：

+ #strong[基本对象（显存与 KV Cache）]：理解 LLM 在生成字符时为何需要维持 KV Cache（键值缓存，避免重复计算历史 Token），以及显存容量与带宽如何成为 Serving 的硬物理瓶颈 \[背景知识\]。
+ #strong[系统物理约束（TTFT 与 TBT SLO）]：理解用户体感延迟被拆解为首字延迟（TTFT）与打字间隔（TBT），以及客户端缓冲区如何提供延迟容忍的"松弛时间" \[背景知识\]。
+ #strong[运行机制（Prefill 与 Decoding 的计算特征差异）]：理解为什么 Prefill 是计算密集型（大 GEMM），而 Decoding 是访存密集型（单 Token GEMV），从而直观理解两者混合运行时的干涉冲突 \[背景知识\]。
+ #strong[指标与系统行为（排队论与 HOL Blocking）]：理解排队论中的队头阻塞现象，以及为何将调度粒度从"请求级"切碎到"Token 级"能够在物理上消除短任务等待长任务的排队延迟 \[基于文中逻辑的推断\]。
