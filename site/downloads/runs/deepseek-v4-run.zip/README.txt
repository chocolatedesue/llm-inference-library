这是「DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence」解构报告的原始运行数据（仅文本）。

来源
  job id        4a795e1f9a2a4d70ba68a0fa3a10ae2c
  source_url    https://arxiv.org/pdf/2606.19348
  OCR 页数      58
  报告模型      gemini-3.6-flash-medium
  prompt 版本   v12
  发布的 PDF    report.compact.pdf -> /downloads/deepseek-v4.pdf

包含什么
  full-text.md              整篇 OCR 文本（模型实际读到的东西）
  pages/page-*.md           逐页 OCR
  metadata.json             抽取出的标题/作者/venue/年份/标签/链接
  job.json, usage.json      运行状态与 token 用量账本
  report*.md                合成出的报告正文
  report*.layout.yaml       排版 DSL
  report*.typ               Pandoc + Typst 的编译输入
  figure-analyses/          逐图分析结果

不包含什么，以及为什么
  input/source.pdf          论文原文，第三方版权内容，按 source_url 自取
  assets/, *-groups/*.png   从原文切出的图片，同上；已发布的 PDF 里嵌了实际用到的图

要重新渲染报告：取回 source_url 的 PDF 重跑流水线，或用 report*.typ 配合自己的图片资源编译。
