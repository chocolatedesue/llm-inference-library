# 图片批次 2

## 图片 1：Figure 3 | Core architectures of CSA. It compresses the number of KV entries to times, and then applies DeepSeek Sparse Attention for further acceleration. Additionally, a small set of sliding window KV entries is combined with the selected compressed KV entries to enhance local fine-grained dependencies.

![Figure 3 | Core architectures of CSA. It compresses the number of KV entries to times, and then applies DeepSeek Sparse Attention for further acceleration. Additionally, a small set of sliding window KV entries is combined with the selected compressed KV entries to enhance local fine-grained dependencies.](../assets/imgs/img_in_image_box_152_172_1038_604.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：作者展示 Compressed Sparse Attention（CSA）的模块架构流程图，旨在验证和解释 DeepSeek-V4 如何通过“序列维度 Token 级压缩（每 $m=4$ 个 Token 压缩为 1 个 KV 入口）+ Lightning Indexer 索引评分与 Top-$k$ 稀疏选择 + 滑动窗口（Sliding Window）KV 补足 + 共享 KV MQA”实现高效长文本注意力的机制主张。该图解释了 CSA 的具体结构设计与数据流，支持论文关于在大幅降低 KV Cache 显存与计算开销的同时保留局部精细依赖与全局稀疏检索能力的分析。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：对应论文 2.3.1 节“Compressed Sparse Attention”及“方法推理树”中关于 CSA 混合注意力架构的描述。
2. **图像类型与布局**：结构示意图 / 架构流程图。图像自下而上组织：底部为 KV Token 隐状态序列（黄/橙色矩形块）与 Query Token 隐状态（绿色矩形块）；中间分为主干 KV 压缩选择路径与右侧虚线框内的 `Lightning Indexer` 索引计算路径；顶部为 `Concatenation` 拼接模块与 `Shared Key-Value Multi-Query Attention` 长灰框。
3. **如何阅读**：从底部输入序列开始自下而上阅读。左侧 KV 路径通过 `Token-Level Compressor` 压缩为 `Compressed KV Entries`，并由 `Top-k Selector` 根据索引得分进行挑选；右侧 `Lightning Indexer` 虚线框内计算 Query 与 `Compressed Indexer Keys` 的注意力，输出 `Index Scores` 柱状图信号控制 `Top-k Selector`；最左侧抽取 `Sliding Window KV Entries`；两者拼接后与右侧 `Queries` 共同进入顶部的 Shared KV MQA。
4. **直接可见的结论**：
   - CSA 结构显式包含滑动窗口路径（`Sliding Window KV Entries`）与压缩稀疏选择路径（`Compressed KV Entries` $\rightarrow$ `Top-k Selector` $\rightarrow$ `Selected Compressed KV Entries`）。`[图像直接可见]`
   - `Lightning Indexer` 被独立包含于虚线框内，拥有独立的 `Token-Level Compressor` 生成 `Compressed Indexer Keys`，其计算出的 `Index Scores` 动态控制主干的 `Top-k Selector`。`[图像直接可见]`
   - 筛选出的 `Selected Compressed KV Entries` 与 `Sliding Window KV Entries` 经 `Concatenation` 拼接后输入顶部的 `Shared Key-Value Multi-Query Attention`。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：验证了 CSA 通过“局部滑动窗口 + 压缩稀疏索引 Top-$k$ 选择”双轨结合降低注意力计算复杂度的机制主张`[正文支持]`。方法设计上，它展示了 CSA 如何在保留 128-token 局部连续性的同时，将历史 KV 压缩 $m=4$ 倍并利用轻量 Indexer 精准筛选 Top-$k$ 条目，解释了正文中 1M 上下文下单 Token FLOPs 与 KV Cache 显著降低的结构根源`[基于文中逻辑的推断]`。该图作为结构示意图，无法单独证明 Top-$k$ 选择的实际精度保留率或端到端硬件加速比`[正文支持]`。
6. **适用范围与证据缺口**：本图覆盖 DeepSeek-V4 中 Compressed Sparse Attention (CSA) 的模块架构设计。无额外证据缺口。

---

---

## 图片 2：Figure 4 | Core architectures of HCA. It performs heavier compression, where the KV entries of tokens will be consolidated into one. Also, we additionally introduce a small set of sliding window KV entries to enhance local fine-grained dependencies.

![Figure 4 | Core architectures of HCA. It performs heavier compression, where the KV entries of tokens will be consolidated into one. Also, we additionally introduce a small set of sliding window KV entries to enhance local fine-grained dependencies.](../assets/imgs/img_in_image_box_320_170_863_499.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：作者展示 Heavily Compressed Attention（HCA）的模块架构流程图，旨在验证和解释 DeepSeek-V4 如何通过“重度无重叠 Token 级压缩（每 $m'=128$ 个 Token 压缩为 1 个 KV 入口）+ 稠密注意力 + 滑动窗口 KV 补足”实现极低开销全局概要注意力的机制主张。该图解释了 HCA 的结构设计（相比 CSA 省去了 Indexer 和 Top-$k$ 稀疏选择，但大幅提高了压缩率），支持 CSA+HCA 混合注意力架构突破 1M 极长上下文计算与显存墙的核心主张。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：对应论文 2.3.2 节“Heavily Compressed Attention”及“方法推理树”中关于 HCA 混合注意力架构的描述。
2. **图像类型与布局**：结构示意图 / 架构流程图。图像自下而上组织：底部为 KV Token 隐状态序列（黄/橙色矩形块）与 Query Token 隐状态（绿色矩形块）；中间左侧分支通过 `Token-Level Compressor` 梯形算子生成 `Heavily Compressed KV Entries`，并与最左侧直接提取的 `Sliding Window KV Entries` 并行流动；中间右侧生成 `Queries`；顶部为 `Concatenation` 模块与 `Shared Key-Value Multi-Query Attention` 长灰框。
3. **如何阅读**：自下而上阅读。对比 CSA 结构图，HCA 中完全去除了 `Lightning Indexer` 虚线框、`Index Scores` 和 `Top-k Selector`。KV 序列经重度压缩后与滑动窗口 KV 条目直接在 `Concatenation` 处拼接，并与 `Queries` 一起送入顶部的 Shared KV MQA 进行全量稠密注意力计算。
4. **直接可见的结论**：
   - HCA 架构不包含任何索引器（Indexer）或 Top-$k$ 稀疏选择模块，其 KV 路径仅由 `Token-Level Compressor` 输出的 `Heavily Compressed KV Entries` 和 `Sliding Window KV Entries` 组成。`[图像直接可见]`
   - `Heavily Compressed KV Entries` 与 `Sliding Window KV Entries` 拼接后直接输入 `Shared Key-Value Multi-Query Attention` 执行全量稠密注意力计算。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：验证了 HCA 采用“重度压缩 + 稠密 MQA + 滑动窗口”简化设计的机制主张`[正文支持]`。在方法设计上，HCA 放弃了复杂的稀疏筛选，转而采用更大的无重叠压缩率 $m'=128$，在极大幅度削减 KV Cache 体积的同时保持全局上下文的稠密覆盖。它与 CSA 形成互补（分别承担高分辨率稀疏检索与重度概要稠密覆盖），共同解释了 DeepSeek-V4 在 1M 上下文下显存占用降至 DeepSeek-V3.2 的 10%（Pro）和 7%（Flash）的结构逻辑`[基于文中逻辑的推断]`。该图无法单独证明 $m'=128$ 大比例压缩是否会导致细粒度语义信息的丢失`[正文支持]`。
6. **适用范围与证据缺口**：本图覆盖 DeepSeek-V4 中 Heavily Compressed Attention (HCA) 的模块架构设计。无额外证据缺口。
