# 图片批次 1

## 图片 1：Figure 1 | Left: benchmark performance of DeepSeek-V4-Pro-Max and its counterparts. Right: inference FLOPs and KV cache size of DeepSeek-V4 series and DeepSeek-V3.2.

![Figure 1 | Left: benchmark performance of DeepSeek-V4-Pro-Max and its counterparts. Right: inference FLOPs and KV cache size of DeepSeek-V4 series and DeepSeek-V3.2.](../figure-groups/page-0001-7c4cbec22eae.png)

*来源：OCR 第 1 页。*

### 解读

1. **论文角色与验证问题**：Figure 1 由 Panel 1（左图，综合基准能力对比）、Panel 2（右上，单 Token 推理 FLOPs 随 Token 位置演进）与 Panel 3（左下，累积 KV Cache 随序列长度增长）三个 Panel 组内配合构成。Panel 1 证明 DeepSeek-V4-Pro-Max 在基础知识、复杂推理与 Agent 任务上达到了与闭源顶尖模型对标或领先的前沿能力标准；Panel 2 与 Panel 3 则直接验证了 CSA+HCA 混合注意力架构在 1M 上下文极长序列下大幅压低单 Token 计算 FLOPs 与 KV Cache 显存占用的量化效率突破。三者共同支撑了“在不牺牲模型顶尖智能的前提下突破 1M 超长上下文计算/显存屏障”的核心主张。`[正文支持]`
   - **图表角色**：`实验结论`
   - **上文呼应**：对应“主张地图与证据计划”第 1 项（效果主张：DeepSeek-V4-Pro 显著降低 1M 上下文下的推理开销与显存占用）与第 4 项（效果主张：DeepSeek-V4-Pro-Max 在竞赛编程与开源领域能力上达到前沿 SOTA），以及正文 Abstract、1 Introduction 和 2.3.4 Efficiency Discussion。
   - **验证的具体问题**：验证 DeepSeek-V4-Pro/Flash 相比旧方法 DeepSeek-V3.2 能否大幅降低 1M 上下文极长序列下的单 Token 推理 FLOPs 和 KV Cache 显存占用，以及 DeepSeek-V4-Pro-Max 是否能在知识、推理与 Agent 核心基准测试中达到前沿 SOTA 水平。`[正文支持]`
2. **图像类型与布局**：组合图，包含 3 个 Panel。Panel 1（左侧）为柱状图（Bar Chart），按任务分组展示 4 个模型（DeepSeek-V4-Pro-Max 蓝底斜纹柱、Claude-Opus-4.6-Max 浅灰柱、GPT-5.4-xHigh 深灰柱、Gemini-3.1-Pro-High 极浅灰柱）在 Knowledge & Reasoning（SimpleQA Verified, HLE, Apex Shortlist, Codeforces）与 Agentic Capabilities（SWE Verified, Terminal Bench 2.0, Toolathlon）共 7 个 Benchmark 上的得分。Panel 2（右上）为折线图（Line Chart），横轴为 Token Position (K)（0 至 1024K），纵轴为 Single-Token FLOPs (T)（0.0 至 1.2 T FLOPs），包含 DeepSeek-V3.2（灰色虚线）、DeepSeek-V4-Pro（深蓝色实线）与 DeepSeek-V4-Flash（浅蓝色实线）三条曲线，并在 1024K 处标注 “3.7× lower” 和 “9.8× lower” 双向箭头指示框。Panel 3（左下）为折线图（Line Chart），横轴为 Sequence Length (K)（0 至 1024K），纵轴为 Accumulated KV Cache (GB)（0 至 50 GB），包含相同的三个模型曲线，并在 1024K 处标注 “9.5× smaller” 与 “13.7× smaller” 指示框。
3. **如何阅读**：Panel 1 需按自左向右顺序阅读 Knowledge & Reasoning 与 Agentic Capabilities 分类下各模型的柱高及顶端具体数值进行横向对比。Panel 2 需随 Token 位置右移观察单 Token FLOPs 增长斜率，重点对比 1024K（1M）终点处 DeepSeek-V4 系列与 DeepSeek-V3.2 的纵坐标差距及倍率标注。Panel 3 需随序列长度右移观察显存占用增长斜率，重点对比 1024K 处三条线的上升幅度与降幅倍率。
4. **直接可见的结论**：
   - Panel 1：DeepSeek-V4-Pro-Max 在 SimpleQA Verified 上得分为 57.9%，显著高于 Claude-Opus-4.6-Max (46.2%) 和 GPT-5.4-xHigh (45.3%)；在 Codeforces 上 Rating 达到 3206，高于 Claude (3168) 与 GPT-5.4 (3052)；在 Apex Shortlist (90.2%)、SWE Verified (80.6%) 上表现优异；在 HLE (37.7%) 和 Terminal Bench 2.0 (67.9%) 上略低于 Gemini-3.1-Pro-High (44.4%) 或 GPT-5.4-xHigh (75.1%)。`[图像直接可见]`
   - Panel 2：随着 Token 位置从 0 扩展至 1024K，DeepSeek-V3.2 的单 Token 推理 FLOPs 呈陡峭线性上升（从约 0.15 T 升至约 1.15 T）；而 DeepSeek-V4-Pro 增长平缓，在 1024K 处比 DeepSeek-V3.2 低 3.7 倍；DeepSeek-V4-Flash 增长更为平缓，在 1024K 处比 DeepSeek-V3.2 低 9.8 倍。`[图像直接可见]`
   - Panel 3：随着序列长度扩展至 1024K，DeepSeek-V3.2 的累积 KV Cache 呈陡峭线性增长（在 1024K 时达到约 49.5 GB）；DeepSeek-V4-Pro 仅增长至约 5.2 GB（体积减小 9.5 倍）；DeepSeek-V4-Flash 仅增长至约 3.6 GB（体积减小 13.7 倍）。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：该图验证了论文关于“混合注意力（CSA+HCA）突破超长上下文推理 FLOPs 与显存瓶颈”的效果主张（Panel 2/3）以及“DeepSeek-V4-Pro-Max 树立开源模型能力前沿 SOTA”的效果主张（Panel 1）。方法设计含义上，Panel 2 与 Panel 3 直观证明了局部重叠压缩（CSA, $m=4$）与重度无重叠压缩（HCA, $m'=128$）的结合能够有效打破传统/旧版注意力随上下文膨胀的二次方及线性显存/算力消耗；读者据此可理解为何 DeepSeek-V4 能将 1M Token 的长文本推理与 Agent 思考留存（Interleaved Thinking）变为常规可行的工程实践。Panel 1 进一步证明了大幅压缩 KV Cache 和降低 FLOPs 并没有牺牲模型的通用智能、编程与 reasoning 能力。该图未直接展示 CSA 与 HCA 单独消融下的各自贡献占比，也未证明系统端到端的真实 Prefill/Decode 延迟瓶颈与 GPU 显存带宽利用率。`[基于文中逻辑的推断]`
6. **适用范围与证据缺口**：适用范围为本证据覆盖论文报告的 1.6T (49B 激活) DeepSeek-V4-Pro 和 284B (13B 激活) DeepSeek-V4-Flash 在 0 至 1024K (1M) 上下文设置下的理论单 Token FLOPs、KV Cache 显存占用及 7 个核心 Benchmark 评估。证据缺口为无额外证据缺口。

---

## 图片 2：Figure 2 | Overall architecture of DeepSeek-V4 series. We use hybrid CSA (Compressed Sparse Attention) and HCA (Heavily Compressed Attention) for attention layers, DeepSeekMoE for feed-forward layers, and strengthen conventional residual connections with mHC.

![Figure 2 | Overall architecture of DeepSeek-V4 series. We use hybrid CSA (Compressed Sparse Attention) and HCA (Heavily Compressed Attention) for attention layers, DeepSeekMoE for feed-forward layers, and strengthen conventional residual connections with mHC.](../assets/imgs/img_in_image_box_333_167_860_755.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：Figure 2 是 DeepSeek-V4 系列整体模型架构的高层拓扑示意图，展示了从输入 Token 嵌入到 Stacked Transformer Block（含 mHC 残差流、CSA/HCA 混合注意力、DeepSeekMoE 前馈网络）再到 Output Prediction Head 与 MTP (Multi-Token Prediction) 模块的数据流与信息流动逻辑。`[正文支持]`
   - **图表角色**：`方法流水线`
   - **上文呼应**：对应论文第 2 节（Architecture）及其子节 2.1、2.2、2.3，呼应“主张地图”中关于 CSA+HCA 混合注意力机制、mHC 流形约束超连接以及 MTP 多 Token 预测的架构设计主张。
   - **验证的具体问题**：直观解释 DeepSeek-V4 架构如何将 mHC（流形约束超连接）的 Pre-Block Mixing / Residual Mixing / Post-Block Mixing 机制与 CSA/HCA 混合注意力层及 DeepSeekMoE 层有机整合，构建支持超长上下文与深层稳定传播的网络拓扑。`[正文支持]`
2. **图像类型与布局**：架构示意图/流程图（Diagram/Flowchart）。整体为自下而上的数据流拓扑。底部为 “Input Tokens” 接入 “Embedding” 模块（黄底圆角框）；中间由虚线框包围 $L$ 个重复的 “Transformer Block $\times L$”；顶部为 “Prediction Head” 与 “MTP Modules”（黄底圆角框），分别通过虚线箭头指向 “LM Loss” 与 “MTP Loss”。虚线框内部包含两条并行/交织主线：左侧为多通道残差流（由 5 个并排胶囊/圆点向量表示），经过 “Residual Mixing”（灰框）与 “Pre-Block Mixing”（灰框）处理；右侧为计算分支，包含 “CSA / HCA”（黄框）和 “DeepSeekMoE”（黄框），计算结果经 “Post-Block Mixing”（灰框）后通过加号（$\oplus$）节点汇入左侧残差流。
3. **如何阅读**：按照自下而上的数据流方向阅读：底部输入 Tokens 经 Embedding 生成初始特征，进入 Transformer Block $\times L$ 主体；残差流在 Pre-Block Mixing 分流，一路经 Residual Mixing 继续向上，另一路输入右侧 CSA/HCA 注意力层进行序列混合；CSA/HCA 的输出经 Post-Block Mixing 与残差流相加；接着进行第二次分流：残差流经 Residual Mixing 向上，同时经 Pre-Block Mixing 分流至右侧 DeepSeekMoE 前馈层；DeepSeekMoE 输出经 Post-Block Mixing 与残差流再次相加；走出 Transformer Block 后，特征进入 Prediction Head 输出主语言模型损失（LM Loss），并进一步传入 MTP 模块输出多 Token 预测损失（MTP Loss）。
4. **直接可见的结论**：
   - DeepSeek-V4 在每个 Transformer Block 内交替使用了“CSA/HCA 混合注意力”层与“DeepSeekMoE”前馈层。`[图像直接可见]`
   - 残差连接采用了扩展的宽流通道（图中用 5 个并行向量胶囊表示），并在进入/离开计算 Block 前后分别设计了 “Pre-Block Mixing”、“Residual Mixing” 与 “Post-Block Mixing” 模块（即 mHC 的超连接混合结构）。`[图像直接可见]`
   - 模型在顶层继承了主 Prediction Head（输出 LM Loss）与 MTP (Multi-Token Prediction) 模块（输出 MTP Loss）。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：该图阐明了论文关于“流形约束超连接 (mHC) 强化传统残差连接”与“CSA/HCA + DeepSeekMoE 模块化交替堆叠”的方法设计与机制主张。方法设计含义上，图示清晰勾勒出 mHC 如何通过 Pre-Block Mixing 将宽残差流投影分发给 Attention（CSA/HCA）与 FFN（DeepSeekMoE），并通过 Post-Block Mixing 与 Residual Mixing 完成非膨胀性的信息融合；读者据此可以理解 mHC 对常规 Transformer 单通道残差流的结构性扩展，以及 CSA/HCA 模块在序列特征提取中的位置。该图仅为高层拓扑示意图，未展示 mHC 中 Sinkhorn-Knopp 迭代对矩阵 $B_l$ 的双随机流形投影数学细节，亦未展示 CSA 与 HCA 的具体压缩率（$m=4, m'=128$）与稀疏 Indexer 选择机制。`[基于文中逻辑的推断]`
6. **适用范围与证据缺口**：适用范围为本证据覆盖 DeepSeek-V4 系列模型（包括 DeepSeek-V4-Pro 与 DeepSeek-V4-Flash）的整体 Transformer Block 及 MTP 顶层架构拓扑定义。证据缺口为无额外证据缺口。
