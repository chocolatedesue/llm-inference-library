# 图片批次 6

## 图片 1：Figure 12 | Detailed dimension scores including Task Completion, Content Quality, Formatting Aesthetics, and Instruction Following.

![Figure 12 | Detailed dimension scores including Task Completion, Content Quality, Formatting Aesthetics, and Instruction Following.](../assets/imgs/img_in_chart_box_612_491_1047_749.jpg)

*来源：OCR 第 43 页。*

### 解读

1. **论文角色与验证问题**：作者需要这张图来多维度评估 DeepSeek-V4-Pro-Max 在真实白领办公（White-Collar Task）实操评估中的综合性能，并与顶尖闭源模型 Opus-4.6-Max 进行具体维度粒度的对比。它属于效果主张，试图验证 DeepSeek-V4-Pro-Max 在白领综合任务各子维度（任务完成度、指令遵循、内容质量、排版美观度及整体表现）上相对于顶级闭源模型的优势与特定局限。`[正文支持]`
   - **图表角色**：实验结论
   - **上文呼应**：对应论文 5.4.3 节“White-Collar Task”及主张地图中关于白领办公实操评测与模型能力局限的陈述（候选图注 Figure 12）。`[正文支持]`

2. **图像类型与布局**：双颜色对比分组柱状图。横轴按 5 个评测维度排列，每个维度包含两根柱子，左侧蓝色柱代表 DeepSeek-V4-Pro-Max，右侧红色柱代表 Opus-4.6-Max。柱顶标记有精确的分数数值，纵轴为分数（Score），范围在 70 至 100 之间，配有灰色虚线网格。

3. **如何阅读**：
   - **坐标轴与单位**：横轴为 5 个评估维度（Task Completion、Instruction Following、Content Quality、Formatting Aesthetics、Overall），纵轴为评分（Score，70-100 分）。
   - **图例**：蓝色柱代表 DeepSeek-V4-Pro-Max，红色柱代表 Opus-4.6-Max。
   - **比较顺序**：依次对比各维度下两模型的柱高和柱顶数值，数值越高表示该维度表现越好。

4. **直接可见的结论**：
   - 在 Task Completion 上，DeepSeek-V4-Pro-Max 得分 98.32，优于 Opus-4.6-Max 的 96.68。`[图像直接可见]`
   - 在 Instruction Following 上，DeepSeek-V4-Pro-Max 得分 87.76，略低于 Opus-4.6-Max 的 88.88。`[图像直接可见]`
   - 在 Content Quality 上，DeepSeek-V4-Pro-Max 得分 83.32，明显高于 Opus-4.6-Max 的 78.00。`[图像直接可见]`
   - 在 Formatting Aesthetics 上，DeepSeek-V4-Pro-Max 得分 76.68，高于 Opus-4.6-Max 的 72.68。`[图像直接可见]`
   - 在 Overall 综合评分上，DeepSeek-V4-Pro-Max 得分 86.52，高于 Opus-4.6-Max 的 84.06。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图提供了白领办公任务多维度对比的效果主张证据。图中所显现的优势（Content Quality 83.32 vs 78.00、Task Completion 98.32 vs 96.68）支持了正文中“DeepSeek-V4-Pro-Max 能主动预测隐式需求、提供补充洞察与深度叙述”的论点；而在 Instruction Following 上略微落后（87.76 vs 88.88）则印证了正文中关于“模型偶尔会遗漏特定格式约束，在纯指令遵循上微弱落后于 Opus”的局限性陈述。读者据此可以理解 Post-Training RL 与 OPD 蒸馏让模型获得了极高内容质量和任务完成度，但在严格格式指令遵循和 PPT Visual Formatting 排版美学上仍存在继续优化的空间。`[正文支持]`

6. **适用范围与证据缺口**：
   - **适用范围**：本证据覆盖论文报告的 30 项白领办公实操任务评测集下 DeepSeek-V4-Pro-Max 与 Opus-4.6-Max 的打分结果。`[正文支持]`
   - **证据缺口**：无额外证据缺口。

---

---

## 图片 2：Figure 13 | Example output of a task which requires drafting a joint marketing proposal for a popular bubble tea brand and the Beijing Subway.

![Figure 13 | Example output of a task which requires drafting a joint marketing proposal for a popular bubble tea brand and the Beijing Subway.](../assets/imgs/img_in_image_box_141_889_1049_1397.jpg)

*来源：OCR 第 43 页。*

### 解读

1. **论文角色与验证问题**：作者需要这张图来定性展示 DeepSeek-V4-Pro 在真实复杂 Agent 任务中的实际生成样例与长文本格式化输出能力。它属于效果主张与适用边界，试图验证模型在执行“为热门奶茶品牌与北京地铁起草联合营销方案”这一包含多页 PPT/方案排版、数据测算、营销排期与资源配置的复杂白领任务时的实际完成质量。`[正文支持]`
   - **图表角色**：实验结论
   - **上文呼应**：对应论文 5.4.3 节“White-Collar Task”中关于复杂白领任务生成样例与幻灯片排版能力的展示（候选图注 Figure 13）。`[正文支持]`

2. **图像类型与布局**：多页文档/PPT 渲染截图拼图。由 4 张 PPT 页面按 2x2 矩阵网格排布组成，背景为浅金/米白色设计风格，包含标题栏、副标题、层次化文本框、表格、时间轴排期图表及页码标注。

3. **如何阅读**：
   - **阅读顺序**：按左上（Page 18/25：UGC传播与社交裂变设计）、右上（Page 21/25：全年营销排期总览）、左下（Page 22/25：站点使用频次与全域覆盖分析）、右下（Page 24/25：分波段投资拆解与资源配置）的顺序阅读。
   - **对比与关注点**：观察各页面的标题结构、层级标题、文本框架、图表/表格排版完整度及中文专业规范表达。

4. **直接可见的结论**：
   - 生成内容包含完整的商业策划框架，涵盖 UGC 传播策略、传播效果预估表格、12 个月全周期营销排期表、30 个地铁站点的频次与覆盖分析图表、以及 500 万总预算的季度拆解表格。`[图像直接可见]`
   - 页面采用了标准的中文层级序号、模态框分组、进度/强度条以及格式化数据表格，表现出高度结构化的专业排版形式。`[图像直接可见]`
   - 页面右下角显示出该方案生成了多达 25 页的完整 PPT 内容（展示了第 18、21、22、24 页等切片）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为 DeepSeek-V4-Pro 在长上下文与复杂 Agent 工作流中的实用生成能力提供了定性样例文证。它印证了正文中关于“模型能够生成深度、连贯且符合规范的专业商业策划案，具备跨多页复杂表格与结构化排版生成能力”的论点；同时也直观呈现了正文中指出的“视觉排版美观度（Formatting Aesthetics）仍有提升空间”（如依赖通用框线和表格，缺乏更丰富的视觉艺术设计）。读者据此可直观理解 1M 上下文与 Post-Training 基础设施对支撑极长 Token 输出与复杂 Agent 格式化写作的实际效能。`[正文支持]`

6. **适用范围与证据缺口**：
   - **适用范围**：本证据覆盖论文 5.4.3 节展示的奶茶品牌与北京地铁联合营销策划案生成样例。`[正文支持]`
   - **证据缺口**：由于输出文档篇幅极长，图中仅展示了 25 页方案中的部分代表性截面页面（第 18、21、22、24 页）。`[图像直接可见]`
