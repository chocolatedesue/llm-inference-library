# 图片批次 5

## 图片 1：Figure 8 | Formal reasoning under practical and frontier regimes. Left: Putnam-200 Pass@8 evaluates a fixed random subset of PutnamBench (Tsoukalas et al., 2024) following the setup introduced by Seed-Prover; all models are tested on the same problem set. We follow the Seed-Prover protocol but replace proprietary search tools with the open-source LeanExplore (Asher, 2025), yielding a lightweight setting with minimal agent tools and bounded sampling. Right: Putnam-2025 probes the frontier of mathematical reasoning in a scaled hybrid formal-informal regime, where informal reasoning is combined with formal verification to expose gaps and improve rigor; DeepSeek-V4 reaches a proof-perfect 120/120.

![Figure 8 | Formal reasoning under practical and frontier regimes. Left: Putnam-200 Pass@8 evaluates a fixed random subset of PutnamBench (Tsoukalas et al., 2024) following the setup introduced by Seed-Prover; all models are tested on the same problem set. We follow the Seed-Prover protocol but replace proprietary search tools with the open-source LeanExplore (Asher, 2025), yielding a lightweight setting with minimal agent tools and bounded sampling. Right: Putnam-2025 probes the frontier of mathematical reasoning in a scaled hybrid formal-informal regime, where informal reasoning is combined with formal verification to expose gaps and improve rigor; DeepSeek-V4 reaches a proof-perfect 120/120.](../figure-groups/page-0040-da30b24a78fd.png)

*来源：OCR 第 40 页。*

### 解读

1. **论文角色与验证问题**：作者展示该图旨在评估 DeepSeek-V4 系列在形式化数学证明（Formal Reasoning）任务中的能力上限与突破。具体针对论文中的前沿能力主张，验证模型在“轻量实用设置（Practical Regime，Putnam-200 Pass@8）”与“前沿规模化混合证明设置（Frontier Regime，Putnam-2025）”下配合 Lean 4.28 形式化验证与 LeanExplore 工具的表现。`[正文支持]`
   - **图表角色**：`实验结论` `[正文支持]`
   - **上文呼应**：呼应正文第 4.3.1 节、第 5.3 节标准 Benchmark 评估，以及主张地图中的“效果主张：DeepSeek-V4-Pro-Max / DeepSeek-V4 在竞赛编程与形式化数学推理上达到前沿 SOTA”。 `[正文支持]`

2. **图像类型与布局**：图像由两个子面板（Panel 1 与 Panel 2）组成的横向条形对比图（Horizontal Bar Chart）构成。Panel 1（左侧）顶部带有标题“Practical Regime”及副标题“Putnam-200 Pass@8 with minimal tools and bounded sampling.”，下方从上至下排列 4 条横向柱状图，前 3 条为灰绿色基线，最后一条 DeepSeek-V4-Flash-Max 用蓝色突出，柱条右侧附有数值；Panel 2（右侧）为 Putnam-2025 上的横向柱状对比图，同样从上至下排列 4 条柱状图，前 3 条为灰绿色基线，最后一条 DeepSeek-V4 为蓝色突出，右侧附有“得分/总分”数值。底部左右分别带有“Panel 1”与“Panel 2”标注。 `[图像直接可见]`

3. **如何阅读**：
   - **横轴/柱长**：代表模型在对应竞赛数据集上的评测得分（Panel 1 为 Putnam-200 上的 Pass@8 得分；Panel 2 为 Putnam-2025 上的成功解题数量/总题数 120），柱越长得分越高。 `[图像直接可见]`
   - **纵轴/条目**：代表参与对比的模型。对比基线包括 Seed-1.5-Prover、Gemini-3-Pro、Seed-2.0-Pro、Aristotle 与 Axiom（灰绿色）；对照组为 DeepSeek 系列模型（蓝色）。 `[图像直接可见]`
   - **阅读顺序**：对比 Panel 1 中在受限采样和轻量工具下 DeepSeek-V4-Flash-Max 相较于专用/闭源 Prover 的得分翻倍优势；再看 Panel 2 中在前沿规模化扩展下 DeepSeek-V4 实现 120/120 满分的表现。 `[图像直接可见]`

4. **直接可见的结论**：
   - Panel 1 中，DeepSeek-V4-Flash-Max 在 Putnam-200 Pass@8 上取得 81.00 分，显著超越 Seed-2.0-Pro（35.50 分）、Gemini-3-Pro（26.50 分）和 Seed-1.5-Prover（26.50 分），得分达到第二名 Seed-2.0-Pro 的 2.28 倍。 `[图像直接可见]`
   - Panel 2 中，DeepSeek-V4 在 Putnam-2025 上达到 120/120 的满分成绩，与 Axiom（120/120）并列第一，高于 Seed-1.5-Prover（110/120）与 Aristotle（100/120）。 `[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - 本证据验证了 DeepSeek-V4 系列在形式化证明与数学推理上的`效果主张`。 `[正文支持]`
   - **旧方法/对比基线限制验证**：传统 Prover 模型（如 Seed-1.5-Prover）或通用闭源模型（如 Gemini-3-Pro）依赖专用搜索工具或在轻量工具设置下表达力有限，在 Putnam-200 上仅达到 26.50~35.50 分；图中结果验证了 DeepSeek-V4 即使在轻量级工具（LeanExplore）和有界采样约束下，仍能依靠强大的自建模与推理能力取得 81.00 分。 `[基于文中逻辑的推断]`
   - **前沿混合推理机制验证**：Panel 2 的 120/120 满分结果验证了将非形式化推理（Informal Reasoning）与形式化验证（Formal Verification）相结合的混合推理范式在扩展测试时算力（Test-Time Scaling）下的极高能力上限。 `[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：
   - **适用范围**：覆盖论文中基于 Lean 4.28 环境、Seed-Prover 评估协议、LeanExplore 开源工具链以及 PutnamBench（Putnam-200 子集与 Putnam-2025 完整集）的形式化证明测试设置。 `[正文支持]`
   - **证据缺口**：无额外证据缺口。 `[正文支持]`

---

---

## 图片 2：Figure 10 | HLE and Terminal Bench 2.0 performance by reasoning effort. "None" indicates Non-think mode, and "Speciale" indicates DeepSeek-V3.2-Speciale model.

![Figure 10 | HLE and Terminal Bench 2.0 performance by reasoning effort. "None" indicates Non-think mode, and "Speciale" indicates DeepSeek-V3.2-Speciale model.](../figure-groups/page-0041-b63fd83b52ff.png)

*来源：OCR 第 41 页。*

### 解读

1. **论文角色与验证问题**：作者展示该图旨在验证不同推理努力程度（Reasoning Effort: Non-think/None, Think High, Think Max）在困难 Reasoning 任务（HLE）与复杂 Agent 任务（TerminalBench 2.0）上的测试时扩展（Test-Time Scaling）效应。具体针对论文的核心机制与效果主张，回答随推理 Token 数扩展性能能否持续单调上升，以及 DeepSeek-V4 相比上一代 DeepSeek-V3.2 在单 Token 效率与能力上限上的优越性。 `[正文支持]`
   - **图表角色**：`实验结论` `[正文支持]`
   - **上文呼应**：呼应正文第 5.1.1 节“Reasoning Efforts”、第 5.3 节及第 5.4 节关于 Test-Time Scaling 与 Token 效率的论述，以及主张地图中“效果主张：DeepSeek-V4 系列通过 Post-Training RL 的 Reasoning Effort 模式实现了高 Token 效率的测试时扩展”。 `[正文支持]`

2. **图像类型与布局**：图像由两个子面板（Panel 1: HLE，Panel 2: TerminalBench 2.0）组成的折线图（Line Chart）构成。每个面板内包含 3 条不同颜色与标记形状的折线：蓝线加星号节点代表 DeepSeek-V4-Pro，浅蓝线加三角节点代表 DeepSeek-V4-Flash，灰色虚线加圆点节点代表 DeepSeek-V3.2（及 Speciale 变体）。节点旁标注有对应的推理模式名称（None, High, Max, Think, Speciale）。图例位于面板右下角，纵轴底部带有截断符号（Break）。底部带有“Panel 1”与“Panel 2”标注。 `[图像直接可见]`

3. **如何阅读**：
   - **横轴**：Total Tokens（总 Token 消耗量，单位为 k，即千 Token），代表模型推理生成的计算资源成本。 `[图像直接可见]`
   - **纵轴**：Pass@1 (%)，准确率百分比，位置越高代表性能越好。 `[图像直接可见]`
   - **对比维度**：观察同一模型在不同 Reasoning Effort（None -> High -> Max）下 Pass@1 随 Total Tokens 增加的增长趋势；比较在相同或相近 Token 消耗下 DeepSeek-V4-Pro/Flash 与 DeepSeek-V3.2 的 Pass@1 高低。 `[图像直接可见]`

4. **直接可见的结论**：
   - **Panel 1 (HLE)**：随着 Reasoning Effort 从 None 提升至 High 和 Max，DeepSeek-V4-Pro 与 Flash 的 Pass@1 均持续上升。DeepSeek-V4-Pro 在 High 模式（~35k tokens）下达到 ~34.6%，Max 模式（~54k tokens）下达到 ~37.8% 的最高分；DeepSeek-V4-Flash 在 Max 模式下（~86k tokens）达到 ~34.8%。DeepSeek-V3.2-Speciale 在 ~35k tokens 下约 30.8%，低于同等 Token 量下的 DeepSeek-V4-Pro (High)。 `[图像直接可见]`
   - **Panel 2 (TerminalBench 2.0)**：DeepSeek-V4-Pro 从 None (59.2%, ~28k tokens) 增长至 High (63.4%, ~36k tokens) 再到 Max (67.9%, ~50k tokens)；DeepSeek-V4-Flash 从 None (48.9%) 提升至 Max (57.0%)。DeepSeek-V3.2 在 Think 模式下仅为 46.5%（~19k tokens），其最高性能低于 DeepSeek-V4-Flash 在 None 模式下的表现（48.9%）。 `[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - 本证据验证了 DeepSeek-V4 系列测试时扩展与多推理模式设计的`效果主张`。 `[正文支持]`
   - **Test-Time Scaling 机制验证**：在困难学术推理（HLE）与实际终端 Agent（TerminalBench 2.0）场景中，性能随思考 Token 增加均展现出单调上升的 Scaling 特性，证明了 Post-Training 阶段通过不同的长度惩罚与上下文窗口控制成功训练出了能力可控梯度递进的 Reasoning Effort 模式。 `[基于文中逻辑的推断]`
   - **旧方法/对比基线限制验证（Token 效率对比）**：上一代 DeepSeek-V3.2 受到架构与 Token 效率瓶颈限制，在同等 Token 消耗下（如 HLE 35k tokens 处）性能显著落后于 DeepSeek-V4-Pro (High)；在 TerminalBench 2.0 上 V3.2 思考模式的最高分（46.5%）甚至不及 V4-Flash 的不思考模式（48.9%），验证了 DeepSeek-V4 混合注意力架构与 Post-Training 优化所带来的更高单 Token 推理价值与长程 Agent 记忆效率。 `[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：
   - **适用范围**：覆盖论文报告的 HLE（Humanities, Logics, Engineering 困难推理库）与 TerminalBench 2.0（终端 Agent 命令行交互）两项代表性任务在 None, Think High, Think Max 模式下的评测设置。 `[正文支持]`
   - **证据缺口**：无额外证据缺口。 `[正文支持]`
