# 图片批次 3

## 图片 1：Figure 5 | Illustration of our EP scheme with related works. Comet (Zhang et al., 2025b) overlaps Dispatch with Linear-1, and Linear-2 with Combine, separately. Our EP scheme achieves a finer-grained overlapping by splitting and scheduling experts into waves. The theoretical speedup is evaluated in the configuration of the DeepSeek-V4-Flash architecture.

![Figure 5 | Illustration of our EP scheme with related works. Comet (Zhang et al., 2025b) overlaps Dispatch with Linear-1, and Linear-2 with Combine, separately. Our EP scheme achieves a finer-grained overlapping by splitting and scheduling experts into waves. The theoretical speedup is evaluated in the configuration of the DeepSeek-V4-Flash architecture.](../assets/imgs/img_in_image_box_145_747_1038_1093.jpg)

*来源：OCR 第 15 页。*

### 解读

1. **论文角色与验证问题**：作者展示此图是为了说明本文提出的 MegaMoE² 细粒度专家并行（EP）通信与计算重叠机制如何突破旧方法的限制。针对旧方法中“粗粒度专家并行（如 Comet）在通信无法被计算完全掩盖、导致通信瓶颈”的缺陷，本图提供机制与效果证据，验证通过将专家拆分为细粒度 Wave（波次）并在单融合 mega-kernel 中实现 Dispatch、L1/L2 计算和 Act+Combine 三路重叠并行调度，如何彻底隐蔽通信延迟并提升 Theoretical Speedup。`[正文支持]`
   - **图表角色**：方法流水线 / 对比基线
   - **上文呼应**：对应“第 3.1 节：细粒度专家并行通信与计算重叠”及旧方法限制地图中“粗粒度专家并行（如 Comet）”。
2. **图像类型与布局**：时间线流程对比示意图。由 (a) Naive Solution、(b) Comet 和 (c) Ours 三个纵向堆叠的 Panel 组成，右下角附有各算子与通信操作的图例说明。
3. **如何阅读**：横轴代表时间推进方向。由上至下对比串行无重叠基线 (a)、Comet 粗粒度重叠基线 (b) 与本文提出的 Wave 细粒度重叠方案 (c)。(b) 拆分为 Communication 和 Computation 2 条轨道；(c) 进一步拆分为 Dispatch、Computation、Activation & Combine 3 条并行轨道，并标出 Expert Wave 1、2、3 三个波次，虚线指示跨轨道的依赖与重叠关系；比较右侧标注的理论加速比数值（1.42× vs 1.92×）。
4. **直接可见的结论**：在 (a) 中，Dispatch、L1、Act、L2、Combine 依次完全串行执行，耗时最长；在 (b) Comet 中，Dispatch 与 L1 重叠，Combine 与 L2 重叠，右侧标注理论加速比为 1.42×；在 (c) Ours 中，专家被切分为 3 个 Expert Wave，在 Dispatch 轨、Computation 轨（L1+L2）与 Activation & Combine 轨（Act+Combine）形成三轨流水线重叠（如 Wave 2 执行 L1+L2 时，Wave 1 执行 Act+Combine），右侧标注理论加速比提升至 1.92×。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：该图属于机制与效果证据。验证了本文提出的细粒度 Expert Wave 重叠 EP 方案通过更细粒度的专家切分与多轨流水线调度，能够将通信延迟完全隐蔽在计算之下。`[正文支持]` 解释了方法设计中将专家切分为波次（Waves）并在单融合 mega-kernel 中同步调度 Dispatch、GEMM 与 Combine 的必要性；对比 Comet 证明了粗粒度重叠无法掩盖 Combine 延迟的缺陷，而细粒度重叠可将理论加速比从 1.42× 提升至 1.92×。该图展示的是 DeepSeek-V4-Flash 架构配置下的理论加速比，不能由该图直接证明不同真实硬件拓扑与 Batch Size 下的实际端到端实测加速比。`[正文支持]`
6. **适用范围与证据缺口**：本证据覆盖论文报告的 DeepSeek-V4-Flash 架构配置下的 EP 通信与计算重叠流水线理论分析。无额外证据缺口。

---

## 图片 2：Figure 6 | Illustration of the KV cache Layout for DeepSeek-V4. The KV cache is organized into two primary components: a classical KV cache for CSA/HCA, and a state cache for SWA and unready-for-compression tokens in CSA/HCA. In the state cache, each request is assigned a fixed-size cache block. Within this block, the SWA segment stores the KV entries corresponding to the most recent tokens, while the CSA/HCA segment stores uncompressed tail states that are not yet ready for compression. In the classical KV cache, we allocate multiple blocks per request. Each cache block covers lcm( ) original tokens, producing CSA compressed tokens and HCA compressed tokens.

![Figure 6 | Illustration of the KV cache Layout for DeepSeek-V4. The KV cache is organized into two primary components: a classical KV cache for CSA/HCA, and a state cache for SWA and unready-for-compression tokens in CSA/HCA. In the state cache, each request is assigned a fixed-size cache block. Within this block, the SWA segment stores the KV entries corresponding to the most recent tokens, while the CSA/HCA segment stores uncompressed tail states that are not yet ready for compression. In the classical KV cache, we allocate multiple blocks per request. Each cache block covers lcm( ) original tokens, producing CSA compressed tokens and HCA compressed tokens.](../assets/imgs/img_in_image_box_177_183_1010_454.jpg)

*来源：OCR 第 22 页。*

### 解读

1. **论文角色与验证问题**：作者展示此图是为了解释 DeepSeek-V4 推理框架中异构 KV Cache 的内存组织架构。针对“CSA/HCA 混合压缩注意力与滑动窗口（SWA）存在不同压缩率（$m=4, m'=128$）、窗口大小（$n_{\text{win}}=128$）及未达到压缩长度的尾部 Token 状态，导致传统 PagedAttention 无法统一管理”的核心机制问题，本图提供机制证据，说明 State Cache 与 Classical KV Cache 解耦管理以及基于 $\text{lcm}(m, m')$ 块对齐的存储组织方案。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：对应“第 3.5.1 节：KV Cache 结构与管理”及旧方法限制地图中“传统 PagedAttention / Jenga / Hymba”。
2. **图像类型与布局**：结构示意图 / 内存布局框图。分为左右两大区域：左侧为“State Cache”，右侧为“KV Cache” (Classical KV Cache)，两边均附有局部放大（Zoom-in）结构框图。
3. **如何阅读**：区分左侧 State Cache（按请求 Request 1 ~ R 划分的固定大小池，管理 SWA 窗口与未压缩尾部 Token）与右侧 Classical KV Cache（按 Block 0 ~ N 划分的块状池，管理已完成压缩的 CSA 与 HCA 缓存）。观察右侧 Block 如何通过 $\text{lcm}(m, m')$ 最小公倍数对齐原始 Token 长度，使每个 Block 包含 $k_1 = \text{lcm}(m, m') / m$ 个 CSA 压缩 Token 和 $k_2 = \text{lcm}(m, m') / m'$ 个 HCA 压缩 Token。
4. **直接可见的结论**：在左侧 State Cache 中，每个 Request (1~R) 分配固定内存块，分为 SWA KV 段和 Uncompressed KV State 段；放大视图显示 SWA 段存储 Layer-0 至 Layer-n 的 SWA KV，Uncompressed 段存储 Layer-2 CSA State、Layer-3 HCA State 等未满压缩窗口的临时状态；在右侧 Classical KV Cache 中，存储按 Block 0~N 组织，放大视图显示在 Block 内按 Layer-2, Layer-3, Layer-4, Layer-5... 交替存放 CSA KV（拆分为 CSA Indexer KV 和 CSA Main KV，容量对应 $k_1$ 个 Token）与 HCA KV（容量对应 $k_2$ 个 Token）。`[图像直接可见]`
5. **它验证的论点与方法设计含义**：该图属于机制证据。验证了 DeepSeek-V4 克服混合注意力 KV Cache 管理障碍的解耦与块对齐设计。`[正文支持]` 说明了 State Cache 为什么能将动态变化的 SWA 窗口和未压缩尾部 Token 抽象为固定尺寸的状态空间模型（State-Space Model）池进行集中管理，以及 Classical KV Cache 为什么利用 $\text{lcm}(m, m')$ 块大小来消除不同层压缩率差异带来的内存碎片，保障高性能 Sparse Attention 算子的对齐访问。该图为架构设计示意图，图中不包含具体的显存吞吐率或 Cache 命中率等定量性能测量数据。`[正文支持]`
6. **适用范围与证据缺口**：本证据覆盖 DeepSeek-V4 推理框架中 CSA/HCA 混合注意力与 SWA 的异构 KV Cache 布局设计。无额外证据缺口。
