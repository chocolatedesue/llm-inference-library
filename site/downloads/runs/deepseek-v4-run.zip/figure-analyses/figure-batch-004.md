# 图片批次 4

## 图片 1：Figure 7 | Thinking management of DeepSeek-V4 series.

![Figure 7 | Thinking management of DeepSeek-V4 series.](../figure-groups/page-0031-0af8d75558f3.png)

*来源：OCR 第 31 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`方法流水线`
   - **上文呼应**：对应论文第 5.1 节（Post-Training Pipeline）中的 Interleaved Thinking 机制，呼应旧方法限制中“DeepSeek-V3/V3.2 在 Agent 多轮交互中，新一轮用户消息会清空先前的思考痕迹，导致重复计算与上下文状态丢失”。
   - **验证/解释的具体问题**：解释 DeepSeek-V4 如何利用 1M 超长上下文与高效 KV Cache，在工具调用场景（Tool-Calling Scenarios）与通用对话场景（General Conversational Scenarios）中实施差异化的思考痕迹（Thinking traces）保留与清除策略，以解决长程 Agent 工作流中的计算浪费与逻辑断层问题。`[正文支持]`

2. **图像类型与布局**：
   - **图像类型与布局**：示意图/流程图（Diagram）。分为 Panel 1（左侧，工具调用场景）与 Panel 2（右侧，通用对话场景）两部分，顶部以虚线隔开。
   - Panel 1（左侧）：自左向右依次展示 Turn 1.1 至 Turn 2.1 的交互过程。每轮纵向分为 Input（灰色背景框，内含 Tools、User message、Thinking、Tool call、Tool result）与 Output（蓝色/淡青色背景框，内含 Thinking、Tool call 或 Answer）。
   - Panel 2（右侧）：自左向右依次展示 Turn 1 至 Turn 3 的交互过程。Input 包含 User message 与历史 Answer，Output 包含 Thinking 与 Answer。

3. **如何阅读**：
   - 阅读顺序：自左向右观察随对话轮次（Turn）推进，Input 框中内容的累积变化。
   - 对照关系：横向对比 Panel 1（工具调用场景下，跨越 User Message 仍完整保留 Thinking 痕迹）与 Panel 2（通用对话场景下，收到新的 User Message 即清空先前 Thinking 痕迹，仅保留 User message 和 Answer）。

4. **直接可见的结论**：
   - 在 Panel 1 中，Turn 1.1 至 Turn 1.3 推进过程中，历史 Thinking（Thinking 1.1, 1.2）被持续保留在 Input 中；当跨越 User message 2 进入 Turn 2.1 时，之前的 Thinking 1.1、1.2、1.3 仍然完整保留在 Input 框内。`[图像直接可见]`
   - 在 Panel 2 中，Turn 1 生成 Thinking 1 后，Turn 2 的 Input 仅包含 User message 1、Answer 1 和 User message 2，Thinking 1 被清空丢弃；同理 Turn 3 的 Input 中仅有历史 User message 和 Answer，Thinking 1 与 Thinking 2 均被移除。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - **所属主张类型**：机制主张（Mechanism Claim）。`[正文支持]`
   - **支持/限制关系**：该图直观阐释了 DeepSeek-V4 的 Interleaved Thinking 机制设计。在工具调用场景下（Panel 1），借助 1M 序列能力保留完整思维链，避免每一个新 User Turn 重新推演解题逻辑导致的算力浪费；在普通对话场景下（Panel 2）清除思考痕迹以保持上下文精简。这为 DeepSeek-V4 在长程 Agent 任务中维持思维连贯性与降低重算开销提供了机制支撑。`[正文支持]`
   - **不能由该图证明的内容**：该图仅为逻辑示意图，无法提供定量的 Token 节省比例或端到端 Agent 任务胜率数据。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：
   - **适用范围**：本图覆盖 DeepSeek-V4 系列在工具调用（Tool-Calling）与通用对话（General Conversational）两类场景下的上下文思考痕迹管理规则。`[正文支持]`
   - **证据缺口**：无额外证据缺口。

---

## 图片 2：Figure 9 | DeepSeek-V4 series performance on the MRCR task.

![Figure 9 | DeepSeek-V4 series performance on the MRCR task.](../assets/imgs/img_in_chart_box_234_640_957_1015.jpg)

*来源：OCR 第 40 页。*

### 解读

1. **论文角色与验证问题**：
   - **图表角色**：`实验结论`
   - **上文呼应**：对应论文第 5.3 节与 5.3.2 节中关于 1M-Token Context（MRCR 8-needle 任务）的评估结果，呼应核心主张“原生支持 1M 超长上下文高效推理与长程检索”以及第 2.3 节 CSA+HCA 混合注意力机制的有效性。
   - **验证/解释的具体问题**：验证 DeepSeek-V4-Pro-Max 与 DeepSeek-V4-Flash-Max 在输入序列长度从 8k 扩展至 1024k (1M) Token 时，在多针大海捞针检索任务（MRCR 8-needle）上的 Average MMR 检索性能表现与长程衰减趋势。`[正文支持]`

2. **图像类型与布局**：
   - **图像类型与布局**：折线图（Line Chart）。
   - 图表顶部标题为“MRCR 8-needle”，左下角包含图例。深蓝色实线带五角星标记代表 DeepSeek-V4-Pro-Max，浅蓝色实线带三角形标记代表 DeepSeek-V4-Flash-Max，每个数据点旁均附有精确的数值标注。

3. **如何阅读**：
   - 横坐标（X 轴）：`Input Tokens`（输入序列长度，按对数/倍数倍增排列：8k, 16k, 32k, 64k, 128k, 256k, 512k, 1024k）。
   - 纵坐标（Y 轴）：`Average MMR`（平均多针召回率，范围 0.0 到 1.0）。
   - 对照组：对比 DeepSeek-V4-Pro-Max（大参数/高算力模式）与 DeepSeek-V4-Flash-Max（轻量化模式）在不同序列长度下的检索表现。

4. **直接可见的结论**：
   - 在 8k 至 128k 上下文范围内，两款模型的 Average MMR 保持在较高水平且基本平稳（Pro-Max 得分在 0.85 至 0.94 之间，Flash-Max 得分在 0.84 至 0.91 之间）。`[图像直接可见]`
   - 当序列长度超过 128k 扩展至 256k、512k 和 1024k (1M) 时，两款模型的 MMR 得分持续下降：Pro-Max 依次降至 0.82 (256k)、0.66 (512k) 和 0.59 (1024k)；Flash-Max 依次降至 0.76 (256k)、0.60 (512k) 和 0.49 (1024k)。`[图像直接可见]`
   - 除 8k 处 Flash-Max (0.91) 略高于 Pro-Max (0.90) 外，在其余所有序列长度下，DeepSeek-V4-Pro-Max 的 MMR 得分均高于 DeepSeek-V4-Flash-Max。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：
   - **所属主张类型**：效果主张（Effect Claim）与适用范围主张（Scope Claim）。`[正文支持]`
   - **支持/限制关系**：该图提供了 DeepSeek-V4 原生支持 1M 上下文检索能力的定量证据，表明其在长达 1M Token 的序列中仍能维持 0.59 (Pro-Max) 的多针召回率。同时，数据揭示了 128k 之后检索性能出现下降的边界，直观界定了混合压缩注意力架构在超长上下文检索场景下的实际适用范围与效能边界。`[正文支持]`
   - **不能由该图证明的内容**：单凭该图无法直接查看其相比外部对比基线模型（如 Gemini-3.1-Pro 或 DeepSeek-V3.2）在同一 MRCR 任务上的定量差距，需结合正文第 5.3.2 节的文字对比描述。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：
   - **适用范围**：本实验覆盖 MRCR 8-needle 评估基准在 8k 至 1024k (1M) Token 序列长度下 DeepSeek-V4-Pro-Max 与 DeepSeek-V4-Flash-Max 的检索性能评估。`[正文支持]`
   - **证据缺口**：该折线图中未直接绘制与其他对比基线（如 Gemini-3.1-Pro 或 DeepSeek-V3.2）的定量对比曲线。`[基于视觉的谨慎推断]`
