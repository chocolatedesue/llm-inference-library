#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[DeepSeek-AI]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[2026]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[大语言模型] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[混合专家模型] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[长上下文] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[混合注意力机制] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[DeepSeek-V4]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：https://arxiv.org/pdf/2606.19348]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[arXiv：https://arxiv.org/abs/2606.19348]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[代码：https://huggingface.co/collections/deepseek-ai/deepseek-v4]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-30]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

我们推出了 DeepSeek-V4 系列的预览版本，其中包括两款强劲的混合专家（MoE）语言模型------拥有 1.6T 总参数（49B 激活）的 DeepSeek-V4-Pro 和拥有 284B 总参数（13B 激活）的 DeepSeek-V4-Flash，两者均支持 100 万 token 的上下文长度。DeepSeek-V4 系列在架构和优化方面融合了多项关键升级：（1）结合了压缩稀疏注意力（CSA）与重度压缩注意力（HCA）的混合注意力架构，以提升长上下文效率；（2）增强传统残差连接的流形约束超连接（mHC）；（3）用于加快收敛速度并提高训练稳定性的 Muon 优化器。我们在超过 32T 多样化且高质量的 token 上对这两款模型进行了预训练，随后通过一套全面的后训练流程释放并进一步提升了它们的能力。DeepSeek-V4-Pro Max 作为 DeepSeek-V4-Pro 的最高推理努力模式，重新定义了开源模型的最高水平，在核心任务上的表现超越了前代模型。同时，DeepSeek-V4 系列在长上下文场景中展现出极高的效率。在 100 万 token 上下文的设定下，与 DeepSeek-V3.2 相比，DeepSeek-V4-Pro 仅需 27% 的单 token 推理 FLOPs 和 10% 的 KV 缓存。这使得我们能够常规化地支持 100 万 token 上下文，从而使长跨度任务和进一步的测试时扩展更加可行。模型权重已发布于 #link("https://huggingface.co/collections/deepseek-ai/deepseek-v4。")

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence],
    [作者], [DeepSeek-AI],
    [发表场所 / 年份], [2026],
    [研究领域], [自然语言处理],
    [关键词], [大语言模型, 混合专家模型, 长上下文, 混合注意力机制, DeepSeek-V4],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件
- arXiv：#link("https://arxiv.org/abs/2606.19348")
- DOI：文中未说明
- 代码 / 数据集：#link("https://huggingface.co/collections/deepseek-ai/deepseek-v4")

#quote(block: true)[
#strong[标签（5 个）]：`大语言模型` · `混合专家模型` · `长上下文` · `混合注意力机制` · `DeepSeek-V4`
]

#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] DeepSeek-V4 系列（包含 1.6T 参数/49B 激活的 DeepSeek-V4-Pro 与 284B 参数/13B 激活的 DeepSeek-V4-Flash）通过提出压缩稀疏注意力（CSA）与重度压缩注意力（HCA）构成的混合注意力架构、流形约束超连接（mHC）以及 Muon 优化器，在预训练 32T\~33T Token 并配合领域专家 RL 与全词表在线策略蒸馏后，实现了原生支持 100 万 Token（1M Tokens）超长上下文的高效推理与长程智能，并在 1M 上下文下将单 Token 推理 FLOPs 降至 27%（Pro）及 KV Cache 显存降至 10%（Pro）。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 本报告基于论文全文文本及包含 6 批图表的证据分析进行解构，覆盖预训练架构设计（CSA, HCA, mHC, Muon）、底层算子与并行系统（MegaMoE², Batch-Invariant Kernels, State Cache）、后训练流水线（GRM, OPD, Interleaved Thinking）以及 7 个核心 Benchmark、MRCR 8-needle 检索、Lean 4 形式化证明、TerminalBench 2.0 与白领办公实操评估。
- #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 文中部分具体实现细节（如集群硬件拓扑规模、数据过滤具体参数）未作完全披露，在对应部分已明确注明为"文中未说明"。
- #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(108, 80, 154, 13%))[#text(size: 8.1pt, weight: "bold", fill: rgb(82, 57, 126))[背景知识]] 大语言模型长上下文注意力计算复杂度与显存管理属于通用 NLP 背景知识，文中未陈述的外部背景已明确标注。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

- #strong[问题定义]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 大语言模型在处理 100 万 Token（1M Tokens）超长上下文时，传统自注意力机制的二次方计算复杂度与 KV Cache 显存膨胀会导致硬件显存溢出（OOM）与单 Token 推理 FLOPs 飙升，瓶颈极其严重。
- #strong[应用与研究价值]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 解决超长上下文的计算与显存效率墙，是解锁下一代 LLM 测试时扩展（Test-Time Scaling）、长程复杂 Agent 多轮思考留存（Interleaved Thinking）以及深度推理的基础设施前提；缺乏高效的长上下文架构，长序列应用将停留在高成本且无法落地的实验阶段。
- #strong[困难来源]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 既要大比例压缩 KV Cache 与降低计算 FLOPs，又要保证局部精细语义检索与全局高层概要能力不衰退；同时在深层 MoE 网络堆叠与超大规模并行训练中，面临数值不稳定（Numerical Instability）、通信开销掩盖以及多专家能力蒸馏融合震荡等工程难题。
- #strong[成功标准]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 在原生支持 1M Token 上下文的前提下，实现相比前代 DeepSeek-V3.2 数量级级的 FLOPs 与 KV Cache 削减，并在知识、编程、数学形式化证明与 Agentic 任务上达到开源 SOTA。
- #strong[本文的 story]：旧路线（标准 Vaswani 注意力及 DeepSeek-V3.2 稠密/稀疏方案）因未对 KV 依赖按"局部精细 + 全局概要"分级压缩，在 1M 上下文下显存与算力彻底失效；本文通过 CSA+HCA 混合压缩注意力改变依赖表示，结合 mHC 保证深层数值稳定，软硬协同突破长上下文与测试时扩展屏障。

== 4. 旧方法为何不够
<4-旧方法为何不够>

+ #strong[标准 Vaswani 自注意力机制]：
  - 原本解决：捕获序列全对全注意力。
  - 限制：计算与存储复杂度对序列长度敏感（$O\(n^2\)$ 或与 $n$ 成正比），在 1M 上下文下导致算力瓶颈与显存溢出。
  - 本文回应：提出 CSA + HCA 混合压缩注意力架构。
  - 检验实验：Figure 1 Panel 2/3 FLOPs 与 KV Cache 对比实验。
+ #strong[DeepSeek-V3 / DeepSeek-V3.2 架构]：
  - 原本解决：MoE 稀疏激活与 MTP 多 Token 预测。
  - 限制：在 1M 极长上下文下单 Token 推理 FLOPs 和 KV Cache 需求依然偏高；多轮 Agent 中新 Turn 清空思考痕迹导致重复推理。
  - 本文回应：引入 CSA+HCA 压缩与 Interleaved Thinking 跨 Turn 思考留存。
  - 检验实验：Figure 1 效率对比与 TerminalBench 2.0 / Figure 7 思考留存对比。
+ #strong[朴素超连接 (Naive Hyper-Connections, HC)]：
  - 原本解决：扩展残差流宽度提升表达力。
  - 限制：深层堆叠时频繁遭遇数值不稳定（Numerical Instability）。
  - 本文回应：提出流形约束超连接（mHC），将残差映射约束在双随机矩阵流形 $cal(M)$ 上。
  - 检验实验：2.2 节与 3.4.2 节稳定性陈述。
+ #strong[粗粒度专家并行 (如 Comet)]：
  - 原本解决：EP 重叠 Dispatch 与 Combine 通信。
  - 限制：重叠粒度较粗，在小 Batch（如 RL Rollout 长尾场景）下通信延迟无法被计算完全掩盖。
  - 本文回应：提出 MegaMoE² 细粒度 Expert Wave 重叠 EP 方案。
  - 检验实验：Figure 5 EP 方案对比与 1.50\~1.73× / 1.96× 加速比。
+ #strong[传统 PagedAttention / Jenga / Hymba]：
  - 原本解决：通用页式 KV 缓存管理。
  - 限制：无法统一处理 CSA/HCA 异构压缩率（$m = 4\,m' = 128$）与未满窗口尾 Token 状态。
  - 本文回应：设计 State Cache 与 Classical KV Cache 解耦管理及 $upright("lcm")\(m\,m'\)$ 块大小对齐布局。
  - 检验实验：3.5.1 节与 Figure 6 布局示意。
+ #strong[Token 级 KL 散度估计 OPD]：
  - 原本解决：多教师蒸馏降低显存开销。
  - 限制：梯度估计方差极高，导致训练剧烈震荡。
  - 本文回应：采用全词表 Logit On-Policy Distillation（缓存最后一层 Hidden State 重建 Logit）。
  - 检验实验：5.1.2 节与 5.2.2 节。

== 5. 核心洞见与假设
<5-核心洞见与假设>

- #strong[混合压缩注意力机制（CSA + HCA）]：
  - #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[核心洞见]：长上下文中的信息依赖兼具局部连续性、全局稀疏性与重度概要性，无需对所有历史 Token 维持无损高分辨率存储。
  - #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] #strong[假设与方案]：将 KV 按 $m = 4$ 进行局部重叠压缩并配合 DSA 稀疏选择（CSA），同时按 $m' = 128$ 进行大比例重度压缩并保持稠密注意力（HCA），两者交替交织可在保留精细检索的同时，将 1M 上下文 KV Cache 与 FLOPs 降低一个数量级。
- #strong[流形约束超连接（mHC）]：
  - #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] #strong[核心洞见]：残差流映射矩阵的谱范数若无约束，深层传播中信号与梯度易发生爆炸或衰减。
  - #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] #strong[假设与方案]：利用 Sinkhorn-Knopp 算法将残差映射矩阵 $B_l$ 约束在双随机矩阵流形（Birkhoff 多面体 $cal(M)$）上，保证 $parallel B_l parallel_2 lt.eq 1$，使残差变换具备非膨胀性，保障深层网络绝对数值稳定性。
- #strong[Muon 优化器正交化更新]：
  - #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] #strong[核心洞见]：二维矩阵参数通过 Newton-Schulz 迭代近似正交化更新，比 Element-wise AdamW 具更高的收敛效率与稳定度。
- #strong[细粒度 Expert Wave 重叠 EP]：
  - #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[核心洞见]：MoE 层内计算量大于通信量，通信延迟具备被计算完全隐蔽的空间。将专家切分为 Waves 并三轨流水线重叠。
- #strong[Post-Training 范式（GRM + OPD + Interleaved Thinking）]：
  - #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] #strong[核心洞见]：Actor 兼任 GRM 配合 Rubric 优化解决难验证任务；多领域专家通过全词表 OPD 无损融合；工具调用场景跨 Turn 完整保留思考痕迹提升 Agent 智力与效率。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

- #strong[系统总览]：数据自输入 Token 嵌入后，经过堆叠的 Transformer Block（交替包含 mHC 宽残差流、CSA/HCA 混合注意力与 DeepSeekMoE），最终经 Prediction Head 与 MTP 模块输出预测。
- #strong[\1. CSA（压缩稀疏注意力）]：
  - #strong[动机]：以高分辨率保留局部与稀疏全局关键信息。
  - #strong[步骤]：输入隐藏状态 $H$。按 $m = 4$ 将每 4 个 Token 压缩为 1 个 KV 入口 $C^(upright("Comp"))$；利用 Lightning Indexer 计算得分并挑选 Top-$k$ 入口；结合 128-token 滑动窗口（SWA）拼接后送入 Shared KV MQA。
  - #strong[输出]：经过分组输出投影后的注意力向量 $hat(upright(bold(o)))_t$。
- #strong[\2. HCA（重度压缩注意力）]：
  - #strong[动机]：提供全序列重度概要稠密覆盖。
  - #strong[步骤]：按无重叠大比例 $m' = 128$ 将 128 个 Token 压缩为 1 个 KV 入口；不经 Top-$k$ 筛选，直接对全量压缩入口及 SWA 进行稠密 Shared KV MQA 计算。
- #strong[\3. mHC（流形约束超连接）]：
  - #strong[动机]：消除宽残差流在深层堆叠时的数值不稳定。
  - #strong[步骤]：将残差状态 $X_l in bb(R)^(n_(upright("hc")) times d)$ ($n_(upright("hc")) = 4$) 展平，通过 Sigmoid 生成 $A_l\,C_l$，对 $tilde(B)_l$ 执行 20 次 Sinkhorn-Knopp 迭代归一化投影至双随机矩阵流形 $cal(M)$ 得到 $B_l$。按 $X_(l + 1) = B_l X_l + C_l cal(F)_l\(A_l X_l\)$ 更新。
- #strong[\4. EP 通信重叠与底层算子（MegaMoE² & State Cache）]：
  - #strong[动机]：消除 EP 通信瓶颈与异构 KV 内存碎片。
  - #strong[步骤]：MegaMoE² 采用单 fused mega-kernel 将专家划分为 Waves，重叠 Dispatch、GEMM 与 Combine；State Cache 集中管理 SWA 与未满尾 Token，Classical KV Cache 采用 $upright("lcm")\(m\,m'\)$ 块对齐组织。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：系统总览]
  #image("assets/source-crops/img_in_image_box_333_167_860_755.png", width: 100%)
  #emph[Figure 2 | Overall architecture of DeepSeek-V4 series. We use hybrid CSA (Compressed Sparse Attention) and HCA (Heavily Compressed Attention) for attention layers, DeepSeekMoE for feed-forward layers, and strengthen conventional residual connections with mHC.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展现 Transformer Block 内 mHC 宽残差流与 CSA/HCA 混合注意力、DeepSeekMoE 的自下而上堆叠拓扑。

- #strong[论证关系]：直观提供方法流水线证据，解释 mHC 的 Pre/Post-Block Mixing 与 CSA/HCA 的位置安排。

- #strong[适用范围]：高层架构拓扑示意，未展示 Sinkhorn-Knopp 的具体数学细节。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：1. CSA（压缩稀疏注意力）]
  #image("assets/source-crops/img_in_image_box_152_172_1038_604.png", width: 100%)
  #emph[Figure 3 | Core architectures of CSA. It compresses the number of KV entries to times, and then applies DeepSeek Sparse Attention for further acceleration. Additionally, a small set of sliding window KV entries is combined with the selected compressed KV entries to enhance local fine-grained dependencies.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：CSA 显式包含 $m = 4$ 压缩、Lightning Indexer Top-$k$ 选择与滑动窗口。

- #strong[论证关系]：解释 CSA 高分辨率稀疏检索在结构上的分工与计算缩减来源。

- #strong[适用范围]：模块设计数据流图，不能单独证明硬件端到端实测加速比。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：2. HCA（重度压缩注意力）]
  #image("assets/source-crops/img_in_image_box_320_170_863_499.png", width: 100%)
  #emph[Figure 4 | Core architectures of HCA. It performs heavier compression, where the KV entries of tokens will be consolidated into one. Also, we additionally introduce a small set of sliding window KV entries to enhance local fine-grained dependencies.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：HCA 采用 $m' = 128$ 重度压缩全量稠密注意力与滑动窗口。

- #strong[论证关系]：解释 HCA 全局重度概要在结构上的分工与计算缩减来源。

- #strong[适用范围]：模块设计数据流图，无法单独证明大比例压缩是否导致细粒度语义丢失。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：4. EP 通信重叠与底层算子（MegaMoE² & State Cache）]
  #image("assets/source-crops/img_in_image_box_145_747_1038_1093.png", width: 100%)
  #emph[Figure 5 | Illustration of our EP scheme with related works. Comet (Zhang et al., 2025b) overlaps Dispatch with Linear-1, and Linear-2 with Combine, separately. Our EP scheme achieves a finer-grained overlapping by splitting and scheduling experts into waves. The theoretical speedup is evaluated in the configuration of the DeepSeek-V4-Flash architecture.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：将专家切分为 3 个 Expert Wave 并实现三轨流水线重叠，理论加速比提升至 1.92×。

- #strong[论证关系]：提供机制证据，证明细粒度重叠能够完全隐蔽 EP 中的通信延迟。

- #strong[适用范围]：Flash 配置下理论分析图，实测需结合不同硬件拓扑。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：4. EP 通信重叠与底层算子（MegaMoE² & State Cache）]
  #image("assets/source-crops/img_in_image_box_177_183_1010_454.png", width: 100%)
  #emph[Figure 6 | Illustration of the KV cache Layout for DeepSeek-V4. The KV cache is organized into two primary components: a classical KV cache for CSA/HCA, and a state cache for SWA and unready-for-compression tokens in CSA/HCA. In the state cache, each request is assigned a fixed-size cache block. Within this block, the SWA segment stores the KV entries corresponding to the most recent tokens, while the CSA/HCA segment stores uncompressed tail states that are not yet ready for compression. In the classical KV cache, we allocate multiple blocks per request. Each cache block covers lcm( ) original tokens, producing CSA compressed tokens and HCA compressed tokens.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：State Cache 管理 SWA 与未满尾 Token，Classical KV Cache 采用 $upright("lcm")\(m\,m'\)$ 块大小消除内存碎片。

- #strong[论证关系]：验证解决 CSA/HCA 异构 KV Cache 管理瓶颈的解耦与对齐设计。

- #strong[适用范围]：推理框架内存结构设计图，不包含具体显存吞吐率实测。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：Post-Training 范式（GRM + OPD + Interleaved Thinking）]
  #image("figure-groups/page-0031-0af8d75558f3.png", width: 100%)
  #emph[Figure 7 | Thinking management of DeepSeek-V4 series.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：在工具调用场景跨 Turn 完整保留 Thinking 痕迹，通用对话场景清空思考痕迹。

- #strong[论证关系]：解释模型在长程 Agent 任务中维持思考连贯性与降低重算开销的机制。

- #strong[适用范围]：逻辑规则示意图，无法提供定量的 Token 节省比例。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

+ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[局部与概要分级压缩机制]：通过 $m = 4$ 的 Top-$k$ 稀疏检索（CSA）保证精确细粒度查找，同时通过 $m' = 128$ 的全量稠密注意力（HCA）维护全局背景语意，既消除了二次方冗余，又规避了纯稀疏注意力的信息丢失风险。
+ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[谱范数界定与非膨胀传输]：mHC 强制将残差映射矩阵限制在双随机流形上，使其谱范数满足 $parallel B_l parallel_2 lt.eq 1$。从线性代数约束来看，信号在多层传递中范数不会发生指数级累积，从而从根源上消除了深层堆叠引发的梯度爆炸与数值晃动。
+ #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] #strong[细粒度流水线掩盖延迟]：MegaMoE² 将原本粗粒度的 EP 过程切分为微小波次，使单卡在进行硬件矩阵计算的同时后台 DMA/RDMA 传输下一波次数据，彻底打破了通信带宽对 MoE 推理/训练扩展的硬性限制。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[长上下文效率与显存]：在 1M 上下文下，能否大幅降低单 Token 推理 FLOPs 和 KV Cache 占用？判定标准为对比 DeepSeek-V3.2 的相对降幅。
- #strong[通用与前沿智能水平]：在知识、推理、编程与 Agentic 基准上能否达到开源/闭源 SOTA？判定标准为 SimpleQA Verified、Codeforces Rating、SWE Verified 等得分。
- #strong[长程检索与形式化证明]：在 1M 序列检索与 Lean 4 证明中表现如何？判定标准为 MRCR 8-needle MMR 曲线与 PutnamBench 成功率。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- #strong[预训练设置]：DeepSeek-V4-Flash 预训练语料 32T Tokens，DeepSeek-V4-Pro 预训练语料 33T Tokens。
- #strong[对比基线]：DeepSeek-V3.2, GPT-5.4-xHigh, Claude-Opus-4.6-Max, Gemini-3.1-Pro-High, Seed-2.0-Pro 等。
- #strong[推理与计算设置]：原生支持 1M Token 上下文；包含 Non-think, Think High, Think Max 三种推理模式。集群硬件拓扑细节文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
==== \(1) 1M 上下文单 Token 推理 FLOPs 相对比例
<1-1m-上下文单-token-推理-flops-相对比例>
- #strong[指标与方向]：1M 上下文单 Token 推理 FLOPs 相对 DeepSeek-V3.2 的比例（%），越小越好。
- #strong[定义与公式]： #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 推理依据：以 DeepSeek-V3.2 1M 单 Token FLOPs 为分母，DeepSeek-V4 FLOPs 为分子得到的百分比。
- #strong[来源层级]：`推导关系（非原文公式） [基于文中逻辑的推断]`，文中未给出 Eq. 编号。
- #strong[实验用途]：评估长上下文计算效率。
- #strong[读数与边界]：DeepSeek-V4-Pro 为 27%（降低 3.7 倍），Flash 为 10%（降低 9.8 倍）。

==== \(2) 1M 上下文 KV Cache 占用相对比例
<2-1m-上下文-kv-cache-占用相对比例>
- #strong[指标与方向]：1M 上下文 KV Cache 体积相对 DeepSeek-V3.2 的比例（%），越小越好。
- #strong[定义与公式]： #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 推理依据：以 DeepSeek-V3.2 1M KV Cache 尺寸为分母，DeepSeek-V4 尺寸为分子得到的百分比。
- #strong[来源层级]：`推导关系（非原文公式） [基于文中逻辑的推断]`，文中未给出 Eq. 编号。
- #strong[实验用途]：评估长上下文显存节省。
- #strong[读数与边界]：DeepSeek-V4-Pro 为 10%（约 5.2 GB，小 9.5 倍），Flash 为 7%（约 3.6 GB，小 13.7 倍）。

==== \(3) mHC 双随机矩阵约束 (Doubly Stochastic Constraint)
<3-mhc-双随机矩阵约束-doubly-stochastic-constraint>
- #strong[指标与方向]：残差映射矩阵 $B_l$ 的约束流形 $cal(M)$。
- #strong[定义与公式]： $ B_l in cal(M) := { M in bb(R)^(n times n) divides M upright(bold(1))_n = upright(bold(1))_n\,med upright(bold(1))_n^T M = upright(bold(1))_n^T\,med M gt.eq 0 } $
- #strong[来源层级]：`原文公式`，2.2 节。
- #strong[实验用途]：保证深层网络信号传输的非膨胀性与稳定性。
- #strong[读数与边界]：每行每列和均为 1，有效消除数值爆炸。

==== \(4) Sinkhorn-Knopp 归一化迭代
<4-sinkhorn-knopp-归一化迭代>
- #strong[指标与方向]：流形投影迭代算子。
- #strong[定义与公式]： $ M^(\(0\)) = exp\(tilde(B)_l\)\,quad M^(\(t\)) = cal(T)_r\(cal(T)_c\(M^(\(t - 1\))\)\) $
- #strong[来源层级]：`原文公式`，2.2 节（$t_max = 20$）。
- #strong[实验用途]：动态将无约束参数映射为双随机矩阵。
- #strong[读数与边界]：迭代 20 次即可精准逼近流形。

==== \(5) 混合 Newton-Schulz 迭代（Muon 优化器）
<5-混合-newton-schulz-迭代muon-优化器>
- #strong[指标与方向]：动量矩阵正交更新算子。
- #strong[定义与公式]： $ M_k = a M_(k - 1) + b #scale(x: 120%, y: 120%)[\(] M_(k - 1) M_(k - 1)^T #scale(x: 120%, y: 120%)[\)] M_(k - 1) + c #scale(x: 120%, y: 120%)[\(] M_(k - 1) M_(k - 1)^T #scale(x: 120%, y: 120%)[\)]^2 M_(k - 1) $
- #strong[来源层级]：`原文公式`，算法 1 及 2.4 节。
- #strong[实验用途]：矩阵参数正交化加速收敛。
- #strong[读数与边界]：前 8 步与后 2 步采用不同系数。

==== \(6) 专家并行计算通信平衡临界比
<6-专家并行计算通信平衡临界比>
- #strong[指标与方向]：硬件算力与带宽比值 $C\/B$（FLOPs/Byte）。
- #strong[定义与公式]： $ C / B lt.eq 2 d = 6144 upright(" FLOPs/Byte") $
- #strong[来源层级]：`原文公式`，3.1 节。
- #strong[实验用途]：确定 EP 重叠无瓶颈的理论硬件算力带宽阈值。
- #strong[读数与边界]：对 SwiGLU 专家维度 $d = 3072$ 成立。

==== \(7) 在线策略蒸馏目标损失 (OPD Loss)
<7-在线策略蒸馏目标损失-opd-loss>
- #strong[指标与方向]：多教师逆 KL 蒸馏损失，越小越好。
- #strong[定义与公式]： $ cal(L)_(upright(O P D))\(theta\)= sum_(i = 1)^N w_i dot.op upright(D)_(upright(K L)) (pi_theta parallel pi_(E_i)) $
- #strong[来源层级]：`原文公式`，5.1.2 节。
- #strong[实验用途]：在学生模型上融合 $N > 10$ 个领域专家能力。
- #strong[读数与边界]：结合全词表 Logits 实现无震荡蒸馏。

==== \(8) Codeforces 期望 Rating 分数
<8-codeforces-期望-rating-分数>
- #strong[指标与方向]：竞技编程综合评分，越大越好。
- #strong[定义与公式]： #box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 推理依据：无放回采样 10 个解题序列，结合人类失败扣分映射 Rank 并转化为 Codeforces Rating 求期望。
- #strong[来源层级]：`推导关系（非原文公式） [基于文中逻辑的推断]`，5.3.1 节。
- #strong[实验用途]：评价顶尖编程推理能力。
- #strong[读数与边界]：DeepSeek-V4-Pro-Max 达到 3206。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
==== 比较工作与被批判限制的呼应
<比较工作与被批判限制的呼应>
#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([比较工作 / 基线方法], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [#strong[DeepSeek-V3.2]], [1M 上下文 FLOPs/KV 占用高；多轮 Agent 清空思考痕迹。], [CSA+HCA 混合注意力、Interleaved Thinking], [Figure 1 FLOPs/KV 实验；TerminalBench 2.0 (46.5% vs 67.9%)。],
    [#strong[朴素超连接 (Naive HC)]], [深层堆叠遭遇数值不稳定。], [流形约束超连接 (mHC)], [预训练稳定性陈述与 Sinkhorn-Knopp 约束。],
    [#strong[粗粒度 EP (Comet)]], [小 Batch 长尾通信无法完全掩盖。], [MegaMoE² 细粒度 Expert Wave 重叠], [理论加速比 1.92× vs 1.42×，端到端实测 1.50\~1.96×。],
    [#strong[Token 级 KL OPD]], [蒸馏方差极高，训练剧烈震荡。], [全词表 Logit On-Policy Distillation], [5.1.2 节多专家无损融合结果。],
  )]
  , kind: table
  )

==== 主张地图与证据表
<主张地图与证据表>
#figure(
  align(center)[#table(
    columns: 3,
    align: (left,left,left,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 1M 上下文下大幅降低 FLOPs 与 KV Cache 占用], [Figure 1 Panel 2/3 折线图与读数], [#strong[强]：Pro 单 Token FLOPs 降至 27%，KV Cache 降至 10%。],
    [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 核心基准达到开源 SOTA 及对标顶尖闭源], [Figure 1 Panel 1 柱状图、表 1/表 6], [#strong[强]：SimpleQA 57.9%, Codeforces 3206, SWE-Verified 80.6%。],
    [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 形式化数学证明突破前沿上限], [Figure 8 (Putnam-200 / Putnam-2025)], [#strong[强]：Putnam-200 得分 81.00 (2.28× 基线)，Putnam-2025 达 120/120 满分。],
    [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 测试时扩展展现单调上升 Scaling 特性], [Figure 10 (HLE / TerminalBench 2.0)], [#strong[中]：Pass\@1 随思考 Token 增加单调上升；边界在于具体思考长度上限受上下文约束。],
  )]
  , kind: table
  )

- #strong[关键实验解释]：实验表明 DeepSeek-V4-Pro-Max 在基础知识与 Agentic 任务上全面超越前代与开源同类，且在 1M 序列下保持显著的开销优势；但在纯指令遵循（Instruction Following: 87.76 vs 88.88）和复杂视觉排版美学上微弱落后于 Opus-4.6-Max。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0001-7c4cbec22eae.png", width: 100%)
    #emph[Figure 1 | Left: benchmark performance of DeepSeek-V4-Pro-Max and its counterparts. Right: inference FLOPs and KV cache size of DeepSeek-V4 series and DeepSeek-V3.2.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
    - #strong[图组结论]：DeepSeek-V4-Pro-Max 在 7 项核心基准上表现顶尖；在 1M 上下文下，V4-Pro 单 Token 推理 FLOPs 降低 3.7 倍，KV Cache 降至 5.2 GB（小 9.5 倍）。

- #strong[论证关系]：支撑"1M 超长上下文高效推理"与"通用能力树立开源 SOTA"两大核心主张。

- #strong[适用范围]：覆盖 0\~1024K 序列长度分析及 7 项评测基准。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_234_640_957_1015.png", width: 100%)
    #emph[Figure 9 | DeepSeek-V4 series performance on the MRCR task.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：长程检索与形式化证明]
    - #strong[图组结论]：8k\~128k 上下文内召回率在 0.85\~0.94；扩展至 1M 时 Pro-Max 保持 0.59，Flash-Max 保持 0.49。

- #strong[论证关系]：定量界定混合注意力在超长序列下的多针检索效能与衰减边界。

- #strong[适用范围]：MRCR 8-needle 8k\~1024k 评估。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0040-da30b24a78fd.png", width: 100%)
    #emph[Figure 8 | Formal reasoning under practical and frontier regimes. Left: Putnam-200 Pass\@8 evaluates a fixed random subset of PutnamBench (Tsoukalas et al., 2024) following the setup introduced by Seed-Prover; all models are tested on the same problem set. We follow the Seed-Prover protocol but replace proprietary search tools with the open-source LeanExplore (Asher, 2025), yielding a lightweight setting with minimal agent tools and bounded sampling. Right: Putnam-2025 probes the frontier of mathematical reasoning in a scaled hybrid formal-informal regime, where informal reasoning is combined with formal verification to expose gaps and improve rigor; DeepSeek-V4 reaches a proof-perfect 120/120.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：长程检索与形式化证明]
    - #strong[图组结论]：Flash-Max 在 Putnam-200 Pass\@8 达 81.00 分（2.28× 基线）；Putnam-2025 达到 120/120 满分。

- #strong[论证关系]：支撑模型在前沿形式化数学推理与测试时扩展上的效果主张。

- #strong[适用范围]：Lean 4.28 形式化证明环境。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0041-b63fd83b52ff.png", width: 100%)
    #emph[Figure 10 | HLE and Terminal Bench 2.0 performance by reasoning effort. \"None\" indicates Non-think mode, and \"Speciale\" indicates DeepSeek-V3.2-Speciale model.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
    - #strong[图组结论]：Pass\@1 随思考 Token 增加呈单调上升趋势，Pro Max 模式在 HLE 达 37.8%，TerminalBench 2.0 达 67.9%。

- #strong[论证关系]：验证 Post-Training RL 导出的 Reasoning Effort 模式的测试时扩展有效性。

- #strong[适用范围]：HLE 与 TerminalBench 2.0 评测。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_612_491_1047_749.png", width: 100%)
    #emph[Figure 12 | Detailed dimension scores including Task Completion, Content Quality, Formatting Aesthetics, and Instruction Following.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
    - #strong[图组结论]：DeepSeek-V4-Pro-Max 在任务完成度（98.32）与内容质量（83.32）上超越 Opus-4.6-Max，在指令遵循上（87.76 vs 88.88）微弱落后。

- #strong[论证关系]：提供真实白领 Agent 场景下的定量效果证据，界定能力优势与特定局限。

- #strong[适用范围]：30 项白领办公实操评测集。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_141_889_1049_1397.png", width: 100%)
    #emph[Figure 13 | Example output of a task which requires drafting a joint marketing proposal for a popular bubble tea brand and the Beijing Subway.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
    - #strong[图组结论]：生成包含完整商业策划框架与多达 25 页的结构化方案，展示了极长 Output 生成力。

- #strong[论证关系]：提供复杂 Agent 场景下的定性样例文证，直观印证长上下文与格式化写作能力。

- #strong[适用范围]：奶茶品牌与北京地铁联合营销策划案生成样例。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1 | Comparison among DeepSeek-V3.2-Base, DeepSeek-V4-Flash-Base, and DeepSeek-V4-Pro-Base. All models are evalu...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：数据、任务、对比与运行设置]
  - #strong[图组结论]：DeepSeek-V4 Base 模型在绝大多数基础能力评测上全面超越前代 DeepSeek-V3.2-Base。

- #strong[论证关系]：验证 Base 模型架构升级（CSA/HCA/mHC）带来的基础智能提升。

- #strong[适用范围]：内部评估框架下的基座模型综合评测。
  #v(5pt)
  #image("table-groups/page-0028-03e1aeaaa967.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2 | Comparison of three reasoning modes]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：数据、任务、对比与运行设置]
  - #strong[图组结论]：Non-think、Think High 与 Think Max 三种推理模式展现出清晰的性能与算力阶梯。

- #strong[论证关系]：支撑测试时扩展与多推理模式设计的有效性。

- #strong[适用范围]：DeepSeek-V4 序列推理模式对比。
  #v(5pt)
  #image("table-groups/page-0029-5f1e032107f7.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 5 | Quick Instruction special tokens for auxiliary tasks.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：Post-Training 范式（GRM + OPD + Interleaved Thinking）]
  - #strong[图组结论]：定义了快捷指令与辅助任务对应的专用特殊 Token 集合。

- #strong[论证关系]：展示后训练阶段控制模型行为与任务调配的机制规范。

- #strong[适用范围]：模型辅助任务指令接口设计。
  #v(5pt)
  #image("table-groups/page-0032-8012d6eca162.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 6 | Comparison between DeepSeek-V4-Pro-Max and closed/open source models. "Max", "xHigh", and "High" denote rea...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：DeepSeek-V4-Pro-Max 在知识、编程与数学等多项前沿 Benchmark 上超越主流开源及闭源顶尖模型。

- #strong[论证关系]：支撑模型达到开源 SOTA 及对标顶级闭源模型的核心主张。

- #strong[适用范围]：通用与前沿智能综合评测集。
  #v(5pt)
  #image("table-groups/page-0038-59705a239414.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 7 | Comparison among different sizes and modes of DeepSeek-V4 series. "Non-Think", "High", and "Max" denote rea...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：详细给出了 Pro 与 Flash 在不同思考模式（Non-Think、High、Max）下的完整 Benchmark 成绩。

- #strong[论证关系]：全面展现 DeepSeek-V4 系列模型在不同尺寸与推理算力分配下的性能全貌。

- #strong[适用范围]：DeepSeek-V4 全系全模式能力评估。
  #v(5pt)
  #image("table-groups/page-0039-b335112bde96.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 8 | Comparison on R&D Coding Benchmark (external models included strictly for evaluation purposes).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：DeepSeek-V4-Pro 在研发编程基准（SWE Verified 等）上取得领先表现。

- #strong[论证关系]：验证模型在真实软件工程与研发代码生成任务上的前沿能力。

- #strong[适用范围]：研发编程基准评测。
  #v(5pt)
  #image("table-groups/page-0044-d1fcd795ae61.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 9 | Agentic Search vs. Retrieval Augmented Search for DeepSeek-V4-Pro.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：Agentic Search 相较于传统的 Retrieval Augmented Search 显著提高了复杂搜索问答准确率。

- #strong[论证关系]：验证动态 Agent 工具调用搜索策略优于被动检索增强范式。

- #strong[适用范围]：复杂搜索问答评估集。
  #v(5pt)
  #image("table-groups/page-0055-2bdf23302ecb.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 10 | Cost Comparison: Agentic Search vs. Retrieval Augmented Search (Mean) for DeepSeek-V4-Pro. Most of the too...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：Agentic Search 通过并行工具调用保持了合理的开销与时延。

- #strong[论证关系]：证明主动 Agent 搜索在带来准确率提升的同时具备工程可行性与开销优势。

- #strong[适用范围]：搜索问答任务开销与延迟分析。
  #v(5pt)
  #image("table-groups/page-0055-04afe8c2e0ec.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 11 | Comparative Evaluation of DeepSeek-V4-Pro and DeepSeek-V3.2 on Search Q&A Tasks.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：DeepSeek-V4-Pro 在搜索问答任务上的综合得分与准确度显著超越前代 DeepSeek-V3.2。

- #strong[论证关系]：验证架构与后训练升级对信息检索与综合理解能力的迭代提升。

- #strong[适用范围]：搜索问答基准对比。
  #v(5pt)
  #image("table-groups/page-0055-ab3a6d39f733.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 12 | Comparative Analysis of DeepSeek-V4-Pro and Gemini-3.1-Pro in Chinese Functional Writing.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：DeepSeek-V4-Pro 在中文实用功能写作（公文、报告等）中相比 Gemini-3.1-Pro 表现出更高质量。

- #strong[论证关系]：支撑模型在中文长文本与复杂实用写作任务中的领先优势。

- #strong[适用范围]：中文实用功能写作评测。
  #v(5pt)
  #image("table-groups/page-0057-6bbb90b9fbff.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 13 | Comparative Analysis of DeepSeek-V4-Pro and Gemini-3.1-Pro in Chinese Creative Writing.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：DeepSeek-V4-Pro 在中文创意写作（故事、文案等）中展现出优异的文采与文脉连贯性。

- #strong[论证关系]：验证模型在长程创作与表达丰富度上的优越性能。

- #strong[适用范围]：中文创意写作评测。
  #v(5pt)
  #image("table-groups/page-0058-4e2f781d79a0.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 14 | DeepSeek-V4-Pro vs. Claude-Opus-4.5 on Complex Instruction Following and Multi-Turn Writing.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：通用与前沿智能水平]
  - #strong[图组结论]：DeepSeek-V4-Pro 在多轮长写作中优势明显，但在部分极端复杂的严格指令遵循上与顶尖闭源模型互有胜负。

- #strong[论证关系]：客观界定模型在复杂指令遵循与多轮写作上的能力定位与适用边界。

- #strong[适用范围]：复杂指令遵循与多轮长写作评测。
  #v(5pt)
  #image("table-groups/page-0058-bddfad940331.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：1M 超长上下文下的巨额计算 FLOPs 与 KV Cache 显存墙及测试时扩展受阻
  - 旧方法限制：标准 Vaswani 注意力二次方爆炸；DeepSeek-V3.2 在 1M 下开销仍大且多轮 Agent 清空思考；朴素 HC 数值不稳定；粗粒度 EP 通信无法隐蔽
  - 核心洞见/假设：长上下文依赖具备"局部精细+全局概要"层次分工；残差映射谱范数需界定在双随机流形上；细粒度 Wave 重叠可完全掩盖 EP 通信
    - 方法模块：CSA（$m = 4$ 压缩稀疏）、HCA（$m' = 128$ 重度压缩稠密）、mHC（Sinkhorn-Knopp 双随机投影）、MegaMoE²（细粒度 Wave EP）、OPD（全词表逆 KL 蒸馏）与 Interleaved Thinking
      - 可验证预测：1M 上下文 FLOPs 与 KV Cache 大幅下降；深层训练不发生梯度爆炸；EP 得到 1.5×+ 端到端加速；形式化证明与 Agent 任务显著超越基线
        - 指标与实验：1M 单 Token FLOPs/KV Cache 百分比；Codeforces/SimpleQA/SWE-Verified/Putnam 成绩；TerminalBench 2.0 准确率
          - 图表证据：Figure 1（FLOPs/KV 折线与能力柱状图）、Figure 5（MegaMoE² 流水线）、Figure 8 (MRCR 检索)、Figure 9 (Putnam 证明)、Figure 10 (Reasoning Effort 扩展)
            - 结论与适用边界：验证了 1M 上下文高效推理与开源 SOTA 能力；适用边界为 128k 后 MRCR 召回有自然衰减，严格指令遵循与视觉排版美学仍有微小改进空间。

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- #strong[贡献总结]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]] 提出 CSA+HCA 混合注意力架构、流形约束超连接（mHC）、Muon 优化器规模化实践、MegaMoE² 细粒度 EP 重叠算子、全词表 OPD 多教师蒸馏范式，并成功训练并开源了原生支持 1M 上下文的 DeepSeek-V4 系列模型。
- #strong[证据充分的结论]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]] 1M 上下文下 DeepSeek-V4-Pro 单 Token 推理 FLOPs 降至 27%，KV Cache 降至 10%；在 Codeforces（3206）、Putnam-2025（120/120）、SWE-Verified（80.6%）等基准上树立了开源前沿 SOTA。
- #strong[尚属推断的意义]：#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]] 混合压缩注意力与 mHC 流形约束的技术路线，为未来极长上下文 Agent 的实时测试时扩展（Test-Time Scaling）与在线学习奠定了通用基础设施范式。
- #strong[适用条件与局限]：1M 多针检索在 128k 序列之后存在表现衰减；在纯严格指令遵循和部分 PPT Visual Formatting 视觉艺术美学上微弱落后于顶尖闭源模型。
- #strong[审稿式风险检查]：
  - 贡献新意：#strong[无明显风险]。CSA+HCA 与 mHC 流形约束构成了显著的技术创新。
  - 写作/可复现性：#strong[低风险]。模型权重已公开发布，但在集群硬件拓扑等部分工程设置上写为文中未说明。
  - 效果大小：#strong[无明显风险]。1M 效率提升 3.7\~9.8 倍，多项 Benchmarks 达到 SOTA。
  - 实验覆盖：#strong[无明显风险]。覆盖从基础知识、编程、数学形式化证明到白领 Agent 的全面评估。
  - 方法设计：#strong[低风险]。mHC 数学推导严谨，Sinkhorn-Knopp 迭代保障了稳定性。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[压缩稀疏注意力 (Compressed Sparse Attention, CSA)]：
  - 最小定义：将每 $m = 4$ 个 Token 隐状态压缩为 1 个入口，并利用 Lightning Indexer 进行 Top-$k$ 稀疏检索的注意力模块。
  - 第一性原理角色：在受限显存带宽与算力约束下，通过牺牲无用历史 Token 的高分辨率存储，连接高分辨率局部依赖与高精度全局稀疏检索。
  - 本文位置：DeepSeek-V4 混合注意力架构的核心交替组件之一。
- #strong[重度压缩注意力 (Heavily Compressed Attention, HCA)]：
  - 最小定义：按 $m' = 128$ 大比例将 Token 压缩为 1 个入口并进行全量稠密 MQA 计算的注意力模块。
  - 第一性原理角色：在零稀疏索引开销的约束下，用极小存储空间连接全局背景语意与高层概要表示。
  - 本文位置：与 CSA 交替堆叠构成混合注意力。
- #strong[流形约束超连接 (Manifold-Constrained Hyper-Connections, mHC)]：
  - 最小定义：将宽残差流映射矩阵通过 Sinkhorn-Knopp 算法强行投影至双随机矩阵流形的残差连接技术。
  - 第一性原理角色：受到谱范数 $parallel B_l parallel_2 lt.eq 1$ 的数学非膨胀约束，确保深层信号传播不发生爆炸或衰减。
  - 本文位置：替代标准残差连接，贯穿整个 Transformer Block。
- #strong[Muon 优化器]：
  - 最小定义：利用 Newton-Schulz 迭代对矩阵参数进行逼近正交化更新的二阶性质优化器。
  - 第一性原理角色：约束参数更新流形正交性，连接高维矩阵梯度与极速稳定收敛。
  - 本文位置：用于预训练与后训练阶段大权重矩阵的参数更新。
- #strong[全词表 On-Policy 蒸馏 (OPD)]：
  - 最小定义：在学生模型产生的轨迹上，通过缓存最后一层 Hidden State 重建全词表 Logits，计算多教师逆 KL 散度的蒸馏范式。
  - 第一性原理角色：在极低显存缓存约束下，无损平滑地连接多领域专家教师能力与单一学生模型。
  - 本文位置：Post-Training 阶段融合领域专家的核心算法。

=== 12.2 学习路径
<122-学习路径>
+ #strong[基本对象：注意力机制中的 KV Cache 与算力/显存墙]
  - 通俗解释：理解大语言模型在生成文本时为什么要保存历史 Key 和 Value 向量，以及为什么序列变长会导致显存溢出。
+ #strong[约束：矩阵谱范数与深层网络训练稳定性]
  - 通俗解释：理解线性代数中矩阵谱范数如何决定向量乘法的缩放，以及为什么残差连接矩阵范数大于 1 会导致深层网络梯度爆炸。
+ #strong[机制：双随机矩阵 (Doubly Stochastic Matrix) 与 Sinkhorn-Knopp 算法]
  - 通俗解释：学习如何通过按行按列交替归一化，将任意正矩阵转化为每行每列和均为 1 的概率矩阵，从而实现能量守恒映射。
+ #strong[系统与指标：计算通信重叠 (Wave Overlapping) 与 1M 上下文推理 FLOPs]
  - 通俗解释：理解 GPU 算力与通信带宽的瓶颈临界比，以及如何通过流水线分波段掩盖传输延迟。
