# 图片批次 5

## 图片 1：Figure 9: Goodput, TTFT, TPOT, and E2E latency for Qwen2.5-32B

![Figure 9: Goodput, TTFT, TPOT, and E2E latency for Qwen2.5-32B](../figure-groups/page-0010-58a8675a5d44.png)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：本图是第 5.2.1 节"Goodput and latency"的核心实验结果图，用于验证论文摘要与 Story 主线中的可验证主张——"在线服务下 PP 存在计算不均衡导致的气泡"这一根问题是否被本文提出的方法（调优静态 chunk、DCP_greedy、DCP_pred、DCP_pred+DS）解决，并证明"调优后的静态 PP 已能超过 TP，DCP/DS 进一步改善延迟"这一效果类主张。[正文支持]
   - **图表角色**：实验结论（同时承担对比基线功能：TP 作为被批判的旧方法基线，PP_static/128~2048 作为静态 chunk 消融，DCP_greedy/DCP_pred/DCP_pred+DS 作为本文方法的递进版本）。
   - **上文呼应**：对应"实验、指标与文字可确认的结论"中 5.2.1 节的全部数值主张（AzureConv/CNN/ShareGPT/CNN-Reversed 的 goodput 数值、chunk=512/256 最优值、DCP_greedy/pred 相对 PP_static 的 TPOT/E2E 降幅）。

2. **图像类型与布局**：Panel 1 为独立图例（TP=蓝圆、PP_static=橙方、DCP_greedy=绿三角、DCP_pred=红菱形、DCP_pred+DS=紫星），不含数据。其余 16 个子图构成 4×4 网格：每行对应一个负载（第1行 AzureConv、第2行 CNN、第3行 ShareGPT、第4行 CNN-Reversed，行内 x 轴量程分别约为 0–10、0–12.5、0–45、0–11 req/s，与各负载的最大稳定请求率相符）；每列依次为 Goodput（柱状图，横轴为 TP/PP128/256/512/1024/2048/DCP_greedy/DCP_pred/DCP_pred+DS）、P90 TTFT（折线）、P90 TPOT（折线）、P90 E2E（折线，随请求率变化）。[图像直接可见]

3. **如何阅读**：柱状图纵轴为 goodput(req/s)，横轴为不同静态 chunk 或本文方法变体，柱顶数字为具体数值；折线图横轴为请求率，纵轴为对应 P90 延迟指标，曲线在接近该方法的 goodput 上限处会陡然上翘（发散），发散点即该方法的 SLO 违反临界点。应重点比较：(1) 柱状图中 TP vs 各 PP 变体的高度；(2) 折线图中各曲线开始发散的请求率位置（越靠右说明可支撑的吞吐越高）；(3) DCP 系列与 PP_static 曲线的间距（体现延迟降幅）。

4. **直接可见的结论**：
   - 三个 prefill-heavy 负载（AzureConv、CNN、ShareGPT）中，静态 PP 的 goodput 随 chunk size 呈先升后降的倒 U 型（如 AzureConv：PP128=4.27→PP512=8.28→PP2048=3.16），DCP_greedy/DCP_pred/DCP_pred+DS 的柱高均达到或略超过该倒 U 峰值，且三者彼此接近，TP 柱始终最矮。[图像直接可见]
   - 在这三个负载的 TTFT/TPOT/E2E 折线图中，TP（蓝）曲线在请求率较低时即陡峭发散；PP_static（橙）曲线在中等请求率区间的 TPOT/E2E 明显高于 DCP_greedy/DCP_pred/DCP_pred+DS（绿/红/紫）三条几乎重合的曲线，直至接近饱和点才趋同。[图像直接可见]
   - CNN-Reversed（第4行，decode-heavy）：Goodput 柱状图中 PP128~2048 各静态 chunk 之间差异很小（6.18–7.23 之间波动，无明显单一峰值），DCP_greedy/DCP_pred 仅略高于最佳 PP_static（7.38/7.40 vs 7.27），但 DCP_pred+DS 显著跃升至 10.42。对应 TTFT 折线中，紫色（DS）曲线的发散点明显比其余曲线靠右（更高请求率才发散），TPOT 折线中 TP 曲线明显抬升最早最高，其余曲线接近重合。[图像直接可见]

5. **它验证的论点与方法设计含义**：
   - 三个 prefill-heavy 负载的结果直接支撑"效果"类主张——调优后的静态 PP 已能在 goodput/TTFT/TPOT 上超过 TP（对应主张地图第3行），且 DCP 系列在几乎不改变 goodput 的前提下大幅压缩 TPOT/E2E（对应"DCP_greedy 有效但存在结构性滞后""DCP_pred 优于 DCP_greedy"两条主张），可视化确认了正文给出的具体百分比数值（19%/18%、35%/31% 等）背后的曲线形态：DCP 曲线整体压低且更靠右发散。[正文支持]
   - CNN-Reversed 行的结果是"必要性"类证据，直接支撑"DCP 对纯 decode 不均衡无效、必须依赖 Delay Scheduling"这一模块动机（4.2 节）：静态 chunk 与 DCP 对 goodput 的提升有限，只有叠加 DS 后 goodput 才跃升，且该跃升由 TTFT 曲线发散点右移驱动（对应正文"DS 通过更快释放 KV 内存降低 TTFT，进而提升 goodput"的机制描述）。[正文支持]
   - TPOT 折线中 DS（紫）在 CNN-Reversed 高请求率处略高于其余聚簇曲线，方向上与 5.2.4 节"DS 使 P99 TPOT 变差 15%"的权衡描述一致，但需注意：该图为真实 CNN-Reversed 负载的 P90 值，而"15%"数值来自 5.2.4 节的合成 decode-heavy 负载与 P99 指标，二者实验设置不同，不能将本图的视觉趋势等同于该具体数值的证据。[基于视觉的谨慎推断]

6. **适用范围与证据缺口**：本证据覆盖论文报告的 4×A100(40GB, PCIe 4.0) 环境下 Qwen2.5-32B 模型，在 AzureConv/CNN/ShareGPT/CNN-Reversed 四条负载上的 TP、PP_static（多个 chunk）、DCP_greedy、DCP_pred、DCP_pred+DS 对比。Panel 12（ShareGPT 的 TPOT 子图）区域存在坐标轴标签重叠（同时可见 "P90 TPOT (ms)" 与 "P90 E2E (ms)" 字样），无法确认该子图是否被相邻 E2E 子图的坐标轴标注污染，这是图像裁剪导致的真实可辨识但无法消解的缺口；其余 15 个子图与图例组织清晰，无额外证据缺口。

---

## 图片 2：Figure 10: Goodput, TTFT, TPOT, and E2E latency for Qwen2.5-14B

![Figure 10: Goodput, TTFT, TPOT, and E2E latency for Qwen2.5-14B](../figure-groups/page-0011-da2b6163b7e3.png)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：本图是第 5.2.1 节末段针对 Qwen2.5-14B 的补充实验，用于验证"论文核心方法在不同模型规模下是否具有一致效果"这一适用范围类主张，并再次给出 AzureConv（prefill-heavy）与 CNN-Reversed（decode-heavy）两个代表性负载下 TP/PP/DCP/DS 的对比，支撑正文"14B 与 32B 呈现相似趋势""chunk 1024 在 14B 上最优""greedy/predictive 相对 PP_static 降低 TPOT 达 40%/50%""DS 对 14B decode-heavy 带来至多 1.4× goodput 提升但对 P90 E2E 无明显改善"等具体数值与定性描述。[正文支持]
   - **图表角色**：实验结论（兼具适用边界功能：检验方法在更小模型规模上的泛化性）。
   - **上文呼应**：对应"实验、指标与文字可确认的结论"中关于 Qwen2.5-14B 的段落（页码11），以及主张地图"局限"部分"仅评估 Qwen2.5 32B/14B 两个模型家族"的适用边界说明。

2. **图像类型与布局**：8 个子图排成 2 行 × 4 列，无独立图例框（图例信息通过柱状图的横轴分类标签体现：TP/PP128/256/512/1024/2048/DCP_greedy/DCP_pred/DCP_pred+DS）。第1行为 AzureConv（prefill-heavy），第2行为 CNN-Reversed（decode-heavy）；每行内 4 列依次为 Goodput（柱状图）、P90 TTFT、P90 TPOT、P90 E2E（均为折线图，横轴请求率）。[图像直接可见]

3. **如何阅读**：与图片1相同的阅读方式——柱状图比较不同 chunk/方法的 goodput 高度，折线图比较各方法曲线的发散请求率与曲线间距。AzureConv 行 x 轴量程约 2–20 req/s，CNN-Reversed 行约 4–24 req/s，二者量程不同，不能跨行直接比较绝对数值，只能比较组内相对位置。[图像直接可见]

4. **直接可见的结论**：
   - AzureConv 行：Goodput 柱状图中 PP1024=16.55 为静态 chunk 中最高，DCP_greedy/DCP_pred/DCP_pred+DS（16.33/16.75/16.71）与其非常接近；TPOT 折线中 PP_static（橙）在请求率 8–16 区间明显高于 DCP_greedy/DCP_pred/DS（绿/红/紫，三者几乎重合更低）；TTFT、E2E 折线呈现类似但间距较小的分层，且各曲线在请求率接近18–20时趋同发散。[图像直接可见]
   - CNN-Reversed 行：Goodput 柱状图中各静态 PP（8.62–16.55… 实为 8.62/13.65/15.16/15.09/14.58）之间差异不大，DCP_greedy/DCP_pred（15.25/15.45）略高于最佳 PP_static，而 DCP_pred+DS 明显跃升至 19.88；TTFT 折线中紫色（DS）曲线发散点比其余曲线（蓝色最早，橙/红其次）明显靠右；TPOT 折线中 TP 最早抬升最高，PP_static/DCP_greedy/DCP_pred 聚簇在约 110ms，DS 在最高请求率处略高于该聚簇（约130ms）；E2E 折线中除 TP 外其余四条曲线几乎完全重合，未见 DS 带来可辨的额外降低。[图像直接可见]

5. **它验证的论点与方法设计含义**：
   - AzureConv 行的结果重复验证了图片1中 prefill-heavy 场景下"DCP 系列在几乎不牺牲 goodput 的情况下显著压低 TPOT/E2E"的效果类主张，且在 14B 这一更小模型上依然成立，说明该结论并非仅限于 32B，是"效果"主张跨模型规模的一致性证据。[正文支持]
   - CNN-Reversed 行的 Goodput 与 TTFT 表现再次确认"DCP 单独对 decode-heavy 负载帮助有限、DS 才是驱动 goodput 提升的关键机制"这一必要性主张，与图片1的结构性发现一致，强化了 DS 模块存在的方法学理由。[正文支持]
   - CNN-Reversed 行的 E2E 子图中 DS 与其余方法几乎重合、无可见改善，这与正文明确陈述的"14B 模型在 P90 E2E 上无可见降低（而 32B 有）"完全吻合，是该适用边界主张的直接图像证据，读者应据此理解：DS 对 goodput/TTFT 的提升在两种模型规模上都成立，但对 P90 E2E 的改善效果具有模型规模依赖性，仅在 32B 上明显。[正文支持]
   - TPOT 折线中 DS 在高请求率处略高于聚簇的现象，方向上与"DS 抢占带来 TPOT 代价"的权衡描述一致，但同图片1一样，正文给出的具体量化（15% P99 变差）来自另一组合成负载实验（5.2.4节），不能将本图的 P90/真实 trace 视觉趋势当作该数值的直接证据。[基于视觉的谨慎推断]

6. **适用范围与证据缺口**：本证据覆盖论文报告的 4×A100(40GB, PCIe 4.0) 环境下 Qwen2.5-14B 模型，仅在 AzureConv 与 CNN-Reversed 两条负载上的对比（正文明确说明"因篇幅限制只报告两个代表性负载"，故本图未覆盖 CNN、ShareGPT 在 14B 上的表现，这是正文本身承认的实验设计边界，而非本图缺口）。图内坐标轴、图例分类、曲线可辨识度良好，无额外证据缺口。
