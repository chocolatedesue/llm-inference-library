# 图片批次 2

## 图片 1：Figure 3: Performance characteristics: (a) prefill time when varying the sequence length, (b) decode time when increasing the batch size, and (c) linear operations when increasing the number of tokens

![Figure 3: Performance characteristics: (a) prefill time when varying the sequence length, (b) decode time when increasing the batch size, and (c) linear operations when increasing the number of tokens](../figure-groups/page-0005-fe5878da2ef5.png)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：本图属于"机制"类证据，用于支撑第 3.1.2 节"流水线不均衡的性能影响"这一核心机制分析,是论证"流水线气泡的根本原因是阶段间计算不均衡"这一核心洞见的定量基础。图表角色：**问题严重性**（量化 P-P、P-D、D-D 三类不均衡背后的性能特性，为后续 DCP/DS 模块设计提供直接依据）。上文呼应：对应第 5 页正文 3.1.2 节，及主张地图中"三类不均衡是气泡根本原因"这一机制主张,并直接支撑正文引用的两个具体数值（"两 prefill 长度 2048/128 产生约 627ms 气泡"、"decode batch size 96→128 差距仅 5%"）。[正文支持]

2. **图像类型与布局**：三个子面板均为柱状图/折线图组合。Panel 1（对应文中 Figure 3a "Prefill"）：横轴为 Sequence length（128/256/512/1024/2048），纵轴为 Time (ms)，堆叠柱状图分 linear（蓝）、attention（红）、others（灰）三段。Panel 2（对应 Figure 3b "Decode"）：横轴为 Batch size（1/32/64/96/128/160），纵轴为 Time (ms)，同样是 linear/attention/others 堆叠柱状图。Panel 3（对应 Figure 3c "Linear layer"）：横轴为 Number of tokens（128 至 2048，密集刻度），纵轴为 Time (ms)，蓝色折线图，无堆叠分量。

3. **如何阅读**：Panel 1 应比较不同序列长度下总柱高（即总延迟）及蓝色（linear）段占比随序列长度增长的趋势；Panel 2 应比较不同 batch size 下总柱高及各分量增长斜率；Panel 3 应观察折线在相邻 token 数之间的跳变幅度是否均匀，尤其关注是否存在局部陡增（阶梯状）。三图共享纵轴单位（ms），但横轴含义不同（序列长度 vs 批大小 vs token 数），不可跨图直接比较数值。

4. **直接可见的结论**：
   - Panel 1：随序列长度从 128 增至 2048，总耗时从约 60ms 增至约 700ms，呈明显递增趋势；蓝色（linear）段始终占总高度的绝大部分，且在 2048 处占比最高（约 630/700）；红色（attention）段随长度增加也有所增长但幅度远小于 linear 段；灰色（others）段占比很小且相对稳定。[图像直接可见]
   - Panel 2：随 batch size 从 1 增至 160，总耗时从约 50ms 增至约 105ms，同样以 linear 段为主要贡献；从 batch size 128 到 160，红色（attention）段有明显增厚，总柱高增幅在该区间视觉上比前几档更陡（96→128 段增幅较小，128→160 段增幅更大）。[基于视觉的谨慎推断]（因该图横轴刻度非等距，129 这一具体点未单独标出，无法从本图直接读出"128→129" 的跳变，只能看到 128→160 区间整体增幅较大）
   - Panel 3：折线呈现明显的"阶梯状"（step-function）模式——在多个相邻 token 数区间（如 128-256、640-768、1024-1152 等）线段近似平坦或缓升，随后出现相对陡峭的上升段，整体呈非平滑的分段线性增长，而非严格递增的连续曲线。[图像直接可见]

5. **它验证的论点与方法设计含义**：该图属于机制类证据，验证第 3.1.2 节的两个核心论断：其一，prefill 延迟主要由 linear 层驱动且与序列长度近似成正比（Panel 1），这是 DCP（动态 chunk 调整）模块设计的物理基础——因为 chunk size 本质上控制的就是这里的 $N_{tokens}$，从而直接控制 linear 层延迟，此现象也是预测模型中 $T_{offline}=\alpha_0 N_{tokens}+\alpha_1$ 公式（4.1.2 节）的经验依据 [正文支持]。其二，Panel 3 的阶梯状模式是硬件 kernel 效率的物理约束的可视化证据，支撑正文"linear operations exhibit a distinct step-function pattern"的论断，是 Delay Scheduling 模块中"microbatch 应对齐 128 的倍数"这一设计决策的直接动机 [正文支持]。需要注意，本图不能单独证明正文中"128→129 差距 31%"这一具体数值——该数值在正文中明确报出，但本图 Panel 3 横轴刻度并未单独标出 129 这一点（可见刻度为 128, 256, 384...），因此该精确数值的可视化定位不能从本图像素直接确认。Panel 2 支持"decode 阶段延迟由请求数主导、且存在非线性跳变"的论断，但 96 与 128 之间的具体 5% 差距数值同样无法从柱状图高度精确读出，只能定性确认二者高度接近。

6. **适用范围与证据缺口**：本图覆盖论文在 4×A100 40GB（PCIe 4.0）环境下、以 Qwen2.5-32B 为对象的单独离线性能剖析实验（图注未明确指出具体是哪个模型/序列长度采样点对应哪个具体请求，但按上下文应为该论文统一的评测环境）。真实剩余缺口：Panel 3 横轴刻度密集且部分标签重叠难以逐一辨认（如 "1152", "1280" 等标签在图像中显示较拥挤），无法精确定位 128→129 这一具体相邻点的阶梯跳变起点，只能确认整体阶梯模式存在；Panel 1/2 中 attention 与 others 分量的具体数值边界因柱状图颜色堆叠精度限制，无法逐段精确读数，仅可做定性比较。

---

## 图片 2：Figure 4: Pipeline bubbles and prefill token throughput according to load and chunk size (when serving Qwen2.5-32B with the Azure Code workload on 4 NVIDIA A100 GPUs)

![Figure 4: Pipeline bubbles and prefill token throughput according to load and chunk size (when serving Qwen2.5-32B with the Azure Code workload on 4 NVIDIA A100 GPUs)](../figure-groups/page-0006-09115dfe9704.png)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图属于"方法流水线"与"效果"证据，对应第 6 页正文 3.2.1 节"Chunked Prefills in Pipeline Parallelism"，用于说明静态 chunk size 选择存在的"气泡-吞吐"权衡困境，是引出"chunk size 需要动态调整"这一设计动机的直接实验证据。图表角色：**问题严重性**（量化静态 chunk 在不同负载下的表现缺陷，为后续 DCP 模块的必要性提供证据）。上文呼应：对应主张地图"旧方法的限制"中"chunked-prefill 静态分块大小需权衡，现有实现未做动态权衡"这一论断，以及第 3.2.1 节引出"chunk size must be dynamically adjusted according to system load"的结论句。[正文支持]

2. **图像类型与布局**：两个并列折线图。Panel 1（对应 Figure 4a "Pipeline bubble"）：横轴为 Request rate (req/s)（1-6），纵轴为 Time (ms)，两条折线分别为 PP₁₂₈（蓝色圆点）与 PP₂₀₄₈（红色三角），代表 chunk size 为 128 与 2048 两种静态配置下的气泡时间。Panel 2（对应 Figure 4b "Prefill throughput"）：横轴为 Chunk size（128/256/512/1024/2048），纵轴为 Throughput (tok/s)，单条黑色折线表示 token 吞吐量随 chunk size 的变化。

3. **如何阅读**：Panel 1 应比较两条曲线在不同请求率下的相对高度与交叉行为，重点关注低负载（1-3 req/s）与高负载（5-6 req/s）区间两条线的高低关系是否发生逆转；Panel 2 应观察吞吐量随 chunk size 增大的单调性及增长速率是否递减（即是否边际收益递减）。

4. **直接可见的结论**：
   - Panel 1：在请求率 1-4 req/s 区间，PP₂₀₄₈（红色）气泡时间显著高于 PP₁₂₈（蓝色），并在请求率 3 附近达到峰值（约 54ms），此时 PP₁₂₈ 始终维持在低值（约 3-5ms）；从请求率 4 到 5，PP₂₀₄₈ 骤降至约 9ms，接近 PP₁₂₈ 水平；在请求率 5-6，两条曲线均维持低值且非常接近。[图像直接可见]
   - Panel 2：吞吐量随 chunk size 增大单调递增，从 chunk size=128 的约 6800 tok/s 增至 chunk size=2048 的约 11300 tok/s；增长曲线呈现边际递减特征——128→256 区间增幅最大（约 2300 tok/s），后续每次翻倍的增幅逐渐收窄（256→512、512→1024、1024→2048 各自增幅依次减小）。[图像直接可见]

5. **它验证的论点与方法设计含义**：该图属于必要性类证据，直接验证静态 chunk size 无法同时兼顾"低气泡"与"高吞吐"两个目标这一核心限制。Panel 1 表明大 chunk（2048）在低到中等负载下产生显著气泡（验证"块大——气泡多"论断），而小 chunk（128）在同等负载下气泡很小，但请求率超过 5 req/s 后两者气泡都趋近于零，说明高负载下气泡问题自然消解（因为流水线被稳定填满）——这一现象直接决定了 DCP 模块"根据负载动态调整 chunk"的设计逻辑：低负载应减小 chunk，高负载可以（也应该）增大 chunk。Panel 2 表明小 chunk 会牺牲吞吐（验证"块小——吞吐低"论断），从而共同证明"固定 chunk size 无法适应变化负载"这一结构性缺陷，是 Algorithm 1（贪心式动态分块）及预测式方法设计的直接实验基础 [正文支持]。该图不能证明动态方法本身的有效性——本图仅展示静态基线的权衡困境，DCP/DS 方法相对基线的改善效果需依赖 Figure 9/10/11 等后续图表（不在本次分析范围内）。

6. **适用范围与证据缺口**：本图覆盖论文在 4×A100 GPU、Azure Code 工作负载、Qwen2.5-32B 模型下针对两个特定 chunk size（128 与 2048）的对比实验（图注明确说明）。无额外证据缺口——正文已充分说明了两条曲线的实验设置（GPU 数量、模型、负载来源），图像本身清晰可辨，未见像素遮挡或数值歧义。
