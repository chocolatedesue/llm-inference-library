# 图片批次 3

## 图片 1：Figure 5: Reducing pipeline stalls from chunked-prefill [2]

![Figure 5: Reducing pipeline stalls from chunked-prefill [2]](../assets/imgs/img_in_image_box_642_140_1105_401.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图是**方法流水线**类证据,用于解释"为什么把长 prefill 切成固定大小的 chunk 能缓解流水线气泡"这一基础机制,是第 4 节动态分块设计(Algorithm 1 / DCP_greedy、DCP_pred)之前的机制铺垫,而非最终动态分块方案本身的效果验证。正文明确说明:"Figure 5 shows that dividing the prompt (A1) into two smaller chunks (A1[C1] and A1[C2]) allows earlier stages in the pipeline to make progress, thus reducing idle time"[正文支持][页码:6-7]。
   - **图表角色**:方法流水线(基础机制示意,支撑 3.2.1 节"leverage chunked-prefill"动机与 4.1 节设计目标)。
   - **上文呼应**:第 3.2.1/4.1 节:静态 chunked-prefill 如何减少长 prefill 独占迭代造成的空闲(idle)。

2. **图像类型与布局**:示意性时间轴(Gantt 风格)图,非真实实验测量曲线。分两个子面板,(a) Naive pipeline parallelism、(b) Pipeline parallelism with chunked-prefills。每个面板含 Worker 0、Worker 1 两行,横轴为时间;顶部图例区分三类色块:纯色蓝(Prefill)、白色空心(Decode)、蓝白斜纹(Prefill + Decode);面板(b)另有紫色色块标记 "Chunked prefill"。

3. **如何阅读**:横轴表示时间推进方向(从左到右,末端有省略号表示序列延续);纵向对比同一时刻 Worker 0 与 Worker 1 各自执行的请求块(A、B、C 等标识不同请求,下标数字为迭代序号,方括号 [C1]/[C2] 表示同一 prefill 请求被切分的子块);应重点比较面板(a)中出现的粉色 "idle" 空档与面板(b)同一时间区间是否仍存在空档。

4. **直接可见的结论**:面板(a)中 Worker 0 在完成 A1、B1 后出现一段标注为 "idle" 的粉色空闲区间,随后才开始 A2、B2;Worker 1 在此期间仍在处理 A1、B1。面板(b)中 A1 被拆分为 A1[C1] 与 A1[C2] 两个紫色 "Chunked prefill" 子块,穿插在 B1、B2 之间执行,Worker 0 和 Worker 1 的时间线上均未出现类似(a)中的 "idle" 空档,请求块之间衔接更紧密[图像直接可见]。

5. **它验证的论点与方法设计含义**:该图属于**机制**类证据,直接对应"三类不均衡(尤其 P-P 不均衡)导致气泡"这一核心洞见的正向解决方案示意:通过把一次性大 prefill(A1)切成小 chunk,使流水线前段(Worker 0)不必等待后段处理完整个大 prefill 才能推进,从而减少空闲。这为后续 4.1 节提出"动态"调整 chunk size(而非固定大小)的设计动机提供了直观的机制基础——图中只展示"切分本身"能消除某一具体空档,并未展示"chunk size 应设多大/如何随负载动态调整"这一后续论文核心贡献点,该部分仍需 Figure 4(气泡/吞吐 vs chunk size 与负载)及 Algorithm 1 等来验证[正文支持]。不能由此图证明:动态调整 chunk size 相对静态 chunked-prefill 的增量收益,也不能证明该机制在真实多请求、多种不均衡类型混合场景下同样有效。

6. **适用范围与证据缺口**:本图为示意性(schematic)图解,并非真实系统运行 trace 的实测时间线,用途仅在于解释切分 prefill 为何能减少特定类型空闲,覆盖范围限于论文示意的"两工位流水线、简化请求序列"场景。无额外证据缺口。

---

## 图片 2：Figure 6: Workflow of predictive dynamic chunked-prefill

![Figure 6: Workflow of predictive dynamic chunked-prefill](../assets/imgs/img_in_image_box_635_161_1105_325.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**:本图是**方法流水线**类证据,展示预测式动态分块(DCP_pred / ALP)调度器的完整在线决策流程,回答"调度器如何利用延迟预测模型在每次调度迭代中选出最优 chunk size"这一具体问题,对应 4.1.2 节"Online inference"部分对该图的逐步骤解说(①~⑤)[正文支持][页码:8-9]。
   - **图表角色**:方法流水线(端到端调度决策工作流示意)。
   - **上文呼应**:第 4.1.2 节"Online inference":Figure 6 演示预测式动态分块调度器如何选择最优 chunk size。

2. **图像类型与布局**:流程图(workflow diagram)与嵌入表格的组合。左侧为竖排的 "State" 输入框(列出 $KV_{free}$、$L_{measured}$、$Q_{waiting}$、$B_{running}$ 四项,标号①);箭头指向中部 "Adaptive latency predictor" 框,内含两个子模块 "Baseline (Offline profiling)" 与 "Adaptation ↻ (Online updating)"(标号②);再指向右侧一张三列表格(Chunk size / Predicted latency / Predicted throughput),行对应候选 chunk size(128、256、384、512、640…直至 2048),其中顶部若干行(128、256)与底部行(2048 附近)以红色高亮,中间某一行(384)以绿色高亮;表格右侧标注④ "Lower bound"、③ "Upper bound" 箭头指向对应高亮区域;最右侧为 "LLM inference" 框(标号⑤),并有一条回绕箭头从 "LLM inference" 返回左侧 "State" 框,构成闭环。

3. **如何阅读**:阅读顺序遵循数字标号①→②→③→④→⑤依次跟随箭头方向;左侧输入框是每次调度迭代读取的系统状态量;中部框是延迟预测器(离线基线+在线校准);表格中每行为一个候选 chunk size 及其预测的迭代延迟与吞吐量,应比较红色高亮行(被淘汰的候选)与绿色高亮行(被选中候选)在数值上与其余行的差异;整体闭环箭头表示该流程每次调度迭代重复执行。

4. **直接可见的结论**:表格中候选 chunk size 越大,"Predicted latency" 数值总体越大(如 128→45,2048→467),同时对应 "Predicted throughput" 数值随之增大后又出现波动(如 384 行为 9223,2048 行为 14745);表格顶部(128、256)与底部(2048 附近)行被标记为红色,中间某一行(384)被标记为绿色并有两条标号箭头(③④)分别指向表格上下两端区域,提示存在"淘汰候选的两条边界线"与"一个被选中的候选";存在从 "LLM inference" 返回 "State" 的闭环箭头[图像直接可见]。因图片像素分辨率限制,红色/绿色具体行与"③④"箭头精确指向的行数边界在视觉上不完全清晰,以下解释依赖文字锚定[基于视觉的谨慎推断]。

5. **它验证的论点与方法设计含义**:该图属于**机制**类证据,将 4.1.2 节文字描述的五步流程(状态获取→预测器在线更新→按 $TPOT_{SLO}$ 淘汰候选得到上界→按 $TTFT_{SLO}$ 所需最小吞吐得到下界→在可行区间内选最小 chunk)可视化为一个闭环调度工作流。红色高亮行对应正文所述"两类被淘汰的候选":表格上端(chunk 太小、吞吐不足以满足 $TTFT_{SLO}$,对应④ Lower bound 淘汰)与下端(chunk 太大、预测延迟超过 $TPOT_{SLO}$,对应③ Upper bound 淘汰);绿色高亮行对应正文"选择满足两界约束的最小候选"这一决策结果。该图支持"ALP 预测模型如何被用于在线选择 chunk size"这一方法必要性论点,即预测式方法相比贪心法能够在同一迭代内直接对多个候选做前瞻式比较,而非像贪心法那样逐步反应式调整[正文支持]。该图不能证明预测模型的**准确性**(MAPE 等精度指标)或该方法相对贪心法/静态 PP 的**实际吞吐延迟收益**,这些仍需 5.2.1 节数值结果与 Table 1 消融数据支持,不能仅凭此工作流图推断。

6. **适用范围与证据缺口**:本图覆盖论文 4.1.2 节所述预测式动态分块调度器的决策流程示意,candidate chunk size 集合以 128 的倍数离散取值(与 Algorithm 1 一致)。正文与图题均未标注坐标轴单位来源或具体候选值是否为真实测量结果还是示意性占位数值,图中数值(如延迟 45ms/467ms、吞吐 7127/14745)与正文实验章节报告的数值之间的对应关系,正文未明确说明,故这些具体数值应视为流程示意用途而非可核验实测结果(OCR/图题未提供进一步说明)[无法从当前 OCR 内容确认]。
