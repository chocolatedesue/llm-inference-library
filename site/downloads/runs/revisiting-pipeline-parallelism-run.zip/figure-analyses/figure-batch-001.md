# 图片批次 1

## 图片 1：Figure 1: Performance comparison for pipeline and tensor parallelism in serving Qwen2.5-32B with the Azure Conversation workload on 4 NVIDIA A100 GPUs

![Figure 1: Performance comparison for pipeline and tensor parallelism in serving Qwen2.5-32B with the Azure Conversation workload on 4 NVIDIA A100 GPUs](../assets/imgs/img_in_chart_box_645_146_1104_600.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：这是论文提出根问题后给出的第一手实测证据,对应第2.3节"Tensor Parallelism vs. Pipeline Parallelism"。其证据类型为**问题严重性**(同时也是**对比基线**):作者需要先证明"PP在低带宽PCIe环境下相较TP到底具体差在哪里、差多少",即PP的TTFT优势与TPOT/气泡劣势是否同时成立、以及这种劣势是否随请求率上升而恶化到违反SLO的地步,从而为后文"气泡是PP的核心待解决问题"这一根问题提供量化起点。`[正文支持]`
   - **图表角色**:问题严重性 / 对比基线
   - **上文呼应**:第2.3节,对应主张地图"4×A100(PCIe)上,PP相比TP有更低TTFT但更高TPOT……TP在SLO达标下可支持比PP高1.2×的请求率"[页码:4]

2. **图像类型与布局**:双子图折线图,共享横轴"Request rate (req/s)"(1–8)。上子图纵轴为P90 TTFT (ms,0–4000),下子图纵轴为P90 TPOT (ms,0–500)。两条曲线均用图例区分:蓝色方块=PP,橙色圆点=TP。图中各有一条黑色水平虚线标出对应的SLO阈值,并各有一条彩色垂直虚线+红色箭头文字标注("TP limited by TTFT_SLO""PP limited by TPOT_SLO")指出该并行方式达到SLO边界时对应的请求率。

3. **如何阅读**:横轴请求率越靠右负载越高;纵轴数值越低延迟越好。应重点比较同一横轴位置PP(蓝)与TP(橙)两条曲线谁更低,以及各自何时穿过对应的SLO虚线(上图2000ms虚线对应TTFT_SLO,下图200ms虚线对应TPOT_SLO)。垂直虚线标出的横轴坐标即为该并行方式的最大可行请求率(goodput边界)。

4. **直接可见的结论**:
   - 上子图(TTFT):在请求率1–6区间,PP(蓝)曲线始终低于或接近TP(橙);TP曲线在请求率约4附近急剧上扬,在该点(约2050ms)穿过2000ms虚线,并被红色箭头标注为"TP limited by TTFT_SLO";请求率7–8时PP曲线也快速上升并明显超过4000ms上限。`[图像直接可见]`
   - 下子图(TPOT):TP(橙)曲线在请求率1–4区间低于PP(蓝),但在请求率约3.2附近PP先穿过200ms虚线(标注"PP limited by TPOT_SLO"),TP约在请求率4处也穿过200ms虚线;请求率5以后TP曲线趋于平台(约400–410ms),而PP曲线继续上升,在请求率7–8时明显高于TP(PP约480–490ms vs TP约410ms)。`[图像直接可见]`
   - 两条垂直虚线分别标在约3.2(PP,下图)和约4(TP,上图)的横轴位置,即两并行方式各自的goodput边界。`[图像直接可见]`

5. **它验证的论点与方法设计含义**:该图是**效果类**证据,直接支持主张地图中"PP相比TP有更低TTFT但更高TPOT""TP在SLO达标下可支持比PP高1.2×的请求率"这一文字结论(4 vs 约3.2,比值约1.2×,与正文所述吻合)`[正文支持]`。图像同时为后文"气泡问题"提供了具体的失效现象锚点:PP的TPOT曲线在中高请求率区间持续高于TP并率先违反SLO,印证了摘要与引言中"计算不均衡导致的流水线气泡在高负载下更严重"这一核心洞见,为第3节的气泡根因分析(P-P/P-D/D-D)提供了实测动机。`[正文支持]`该图**不能**证明气泡具体由哪种不均衡(P-P/P-D/D-D)主导,这部分留给Figure 2/3去解释;也不能说明本文提出的DCP/DS方法效果,这属于Figure 9/10等后续证据范围。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**:该图覆盖论文报告的4×A100 40GB(PCIe 4.0)环境、Qwen2.5-32B模型、Azure Conversation负载、SLO为TTFT 2000ms/TPOT 200ms(MLPerf基准)、请求率1–8 req/s区间下的PP与TP对比。无额外证据缺口。

---

## 图片 2：Figure 2: Three types of pipeline bubbles (The subscript indicates the iteration number.)

![Figure 2: Three types of pipeline bubbles (The subscript indicates the iteration number.)](../assets/imgs/img_in_image_box_131_143_1076_311.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**:这是第3.1.1节"Types of Pipeline Imbalance"的核心机制示意图,证据类型为**机制**。其目的不是展示实测数据,而是用具体的时间线例子解释"流水线气泡的根因——阶段间计算不均衡"具体如何在请求调度中产生,并区分P-P、P-D、D-D三类不均衡各自的触发条件,直接对应论文"核心洞见"部分对气泡成因的第一性原理分解。`[正文支持]`
   - **图表角色**:机制
   - **上文呼应**:第3.1.1节,对应主张地图"三类不均衡(P-P/P-D/D-D)是气泡的根本原因"[页码:4-5]

2. **图像类型与布局**:两行(Worker 0、Worker 1)、多列(按迭代时间 T1…T5,再间隔省略号后接 Ti、Ti+1、Ti+2)的甘特图/时间线示意图。图例标出四种色块:深蓝色=Prefill、白色=Decode、斜纹填充=Prefill+Decode混合、粉红色=Idle(空闲)。左半部分(T1–T5)标注为"Prefill-heavy",右半部分(Ti–Ti+2)标注为"Decode-heavy";图上方用带圈数字①②③标出三处关键不均衡实例,每个数字上方对应一条虚线分隔迭代列。每个色块内标注了请求编号组合(如A1B1、C1D1等,下标为迭代序号)。

3. **如何阅读**:横向阅读表示时间推进(迭代 T1→T2→…),纵向对比同一列中Worker 0与Worker 1的色块类型和长度差异;色块越长代表该worker在该迭代耗时越久,粉红色块代表该worker提前完成而空闲等待。带圈数字①②③标出图注/正文叙述中具体讨论的三个不均衡瞬间,应结合图题"Three types of pipeline bubbles"与正文逐一对应阅读。

4. **直接可见的结论**:
   - 左侧"Prefill-heavy"区域:Worker 0与Worker 1的色块在多个迭代列中呈深蓝(Prefill)与白色(Decode)交替、且两行同列色块类型/宽度不总是对齐,标号①②所在列附近可见深蓝块与白块并列或深蓝块与斜纹混合块并列的情形,其中一处出现斜纹(Prefill+Decode混合)色块。`[图像直接可见]`
   - 右侧"Decode-heavy"区域(Ti、Ti+1、Ti+2):两行色块以白色(Decode)为主,且明显穿插粉红色(Idle)色块,标号③标注在该区域起始处。`[图像直接可见]`
   - 整体上两行的色块边界并非同步对齐,存在错位,且错位处伴随粉红色空闲块出现。`[图像直接可见]`
   - 由于色块内文字较小、渲染分辨率有限,无法逐一精确核对每个请求下标(如具体是A2B2还是C2D2)与正文描述的完全字符级对应关系,此处仅作整体结构性判断。`[基于视觉的谨慎推断]`

5. **它验证的论点与方法设计含义**:该图是**机制类**证据,为主张地图中"P-P/P-D/D-D三类不均衡是气泡根本原因"提供可视化支撑`[正文支持]`。图中"深蓝(Prefill)+白(Decode)+斜纹(混合)+粉红(Idle)"四色体系直观展示了正文所述三种失衡的判别标准:同为Prefill但长度不同(P-P,对应正文T2处描述)、Prefill与Decode并存导致速度悬殊(P-D,对应正文T3、T4描述)、全为Decode但请求数不均(D-D,对应正文Ti–Ti+2描述)。这直接为方法设计提供了动机锚点:P-P/P-D两类可通过动态chunk size(DCP)缓解,而D-D类由于色块全为Decode、请求数导致的不均衡,是延迟调度(Delay Scheduling)模块要专门解决的场景,与主张地图"模块三:延迟调度"的动机描述一致。`[正文支持]`该图本身**不能**证明气泡的具体时长或对TPOT的量化影响(那由Figure 3提供627ms等数值),只提供结构性机制解释。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**:该图为简化教学性示意图,正文明确说明其假设为"两阶段流水线、最大批大小为3"的简化场景,并非实测数据可视化,适用范围仅限于解释机制而非量化性能。无额外证据缺口。
