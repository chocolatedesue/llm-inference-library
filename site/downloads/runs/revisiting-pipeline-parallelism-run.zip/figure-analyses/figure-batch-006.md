# 图片批次 6

## 图片 1：Figure 12: Goodput comparison of Qwen2.5 32B and 14B under various SLO constraints.

![Figure 12: Goodput comparison of Qwen2.5 32B and 14B under various SLO constraints.](../assets/imgs/img_in_chart_box_638_526_1106_953.jpg)

*来源：OCR 第 12 页。*

### 解读

1. **论文角色与验证问题**：本图对应 5.2.3 节“Goodput under varying SLOs”，图表角色为**实验结论**（兼有**对比基线**成分：TP、PP、DCP、DS 同时呈现）。它验证的具体问题是：在逐步收紧的 TTFT/TPOT SLO 约束下，DCP（贪心/预测式动态分块）与 DS（延迟调度）相对 PP baseline、TP 的 goodput 优势是否稳健，尤其检验主张地图中“SLO scale 从 1.0 降至 0.4 时，DCP 相对 PP 的 goodput 提升从 2.7×增至 5.4×（32B）、1.7×增至2.4×（14B）”，以及“decode-heavy 场景下 DS 相较 PP baseline 提供最高 1.4× goodput 提升，但 SLO 低于 0.6 时效果骤降”。`[正文支持]`
   - **图表角色**：实验结论（含对比基线）。
   - **上文呼应**：5.2.3 节“Goodput under varying SLOs”，对应主张地图“DCP 相对 PP 提升随 SLO 收紧而增大”“DS 仅在 decode-heavy 下有效”“PP 在 32B+AzureConv 下相对 TP 优势减弱”等主张。

2. **图像类型与布局**：2×2 分组折线图。上排为 Qwen2.5-32B（(a)），下排为 Qwen2.5-14B（(b)）；每排左侧为 AzureConv 工作负载、右侧为 CNN-Reversed 工作负载。每个子图 x 轴为 SLO scale（1.0→0.2，逆序递减），y 轴为 Goodput (req/s)。五条曲线对应 TP（蓝圆实线）、PP（橙方虚线）、DCP_greedy（绿三角点划线）、DCP_pred（红菱形点划线）、DCP_pred+DS（紫星实线），共用一个顶部图例。

3. **如何阅读**：横向比较同一子图内不同 SLO scale 下各方法的 goodput 高度差，纵向比较同一方法在 AzureConv vs CNN-Reversed、32B vs 14B 之间的形态差异；重点关注 DCP/DS 曲线与 PP/TP 曲线之间的纵向间距（间距越大代表提升倍数越大）以及曲线随 SLO 收紧时是否提前跌至 0。

4. **直接可见的结论**：所有曲线均随 SLO scale 收紧（从 1.0 到 0.2）单调下降。在 32B-AzureConv 与 14B-AzureConv 两个子图中，DCP_pred、DCP_pred+DS、DCP_greedy 三条曲线全程明显高于 PP 和 TP，且在 SLO scale 较高时（1.0~0.6）与 PP/TP 的纵向间距最大；32B-AzureConv 在 SLO scale=0.2 时所有曲线（含 TP）均趋近于 0。在 32B-CNN-Reversed 子图中，DCP 系列与 PP 曲线在 SLO scale 1.0~0.6 区间高度接近、几乎重叠，明显高于 TP；但在 0.2 处 TP 反而高于（未跌到 0 而 DCP/PP 已接近 0）。在两个 AzureConv 子图中，DCP_pred 与 DCP_pred+DS 两条曲线几乎完全重合，全程不可分辨；而在 14B-CNN-Reversed 子图中，DCP_pred+DS 在 SLO scale≈0.6~1.0 区段可见略高于 DCP_greedy/DCP_pred 的分离。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：本图属于**效果类**主张的直接证据：DCP 系列在两模型的 AzureConv（prefill-heavy）负载下相对 PP/TP 全程保持明显优势，且该优势在 SLO 收紧时未消失，支持“DCP 提升随 SLO 收紧而增大”的稳健性主张 `[正文支持]`。DCP_pred 与 DCP_pred+DS 曲线在 AzureConv 子图中的几乎完全重合，与正文“delay scheduling (DS) provides no additional benefit for this prefill-heavy workload”的陈述一致，说明 DS 模块的增益具有**适用范围**限定——仅在 decode-heavy 场景激活 `[正文支持]`。14B-CNN-Reversed 子图中 DCP_pred+DS 相对 DCP_greedy/DCP_pred 的可见分离，为“DS 在 decode-heavy 负载下提供额外 goodput 提升”提供图像支持，但因四条 DCP/DS 系曲线在图中区分度有限，无法从本图单独判读具体倍数（如 1.4×）`[基于视觉的谨慎推断]`。32B-AzureConv 子图中 TP 与 DCP/PP 在低 SLO scale 处的相对位置变化，与正文“32B 模型在 AzureConv 下 PP 相对 TP 优势减弱”的定性描述方向一致，但正文未量化该减弱程度，本图也不能替代该缺失的量化 `[正文支持]`。

6. **适用范围与证据缺口**：本图覆盖论文报告的 4×A100 40GB PCIe 环境下，Qwen2.5-32B/14B 两模型、AzureConv 与 CNN-Reversed 两条负载、SLO scale 从 1.0 至 0.2 的五档设置。真实剩余缺口：图中 DCP_greedy、DCP_pred、DCP_pred+DS 三条曲线在多处高度重叠（尤其两个 AzureConv 子图），仅凭像素无法可靠区分三者之间的精确数值差异，具体倍数需依赖正文数值（如 2.7×~5.4×、1.4×）而非图像本身读出。

---

## 图片 2：Figure 11: CDF of iteration latency for (a) AzureConv, (b) CNN, and (c) CNN-Reversed

![Figure 11: CDF of iteration latency for (a) AzureConv, (b) CNN, and (c) CNN-Reversed](../assets/imgs/img_in_chart_box_183_146_1043_415.jpg)

*来源：OCR 第 12 页。*

### 解读

1. **论文角色与验证问题**：本图对应 5.2.2 节 CDF 分析，图表角色为**实验结论**。它验证的问题是：DCP_pred、DCP_greedy 相对 PP_static 是否能将单次调度迭代延迟的分布向低延迟区间集中（从而减少流水线气泡），以及 DS 是否能在 decode-heavy（CNN-Reversed）场景下进一步压缩迭代延迟尾部，对应主张地图“DCP_pred 优于 DCP_greedy，尤其在尾延迟上”“CNN-Reversed 上 DS 使 P90 迭代延迟从 28.94ms 降至 24.53ms”等具体数值结论。`[正文支持]`
   - **图表角色**：实验结论。
   - **上文呼应**：5.2.2 节“CDF analysis”，呼应主张地图 P90/P99 迭代延迟数值（AzureConv：51.68ms→29.56ms→21.53ms；P99 65.34ms→30.94ms）。

2. **图像类型与布局**：三个并排的累积分布函数（CDF）曲线图，分别为 (a) AzureConv、(b) CNN、(c) CNN-Reversed 三种工作负载（对应图注中约 4/5/8 req/s 的平均负载）。每个子图 x 轴为迭代延迟 Time (ms)，y 轴为 CDF（0~1）。四条曲线：PP_static（橙点线）、DCP_greedy（绿虚线）、DCP_pred（红点划线）、DCP_pred+DS（紫实线），共用顶部图例。

3. **如何阅读**：同一 x 坐标下曲线越靠上（CDF 值越大）代表该延迟阈值内完成的迭代比例越高，即延迟更低更集中；曲线爬升越陡且越靠左，代表尾部延迟越短；比较不同方法曲线在中低分位（~0.5~0.9）及右侧长尾拖尾程度的差异。

4. **直接可见的结论**：(a) AzureConv 与 (b) CNN 两个子图中，PP_static（橙点线）在约 0.6~0.8 处出现明显平台并向右拖出长尾（延伸至约 60~85ms 才接近 1.0）；DCP_greedy（绿虚线）爬升更快，在约 50~60ms 内即达到 1.0；DCP_pred（红）与 DCP_pred+DS（紫）两条曲线几乎完全重合，爬升最陡，在约 20~30ms 内已接近 0.9 以上，尾部最短。(c) CNN-Reversed 子图中，PP_static、DCP_greedy、DCP_pred 三条曲线的形态高度接近、几乎重叠；只有 DCP_pred+DS（紫）曲线在约 20~30ms 区间明显更靠左/靠上，随后各曲线在约 35ms 后重新收敛到 1.0。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：(a)(b) 子图中 DCP_pred/DCP_pred+DS 曲线相对 PP_static 明显左移且尾部更短，直接支持“DCP_pred 相比 PP_static 显著缩短 P90/P99 迭代延迟、更有效集中于低延迟区间”这一**效果类**主张，且 DCP_pred 与 DCP_pred+DS 在 prefill-heavy 负载（AzureConv、CNN）中几乎重合，与正文“对 AzureConv，D-D 不均衡可忽略，DCP_pred+DS 很少被触发，行为与 DCP_pred 相近”的陈述一致 `[正文支持]`。(c) 子图中 PP_static/DCP_greedy/DCP_pred 三线接近而 DCP_pred+DS 单独左移，直接支持“decode-heavy 负载下 DCP 各变体差异有限，DS 才是压缩尾延迟的关键机制”这一**机制类**主张，与正文“CNN-Reversed 上 DS 使 P90 迭代延迟从 28.94ms 降至 24.53ms”的方向一致，但本图无法单独读出精确的 28.94ms/24.53ms 数值，只能确认相对位置关系 `[基于视觉的谨慎推断]`。该证据支撑方法设计含义：动态分块（DCP）主要作用于 prefill 引起的迭代延迟分布压缩，而延迟调度（DS）是应对 decode-heavy 场景残余不均衡的必要补充模块，二者并非互相替代关系。

6. **适用范围与证据缺口**：本图覆盖论文在同一 4×A100 PCIe 环境下、AzureConv（约4 req/s）、CNN（约5 req/s）、CNN-Reversed（约8 req/s）三条负载在其对应平均请求率下采集的迭代延迟 CDF。真实剩余缺口：(a)(b) 子图中 DCP_pred 与 DCP_pred+DS 两条曲线几乎完全重合，仅凭像素无法区分二者在该负载下是否存在细微差异；(c) 子图中 PP_static、DCP_greedy、DCP_pred 三线在多处交叠，无法从图像本身精确判读三者两两之间的数值差距，需依赖正文给出的具体数值。
