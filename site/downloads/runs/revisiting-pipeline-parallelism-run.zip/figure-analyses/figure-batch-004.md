# 图片批次 4

## 图片 1：Figure 7: Reducing pipeline stalls with delay scheduling

![Figure 7: Reducing pipeline stalls with delay scheduling](../assets/imgs/img_in_image_box_632_140_1134_441.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 4.2 节 "Dynamic Rebalancing"（Delay Scheduling）机制的图解说明，图注为 "Figure 7: Reducing pipeline stalls with delay scheduling"（页码：9）。正文在同页详细逐步描述了 (a)(b) 两个 worker 的时间轴内容（"Worker 0 executes a microbatch containing C3D3E2F2 while Worker 1 processes a smaller microbatch A3B3 at T_{i+2}"；"request E and F are temporarily suspended... Once request A completes at T_{i+2}, the suspended decode-phase E2 can be resumed, forming a microbatch B4E2"），与图中标注完全对应。
   - **图表角色**：方法流水线（机制说明）。
   - **上文呼应**：第 4.2 节 delay scheduling 机制描述，对应模块三"延迟调度"设计。[正文支持]

2. **图像类型与布局**：两个水平时间轴（Gantt 风格）示意图，(a) "Imbalanced pipeline in decode-heavy phases"，(b) "Balanced pipeline with delay scheduling"。每图含 Worker 0 / Worker 1 两行，列为迭代时间点 T_i, T_{i+1}...。图例区分 Prefill（深蓝）、Decode（白）、Prefill+Decode（蓝白斜纹）、Idle（粉色阴影）。(b) 图顶部额外有灰色 "Suspended requests" 方框（多次出现 F2），并用编号①②③④⑤标注操作时序，右侧标注 "Saved cycles" 区间。

3. **如何阅读**：横轴为调度迭代（T_i, T_{i+1}, …），纵轴为两个流水线 Worker；每个格子内字母+下标（如 C3D3E2F2）表示该迭代该 Worker 正在处理的请求标签及迭代序号，粉色阴影格代表该 Worker 当前空闲（气泡）。应比较 (a)(b) 两图中粉色空闲格数量/位置的差异，以及 (b) 图中 E2、F2 从主时间轴中被抽出、悬挂、再恢复插入的路径。

4. **直接可见的结论**：(a) 图中 Worker 0 在若干迭代（如含 C3D3E2F2 之后邻近格）呈粉色空闲，Worker 1 在其他迭代也出现空闲格，两个 Worker 的空闲呈交替、持续出现的模式 [图像直接可见]。(b) 图中同一时间跨度内粉色空闲格明显更少，请求 E、F 的 decode 阶段（E2、F2）被移出正常时间轴放入顶部悬挂框，随后按①③（E2 恢复、组成 B4E2）与④⑤（F2 恢复）的顺序重新插入 Worker 0 时间轴；右侧 "Saved cycles" 标注了相对 (a) 节省的时间区间 [图像直接可见]。(b) 图达到相同请求处理进度所展示的时间列数少于 (a) [基于视觉的谨慎推断]。

5. **它验证的论点与方法设计含义**：该图为机制类证据，直接图解正文对 delay scheduling 算法执行流程的文字描述（挂起过载 Worker 上的部分 decode 请求 → 待其他请求完成释放资源后按序恢复），与正文逐句对应 [正文支持]。它支持的主张是"通过在流水线各阶段间动态迁移/悬挂-恢复 decode 请求，可以减少 D-D 不均衡导致的气泡"这一机制性设计合理性，而非提供具体延迟数值改善幅度（数值效果由 5.2 节的 Figure 9/11/13 等提供，不在本图范围）。读者应据此理解 delay scheduling 的核心操作顺序：识别过载 Worker → 抢占/挂起部分请求 → 在其他请求完成腾出资源后按 TPOT_slack 状态选择性恢复挂起请求，从而将集中的空闲时间分散或消除。该图不能证明该机制在真实负载下的量化收益或极端情况下的鲁棒性。

6. **适用范围与证据缺口**：本图为抽象示意性 Gantt 图，基于正文假设的"两阶段流水线、最大批大小为 3"的简化示例（与 Figure 2 使用相同的简化假设一致），用于解释机制而非报告实测数据，图中未标注具体延迟数值或硬件参数。无额外证据缺口。

---

## 图片 2：Figure 8: Input and output length distributions

![Figure 8: Input and output length distributions](../assets/imgs/img_in_chart_box_633_754_1119_907.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：该图对应 5.1 节 "Models and workloads" 中对三条真实负载 trace 的描述："we use three real-world traces, including Azure Conversation [22], ShareGPT [24], and CNN [9]... Figure 8 shows the input and output length distributions of the traces"（页码：9）。它为 5.2.1 节中"AzureConv, CNN, and ShareGPT workloads exhibit prefill-heavy behavior"（页码：10）这一工作负载分类提供支撑数据。
   - **图表角色**：问题严重性 / 实验结论（实验设置的负载表征）。
   - **上文呼应**：5.1 节实验设置 + 5.2.1 节对 prefill-heavy 负载的分类论断。[正文支持]

2. **图像类型与布局**：三个并排直方图子图 (a) Azure Trace Conv、(b) ShareGPT、(c) CNN-DailyMail；横轴 Token Length，纵轴 Frequency；每个子图内叠加蓝色（Input）与橙色（Output）两组直方图，图例标注各自均值（avg）。

3. **如何阅读**：横轴为 token 长度区间，纵轴为该长度区间内的样本频次；蓝色柱为输入（prompt）长度分布，橙色柱为输出（生成）长度分布；图例中数值（如 Input avg=1161）为对应分布的均值。应比较同一子图内 Input 与 Output 分布的集中区间、峰值位置及均值差异，以及三个子图之间分布形态的差异。

4. **直接可见的结论**：(a) Azure Trace Conv：Input 均值 1161，分布延伸至约 6000 token 且有长尾；Output 均值 212，集中于较低 token 区间 [图像直接可见]。(b) ShareGPT：Input 均值 226，Output 均值 199，两分布均高度集中在 0–500 token 区间，峰值位置相近 [图像直接可见]。(c) CNN-DailyMail：Input 均值 883，分布延伸至接近 3000 token；Output 均值 65，几乎全部集中在接近 0 的极低 token 区间 [图像直接可见]。三者中 Azure Conv 与 CNN-DailyMail 的 Input 均值明显高于 Output 均值（相差约 5–13 倍），而 ShareGPT 的 Input/Output 均值相对接近 [基于视觉的谨慎推断]。

5. **它验证的论点与方法设计含义**：该图为实验设置的表征性证据，用实测的 Input/Output 长度分布数值支持 5.2.1 节将 AzureConv、CNN、ShareGPT 归类为 "prefill-heavy" 的论断 [正文支持，属效果/必要性类证据的背景支撑]。其中 CNN-DailyMail 的 Input 均值(883)远大于 Output 均值(65)，与正文"CNN 为 prefill-heavy，因而通过反转其输入输出分布构造 CNN-Reversed 作为 decode-heavy 对照负载"的设计动机相符 [正文支持]。该图本身不包含 CNN-Reversed 的分布（正文说明其为对 CNN 分布的输入输出对调，未单独绘制），故不能直接从本图读出 CNN-Reversed 的具体数值。ShareGPT 的 Input/Output 均值较接近，说明其虽被归类为 prefill-heavy，但输入输出不均衡程度弱于 AzureConv/CNN，这为理解 5.2.1 节中 ShareGPT 上 DCP 改善幅度相对小于 CNN/AzureConv 的结果提供背景，但该图与该数值差异之间的因果关系正文未明确建立，属推断 [基于文中逻辑的推断]。

6. **适用范围与证据缺口**：本图覆盖论文实际使用的三条真实 trace（Azure Conversation、ShareGPT、CNN-DailyMail）的输入输出 token 长度分布统计，不包含 CNN-Reversed（其为对 CNN 分布的输入输出互换构造，未单独作图）。图中未标注纵轴频次对应的具体采样请求总量，正文也未给出该细节，此为正文明确未报告的实验设计细节，但不影响图像可见的相对分布形状与均值对比结论。
