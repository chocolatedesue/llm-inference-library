# 图片批次 1

## 图片 1：Figure 1: CAAT-Net model architecture. Left. We exemplify our approach on a two-layer fully-connected neural network on a single device. Middle. When using tensor-parallelism with two devices, the input activation X is identical on both devices. Each device uses its own set of weights to multiply the inputs, yielding intermediate activations, which are then reduced into identical copies of Z on both devices. Right. CAAT-Net receives different input activations, and , for Device 1 and Device 2, respectively. These yield intermediate activations that are partially synced between the devices, producing and on Device 1 and Device 2, respectively. Private channels are marked P, and shared channels are marked S.

![Figure 1: CAAT-Net model architecture. Left. We exemplify our approach on a two-layer fully-connected neural network on a single device. Middle. When using tensor-parallelism with two devices, the input activation X is identical on both devices. Each device uses its own set of weights to multiply the inputs, yielding intermediate activations, which are then reduced into identical copies of Z on both devices. Right. CAAT-Net receives different input activations, and , for Device 1 and Device 2, respectively. These yield intermediate activations that are partially synced between the devices, producing and on Device 1 and Device 2, respectively. Private channels are marked P, and shared channels are marked S.](../assets/imgs/img_in_image_box_213_262_1011_576.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图是论文核心架构机制的整体示意图，证据类型为"机制"说明。作者用它建立读者对"标准全连接网络 → 张量并行 → CAAT-Net"三种设置的直观递进理解，回应根问题"张量并行的 all-reduce 如何工作、其通信开销来自何处"，并直接引出核心架构假设"部分通道归约"（模块1、模块2）[正文支持]。
   - **图表角色**：机制。
   - **上文呼应**：对应第3节"CAAT-Net"引言段及3.1节"Architecture"中标准all-reduce MLP与部分通道归约MLP的公式推导（页码：3-5）。

2. **图像类型与布局**：示意图（非曲线/柱状），三个并列分组框，标题分别为"Original Model"、"Tensor Parallel"、"CAAT-Net"。每组用黑色节点表示输入/输出，橙色节点/连线代表"Device 1"计算，蓝色节点/连线代表"Device 2"计算；虚线表示"跨设备发送的值"，实线表示"设备本地计算的值"（见图例）。最右侧 CAAT-Net 组的输出节点标注了"S"（Shared，共享通道）与"P"（Private，私有通道）。

3. **如何阅读**：从左到右依次对比三种设置下同一个两层全连接网络的计算路径；中间"Tensor Parallel"组中 Z 节点用虚线圈标出（表示需要跨设备通信同步）；右侧"CAAT-Net"组中每个设备各自输出 $Z_1$、$Z_2$，其中标"S"的节点在两设备间用虚线连接（对应共享通道需通信），标"P"的节点无跨设备虚线（私有通道不通信）。应比较的是三组中"哪些连接/节点需要跨设备虚线"的差异。

4. **直接可见的结论**：
   - Original Model 中，输入 X 到隐藏层节点、隐藏层到输出 Z 全部是同一设备内的黑色实线连接，无跨设备虚线 [图像直接可见]。
   - Tensor Parallel 组中，输入 X 为同一份黑色节点（无颜色区分，暗示两设备共享相同输入），中间隐藏层节点按颜色分裂为 Device 1（橙）与 Device 2（蓝），两组各自计算后在输出 Z 处以虚线圈标注（表示该处发生跨设备通信/all-reduce）[图像直接可见]。
   - CAAT-Net 组中，输入本身就分裂为 $X_1$（黑色，对应 Device 1 行）与 $X_2$（黑色，对应 Device 2 行），不再共享同一份输入；每个设备内部隐藏层节点仍按颜色区分（橙/蓝）；输出端每个设备各自产生 $Z_1$、$Z_2$，各自又分为标"S"（有跨设备虚线连接另一设备对应S节点）和标"P"（无跨设备连线）两类节点 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图属于机制类证据，直观对应正文精确公式：标准MLP的 $Z=Y_1B_1+Y_2B_2$（全all-reduce，图中Tensor Parallel组Z处虚线圈）与部分通道归约的 $Z_1=[Y_1B_{11}+Y_2B_{12}, Y_1B_{21}]$（图中CAAT-Net组的S/P节点划分）[正文支持，页码：4-5]。它同时可视化了核心洞见——CAAT-Net与传统张量并行的关键区别在于输入本身即不同（$X_1 \neq X_2$），而非仅在输出处引入差异；图注也明确写出这一点（"CAAT-Net receives different input activations, $X_1$ and $X_2$...Private channels are marked P, and shared channels are marked S"）。此图不能单独证明准确率、通信量降低比例或收敛性等实验结论，这些需分别由Table 1、Figure 3/4等提供[正文支持]。

6. **适用范围与证据缺口**：本图覆盖的是论文以张量并行维度=2、两层全连接网络为例的示意性机制说明（正文3.1节明确"we examine a case where the tensor-parallel dimension is 2"），并非实际7B模型的完整架构图。无额外证据缺口。

---

## 图片 2：Figure 2: Partial synchronization and partial channel-reduce. (a) Vanilla transformers in current training frameworks. The operation f is an all-reduce in the forward pass and identity in the backward pass. The operation g is an all-reduce in the backward pass and identity in the forward pass. (b) With partial synchronization, h denotes the reduction operation in both the forward and the backward pass, since both must be done at the same location. Synchronization of the normalization function parameters is necessary. (c) Partial channel-reduce with parameter p over 2 devices.

![Figure 2: Partial synchronization and partial channel-reduce. (a) Vanilla transformers in current training frameworks. The operation f is an all-reduce in the forward pass and identity in the backward pass. The operation g is an all-reduce in the backward pass and identity in the forward pass. (b) With partial synchronization, h denotes the reduction operation in both the forward and the backward pass, since both must be done at the same location. Synchronization of the normalization function parameters is necessary. (c) Partial channel-reduce with parameter p over 2 devices.](../assets/imgs/img_in_image_box_216_149_1000_584.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图是论文第4节"Partial Synchronization: Implementation"中反向传播位置调整（模块3）的核心机制图，证据类型为"机制/必要性"。它直接解释根问题"为何标准张量并行框架（如Megatron-LM）在部分同步下会产生forward-backward mismatch"，并可视化作者提出的解决方案——把all-reduce操作从归一化层反传前（'g'操作）移到反传后（'h'操作）；子图(c)则可视化"部分通道归约"操作本身在MLP/attention层输出上的具体执行方式（对应模块1、2）[正文支持]。
   - **图表角色**：机制。
   - **上文呼应**：对应第4节"Forward-backward mismatch"段落（页码：5-7）关于f/g/h操作位置及其数学推导；子图(c)呼应第3节"partial channel-reduce"定义（页码：3-5）。

2. **图像类型与布局**：三个示意图子图，(a)与(b)结构相同（Attention → f → Norm+Residual(×2条并行路径) → g/h → MLP，输入输出为 $Z_1,Z_2 \to X_1,X_2$，用橙/绿两色区分Device 1/Device 2数据流），(c)为矩阵/张量分块示意图，展示 $Z_1,Z_2$（橙/绿立方体，标注Token/Batch/Hidden三维）经过"Partial Channel-Reduce"模块后，各自的隐藏维度被切分为浅蓝色"Shared Channels"（宽度 $p\cdot h$，两设备对应部分相加为 $Z_1+Z_2$）与保留原色的"Private Channels"（宽度 $(1-p)\cdot h$，各自保留 $Z_1$ 或 $Z_2$）。

3. **如何阅读**：(a)与(b)对比阅读——同一网络位置（Attention输出到MLP输入之间）中，(a)的归约操作标记为g（位于Norm之前），(b)的归约操作标记为h（位于Norm之后），二者的差异即是流程图中"f/g/h"色块相对"Norm, Residual"色块的先后顺序；(c)则应按"输入 $Z_1,Z_2$ 整体张量 → 经Partial Channel-Reduce模块 → 输出被按hidden维度切成shared/private两部分"的从左到右顺序阅读，比较切分后色块宽度比例（$p\cdot h$ vs $(1-p)\cdot h$）与颜色变化（原色→浅蓝色代表被归约求和）。

4. **直接可见的结论**：
   - (a)中，f位于Attention之后、Norm之前，g位于两条并行的Norm+Residual分支之后、MLP之前，即归约点g在归一化处理之后（forward视角）[图像直接可见]。
   - (b)中，h这一单一色块同时承担了(a)中f和g的角色，且其在流程图中的位置相对Norm+Residual色块，与(a)中g的位置一致（Norm之后一次归约）——但图注文字说明其反向传播时的归约时机与(a)不同 [图像直接可见位置关系；反向时机差异依赖图注/正文，图像本身不能单独区分正反向][基于视觉的谨慎推断]。
   - (c)中，$Z_1$（橙）与 $Z_2$（绿）经过Partial Channel-Reduce后，输出的shared channels部分（浅蓝色，宽度标注 $p\cdot h$）在两设备上数值相同（均标为 $Z_1+Z_2$），而private channels部分（宽度标注 $(1-p)\cdot h$）分别保留各自原色（$Z_1$ 或 $Z_2$），未被混合 [图像直接可见]。

5. **它验证的论点与方法设计含义**：(a)(b)两图为机制类证据，直接可视化正文推导——全同步下 f/g 分离但等价于把归约放在Norm前或后（数学等价，因矩阵乘法可分配），而部分同步下二者必须合并为h（归约位置固定在Norm导数计算之后）[正文支持，页码：6-7]。这构成论文最重要的必要性论证：若不做此调整，会产生forward-backward mismatch导致训练发散。(c)图则是"部分通道归约"操作本身的精确可视化，直接对应正文变量定义（shared channels为前 $h\cdot p$ 个通道，被求和；private channels为其余 $(1-p)\cdot h$ 个通道，设备各自保留）[正文支持，页码：3-4]，与图片1中CAAT-Net的S/P节点标注呼应，是模块1、2architecture设计的具体机制展示。该图不能证明该调整在实际训练中带来的收敛/发散数值差异（这需要正文文字提及但未提供的具体实验曲线，见页码：2的"导致训练发散"陈述，无配图）。

6. **适用范围与证据缺口**：本图覆盖论文以张量并行维度=2为例的一般性机制推导（对应正文3.1/4节的简化情形），(c)图未标注具体张量并行维度但沿用同样双设备示例。真实缺口：图(b)中h操作在反向传播时具体如何与(a)的f、g区分（即两者反向语义差异）无法仅从图像布局本身完全确认，需依赖图注与正文文字联合解读，图像本身对此存在裁剪/简化（正反向的图形表示相同，仅通过文字说明区分）——这是图像与文字结合才能消解的缺口，而非纯视觉遮挡，故按规则不应写为"无法从图像判断"的独立缺口；此处仅指出该依赖关系。
