# 图片批次 3

## 图片 1：Figure 4: Speedup in training and inference for a Llama 7B model. Top Left Training speedup for varying values of p and tensor-parallel dimension. Top Right. Inference Time-To-First-Token (TTFT) speedup on different hardware, using batch-size 128. Bottom Left. Inference TTFT speedup using tensor-parallel 8 as a function of batch size, for different values of p. Bottom Right. Inference TTFT speedup using tensor-parallel 16 as a function of batch size, for different values of p.

![Figure 4: Speedup in training and inference for a Llama 7B model. Top Left Training speedup for varying values of p and tensor-parallel dimension. Top Right. Inference Time-To-First-Token (TTFT) speedup on different hardware, using batch-size 128. Bottom Left. Inference TTFT speedup using tensor-parallel 8 as a function of batch size, for different values of p. Bottom Right. Inference TTFT speedup using tensor-parallel 16 as a function of batch size, for different values of p.](../figure-groups/page-0010-8085d62969b1.png)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：本图（Figure 4，正文第 9–10 页 "5.2 Speedup" 节）证据类型为**实验结论**（训练/推理加速幅度的定量展示），其中右上 Panel 2 兼有**对比基线**成分（跨硬件对比）。它验证的具体问题是核心贡献第 3 条——"CAAT-Net 在多种设置下同时加速训练和推理，且准确率与全同步训练基本持平"——中的加速部分，并为正文列举的具体加速数字（TP16 训练吞吐提升 14%/9%，TP16 推理 batch=32 时最大加速 26%，NVIDIA 硬件最大加速 13% 等）提供可视化支撑。`[正文支持]`
   - **图表角色**：实验结论（含对比基线）。
   - **上文呼应**：对应第 5.2 节 "Speedup"（Training 段落与 Inference 段落，页码 9–10）。

2. **图像类型与布局**：四宫格折线图（2×2）。Panel 1（左上，"Training Speedup"）：横轴张量并行维度（4/8/16，线性刻度标注但按对数间距排列），纵轴 Speedup [%]，五条线分别为 p=0、p=0.25、p=0.5、p=0.75、Baseline（图例含颜色区分：红/蓝/黄/绿/紫）。Panel 2（右上，"Inference Speedup"）：横轴同步因子 p（0→1），纵轴 Speedup [%]，三条线分别为 H100（红）、A100（蓝）、Gaudi3（黄），对应不同硬件。Panel 3（左下，"TP 8 Inference Speedup"）：横轴 Batch Size（2⁴–2⁸，对数刻度），纵轴 Speedup [%]，线为 p=0/0.25/0.5/0.75/Baseline。Panel 4（右下，"TP 16 Inference Speedup"）：布局与 Panel 3 相同，仅张量并行维度换为 16。

3. **如何阅读**：Panel 1 与图题对应"Top Left: Training speedup for varying values of p and tensor-parallel dimension"；Panel 2 对应"Top Right: Inference TTFT speedup on different hardware, using batch-size 128"；Panel 3 对应"Bottom Left: Inference TTFT speedup using tensor-parallel 8 as a function of batch size"；Panel 4 对应"Bottom Right: ...tensor-parallel 16..."。所有纵轴均为相对基线的百分比加速（Speedup %），数值越高代表相对基线越快；Baseline 线（紫色，Panel1/3/4）应恒为 0% 参照线。

4. **直接可见的结论**：
   - Panel 1：p=0 时训练加速最高，随 TP 从 4→16 从约 18% 升至约 31%；p=0.25 稳定在约 13–16%；p=0.5 约 6–10%；p=0.75 最低，约 2–6%；Baseline 恒定于 0% 附近。`[图像直接可见]`
   - Panel 2：p=0 时 Gaudi3 加速最高（约 31%），H100/A100 略低（约 18–20%）；随 p 增大三条线均单调下降，至 p=1 时三者收敛至约 0%；Gaudi3 在低 p 区间领先 H100/A100 较明显。`[图像直接可见]`
   - Panel 3：p=0 曲线在约 28–32% 区间波动，是四条曲线中最高；p=0.25 次之（约 12–17%）；p=0.5、p=0.75 更低且部分区段接近或交叉；Baseline 恒为 0%。`[图像直接可见]`
   - Panel 4：p=0 曲线明显高于其余（约 38–57%，在 batch=2⁵附近达峰值约 57%后回落）；p=0.25 在 batch=2⁵ 附近出现局部峰值（约 26%）后下降；p=0.5、p=0.75 整体更低；Baseline 恒为 0%。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：图像证实了"主张地图"中列出的效果类主张——"推理/训练加速具体百分比（26%、14%、9%、13% 等）"[正文支持][页码：9-10]：Panel 4 中 p=0.25 曲线在 batch size 2⁵（即 32）附近出现的局部峰值与正文"TP16、p=0.25 在 batch=32 时最大加速 26%"的描述方向一致；Panel 1 中 TP=16 处 p=0.25 与 p=0.5 两条线的相对高度差与正文"TP16 下 p=0.25 提升 14%、p=0.5 提升 9%"的数量级关系一致。Panel 2 中 Gaudi3 在低 p 区间高于 H100/A100，呼应正文"Speedup on Gaudi is more significant...on NVIDIA hardware...up to 13%"的跨硬件比较陈述，属于**对比基线**证据：这里的"基线"并非另一竞争方法，而是同一 CAAT-Net 方法在不同硬件平台上的效果对比，用于说明方法并非 Gaudi 专属。四个 Panel 共同表明：p 越小（同步通道越少）加速越大，加速随张量并行维度/批大小的变化趋势整体符合"通信降低→加速提升"的核心逻辑，但**该图本身不能证明"准确率不下降"这一并行主张**（该证明由 Table 1/Figure 3 承担），也不能单独证明"通信量降低比例"的理论值（理论分析在 Appendix C，未在当前 OCR 内容中）。此外，正文明确说明所有训练加速数字（Panel 1）均在反向传播 16 位精度累积（而非论文推荐的 fp32）条件下测得，属于"performance projection"而非推荐配置下的实测结果 [作者明确陈述][页码：10]，这构成读者理解 Panel 1 数字时必须附加的适用边界，而非本图证明的额外主张。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的 Llama2-7B 模型，在 Intel Gaudi3（Panel 1/3/4）及 NVIDIA H100-80GB-HBM3、A100-SXM4-80GB（Panel 2 及部分对照）上的实测加速；Panel 2 固定 batch size=128，Panel 3/4 固定张量并行维度分别为 8/16 并在多个 batch size 下测量；34B/70B 模型的对应结果在 Appendix E.4、绝对时延数据在 Appendix E.5、更多 batch size 在 Appendix E.6，均未包含在当前 OCR/图片中——"无法从当前OCR内容确认"具体数字。纵轴单位为百分比可读，但 TTFT 本身的绝对单位（毫秒/秒）正文未标注 [页码：9，"文中未说明"]，本图不涉及绝对时延读数，故不构成本图的直接缺口。各折线未标注具体数值点，无法从图像本身精确核对正文给出的"14%/9%/26%/13%"等具体百分比是否与像素位置完全对应，只能确认趋势方向一致——此为图像分辨率导致的真实读数缺口。

---

## 图片 2：Figure 6: Effects of All-Reduce Accumulation Precision in the Backward Pass on TinyLlama Train Loss.

![Figure 6: Effects of All-Reduce Accumulation Precision in the Backward Pass on TinyLlama Train Loss.](../assets/imgs/img_in_chart_box_322_863_903_1154.jpg)

*来源：OCR 第 18 页。*

### 解读

1. **论文角色与验证问题**：本图对应 Appendix E.1（"Effects of All-Reduce Bit Precision in the Backward Pass"，页码 18，标题为 Figure 6），证据类型为**消融验证**（同时也支撑第 4 节中的必要性主张）。它验证的具体问题是"主张地图"模块 4 与主张表中的关键论点——"部分同步需两项调整（反向位置调整+fp32累积）才能避免发散"中 fp32 累积这一项的**数值必要性**：即两种反向实现在数学上等价（全同步条件下），但 16 位精度累积仍会导致收敛出现明显差距，而 fp32 累积可完全消除该差距 [作者明确陈述][页码：7]。`[正文支持]`
   - **图表角色**：消融验证（精度维度的必要性证明）。
   - **上文呼应**：对应正文第 4 节 "Numerical stability via 32 bit gradient accumulation"（页码 7）及 Appendix E.1 文字说明（页码 18："Results in Figure 6 show severe degradation with 16 bit accumulation after 15K training steps"）。

2. **图像类型与布局**：单幅折线图（训练损失曲线，Train Loss vs Step）。横轴为训练步数 Step（0–20000），纵轴为 Loss（约 2–10+）。三条曲线：红色为 "bfloat16 accumulation"，蓝色为 "float32 accumulation"，黄色为 "Baseline"（对应正文所述的、未做任何本文调整的 Intel Megatron-LM fork 原始实现）。

3. **如何阅读**：三条曲线在训练前期（约 0–15000 步）应重合或高度接近，代表数学等价性在早期未显现差异；15000 步之后需观察红色曲线是否出现剧烈偏离/尖峰，而蓝色（fp32）与黄色（Baseline）是否保持平滑收敛，这是判断"16 位精度累积是否导致发散"的关键读图位置。

4. **直接可见的结论**：三条曲线在约 0–15000 步高度重合，均从约 10.6 快速下降并收敛至约 2.5 附近；约 15000 步之后，红色（bfloat16 accumulation）曲线出现多次剧烈尖峰，峰值达到约 8–9（相对基线约 2.5 的水平出现严重偏离），而蓝色（float32 accumulation）与黄色（Baseline）曲线在整个 15000–20000 步区间继续保持平滑、稳定地维持在约 2.3–2.5 附近，未见明显尖峰。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：本图直接支持"数值假设"——即便两种反向实现在全同步条件下数学等价，16 位精度累积仍会引入数值误差导致训练不稳定/发散，而改用 fp32 累积可完全消除该差距 [页码：7]，这是一条**必要性**类主张：它证明了模块 4（反向梯度 fp32 累积）并非可选的性能优化，而是避免训练发散的必要工程调整。图中 bfloat16 曲线在训练中后期（15K 步后）才出现剧烈发散、而非从一开始就偏离，说明该数值问题具有训练后期累积效应的特征，这与正文"severe degradation... after 15K training steps"的描述完全一致 `[正文支持]`。同时，float32 与 Baseline 曲线始终高度贴合，说明"改为 fp32 累积可完全消除该收敛差距"这一主张在此图中得到直接印证，而非仅靠推导。该图**不能**用于判断部分通道归约（partial channel-reduce，p<1）本身对准确率的影响——根据图题与正文，本实验是针对"反向传播实现方式（g vs h 操作位置）+精度"这一变量的消融，与 p 值大小无关，图中的 TinyLlama 模型配置应理解为在全同步或固定部分同步设置下对比精度效应，而非跨 p 值扫描（跨 p 值扫描由 Figure 3 承担）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文在 TinyLlama（1.1B）模型上、使用与第 5.1 节相同训练设置进行的精度消融实验，对比对象为原始 Intel Megatron-LM fork（Baseline）、应用第 4 节调整后但反向 all-reduce 累积用 bfloat16、以及应用全部调整（含 fp32 累积）三种配置 [页码：18]。图中未标注具体的 loss 数值刻度精确读数（纵轴刻度为整数网格，无法读出发散尖峰的精确数值，只能确认量级约为基线的 3–4 倍），也未说明该 TinyLlama 变体在此实验中使用的具体 p 值（正文 Appendix E.1 描述中未提及 p 参数，只说明是"variants of the TinyLlama model, as is described in Section 5.1"）——"文中未说明"该消融实验采用的具体同步因子 p 取值，此为真实缺口。
