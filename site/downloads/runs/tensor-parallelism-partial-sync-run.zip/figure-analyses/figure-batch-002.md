# 图片批次 2

## 图片 1：Figure 3: Training accuracy in multiple scenarios. Left. Validation loss of 130M and 1.1B models for different values of , and of the 7B model with , normalized to the loss at . Right. Validation loss for the 130M model with varying values of and tensor-parallel dimension (TP).

![Figure 3: Training accuracy in multiple scenarios. Left. Validation loss of 130M and 1.1B models for different values of , and of the 7B model with , normalized to the loss at . Right. Validation loss for the 130M model with varying values of and tensor-parallel dimension (TP).](../figure-groups/page-0008-a4cab5da7676.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图为 Figure 3（左右两个 Panel 属于同一图号，不拆分）。左图证据类型为“实验结论”，验证核心贡献 3（“中等程度减少同步有时能改善而非仅维持验证损失”）与主张地图中“130M/1.1B/7B 在不同 p 下验证损失趋势”一条；右图证据类型兼具“实验结论”与“消融验证”，验证张量并行维度对 p-退化阈值的影响这一机制性主张。**上文呼应**：第 5.1 节“Large Scale Training”正文（页码 8-9），对应主张地图“中等程度减少同步…改善验证损失”与“p 过低导致性能变差，且该退化起始点随 TP 增大而提前”两条。[正文支持]

2. **图像类型与布局**：两个并列的折线图（曲线图）。左图（Panel 1）：横轴为同步因子 p（0.0–1.0），纵轴为“Normalized Loss”（归一化到 p=1 处的损失），三条系列：130M（红色圆点）、1B（蓝色方点）、7B（橙色星形，仅 p=0.5 一个点）。右图（Panel 2）：横轴同为 p，纵轴为原始 Loss（1.86–1.96+ 区间），四条系列对应 TP=2/4/8/16（红/蓝/黄/绿），另有一条水平黑色参考线。

3. **如何阅读**：左图应比较不同模型规模（130M vs 1B vs 7B）在同一横轴 p 下的归一化损失高低及最低点位置；7B 仅有 p=0.5 一个点，作为与其他模型趋势的对照锚点。右图应比较不同 TP 曲线各自的最低点（谷值）相对于横轴 p 的位置，以及各曲线与水平参考线（可读作 p=1 即全同步基线的损失水平）的交叉点；曲线整体走势为先降后升的“U 形”。

4. **直接可见的结论**：左图中，p 从很小值增大时归一化损失快速下降，130M 与 1B 曲线在 p≈0.5–0.75 附近出现最低点（约 0.99，低于 p=1 处的 1.00），随后随 p 继续增大略微回升至 1.00；7B 的星形点位于 p=0.5 处，同样低于 1.00 的基线水平 [图像直接可见]。右图中，TP=2（红）、TP=4（蓝）两条曲线的最低点出现在较小的 p（约 0.15–0.35），而 TP=8（黄）、TP=16（绿）曲线的最低点明显右移至更大的 p（约 0.4–0.6 甚至更高），且 TP=16 曲线在小 p 处的损失上升幅度和绝对高度均大于其余三条 [图像直接可见]。所有曲线在 p=1 附近均趋近同一水平线附近 [图像直接可见]。

5. **它验证的论点与方法设计含义**：左图为“效果”类主张提供直接支持——中等 p（约 0.5）不仅未使验证损失变差，反而略优于全同步基线（p=1），这与正文“Reducing the communication by 50% achieves either similar or slightly better validation loss for all models”一致，7B 星形点尤其支持大模型上该趋势可外推 [正文支持]。右图为“机制”类主张提供直接支持——随 TP 增大，可安全降低同步的 p 下限随之上移（退化起始点提前到更高 p），这解释了论文选择 7B 大规模训练配置为 p=0.5、TP=8 的依据（“基于消融研究预期该组合能取得良好准确率同时显著降低带宽”）[正文支持]。该图不能证明的：图中未标出具体退化转折点的精确数值（仅可视觉估读），也不涉及零样本准确率（该图只反映验证损失，不是 Table 1 的准确率指标）。

6. **适用范围与证据缺口**：本图覆盖 130M、1.1B（TinyLlama）与 7B（仅 p=0.5 一点）模型、TP∈{2,4,8,16}（仅在 130M 模型上做 TP 扫描）、RedPajama 数据集训练的验证损失结果。真实缺口：右图水平参考线的具体数值含义（是否严格等于 p=1 处损失，还是某个其他基线阈值）图上未标注图例说明，OCR 图注也未提及该参考线，故其精确定义“无法从当前 OCR 内容确认”；此外图中坐标读数均为视觉估读，非精确数值。

---

## 图片 2：Figure 5: Comparison to compression methods. Validation loss vs. p for 130M models using CAAT-Net, Top-k masking and random masking.

![Figure 5: Comparison to compression methods. Validation loss vs. p for 130M models using CAAT-Net, Top-k masking and random masking.](../assets/imgs/img_in_chart_box_629_976_1006_1180.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：本图为 Figure 5，证据类型为“对比基线”。它验证第 5.3 节中 CAAT-Net 与两种压缩通信方法（Top-K mask、随机掩码）的对比主张，检验作者对“压缩方法此前未被证明适用于张量并行、且实测中即便轻微压缩也严重损害准确率”这一旧方法限制批判的具体证据。**上文呼应**：第 5.3 节“Comparison to compression methods”（页码 10-11），对应主张地图“CAAT-Net 优于 Top-K/随机掩码压缩方法”一条，以及“比较工作与受批判限制地图”表中对压缩类相关工作（自编码器/Top-K [14,15]）的批判。[正文支持]

2. **图像类型与布局**：单幅折线图。横轴为 p（0.0–1.0，此处 p 定义为“激活未被置零的概率”，与 Figure 3 中“同步比例”的 p 含义不同但共用符号），纵轴为 Loss（2.0–3.0）。三条系列：CAAT-Net（红色圆点）、Top-K（蓝色方点）、Random（黄色三角点）。

3. **如何阅读**：应比较三条曲线在相同 p 值下的纵轴 Loss 高低，尤其关注 p 较小（压缩程度较大）时三者差距，以及 p→1（接近不压缩/全同步）时三者是否收敛。

4. **直接可见的结论**：在 p 较小处（如 p≈0.1–0.3），Random（黄）曲线 Loss 最高（约 2.7–3.0），Top-K（蓝）次之（约 2.3–2.65），CAAT-Net（红）显著最低且平坦（约 2.05–2.1）；随 p 增大，Top-K 与 Random 曲线快速下降，三条曲线在 p 接近 0.9–1.0 时趋于接近（约 2.0–2.05）；CAAT-Net 曲线在整个 p 范围内几乎保持水平、变化幅度远小于另外两条曲线 [图像直接可见]。

5. **它验证的论点与方法设计含义**：本图直接支持“比较效果”类主张——在相同的通道/激活保留比例下，CAAT-Net 在小 p（强压缩/低同步）区间的验证损失远低于 Top-K 与随机掩码两种压缩基线，印证正文“even minimal compression”即导致 Top-K/随机掩码“severe degradation”，而 CAAT-Net 保持较低损失 [正文支持]。这为论文批判压缩类相关工作的具体 limit（“尚未证明压缩对张量并行有效”“实测中即便极小压缩也导致准确率严重下降”）提供了本图对应的实际检验部分：即在“保留比例”这一相同自变量下的验证损失对比，而非通信效率或计算开销对比（后者正文说明见 Appendix D，未在本图内容中）。该图不能证明的：压缩方法计算开销大小、Top-K/随机掩码的实际通信效率损失比例（正文提及“less efficient in reducing communication than CAAT-Net”，但具体量化数据在 Appendix D，未在本图或当前 OCR 中体现）。

6. **适用范围与证据缺口**：本图/实验仅覆盖 130M 参数 Llama 架构模型，训练 2.6B token（远小于 Section 5.1 的 160B/100B/7.8B token 规模），RedPajama 数据集，此处的 p 是“未被置零概率”而非 Figure 3 中的“同步通道比例”。真实缺口：图中各点的精确 Loss 数值仅可视觉估读，无法读出精确坐标值；三条曲线在 p 接近 1 处是否完全重合还是仍有细微差距，因像素分辨率限制难以精确区分——"无法从当前OCR内容确认"具体数值差距。
