# 图片批次 4

## 图片 1：Figure 7: Partial Channel Scaling. Validation loss vs. p for with and without private channel scaling, on a 130M model.

![Figure 7: Partial Channel Scaling. Validation loss vs. p for with and without private channel scaling, on a 130M model.](../assets/imgs/img_in_chart_box_322_148_904_466.jpg)

*来源：OCR 第 20 页。*

### 解读

1. **论文角色与验证问题**：这是一张**消融验证**类证据。它对应正文第 4 节 "Private channel scaling" 模块（模块 5：私有通道方差缩放）的陈述——作者在页码 7 明确写道："we find a slight improvement in validation loss across values of p, [...] private channel scaling is not mandatory to achieve sufficient accuracy results"，并在页码 9 补充"Disabling it provides an additional 1–2% speedup, with only minor accuracy degradation (see Appendix E.3)"。本图即为 Appendix E.3 中承诺的消融图，用于验证"私有通道缩放是次要改进项、非必需设计"这一**效果（次要）/鲁棒性**主张。`[正文支持]`
   - **图表角色**：消融验证。
   - **上文呼应**：第 4 节"Private channel scaling"段落（页码 7）+ 第 5.2 节末尾对 Appendix E.3 的引用（页码 9）；对应主张地图中"Private channel scaling 带来轻微改善但非必需"一条。

2. **图像类型与布局**：单面板折线图（非多 Panel 组合）。两条曲线：红色圆点标记为 "Private Channel Scaling"（启用缩放），蓝色方块标记为 "No Private Channel Scaling"（未启用缩放），无其他分组或子图。

3. **如何阅读**：横轴为同步因子 $p$（0.0–1.0），纵轴为 Loss（验证损失，越低越好，范围 1.85–2.10）。应比较同一 $p$ 值下红、蓝两条曲线的高度差，以及整体趋势随 $p$ 变化的形状。图例已标明两条线对应的实验组（有/无私有通道缩放）。

4. **直接可见的结论**：两条曲线形状高度相似，均呈现"$p$ 极低时损失很高（约 2.10）→ 随 $p$ 增大迅速下降 → 在 $p\approx0.5$–$0.75$ 附近取得或接近最低点（约 1.87–1.88）→ $p\to1$ 时略有回升（约 1.89–1.90）"的整体趋势。在 $p$ 极小处（约 0.03）两曲线看似重合为一条线；从 $p\approx0.12$ 起两曲线分开，红色（启用缩放）在几乎所有可见 $p$ 值上均等于或略低于蓝色（未启用缩放），但两者差距很小（视觉上不超过约 0.02–0.05 个损失单位），且随 $p$ 增大差距进一步收窄，在 $p$ 接近 1 时两线几乎重合。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图的可见差距（红色持续小幅低于蓝色，但差距很小、且在高 $p$ 时几乎消失）直接支持正文"效果（次要）"类主张——私有通道方差缩放能带来**轻微**验证损失改善，但**并非必需**，因为两条曲线的整体趋势和最优 $p$ 区间基本一致，未缩放模型仍能达到"足够的准确率结果" `[正文支持]`。这为方法设计提供依据：读者可据此理解为何作者在正式大规模训练（第 5.1、5.2 节）中默认启用缩放（因其确有微小收益且无害），但也允许工程上为换取 1–2% 训练速度提升而禁用它（页码 9）。该图**不能**证明的是：缩放对更大规模模型（1.1B、7B）或不同张量并行维度是否同样"轻微"；图中也未标注具体张量并行维度，因此该结论的适用范围严格限定于图注所述的 130M 模型。

6. **适用范围与证据缺口**：本图覆盖的实验设置为 130M 参数（LLaMA 架构）模型在 RedPajama 数据集上、跨一系列 $p$ 值（约 0.03–1.0）的验证损失对比，衡量"是否启用私有通道方差缩放"这一单一自变量的影响；这与正文"Ablation studies for private channel scaling are available at Appendix E.3"的表述一致。真实缺口：图注（"on a 130M model"）与正文均未说明该消融实验对应的张量并行维度（第 5.1 节其他 130M 消融曾同时报告不同 TP 维度，但本图未标注），故无法确认该结论是否对不同 TP 维度都成立——"文中未说明"；此外坐标轴刻度较粗（0.05 为最小可读间隔），无法从图中读出与正文"1–2% 速度提升，伴随轻微准确率下降"相对应的精确损失数值，只能确认差距方向和大致量级。
