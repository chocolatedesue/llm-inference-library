# OCR 第 1 页

# Tensor-Parallelism with Partially Synchronized Activations

Itay Lamprecht $ ^{\dagger\ddagger} $ Asaf Karnieli $ ^{\dagger} $ Yair Hanani $ ^{\dagger} $ Niv Giladi $ ^{\circ} $* Daniel Soudry $ ^{\ddagger} $

 $ ^{\dagger} $Intel, Israel

 $ ^{\ddagger} $Department of Electrical and Computer Engineering - Technion, Haifa, Israel

 $ ^{\circ} $AWS AI Labs

{itay.lamprecht, yair.hanani}@intel.com

{ngiladi}@amazon.com

{asafkarnieli, daniel.soudry}@gmail.com

## Abstract

Training and inference of Large Language Models (LLMs) with tensor-parallelism requires substantial communication to synchronize activations. Our findings suggest that with a few minor adjustments to current practices, LLMs can be trained without fully synchronizing activations, reducing bandwidth demands. We name this “Communication-Aware Architecture for Tensor-parallelism” (CAAT-Net). We train a 7B parameter CAAT-Net model and show that tensor-parallel communication can be reduced by up to 50% with no significant drop in pretraining accuracy across nearly all evaluated benchmarks. We also experiment with smaller 130M and 1.1B models to show the robustness and scalability of our method. We find that, in some scenarios, validation loss can even improve when reducing communication. Finally, we demonstrate how CAAT-Net accelerates both training and inference workloads across various settings and model sizes.

## 1 Introduction

As Large Language Model (LLM) training continues to scale, often requiring the use of hundreds or even thousands of devices, the need for efficient distributed training and inference techniques is constantly growing. Tensor-parallelism [1] is a critical component in the training of many well-known LLMs, such as GPT-3 [2], Llama [3, 4], and BLOOM [5], enabling the efficient utilization of hardware resources to support models with billions of parameters. By partitioning weight tensors across multiple devices, tensor-parallelism allows each device to store only a fraction of the model's weights during computation. This significantly reduces the memory footprint per device, making it feasible to train extremely large models on hardware with limited memory capacity. The efficiency of tensor-parallelism in reducing training memory has made it a cornerstone technique for distributed training. During inference, where the LLM response time is critical, distributing the computation over multiple devices using tensor-parallelism can significantly reduce latency.

Much of the total time spent training or using LLMs is consumed by the communication overhead inherent in tensor-parallelism, which arises from the need to synchronize activation or gradient tensors. Specifically, synchronization is done by all-reduce operations, where tensors from all devices are summed into a single tensor, which is copied to all devices. This operation occurs multiple times in each forward and backward pass and constitutes a substantial fraction of the total workload time.

A recent approach to addressing this issue is pipelining communication and computation [6] in such a way that the communication is overlapped with the computation and the footprint of communication

---

# OCR 第 2 页

is reduced. However, this approach is limited: when tensor-parallelism is expanded to use more devices, the compute workload per device decreases, while communication payload per device remains relatively constant [7]. This means that the relative cost of communication grows as the compute-to-communication ratio decreases. In extreme cases, communication time can overcome computation time, and thus dominate the training process. For these reasons, even the largest language models are typically trained with a tensor-parallelism dimension of 8 [4], utilizing fast intra-node communication for the heavy all-reduce operations.

Improving tensor-parallelism efficiency is even more important given that the growth in compute power exceeds the growth in communication bandwidth [7]. This trend should further expose communication time in large-scale training. Minimizing tensor-parallelism communication can enable better hardware compute utilization and reduce overall training costs, especially when extending tensor-parallelism across nodes. This is in line with the recent trend of building multi-node systems with high bandwidth communication.

In traditional tensor-parallelism, the activation tensors after communication are identical on all devices, i.e., fully synchronized. In this work, we show that LLM training can converge without fully synchronizing the activation tensors in the all-reduce operation. This means that we allow activations to vary on different devices after communication. We show that without full synchronization, the current training practice needs to be slightly adjusted. Failing to do so leads to critical issues such as a mismatch between forward and backward passes and numerical issues, which often result in training divergence. Relying on this insight, we suggest the partial channel-reduce operation, in which only a subset of the channels in the hidden dimension of the activation tensors is reduced. Unlike regular all-reduce, activations are not identical on all devices after the partial channel-reduce operation. In the extreme case where no channels are synchronized in partial channel-reduce, the model resembles an ensemble, communicating only to compute the loss function and embeddings. In the case where all channels are reduced, the model is a vanilla transformer model. We introduce Communication-Aware Architecture for Tensor-parallelism (CAAT-Net) — a new model architecture that is tailored for tensor-parallelism by utilizing partial channel-reduce to decrease communication overhead. While CAAT-Net has a smaller communication overhead compared to an identical model with full all-reduce, the number of parameters and total compute stay the same.

We train a Llama2-7B model [8] with partial channel-reduce over 160B tokens and show that there is no significant degradation in nearly all evaluation benchmarks we tested, while reducing the communication payload by 50%. Furthermore, we train multiple variants of the 1.1B parameter TinyLlama model [9] and a smaller 130M parameter model. We study the effects of the number of synchronized channels and tensor-parallel dimension on accuracy. We find that a gradually reducing communication from full synchronization first yields a slight improvement in validation loss, but performance worsens when communication becomes too limited. Reducing the communication by 50% achieves either similar or slightly better validation loss for all models we tested. Finally, we show the training and inference speedup of our proposed method in various settings.

In summary, our contributions in this paper are as follows:

- We show that when using tensor-parallelism, LLMs can be trained without fully synchronizing activation tensors.

- We propose CAAT-Net, a novel architecture that significantly decreases communication traffic in training with tensor-parallelism by synchronizing only part of the activation tensors.

- We show that in various settings, CAAT-Net accelerates both training and inference, and achieves accuracy largely on par with fully synchronized training.

## 2 Related Work

The challenge of efficient training and inference on a large scale has attracted much attention, both in the engineering and research fronts, in close correspondence with each other. While most of the literature focuses on reducing data-parallel communication, there have been a few works that focus on tensor-parallelism. Our approach is orthogonal to all methods covered in this section.

Pipelining computation and communication. Some methods accelerate training with tensor-parallelism by overlapping communication and computation, [6, 10–12]. In Domino DeepSpeed, the training batch is split into smaller pieces, and data dependency is broken such that communication

---

# OCR 第 3 页

is not on the critical path and can be overlapped with computation. Alternatively, Ladder Residual pipelines communication and computation by changing the transformer architecture, such that each layer uses an earlier version of the input from two layers back. This allows it to compute while the previous layer's results are still being communicated. While these approaches achieve speedup in inference and training, they are limited — there are many cases in which the compute time is not sufficient to fully hide tensor-parallel communication. For example, with a growing tensor-parallel dimension, the computation per device is reduced while the communication is not, so overlapping efficiency is reduced as well. Furthermore, other parallelism types interfere with tensor-parallel related communication. One of many examples is context-parallelism, where communication time alone can exceed compute time [13]. When adding tensor-parallelism after attention blocks that use context-parallelism, there is no compute left to pipeline both types of communication. For this reason we view our method, which reduces the total tensor-parallel communication, as complementary to pipelining methods.

Additionally, in NVIDIA GPUs such as H100/H200, pipelining communication and computation comes with a cost — the Stream Multiprocessors (SM), which perform the computation, are also needed for communication. When pipelining communication and computation, some SM cycles are spent on communication-related tasks instead of computation. Furthermore, while pipelining computation and communication can accelerate training and inference, our method reduces total communication, and can potentially improve other aspects such as power consumption.

Compressed communication. Another approach is to address the communication overhead by compressing the communication itself at the tensor-parallel or pipeline-parallel stages [14, 15]. This can be done using various methods, such as auto-encoders or sending the Top-K elements of the tensors. While compression succeeded in other aspects of optimization, it has yet been demonstrated that compression works for tensor-parallels, to the best of our knowledge. In fact, we observed severe degradation in model accuracy with even minimal compression using Top-K or random masking to compress activations (our observations can be found in Section 5.3). Additionally, compression introduces additional computation overhead which can reduce the speedup achieved by reducing communication. Our method differs from these methods because it does not compress activations. Although not all activations are shared between devices, those that are not shared are still used.

Asynchronous optimization. A different approach, mainly focused on mitigating overhead introduced by data-parallel communication, introduces asynchronism to the optimization by not waiting for all communication or straggling devices. In this case, different devices store all of the model weights, but each device can hold a slightly different copy. Asynchronous training is inherently more scalable than synchronous training by being robust to all kinds of worker and communication faults. However, this scalability comes with a price: convergence difficulties and generalization deterioration [16]. In contrast, when training with tensor-parallelism, each device stores a different subset of the model weights. Therefore, while we do not completely synchronize activations, we do not encounter the problem of multiple workers storing a different copy of the same weight, and training remains synchronous.

Post-training techniques. There have been many attempts to reduce tensor-parallel communication using post-training techniques, such as quantization [17, 18], and selectively removing complete communication points after the attention operation [19]. While these techniques are promising, they are relevant only for decreasing the communication bottleneck during inference.

## 3 CAAT-Net

To reduce communication bandwidth in LLM training and inference, we replace the all-reduce operation, designed to synchronize activations between devices, with a partial channel–reduce operation, such that only a subset of the channels in the hidden dimension is synchronized between devices. In partial channel–reduce, channels that are sent to other devices are referred to as shared channels, while those that are unique per device are private channels. The shared channels are chosen at initialization to be the first  $ h \cdot p $ channels, where h is the hidden dimension size and p is a synchronization factor controlling how much of the hidden dimension is synchronized. For p = 1 the partial channel–reduce turns into a full all-reduce operation (no private channels). The operation is visualized in Figure 2 (c). In this section we present a novel communication-aware model architecture

---

# OCR 第 4 页

which utilizes partial channel-reduce to accelerate LLM training and inference. A theoretical speedup analysis of our method is available in Appendix C.

<div style="text-align: center;"><img src="assets/imgs/img_in_image_box_213_262_1011_576.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Figure 1: CAAT-Net model architecture. Left. We exemplify our approach on a two-layer fully-connected neural network on a single device. Middle. When using tensor-parallelism with two devices, the input activation X is identical on both devices. Each device uses its own set of weights to multiply the inputs, yielding intermediate activations, which are then reduced into identical copies of Z on both devices. Right. CAAT-Net receives different input activations,  $ X_{1} $ and  $ X_{2} $, for Device 1 and Device 2, respectively. These yield intermediate activations that are partially synced between the devices, producing  $ Z_{1} $ and  $ Z_{2} $ on Device 1 and Device 2, respectively. Private channels are marked P, and shared channels are marked S.</div>


### 3.1 Architecture

While changing the communication primitive from all-reduce to partial channel—reduce seems like a minor change, it effectively changes the model architecture. Partial channel—reduce fundamentally alters the model's computation graph and information flow. This distinguishes CAAT-Net from communication optimizations like pipelining or compression, which preserve or approximate the underlying mathematical operations. Consequently, the Multi Layer Perceptron (MLP) and attention layers must be defined differently when taking partial channel—reduction into account. In this section we define the MLP using partial channel—reduce. The definition of the attention operation is described in Appendix A.1.

Standard all-reduce in MLP. Before mathematically describing the MLP using partial channel–reduce, we describe the MLP using regular all-reduce in a tensor-parallel setting. For simplicity, we examine a case where the tensor-parallel dimension is 2. For the general case, refer to Appendix A.2. Given consecutive MLP weight matrices A and B, input tensor X and an activation function  $ \sigma $, the output of the MLP layer Z is given by

 $$ Y=\sigma(XA)\quad;\quad Z=YB $$ 

where Y is the output of the first MLP layer. The basic architecture of a transformer MLP is visualized in Figure 1 (left). When using tensor-parallelism, we partition A along its columns, i.e.,

 $$ A=\left[A_{1},A_{2}\right] $$ 

so the computation of Y, is

 $$ Y_{1}=\sigma\left(X A_{1}\right)\quad;\quad Y_{2}=\sigma\left(X A_{2}\right)\quad;\quad Y=\left[Y_{1},Y_{2}\right]. $$ 

We partition B along its rows, i.e.

 $$ \boldsymbol{B}=\begin{bmatrix}B_{1}\\ B_{2}\end{bmatrix} $$

---

# OCR 第 5 页

and, after an all-reduce, the output of the MLP is

 $$ Z=Y_{1}B_{1}+Y_{2}B_{2}, $$ 

where  $ Y_{1}B_{1} $ is computed on the first device and  $ Y_{2}B_{2} $ is computed on the second. The implementation of all-reduce with tensor-parallelism is visualized in Figure 1 (middle).

Partial channel-reduce in MLP. We first note that with partial channel-reduce, the input to the MLP will be different per device (as the previous attention layer will also use partial channel-reduce in its output). Therefore, the inputs to each device are denoted  $ X_1 $ and  $ X_2 $, as is shown in Figure 1 (right). Thus, the output of the first linear layer when using partial channel-reduce is:

 $$ Y_{1}=\sigma\left(X_{1}A_{1}\right)\quad;\quad Y_{2}=\sigma\left(X_{2}A_{2}\right)\quad;\quad Y=\left[Y_{1},\;Y_{2}\right]\;. $$ 

Next, we need to partition B along both its columns and rows

 $$ \boldsymbol{B}=\begin{bmatrix}B_{11}B_{21}\\ B_{12}B_{22}\end{bmatrix}. $$ 

Then, the outputs of the MLP with partial channel-reduce, denoted  $ Z_{1} $ and  $ Z_{2} $, are different per device and are calculated by

 $$ Z_{1}=\left[Y_{1}B_{11}+Y_{2}B_{12},Y_{1}B_{21}\right]\quad;\quad Z_{2}=\left[Y_{1}B_{11}+Y_{2}B_{12},Y_{2}B_{22}\right], $$ 

where  $ B_{11} $ and  $ B_{21} $ are on the first device, and  $ B_{12} $ and  $ B_{22} $ are on the second device. The values in  $ Y_{1}B_{11} + Y_{2}B_{12} $ are in the shared channels, and  $ Y_{1}B_{21} $ and  $ Y_{2}B_{22} $ are both in the private channels, which are visualized in Figures 1 and 2.

### 3.2 CAAT-Net Inference

Models trained with CAAT-Net use partial channel-reduce in inference as well. This leads to communication reduction and speedup when serving models, as we show in Section 5.2.

If the model is served with the same tensor-parallel dimension that it is trained with, serving the model is straightforward. This is different when using the model in inference with tensor-parallel dimension different than in training. As an example, we examine a scenario where the model is trained with a tensor-parallel dimension of 2, and inference is performed with a single device. In training, the output of a transformer layer is different on each device. In inference, one device needs to handle both of these copies. This can be done using 'logical devices'. In this case, a single physical device can simulate multiple tensor-parallel ranks, and sequentially calculate the output of each layer for every 'logical' tensor-parallel device. Furthermore, the partial channel-reduce is replaced with local summation inside the single device. It is also possible to return to a full all-reduce operation during inference through fine tuning, to increase the value of p to 1. Then, a regular transformer architecture is achieved, and inference can be run on any tensor-parallel dimension.

## 4 Partial Synchronization: Implementation

To train LLMs without full synchronization of activation tensors, there are two main adjustments that must be done to current training frameworks [1]. The first is an adjustment to the backward implementation of tensor-parallelism, which is necessary to avoid forward-backward mismatch in training. The second is accumulating tensors in 32 bit (fp32) in the all-reduce of the backward pass. We find empirically that this is necessary to avoid numerical issues in training.

Forward-backward mismatch. To train LLMs with partial activation synchronization, we need to further examine the backward pass of a transformer model. In traditional LLM training, the all-reduce operation in the backward pass is done on the neural gradients produced by an MLP or attention layer, as shown in Figure 2a. Explicitly calculating the gradients propagated through the network, we find that the all-reduce operation can be applied in multiple locations in the backward pass without altering the backpropagation algorithm. We also find that in the case of partially synchronized activations, the reduction operation can only be applied in one place. To show this analytically we examine the input to an MLP layer on device $m$, denoted $X_{m}$, as a function of the output of a previous attention layer

---

# OCR 第 6 页

<div style="text-align: center;"><img src="assets/imgs/img_in_image_box_216_149_1000_584.jpg" alt="Image" width="64%" /></div>


<div style="text-align: center;">Figure 2: Partial synchronization and partial channel-reduce. (a) Vanilla transformers in current training frameworks. The operation f is an all-reduce in the forward pass and identity in the backward pass. The operation g is an all-reduce in the backward pass and identity in the forward pass. (b) With partial synchronization, h denotes the reduction operation in both the forward and the backward pass, since both must be done at the same location. Synchronization of the normalization function parameters is necessary. (c) Partial channel-reduce with parameter p over 2 devices.</div>


on device m before the all-reduce operation, denoted  $ Z_{m} $, with R being the residual connection, we have

 $$ X_{m}=\mathrm{N o r m}\left(\sum_{m}Z_{m}+R\right), $$ 

where Norm can be any normalization function (typically LayerNorm [20] or RMSNorm [21]). We examine the loss  $ \mathcal{L} $ as a function of  $ X_m $ for all m, and  $ X_m $ as a function of  $ Z_1 $, and calculate the derivative of the loss function w.r.t  $ Z_1 $. For simplicity, we ignore below the residual connections (in Appendix B we show the derivation including the residual). Using the chain rule:

 $$ \frac{\partial\mathcal{L}\left(X_{1}\left(Z_{1}\right),...,X_{M}\left(Z_{1}\right)\right)}{\partial Z_{1}}=\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X_{m}\left(Z_{1}\right)}{\partial Z_{1}}\right)=\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X}{\partial Z_{1}}\right). $$ 

In the second equation, we recalled that  $ \frac{\partial X_m}{\partial Z_1} $ are equal for all  $ m $ (denoted now as  $ \frac{\partial X}{\partial Z_1} $) because in tensor-parallelism with full all-reduce operations  $ X_1(Z_1) = X_2(Z_1) = \ldots = X_M(Z_1) $, and thus their derivative w.r.t.  $ Z_1 $ are also equal. Here, the summation over  $ m $ is the all-reduce operation in the backward pass. Our key insight here is that, since the matrix multiplication distributes over addition, i.e.

 $$ \sum_{m}\left(\frac{\partial\mathcal{L}(X_{m})}{\partial X_{m}}\cdot\frac{\partial X}{\partial Z_{1}}\right)=\sum_{m}\left(\frac{\partial\mathcal{L}(X_{m})}{\partial X_{m}}\right)\cdot\frac{\partial X}{\partial Z_{1}}, $$ 

the all-reduce operation can be used before back-propagating through the normalization function (right side of the equation), or after the normalization function (left side of the equation). In standard training frameworks, such as Megatron-LM, the all-reduce operation is used before back-propagation through the normalization function (i.e., the ‘g’ operation in Figure 2a). When training with partial synchronization, the assumption that  $ \frac{\partial X_m}{\partial Z_m} $ are equal for all m no longer holds. For this reason, the all-reduce operation in the backward pass must occur after the calculation of the normalization function derivative (i.e., the ‘h’ operation in Figure 2b) so it would match the location of the summation in the forward pass (i.e., the ‘f’ operation in Figure 2a), to get the correct gradients.

---

# OCR 第 7 页

Similarly, we examine the normalization function parameter update, denoted  $ \beta $, with a full all-reduce operation:

 $$ \frac{\partial\mathcal{L}\left(X_{1}\left(\beta\right),...,X_{M}\left(\beta\right)\right)}{\partial\beta}=\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X_{m}}{\partial\beta}\right). $$ 

In the gradient descent step, after each iteration, before updating the weights, the updates  $ \frac{\partial \mathcal{L}}{\partial \beta} $ need to be synchronized with an all-reduce operation. In popular training frameworks, the fact that  $ \frac{\partial X_m}{\partial \beta} $ is identical for all  $ m $ devices is used once again. There is no need for gradient synchronization after each step, if the all-reduce happens before backpropagating through the normalization function:

 $$ \sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\right)\cdot\frac{\partial X}{\partial\beta}, $$ 

where, again,  $ \frac{\partial X_m}{\partial \beta} $ are equal for all  $ m $ (denoted as  $ \frac{\partial X}{\partial \beta} $). To summarize, when using full all-reduce, the following are equivalent:

• Reduce the neural gradients before they backpropagate through the normalization function.

- Reduce the gradients after they backpropagate through the normalization function, and reduce normalization function parameters before the weight update.

However, when training with partial synchronization, such as partial channel-reduce, only the second approach is possible. Our altered backward implementation is detailed in Figure 2b. It is important to note that the number of normalization function parameters per layer is typically  $ \Theta(h) $, where h is the hidden size, and the synchronization of normalization function parameters happens after every step. For these reasons, the additional communication of normalization function parameters is negligible in comparison to the tensor-parallel all-reduce operation.

Numerical stability via 32 bit gradient accumulation. In the previous section we presented two different implementations of the backward pass. If we fully synchronize activations in the forward pass, these implementations are mathematically identical. Despite this equivalence, we found in our experiments that there can still be a large gap in training convergence when using our alternative implementation, even when activations are fully synchronized. This gap arises due to numerical differences between the implementations, and it can be completely mitigated by accumulating the reduced gradients in 32 bit precision instead of 16 bit precision. While LLMs are conventionally trained in 16 bit precision, there are some operations where 32 bit precision is critical, such as in the accumulation in matrix multiplication operations, or normalization layers. While the tensor-parallel gradient all-reduce is typically not one of these operations, we find that when moving the all-reduce in the backward pass, 32 bit accumulation is crucial. It is important to note that while accumulation needs to be done in 32 bit precision, the communication itself can be done in 16 bit precision, and values are simply upcast after communication and before accumulation. Loss curves comparing our training experiments with all-reduce accumulation in fp32 and bfloat16 are available in Appendix E.1.

Private channel scaling. Partial channel-reduce leads to differences in the statistics of shared and private channels, which affects signal propagation in the network. Consider the case of partial channel-reduce with 2 tensor-parallel devices. Assuming each element in the MLP outputs before reduction ( $ Y_1B_{11} $,  $ Y_2B_{12} $,  $ Y_1B_{21} $) has zero mean and variance  $ \sigma_A^2 $, and are independent between devices. The activation variance for shared channels is

 $$ \mathrm{Var}(Y_{1}B_{11}+Y_{2}B_{12})=\mathrm{Var}(Y_{1}B_{11})+\mathrm{Var}(Y_{2}B_{12})=2\sigma_{A}^{2}, $$ 

and for private channels is:

 $$  Var(Y_{1}B_{21})=\sigma_{A}^{2} $$ 

This variance mismatch can lead to uneven signals across channels in both the activation and gradient calculations. To correct this mismatch, we multiply the activations in the private channels by a corrective factor of  $ \sqrt{2} $ (or  $ \sqrt{r} $ if we train with a tensor-parallel dimension of r). This way, after the partial channel-reduce, the activations have identical variances over all channels. Ablation studies for private channel scaling are available at Appendix E.3. While we find a slight improvement in validation loss across values of p, private channel scaling is not mandatory to achieve sufficient accuracy results.

---

# OCR 第 8 页

<div style="text-align: center;">Table 1: CAAT-Net vs baseline: Zero-shot accuracy after pretraining. 7B parameter models, with $p = 0.5$ and tensor-parallel 8.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Model</td><td style='text-align: center; word-wrap: break-word;'>LAMBADA (acc)</td><td style='text-align: center; word-wrap: break-word;'>Hellaswag (acc)</td><td style='text-align: center; word-wrap: break-word;'>WinoGrande (acc)</td><td style='text-align: center; word-wrap: break-word;'>PIQA (acc)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>$ 61.34 \pm 0.68 $</td><td style='text-align: center; word-wrap: break-word;'>$ 45.85 \pm 0.50 $</td><td style='text-align: center; word-wrap: break-word;'>$ 61.48 \pm 1.37 $</td><td style='text-align: center; word-wrap: break-word;'>$ 72.91 \pm 1.06 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>CAAT-Net</td><td style='text-align: center; word-wrap: break-word;'>$ 61.05 \pm 0.68 $</td><td style='text-align: center; word-wrap: break-word;'>$ 46.10 \pm 0.50 $</td><td style='text-align: center; word-wrap: break-word;'>$ 62.19 \pm 1.36 $</td><td style='text-align: center; word-wrap: break-word;'>$ 72.86 \pm 1.04 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>OpenBookQA (acc)</td><td style='text-align: center; word-wrap: break-word;'>BOOL-Q (acc)</td><td style='text-align: center; word-wrap: break-word;'>WikiText (ppl)</td><td style='text-align: center; word-wrap: break-word;'>Validation Loss</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>$ 26.60 \pm 1.98 $</td><td style='text-align: center; word-wrap: break-word;'>$ 64.89 \pm 0.83 $</td><td style='text-align: center; word-wrap: break-word;'>12.51</td><td style='text-align: center; word-wrap: break-word;'>1.01</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>CAAT-Net</td><td style='text-align: center; word-wrap: break-word;'>$ 24.00 \pm 1.87 $</td><td style='text-align: center; word-wrap: break-word;'>$ 62.51 \pm 0.85 $</td><td style='text-align: center; word-wrap: break-word;'>12.46</td><td style='text-align: center; word-wrap: break-word;'>1.00</td></tr></table>

## 5 Experiments

Experiments were conducted with Intel Gaudi3 HPU accelerators. Gaudi3 has 128GB on-board memory. Each device has 525 GB/s intra-node connection and 75 GB/s inter-node connection.

### 5.1 Large Scale Training

We trained a variation of Llama2-7b [8] with partial channel-reduce. Training was conducted from scratch over 160B tokens from the RedPajama dataset, spanning 8 nodes, each containing 8 accelerators. We chose a partial channel-reduce hyperparameter of p = 0.5 and a tensor-parallel dimension of 8, with all other hyperparameters identical to those used in training of the original model. We choose these values of p and tensor-parallel dimension as an example which we expected, based on our ablation studies, to yield good accuracy results, while significantly reducing network bandwidth.

We evaluate the model's performance on a diverse set of common sense tasks selected from the Language Model Evaluation Harness framework [22]. The chosen benchmarks include tasks such as HellaSwag [23], WikiText103 [24], LAMBADA [25], WinoGrande [26], PIQA [27], OpenBookQA [28] and BoolQ [29]. The zero-shot results are available in Table 1. All accuracy results are not statistically significant, except for Bool-Q, which is marginally significant (p-value = 0.046 using Welch's t-test).

To further study the scalability and robustness of our method, we train 130M and 1.1B models in multiple settings. The 1.1B model used is TinyLlama [9], and is trained over 100B tokens. The 130M parameter model is a small custom model based on the LLaMA architecture. It has 16 attention heads and a hidden dimension size of 768. It was trained with an initial learning rate of  $ 6 \cdot 10^{-4} $, with the AdamW optimizer. The training was performed with a global batch size of 256 and a sequence length of 1024. The architecture consists of 12 transformer layers with multi-head attention. It is trained over 7.8B tokens. Both models are trained on the RedPajama dataset, using the GPTSentencePiece tokenizer.

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_216_1052_611_1265.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_614_1051_1005_1264.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">Figure 3: Training accuracy in multiple scenarios. Left. Validation loss of 130M and 1.1B models for different values of $p$, and of the 7B model with $p = 0.5$, normalized to the loss at $p = 1$. Right. Validation loss for the 130M model with varying values of $p$ and tensor-parallel dimension (TP).</div>


We train both models with varying values of $p$, with tensor-parallel dimension of 8. Results are available in Figure 3 (left). We find that for large values of $p$ (over 0.75), the 130M and 1.1B models behave similarly. For intermediate values of $p$ (between 0.75 and 0.25), the smaller 130M model

---

# OCR 第 9 页

has a slight improvement in validation loss compared to the baseline, while the 1.1B model is close to or slightly above the baseline. For smaller values of $p$, there is degradation for both models. Furthermore, we added the 7B model we trained with $p = 0.5$, which shows a slight improvement w.r.t the baseline, showing potential in further scaling our method. Zero-shot accuracy for all 1.1B experiments is available in Appendix E.2.

We also study the effects of tensor-parallel dimension on the 130M model. Results are available in Figure 3 (right). For all tensor-parallel dimensions, gradually decreasing p from 1 initially leads to a slight improvement in validation loss, but performance deteriorates once p becomes too low. As the tensor-parallel dimension increases, this degradation begins at a higher value of p. For all tensor-parallel dimensions, p = 0.5 does not degrade or improves validation loss.

Finally, we train an additional model, other than the models from the Llama architecture, to show the robustness of our method. Specifically, we trained GPT3-XL [2] with tensor-parallel 8 and p = 0.5, on the RedPajama dataset using the GPTSentencePiece tokenizer, rotary positional embeddings and with a global batch size of 512. We trained for a total of 50B tokens. Similarly to results on Llama, we find that CAAT-Net maintains accuracy results. The full results are available in Appendix E.2.

### 5.2 Speedup

We examine Llama2-7b with partial channel-reduce to measure inference and training speedup. In this section we show relative speedup (i.e., speedup compared to the baseline). For absolute measurements, see Appendix E.5. Furthermore, for inference, we experiment with larger models (34B and 70B) and achieve similar results to those reported in this section. Full results for these models are available in Appendix E.4.

Inference. To measure inference speedup, we report the Time-to-First-Token (TTFT) for varying batch sizes, using a prompt length of 2K tokens. We use partial channel-reduce with tensor-parallel 8 and 16. We compare results against the baseline, which is Intel's Optimum-Habana without any of our adjustments. The results are shown in Figure 4 (bottom). For tensor-parallel 16 and p = 0.25 we measure a maximum speedup of 26% with batch size 32. In the large scale training setting of p = 0.5 and tensor-parallel 8, which we show does not degrade accuracy, we obtain a maximum speedup of 14% for batch size 32.

Furthermore, to show that accelerating workloads using CAAT-Net is not specific to Intel Gaudi hardware, we conduct experiments on NVIDIA hardware. Our experiments were done using the gpt-fast repository, and consisted of replacing all-reduce with partial channel-reduce during inference. We conducted experiments on 8 NVIDIA H100-80GB-HBM3, and 8 NVIDIA A100-SXM4-80GB, both with NVLink. Results are shown in Figure 4 (top right). We find that our method speeds up inference TTFT by up to 13% on NVIDIA hardware with p = 0.25 and tensor-parallel dimension 8. Speedup on Gaudi is more significant in our experiments, but we believe further software performance optimizations on NVIDIA hardware can bridge this gap. Full measurements, including for additional batch sizes, are available in Appendix E.6.

Alongside accuracy considerations, practitioners should consider hardware constraints when selecting $p$. For example, on Gaudi3, speedup results were more significant when selecting $p$ such that the communication volume is a multiple of the communication buffer size. Specifically, when experimenting with Llama2-7B with batch size 16, we identified that the optimal performance speedup is achieved with a value of $p$ which is a multiple of $2^{-7}$ (i.e., the number of channels reduced is a multiple of 16). As a result, selecting $p = 0.703125$, which is equal to $90 \cdot 2^{-7}$, achieves better speedup than $p = 0.7$.

Training. To measure training throughput speedup, we report the tokens per second (TPS), for tensor-parallel dimensions 4, 8, and 16, with varying values of p. Tensor-parallel 4 experiments were conducted with a micro-batch size of 4, while tensor-parallel 8 and 16 experiments were conducted with a micro-batch size of 8. The results are shown in Figure 4 (top left). We compare results against the baseline, which is Intel's Megatron-LM fork without any of our adjustments. For training in tensor-parallel 16, our method can improve throughput by up to 14% when selecting p = 0.25 and by 9% when selecting p = 0.5.

All experiments were conducted using private channel scaling, as described in Section 4. Disabling it provides an additional 1–2% speedup, with only minor accuracy degradation (see Appendix E.3), making training without private channel scaling a reasonable alternative. It is important to note that

---

# OCR 第 10 页

in training speedup experiments, for all values of p and the baseline, accumulation in the backward pass was done in 16-bit precision due to technical implementation limitations. For this reason, the training throughput results in this section should be seen as a performance projection. We do not expect accumulation in fp32, if communication is kept in 16-bit precision, to significantly affect the speedup reported in this section.

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_215_294_607_512.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_611_295_1007_511.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_214_522_609_737.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_610_523_1006_737.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;">Figure 4: Speedup in training and inference for a Llama 7B model. Top Left Training speedup for varying values of p and tensor-parallel dimension. Top Right. Inference Time-To-First-Token (TTFT) speedup on different hardware, using batch-size 128. Bottom Left. Inference TTFT speedup using tensor-parallel 8 as a function of batch size, for different values of p. Bottom Right. Inference TTFT speedup using tensor-parallel 16 as a function of batch size, for different values of p.</div>


### 5.3 Comparison to compression methods

To compare our method to compression methods, we use two alternative approaches for compressing activation communication. While CAAT-Net preserves low validation loss, we report severe degradation for both compression methods, even with minimal compression. The first method is reducing communication using a random mask. The values that are multiplied by 0 in the random mask are not communicated. This is effectively applying dropout before communication. The second method is using a Top-K mask, which selects the Top-K entries in each token of the activation tensor and discards the others. In both cases, we apply the mask in the forward pass before communication. To avoid a forward-backward mismatch,

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_629_976_1006_1180.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">Figure 5: Comparison to compression methods. Validation loss vs. p for 130M models using CAAT-Net, Top-k masking and random masking.</div>


the same mask is applied in the backward pass as well. Furthermore, the Top-K and random masks are less efficient in reducing communication than CAAT-Net. See Appendix D for details.

To be consistent with CAAT-Net experiments, we denote by p the probability that an activation is not zeroed (so if p = 1, applying the mask is equivalent to applying the identity function). We train the 130M parameter Llama model detailed in Section 5.1 for a total of 2.6B tokens. We experiment with different values of p, and report significant degradation for Top-K and random masks. Results are available in Figure 5.

---

# OCR 第 11 页

## 6 Conclusion

In this paper, we show that with minor changes to current training frameworks, activations do not need to be fully synchronized in tensor-parallel communication for training to converge. We propose CAAT-Net, which significantly decreases tensor-parallel related network traffic in LLM training with minor to no degradation in accuracy. We experiment with smaller networks to explore the effects of tensor-parallel dimension and the synchronization factor. Finally, we show how our method speeds up inference and training workloads.

## Acknowledgments and Disclosure of Funding

The research of DS was funded by the European Union (ERC, A-B-C-Deep, 101039436). Views and opinions expressed are however those of the author only and do not necessarily reflect those of the European Union or the European Research Council Executive Agency (ERCEA). Neither the European Union nor the granting authority can be held responsible for them. DS also acknowledges the support of the Schmidt Career Advancement Chair in AI.

## References

[1] Mohammad Shoeybi, Mostofa Patwary, Raul Puri, Patrick LeGresley, Jared Casper, and Bryan Catanzaro. Megatron-lm: Training multi-billion parameter language models using model parallelism, 2020. URL https://arxiv.org/abs/1909.08053.

[2] Tom B. Brown, Benjamin Mann, Nick Ryder, Melanie Subbiah, Jared Kaplan, Prafulla Dhariwal, Arvind Neelakantan, Pranav Shyam, Girish Sastry, Amanda Askell, et al. Language models are few-shot learners, 2020. URL https://arxiv.org/abs/2005.14165.

[3] Hugo Touvron, Thibaut Lavril, Gautier Izacard, Xavier Martinet, Marie-Anne Lachaux, Timothée Lacroix, Baptiste Rozière, Naman Goyal, Eric Hambro, Faisal Azhar, Aurelien Rodriguez, Armand Joulin, Edouard Grave, and Guillaume Lample. Llama: Open and efficient foundation language models, 2023. URL https://arxiv.org/abs/2302.13971.

[4] Abhimanyu Dubey, Abhinav Jauhri, Abhinav Pandey, Abhishek Kadian, Ahmad Al-Dahle, Aiesha Letman, Akhil Mathur, Alan Schelten, Amy Yang, Angela Fan, et al. The llama 3 herd of models, 2024. URL https://arxiv.org/abs/2407.21783.

[5] BigScience Workshop, :, Teven Le Scao, Angela Fan, Christopher Akiki, Ellie Pavlick, Suzana Ilić, Daniel Hesslow, Roman Castagné, Alexandra Sasha Luccioni, François Yvon, Matthias Gallé, et al. Bloom: A 176b-parameter open-access multilingual language model, 2023. URL https://arxiv.org/abs/2211.05100.

[6] Guanhua Wang, Chengming Zhang, Zheyu Shen, Ang Li, and Olatunji Ruwase. Domino: Eliminating communication in llm training via generic tensor slicing and overlapping, 2024. URL https://arxiv.org/abs/2409.15241.

[7] Suchita Pati, Shaizeen Aga, Mahzabeen Islam, Nuwan Jayasena, and Matthew D. Sinclair. Computation vs. communication scaling for future transformers on future hardware, 2023. URL https://arxiv.org/abs/2302.02825.

[8] Hugo Touvron, Louis Martin, Kevin Stone, Peter Albert, Amjad Almahairi, Yasmine Babaei, Nikolay Bashlykov, Soumya Batra, Prajjwal Bhargava, et al. Llama 2: Open foundation and fine-tuned chat models, 2023. URL https://arxiv.org/abs/2307.09288.

[9] Peiyuan Zhang, Guangtao Zeng, Tianduo Wang, and Wei Lu. Tinyllama: An open-source small language model, 2024. URL https://arxiv.org/abs/2401.02385.

[10] Abhinav Jangda, Jun Huang, Guodong Liu, Amir Hossein Nodehi Sabet, Saeed Maleki, Youshan Miao, Madanlal Musuvathi, Todd Mytkowicz, and Olli Sarikivi. Breaking the computation and communication abstraction barrier in distributed machine learning workloads, 2022. URL https://arxiv.org/abs/2105.05720.

---

# OCR 第 12 页

[11] Shengwei Li, Zhiquan Lai, Yanqi Hao, Weijie Liu, Keshi Ge, Xiaoge Deng, Dongsheng Li, and Kai Lu. Automated tensor model parallelism with overlapped communication for efficient foundation model training, 2023. URL https://arxiv.org/abs/2305.16121.

[12] Muru Zhang, Mayank Mishra, Zhongzhu Zhou, William Brandon, Jue Wang, Yoon Kim, Jonathan Ragan-Kelley, Shuaiwen Leon Song, Ben Athiaratkun, and Tri Dao. Ladder-residual: parallelism-aware architecture for accelerating large model inference with communication overlapping, 2025. URL https://arxiv.org/abs/2501.06589.

[13] Amy Yang, Jingyi Yang, Aya Ibrahim, Xinfeng Xie, Bangsheng Tang, Grigory Sizov, Jeremy Reizenstein, Jongsoo Park, and Jianyu Huang. Context parallelism for scalable million-token inference, 2025. URL https://arxiv.org/abs/2411.01783.

[14] Song Bian, Dacheng Li, Hongyi Wang, Eric P. Xing, and Shivaram Venkataraman. Does compressing activations help model parallel training?, 2023. URL https://arxiv.org/abs/2301.02654.

[15] M. I. Rudakov, A. N. Beznosikov, Ya. A. Kholodov, and A. V. Gasnikov. Activations and gradients compression for model-parallel training. Doklady Mathematics, 108(S2):S272–S281, December 2023. ISSN 1531-8362. doi: 10.1134/s1064562423701314. URL http://dx.doi.org/10.1134/S1064562423701314.

[16] Niv Giladi, Mor Shpigel Nacson, Elad Hoffer, and Daniel Soudry. At stability's edge: How to adjust hyperparameters to preserve minima selection in asynchronous training of neural networks?, 2020. URL https://arxiv.org/abs/1909.12340.

[17] Jan Hansen-Palmus, Michael Truong Le, Oliver Hausdörfer, and Alok Verma. Communication compression for tensor parallel llm inference, 2024. URL https://arxiv.org/abs/2411.09510.

[18] Qingyuan Li, Bo Zhang, Liang Ye, Yifan Zhang, Wei Wu, Yerui Sun, Lin Ma, and Yuchen Xie. Flash communication: Reducing tensor parallelization bottleneck for fast large language model inference, 2024. URL https://arxiv.org/abs/2412.04964.

[19] Han-Byul Kim, Duc Hoang, Arnav Kundu, Mohammad Samragh, and Minsik Cho. Spd: Sync-point drop for efficient tensor parallelism of large language models, 2025. URL https://arxiv.org/abs/2502.20727.

[20] Jimmy Lei Ba, Jamie Ryan Kiros, and Geoffrey E. Hinton. Layer normalization, 2016. URL https://arxiv.org/abs/1607.06450.

[21] Biao Zhang and Rico Sennrich. Root mean square layer normalization, 2019. URL https://arxiv.org/abs/1910.07467.

[22] Leo Gao, Jonathan Tow, Baber Abbasi, Stella Biderman, Sid Black, Anthony DiPofi, Charles Foster, Laurence Golding, Jeffrey Hsu, Alain Le Noac'h, Haonan Li, Kyle McDonell, Niklas Muennighoff, et al. A framework for few-shot language model evaluation, 12 2023. URL https://zenodo.org/records/10256836.

[23] Rowan Zellers, Ari Holtzman, Yonatan Bisk, Ali Farhadi, and Yejin Choi. Hellaswag: Can a machine really finish your sentence?, 2019. URL https://arxiv.org/abs/1905.07830.

[24] Stephen Merity, Caiming Xiong, James Bradbury, and Richard Socher. Pointer sentinel mixture models, 2016. URL https://arxiv.org/abs/1609.07843.

[25] Denis Paperno, Germán Kruszewski, Angeliki Lazaridou, Quan Ngoc Pham, Raffaella Bernardi, Sandro Pezzelle, Marco Baroni, Gemma Boleda, and Raquel Fernández. The lambada dataset: Word prediction requiring a broad discourse context, 2016. URL https://arxiv.org/abs/1606.06031.

[26] Keisuke Sakaguchi, Ronan Le Bras, Chandra Bhagavatula, and Yejin Choi. Winogrande: An adversarial winograd schema challenge at scale, 2019. URL https://arxiv.org/abs/1907.10641.

---

# OCR 第 13 页

[27] Yonatan Bisk, Rowan Zellers, Ronan Le Bras, Jianfeng Gao, and Yejin Choi. Piqa: Reasoning about physical commonsense in natural language, 2019. URL https://arxiv.org/abs/1911.11641.

[28] Todor Mihaylov, Peter Clark, Tushar Khot, and Ashish Sabharwal. Can a suit of armor conduct electricity? a new dataset for open book question answering, 2018. URL https://arxiv.org/abs/1809.02789.

[29] Christopher Clark, Kenton Lee, Ming-Wei Chang, Tom Kwiatkowski, Michael Collins, and Kristina Toutanova. Boolq: Exploring the surprising difficulty of natural yes/no questions, 2019. URL https://arxiv.org/abs/1905.10044.

---

# OCR 第 14 页

## A Mathematical Description of MLP and Attention Using Partial Channel-Reduce

### A.1 Attention

In this section, we describe an attention layer using partial channel-reduce. Like in section 3.1, we examine a case where the tensor-parallel dimension is 2. Furthermore, for simplicity, we assume the model consists of only 2 attention heads.

Standard all-reduce in Attention. Below, we describe the output of the attention layer with a full all-reduce. The attention head outputs,  $ H_{1} $ and  $ H_{2} $, for the first and second heads, respectively, are

 $$ H_{1}=\mathrm{Attention}\left(X W_{1}^{K},X W_{1}^{Q},X W_{1}^{V}\right)\quad;\quad H_{2}=\mathrm{Attention}\left(X W_{2}^{K},X W_{2}^{Q},X W_{2}^{V}\right). $$ 

In tensor-parallelism, the output projection of the attention layer O, is sharded between devices. The output Z after all-reduce is:

 $$ Y=\left[H_{1},H_{2}\right]\quad;\quad Z=Y O,\quad;\quad O=\begin{bmatrix}O_{1}\\ O_{2}\end{bmatrix}\quad;\quad Z=H_{1}O_{1}+H_{2}O_{2}, $$ 

where  $ H_{1}O_{1} $ is calculated on the first device and  $ H_{2}O_{2} $ is calculated on the second one.

Partial channel-reduce in Attention. As in the MLP case, when introducing partial channel-reduce, the input to the attention is not necessarily identical on each device. The inputs on each device are denoted  $ X_{1} $ and  $ X_{2} $:

 $$ \begin{aligned}&H_{1}=\mathrm{Attention}\left(X_{1}W_{1}^{K},X_{1}W_{1}^{Q},X_{1}W_{1}^{V}\right)\\&H_{2}=\mathrm{Attention}\left(X_{2}W_{2}^{K},X_{2}W_{2}^{Q},X_{2}W_{2}^{V}\right)\\ \end{aligned} $$ 

The outputs of the attention layer with partial channel-reduce are different per device, and are denoted  $ Z_{1} $ and  $ Z_{2} $:

 $$ \begin{aligned}Y=\left[H_{1},H_{2}\right].\quad;\quad O&=\begin{bmatrix}O_{11}&O_{21}\\O_{12}&O_{22}\end{bmatrix}\\Z_{1}=\left[H_{1}O_{11}+H_{2}O_{12},H_{1}O_{21}\right]\quad;\quad Z_{2}&=\left[H_{1}O_{11}+H_{2}O_{12},H_{2}O_{22}\right].\end{aligned} $$ 

### A.2 Partial channel-reduce with many devices

In this section, we relax the assumptions made in Section 3.1 and Appendix A.1, to allow more than 2 tensor-parallel devices.

MLP. An MLP operation in transformers with a full all-reduce operation can be described as follows. Given weight matrices  $ A \in \mathbb{R}^{h \times f} $ and  $ B \in \mathbb{R}^{f \times h} $, where  $ f $ is the Feed Forward Network (FFN) hidden dimension, and input activations  $ X \in \mathbb{R}^{b \times t \times h} $, the MLP can be written in index notation as:

 $$ Z_{i l}=\sum_{k}\sigma\left(\sum_{j}X_{i j}A_{j k}\right)B_{k l}, $$ 

where $t$ is the sequence length, $b$ is the batch size, and $\sigma$ is the nonlinearity. To introduce the partial channel–reduce operation, we first rewrite Eq. 20 in a notation that incorporates tensor-parallelism.

 $$ \begin{aligned}\tilde{Z}_{ilm}=\sum_{k}\sigma\left(\sum_{j}X_{ij}\tilde{A}_{jkm}\right)\tilde{B}_{klm}\\ Z_{il}=\sum_{m}\tilde{Z}_{ilm},\end{aligned} $$

---

# OCR 第 15 页

where  $ \tilde{A} $ is A written in column-parallel notation such that the last dimension corresponds to tensor-parallel rank, and similarly  $ \tilde{B} $ is B written in row-parallel notation. The summation over m is the all-reduce operation. Finally, we write the MLP with the partial channel-reduce operation as follows:

 $$ \begin{aligned}\tilde{Z}_{ilm}&=\sum_{k}\sigma\left(\sum_{j}X_{ijm}\tilde{A}_{jkm}\right)\tilde{B}_{klm}\\Z_{ilm}&=\begin{cases}\sum_{m}\tilde{Z}_{ilm}&\text{if}l<\text{floor}(hp)\\\tilde{Z}_{ilm}&\text{if}l\geq\text{floor}(hp)\end{cases}.\end{aligned} $$ 

Here, the summation over m is the partial channel-reduce operation. The main differences between Eq.21 and Eq.22 are:

• The sum over  $ \tilde{Z} $ is only over the first  $ p \cdot h $ channels of the hidden dimension.

- The input to the MLP is different per device when using partial channel–reduce, because the previous attention layer also used partial channel–reduce in its output. Thus, the input to MLP, X, has an additional index, m, corresponding to tensor-parallel device rank. Similarly, Z has an additional index, m, because each device contains different parameters in the private channels after the partial channel–reduce operation.

Attention. We present the attention operation with partial channel-reduce. For simplicity, we assume that the tensor-parallel degree is the number of heads, though this assumption can easily be relaxed. The attention operation with a full operation is all-reduce is:

 $$ \begin{aligned}\mathrm{H}_{ijm}=&Attention\left(XW_{m}^{K},XW_{m}^{Q},XW_{m}^{V}\right)_{ij}\\\tilde{Z}_{ilm}=&\sum_{j}\mathrm{H}_{ijm}\tilde{O}_{jlm}\\&Z_{il}=\sum_{m}\tilde{Z}_{ilm},\end{aligned} $$ 

where  $ H_{ijm} $ is an item in the  $ m^{th} $ attention head output, and  $ \tilde{O}_{jlm} $ is an item in the attention output projection, after reshaping the attention output projection O to be written in a row-parallel notation. Hence, the output of the attention operation with the partial channel-reduce operation is:

 $$ \begin{aligned}\mathrm{H}_{ijm}&=\operatorname{Attention}\left(X_{m}W_{m}^{K},X_{m}W_{m}^{Q},X_{m}W_{m}^{V}\right)_{ij}\\&\quad\tilde{Z}_{ilm}=\sum_{j}\mathrm{H}_{ijm}O_{jlm}\\Z_{ilm}&=\begin{cases}\sum_{m}\tilde{Z}_{ilm}&\text{if}l<\text{floor}(hp)\\\tilde{Z}_{ilm}&\text{if}l\geq\text{floor}(hp)\end{cases}.\end{aligned} $$ 

The main differences between Eq.23 and Eq.24 are:

• The sum over  $ \tilde{Z} $ is only over the first  $ p \cdot h $ channels of the hidden dimension.

• Apart from the first attention layer, the input to the attention is different per device when using partial channel-reduce, because the previous MLP layer also used partial channel-reduce in its output. Thus, the input to the attention, X, has an additional index m, corresponding to the tensor-parallel rank. Similarly, Z has an additional index because each device contains different parameters after the partial channel-reduce operation.

## B Analyzing Forward-Backward Mismatch Considering Residual Connections

For a transformer with all-reduce, we examine the input to an MLP layer on device m, denoted  $ X_{m} $, as a function of the output of a previous attention layer on device m before the all-reduce operation.

---

# OCR 第 16 页

denoted  $ Z_{m} $ with R being the residual connection from before the attention block, we have

 $$ X_{m}=\mathrm{norm}\left(\sum_{m}Z_{m}+R\right). $$ 

 $ R $ is the residual connection from before the attention block. We look at the loss as a function of  $ X_m $ for all  $ m $, and of the residual connection (that skips the next layer) on the  $ m^{th} $ device,  $ R_m $. We also look at  $ X_m $ and  $ R_m $ as a function of  $ Z_1 $, and calculate the derivative of the loss function w.r.t  $ Z_1 $ using the chain rule:

 $$ \begin{aligned}\frac{\partial\mathcal{L}\left(X_{1}\left(Z_{1}\right),...,X_{M}\left(Z_{1}\right),R_{1}\left(Z_{1}\right),...,R_{M}\left(Z_{1}\right)\right)}{\partial Z_{1}}=&\\\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X_{m}\left(Z_{1}\right)}{\partial Z_{1}}+\frac{\partial\mathcal{L}\left(R_{m}\right)}{\partial R_{m}}\cdot\frac{\partial R_{m}\left(Z_{1}\right)}{\partial Z_{1}}\right)=&\\\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X_{m}\left(Z_{1}\right)}{\partial Z_{1}}+\frac{\partial\mathcal{L}\left(R_{m}\right)}{\partial R_{m}}\right)=&\\\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X}{\partial Z_{1}}+\frac{\partial\mathcal{L}\left(R_{m}\right)}{\partial R_{m}}\right)\end{aligned} $$ 

where in the second equation we used the fact that

 $$ \frac{\partial R_{m}\left(Z_{1}\right)}{\partial Z_{1}}=\frac{\partial}{\partial Z_{1}}\sum_{m}Z_{m}=1, $$ 

and in the last equation, we equated  $ \frac{\partial X_m}{\partial Z_1} $ for all  $ m $ (denoted now as  $ \frac{\partial X}{\partial Z_1} $) because in Tensor-Parallelism with full all-reduce operations  $ X_1(Z_1) = X_2(Z_1) = \ldots = X_M(Z_1) $, and thus their derivative w.r.t  $ Z_1 $ are also equal. Here, the summation over  $ m $ is the all-reduce operation in the backward pass. Our key insight is here is that, due to the distributivity of matrix multiplication:

 $$ \sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X}{\partial Z_{1}}+\frac{\partial\mathcal{L}\left(R_{m}\right)}{\partial R_{m}}\right)=\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\right)\cdot\frac{\partial X}{\partial Z_{1}}+\sum_{m}\frac{\partial\mathcal{L}\left(R_{m}\right)}{\partial R_{m}}. $$ 

In other words, the all-reduce operation can happen before back-propagating through the normalization function (right side of the equation), or after the normalization function (left side of the equation). On the right hand side of the equation, the summation of the residual gradient happens in the all-reduce of the next layer, i.e. the layer after the residual is accumulated back into the activation tensors. In standard training frameworks, such as Megatron-LM, the all-reduce operation happens before back-propagating through the normalization function. When training with CAAT-Net, the assumption that  $ \frac{\partial X_m}{\partial Z_m} $ are equal for all m no longer holds. For this reason, the all-reduce operation in the backward pass must be after the calculation of the normalization function derivative.

Similarly, we examine the normalization function parameter update, denoted  $ \beta $, with a full all-reduce operation. Because the residual splits from the activations before the normalization function is applied, the normalization function parameter update is not a function of the residual states:

 $$ \frac{\partial\mathcal{L}\left(X_{1}\left(\beta\right),...,X_{M}\left(\beta\right)\right)}{\partial\beta}=\sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\cdot\frac{\partial X_{m}}{\partial\beta}\right). $$ 

In the gradient descent step, this means that after each iteration, before updating the weights, the updates $\partial\beta$ need to be synchronized themselves with an all-reduce operation. In popular training frameworks, the fact that $\frac{\partial X_{m}}{\partial\beta}$ are equal for all $m$ is utilized once again. When the all-reduce happens before backpropagating through the normalization function, there is no need for gradient synchronization after each step:

 $$ \sum_{m}\left(\frac{\partial\mathcal{L}\left(X_{m}\right)}{\partial X_{m}}\right)\cdot\frac{\partial X}{\partial\beta}. $$ 

Once again, equated  $ \frac{\partial X_{m}}{\partial \beta} $ for all m (denoted now as  $ \frac{\partial X}{\partial \beta} $).

---

# OCR 第 17 页

## C Speedup Analysis

We suggest a simple model to further understand the relation between compute and communication times, and analyze the potential speed-up of our method. We make the following assumptions:

- Compute is modeled only as GEMM operations — specifically in the MLP and attention. Communication is modeled only as the tensor-parallel all-reduce. We neglect all other computations (embeddings, language model head, etc.) and communications (pipeline parallel, data parallel, etc.)

• We assume a constant ratio between compute and communication capacity, C, given in units of  $ \frac{FLOP/s}{GB/s} $.

• We assume that the communication time roughly does not change when we adjust the tensor-parallel dimension. This assumption is true in Gaudi processors when using multi-node connections, due to inter- and intra-node communications overlapping during all-reduce operations. Additionally, we assume that computation time is inversely proportional to the tensor-parallel dimension. This assumption is only approximately true since computation time depends on many factors, such as tensor shapes.

We examine the forward pass of a transformer with a simple MLP, where the first weight matrix in the MLP is of dimension  $ h \times 4h $ and the second weight matrix is of dimension  $ 4h \times h $. This type of MLP is common in LLM's such as GPT and BERT. We consider batch size 1, as batch size does not affect the results in this section. When multiplying an  $ m \times p $ matrix by a  $ p \times n $ matrix, the total number of operations (multiplications and additions) is  $ m \cdot p \cdot (2n-1) $, which we approximate to  $ 2m \cdot p \cdot n $. Based on this, the total number of computation operations in a transformer layer with sequence length s, n heads and hidden size h is:

 $$ \begin{aligned}MLP ops=&\underbrace{8sh^{2}}_{h to4h}+\underbrace{8sh^{2}}_{4h to h}=16sh^{2}\\ Attention ops=&\underbrace{6sh^{2}}_{qkv proj}+\underbrace{4s^{2}h}_{attention}+\underbrace{2sh^{2}}_{out proj}=\\&4s^{2}h+8sh^{2}.\end{aligned} $$ 

To calculate the total communication payload, we recall that in each full all-reduce operation,  $ s \cdot h $ activations are sent and received by each device, and this happens twice every transformer block. Thus the total number of compute operations G, and communication payload P as a function of p, per device, are:

 $$ G=\frac{24sh^{2}+4s^{2}h}{r} $$ 

 $$ P(p)=2s h p, $$ 

where r is the tensor-parallel dimension and p is the CAAT-Net synchronization factor. Consequently, the total time for computation and communication of a single transformer layer in the forward pass is

 $$ T(p)=G+P(p)\;. $$ 

We find that the speed-up introduced by our method is:

 $$ \frac{T(1)-T(p)}{T(1)}=(1-p)\frac{1}{1+\frac{12h+2s}{Cr}}. $$ 

Our method is more significant for large $C$ and $r$, but diminishes for very large $h$ and $s$. This is because computation is quadratic in $h$ and $s$ while the communication is linear. If communication is hidden behind all of the computation, then there is a maximal value of $p$ at which communication and computation times are equal, and there is less motivation to decrease $p$ to improve speed-up. If $G \geq P(1)$, then the optimal value of $p$ is $p^* = 1$. Otherwise we can set $G = P(p)$. Considering both cases, we find that the value of $p^*$ is:

 $$ p^{*}=\min(\frac{12h+2s}{C r},1). $$

---

# OCR 第 18 页

## D Top-K and Random Masks Communication Reduction

Analyzing the communication volume reduction in these experiments, we note that only the communication in the forward pass is compressed. This is because we use vanilla tensor-parallelism, and not our alternate implementation detailed in Section 4, so communication doesn’t happen in the same location in the forward and backward passes. For this reason, unlike CAAT-Net, communication compression in the forward pass does not imply communication compression in the backward pass. Additionally, all-reduce happens in 2 steps – reduce-scatter and all-gather. Applying a mask before communication is equivalent to compressing the reduce-scatter operation, which accounts for only half of the total communication in the all-reduce. For these reasons, compressing communication using a Top-K or random masking with parameter  $ p $ leads to a  $ (\frac{100 \cdot (1 - p)}{4}) $ % reduction in tensor-parallel communication volume. In CAAT-Net with parameter  $ p $ communication is compressed in the reduce-scatter and all-gather of both the forward and backward passes. The total tensor-parallel communication in CAAT-Net is reduced by  $ (100 \cdot (1 - p)) $%.

## E Additional Results

### E.1 Effects of All-Reduce Bit Precision in the Backward Pass

In this section we show that 16 bit accumulation in the backward pass all-reduce leads to loss divergence. To show this, we train the variants of the TinyLlama model, as is described in Section 5.1. The first is trained using the Intel's Megatron-LM fork repository, without any additional changes. The second variant is trained after applying the changes detailed in Section 4, with the backward pass all-reduce accumulation in bfloat16 precision. The third is trained after applying all changes in the Section 4, including 32 bit accumulation in the backward pass. Results in Figure 6 show severe degradation with 16 bit accumulation after 15K training steps. Despite the mathematical equivalence between the two implementations, numerical differences lead to instability.

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_322_863_903_1154.jpg" alt="Image" width="47%" /></div>


<div style="text-align: center;">Figure 6: Effects of All-Reduce Accumulation Precision in the Backward Pass on TinyLlama Train Loss.</div>


### E.2 TinyLlama and GPT-XL Accuracy Evaluation for varying values of p

We report the full zero-shot accuracy evaluation of TinyLlama using varying values of $p$. The evaluation metrics are those described in Section 5.1. Overall $p = 0.75$ achieves the best accuracy, with the highest score in 5 out of 8 metrics. Results are available in Table 1. Additionally, we report full zero-shot accuracy evaluation of GPT-XL for $p = 0.5$. Results are available in Table 2.

---

# OCR 第 19 页

<div style="text-align: center;">Table 2: Zero-shot accuracy results on GPT-XL</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>p</td><td style='text-align: center; word-wrap: break-word;'>LAMBADA (acc)</td><td style='text-align: center; word-wrap: break-word;'>Hellaswag (acc)</td><td style='text-align: center; word-wrap: break-word;'>WinoGrande (acc)</td><td style='text-align: center; word-wrap: break-word;'>PIQA (acc)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>$ 50.16 \pm 0.70 $</td><td style='text-align: center; word-wrap: break-word;'>$ 36.07 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 52.41 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 68.06 \pm 1.11 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.5</td><td style='text-align: center; word-wrap: break-word;'>$ 48.17 \pm 0.69 $</td><td style='text-align: center; word-wrap: break-word;'>$ 36.26 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 53.83 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 67.79 \pm 1.09 $</td></tr><tr><td colspan="2">OpenBookQA (acc)</td><td style='text-align: center; word-wrap: break-word;'>BOOL-Q (acc)</td><td style='text-align: center; word-wrap: break-word;'>WikiText (ppl)</td><td style='text-align: center; word-wrap: break-word;'>Validation Loss</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>$ 19.20 \pm 1.76 $</td><td style='text-align: center; word-wrap: break-word;'>$ 60.85 \pm 0.85 $</td><td style='text-align: center; word-wrap: break-word;'>19.25</td><td style='text-align: center; word-wrap: break-word;'>1.28</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.5</td><td style='text-align: center; word-wrap: break-word;'>$ 18.60 \pm 1.74 $</td><td style='text-align: center; word-wrap: break-word;'>$ 61.01 \pm 0.85 $</td><td style='text-align: center; word-wrap: break-word;'>19.00</td><td style='text-align: center; word-wrap: break-word;'>1.27</td></tr></table>

<div style="text-align: center;">Table 3: Zero-shot accuracy results on TinyLlama for varying values of p</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>p</td><td style='text-align: center; word-wrap: break-word;'>LAMBADA (acc)</td><td style='text-align: center; word-wrap: break-word;'>Hellaswag (acc)</td><td style='text-align: center; word-wrap: break-word;'>WinoGrande (acc)</td><td style='text-align: center; word-wrap: break-word;'>PIQA (acc)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>$ 48.26 \pm 0.70 $</td><td style='text-align: center; word-wrap: break-word;'>$ 35.55 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 55.25 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 67.03 \pm 1.10 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.875</td><td style='text-align: center; word-wrap: break-word;'>$ 46.43 \pm 0.69 $</td><td style='text-align: center; word-wrap: break-word;'>$ 35.89 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 53.04 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 64.96 \pm 1.11 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.75</td><td style='text-align: center; word-wrap: break-word;'>$ 49.39 \pm 0.70 $</td><td style='text-align: center; word-wrap: break-word;'>$ 35.88 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 52.80 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 68.99 \pm 1.08 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.625</td><td style='text-align: center; word-wrap: break-word;'>$ 48.92 \pm 0.70 $</td><td style='text-align: center; word-wrap: break-word;'>$ 35.61 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 53.20 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 67.41 \pm 1.09 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.5</td><td style='text-align: center; word-wrap: break-word;'>$ 48.01 \pm 0.70 $</td><td style='text-align: center; word-wrap: break-word;'>$ 35.65 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 51.26 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 67.68 \pm 1.09 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.375</td><td style='text-align: center; word-wrap: break-word;'>$ 45.74 \pm 0.69 $</td><td style='text-align: center; word-wrap: break-word;'>$ 35.48 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 52.88 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 68.28 \pm 1.09 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.25</td><td style='text-align: center; word-wrap: break-word;'>$ 48.83 \pm 0.70 $</td><td style='text-align: center; word-wrap: break-word;'>$ 35.63 \pm 0.48 $</td><td style='text-align: center; word-wrap: break-word;'>$ 50.83 \pm 1.40 $</td><td style='text-align: center; word-wrap: break-word;'>$ 67.74 \pm 1.09 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.125</td><td style='text-align: center; word-wrap: break-word;'>$ 44.25 \pm 0.69 $</td><td style='text-align: center; word-wrap: break-word;'>$ 34.63 \pm 0.47 $</td><td style='text-align: center; word-wrap: break-word;'>$ 50.83 \pm 1.38 $</td><td style='text-align: center; word-wrap: break-word;'>$ 66.27 \pm 1.10 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>$ 33.96 \pm 0.66 $</td><td style='text-align: center; word-wrap: break-word;'>$ 30.49 \pm 0.46 $</td><td style='text-align: center; word-wrap: break-word;'>$ 50.28 \pm 1.41 $</td><td style='text-align: center; word-wrap: break-word;'>$ 64.09 \pm 1.12 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>OpenBookQA (acc)</td><td style='text-align: center; word-wrap: break-word;'>BOOL-Q (acc)</td><td style='text-align: center; word-wrap: break-word;'>WikiText (ppl)</td><td colspan="2">Validation Loss</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>$ 21.20 \pm 1.83 $</td><td style='text-align: center; word-wrap: break-word;'>$ 59.57 \pm 0.86 $</td><td style='text-align: center; word-wrap: break-word;'>19.10</td><td style='text-align: center; word-wrap: break-word;'>1.28</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.875</td><td style='text-align: center; word-wrap: break-word;'>$ 20.00 \pm 1.79 $</td><td style='text-align: center; word-wrap: break-word;'>$ 60.24 \pm 0.86 $</td><td style='text-align: center; word-wrap: break-word;'>19.05</td><td style='text-align: center; word-wrap: break-word;'>1.28</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.75</td><td style='text-align: center; word-wrap: break-word;'>$ 20.60 \pm 1.81 $</td><td style='text-align: center; word-wrap: break-word;'>$ 61.04 \pm 0.85 $</td><td style='text-align: center; word-wrap: break-word;'>18.84</td><td style='text-align: center; word-wrap: break-word;'>1.27</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.625</td><td style='text-align: center; word-wrap: break-word;'>$ 21.40 \pm 1.84 $</td><td style='text-align: center; word-wrap: break-word;'>$ 60.12 \pm 0.86 $</td><td style='text-align: center; word-wrap: break-word;'>19.08</td><td style='text-align: center; word-wrap: break-word;'>1.28</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.5</td><td style='text-align: center; word-wrap: break-word;'>$ 21.00 \pm 1.82 $</td><td style='text-align: center; word-wrap: break-word;'>$ 59.24 \pm 0.86 $</td><td style='text-align: center; word-wrap: break-word;'>20.12</td><td style='text-align: center; word-wrap: break-word;'>1.28</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.375</td><td style='text-align: center; word-wrap: break-word;'>$ 19.40 \pm 1.77 $</td><td style='text-align: center; word-wrap: break-word;'>$ 57.13 \pm 0.85 $</td><td style='text-align: center; word-wrap: break-word;'>19.30</td><td style='text-align: center; word-wrap: break-word;'>1.29</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.25</td><td style='text-align: center; word-wrap: break-word;'>$ 20.60 \pm 1.81 $</td><td style='text-align: center; word-wrap: break-word;'>$ 51.53 \pm 0.87 $</td><td style='text-align: center; word-wrap: break-word;'>19.60</td><td style='text-align: center; word-wrap: break-word;'>1.29</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0.125</td><td style='text-align: center; word-wrap: break-word;'>$ 20.60 \pm 1.81 $</td><td style='text-align: center; word-wrap: break-word;'>$ 54.07 \pm 0.87 $</td><td style='text-align: center; word-wrap: break-word;'>20.36</td><td style='text-align: center; word-wrap: break-word;'>1.31</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>$ 17.80 \pm 1.71 $</td><td style='text-align: center; word-wrap: break-word;'>$ 56.97 \pm 0.87 $</td><td style='text-align: center; word-wrap: break-word;'>28.37</td><td style='text-align: center; word-wrap: break-word;'>1.49</td></tr></table>

### E.3 Private Channel Scaling Ablations

In this section we present an ablation study for private channel scaling. We train the 130M model presented in Section 5.1 over 7.8B tokens, with a tensor-parallel dimension of 8 and p = 0.5. We record the validation loss at the end of training, with and without private channel scaling, and see a slight improvement when using private-channel scaling over most values of p. Results are presented in Figure E.3.

### E.4 Additional Speedup Results

In this section, we report inference speedup on 34B and 70B Llama models. These models use grouped query attention (GQA) of 8, so it is possible to evaluate our speedup only on tensor-parallel dimension of 8 (our a lower multiple of 2). Absolute measurements are shown in Tables 4 and 5.

---

# OCR 第 20 页

<div style="text-align: center;"><img src="assets/imgs/img_in_chart_box_322_148_904_466.jpg" alt="Image" width="47%" /></div>


<div style="text-align: center;">Figure 7: Partial Channel Scaling. Validation loss vs. p for with and without private channel scaling, on a 130M model.</div>


<div style="text-align: center;">Table 4: Absolute measurements of Llama 70B inference Time-to-First-Token (TTFT) for tensor-parallel 8. Measured in milliseconds, with varying batch sizes and values of p.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Batch size</td><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>p = 0.75</td><td style='text-align: center; word-wrap: break-word;'>p = 0.5</td><td style='text-align: center; word-wrap: break-word;'>p = 0.25</td><td style='text-align: center; word-wrap: break-word;'>No communication</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>16</td><td style='text-align: center; word-wrap: break-word;'>1402</td><td style='text-align: center; word-wrap: break-word;'>1301</td><td style='text-align: center; word-wrap: break-word;'>1224</td><td style='text-align: center; word-wrap: break-word;'>1153</td><td style='text-align: center; word-wrap: break-word;'>1093</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>32</td><td style='text-align: center; word-wrap: break-word;'>2769</td><td style='text-align: center; word-wrap: break-word;'>2595</td><td style='text-align: center; word-wrap: break-word;'>2436</td><td style='text-align: center; word-wrap: break-word;'>2281</td><td style='text-align: center; word-wrap: break-word;'>2092</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>64</td><td style='text-align: center; word-wrap: break-word;'>5513</td><td style='text-align: center; word-wrap: break-word;'>5290</td><td style='text-align: center; word-wrap: break-word;'>4982</td><td style='text-align: center; word-wrap: break-word;'>4654</td><td style='text-align: center; word-wrap: break-word;'>4259</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>128</td><td style='text-align: center; word-wrap: break-word;'>10962</td><td style='text-align: center; word-wrap: break-word;'>10293</td><td style='text-align: center; word-wrap: break-word;'>9817</td><td style='text-align: center; word-wrap: break-word;'>9457</td><td style='text-align: center; word-wrap: break-word;'>8731</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>256</td><td style='text-align: center; word-wrap: break-word;'>20606</td><td style='text-align: center; word-wrap: break-word;'>19242</td><td style='text-align: center; word-wrap: break-word;'>18055</td><td style='text-align: center; word-wrap: break-word;'>16854</td><td style='text-align: center; word-wrap: break-word;'>15107</td></tr></table>

<div style="text-align: center;">Table 5: Absolute measurements of Llama 34B inference Time-to-First-Token (TTFT) for tensor-parallel 8. Measured in milliseconds, with varying batch sizes and values of p.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Batch size</td><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>p = 0.75</td><td style='text-align: center; word-wrap: break-word;'>p = 0.5</td><td style='text-align: center; word-wrap: break-word;'>p = 0.25</td><td style='text-align: center; word-wrap: break-word;'>No communication</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>16</td><td style='text-align: center; word-wrap: break-word;'>730</td><td style='text-align: center; word-wrap: break-word;'>682</td><td style='text-align: center; word-wrap: break-word;'>637</td><td style='text-align: center; word-wrap: break-word;'>590</td><td style='text-align: center; word-wrap: break-word;'>532</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>32</td><td style='text-align: center; word-wrap: break-word;'>1519</td><td style='text-align: center; word-wrap: break-word;'>1429</td><td style='text-align: center; word-wrap: break-word;'>1328</td><td style='text-align: center; word-wrap: break-word;'>1226</td><td style='text-align: center; word-wrap: break-word;'>1074</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>64</td><td style='text-align: center; word-wrap: break-word;'>2977</td><td style='text-align: center; word-wrap: break-word;'>2861</td><td style='text-align: center; word-wrap: break-word;'>2675</td><td style='text-align: center; word-wrap: break-word;'>2453</td><td style='text-align: center; word-wrap: break-word;'>2178</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>128</td><td style='text-align: center; word-wrap: break-word;'>6081</td><td style='text-align: center; word-wrap: break-word;'>5738</td><td style='text-align: center; word-wrap: break-word;'>5424</td><td style='text-align: center; word-wrap: break-word;'>5081</td><td style='text-align: center; word-wrap: break-word;'>4544</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>256</td><td style='text-align: center; word-wrap: break-word;'>11104</td><td style='text-align: center; word-wrap: break-word;'>10270</td><td style='text-align: center; word-wrap: break-word;'>9575</td><td style='text-align: center; word-wrap: break-word;'>8870</td><td style='text-align: center; word-wrap: break-word;'>7942</td></tr></table>

### E.5 Absolute Performance Metrics

In Section 5.2 of the paper we reported speedup in training and inference on a Llama-7b model, relative to the baseline. Here we report the absolute measurements, from which the speedup was calculated.

<div style="text-align: center;">Table 6: Absolute measurements of training throughput. Measured in tokens per second (tps) for different tensor-parallel (TP) dimensions, and values of p.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>TP dimension</td><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>p = 0.75</td><td style='text-align: center; word-wrap: break-word;'>p = 0.5</td><td style='text-align: center; word-wrap: break-word;'>p = 0.25</td><td style='text-align: center; word-wrap: break-word;'>No communication</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>34904</td><td style='text-align: center; word-wrap: break-word;'>36883</td><td style='text-align: center; word-wrap: break-word;'>38586</td><td style='text-align: center; word-wrap: break-word;'>39728</td><td style='text-align: center; word-wrap: break-word;'>40944</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>8</td><td style='text-align: center; word-wrap: break-word;'>64395</td><td style='text-align: center; word-wrap: break-word;'>67495</td><td style='text-align: center; word-wrap: break-word;'>70403</td><td style='text-align: center; word-wrap: break-word;'>72917</td><td style='text-align: center; word-wrap: break-word;'>76646</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>16</td><td style='text-align: center; word-wrap: break-word;'>96642</td><td style='text-align: center; word-wrap: break-word;'>98625</td><td style='text-align: center; word-wrap: break-word;'>106050</td><td style='text-align: center; word-wrap: break-word;'>112456</td><td style='text-align: center; word-wrap: break-word;'>126227</td></tr></table>

---

# OCR 第 21 页

<div style="text-align: center;">Table 7: Absolute measurements of inference Time-to-First-Token (TTFT) for tensor-parallel 16. Measured in milliseconds, with varying batch sizes and values of p.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Batch size</td><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>$ p = 0.75 $</td><td style='text-align: center; word-wrap: break-word;'>$ p = 0.5 $</td><td style='text-align: center; word-wrap: break-word;'>$ p = 0.25 $</td><td style='text-align: center; word-wrap: break-word;'>No communication</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>16</td><td style='text-align: center; word-wrap: break-word;'>214</td><td style='text-align: center; word-wrap: break-word;'>209</td><td style='text-align: center; word-wrap: break-word;'>187</td><td style='text-align: center; word-wrap: break-word;'>165</td><td style='text-align: center; word-wrap: break-word;'>100</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>32</td><td style='text-align: center; word-wrap: break-word;'>443</td><td style='text-align: center; word-wrap: break-word;'>386</td><td style='text-align: center; word-wrap: break-word;'>358</td><td style='text-align: center; word-wrap: break-word;'>326</td><td style='text-align: center; word-wrap: break-word;'>193</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>64</td><td style='text-align: center; word-wrap: break-word;'>746</td><td style='text-align: center; word-wrap: break-word;'>696</td><td style='text-align: center; word-wrap: break-word;'>637</td><td style='text-align: center; word-wrap: break-word;'>565</td><td style='text-align: center; word-wrap: break-word;'>391</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>128</td><td style='text-align: center; word-wrap: break-word;'>1388</td><td style='text-align: center; word-wrap: break-word;'>1291</td><td style='text-align: center; word-wrap: break-word;'>1174</td><td style='text-align: center; word-wrap: break-word;'>1060</td><td style='text-align: center; word-wrap: break-word;'>792</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>256</td><td style='text-align: center; word-wrap: break-word;'>2625</td><td style='text-align: center; word-wrap: break-word;'>2393</td><td style='text-align: center; word-wrap: break-word;'>2178</td><td style='text-align: center; word-wrap: break-word;'>2059</td><td style='text-align: center; word-wrap: break-word;'>1630</td></tr></table>

<div style="text-align: center;">Table 8: Absolute measurements of inference Time-to-First-Token for tensor-parallel 8. Measured in milliseconds, with varying batch sizes and values of p.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Batch size</td><td style='text-align: center; word-wrap: break-word;'>Baseline</td><td style='text-align: center; word-wrap: break-word;'>p = 0.75</td><td style='text-align: center; word-wrap: break-word;'>p = 0.5</td><td style='text-align: center; word-wrap: break-word;'>p = 0.25</td><td style='text-align: center; word-wrap: break-word;'>No communication</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>16</td><td style='text-align: center; word-wrap: break-word;'>204</td><td style='text-align: center; word-wrap: break-word;'>189</td><td style='text-align: center; word-wrap: break-word;'>181</td><td style='text-align: center; word-wrap: break-word;'>160</td><td style='text-align: center; word-wrap: break-word;'>139</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>32</td><td style='text-align: center; word-wrap: break-word;'>411</td><td style='text-align: center; word-wrap: break-word;'>374</td><td style='text-align: center; word-wrap: break-word;'>352</td><td style='text-align: center; word-wrap: break-word;'>320</td><td style='text-align: center; word-wrap: break-word;'>279</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>64</td><td style='text-align: center; word-wrap: break-word;'>853</td><td style='text-align: center; word-wrap: break-word;'>786</td><td style='text-align: center; word-wrap: break-word;'>727</td><td style='text-align: center; word-wrap: break-word;'>641</td><td style='text-align: center; word-wrap: break-word;'>571</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>128</td><td style='text-align: center; word-wrap: break-word;'>1645</td><td style='text-align: center; word-wrap: break-word;'>1571</td><td style='text-align: center; word-wrap: break-word;'>1475</td><td style='text-align: center; word-wrap: break-word;'>1295</td><td style='text-align: center; word-wrap: break-word;'>1133</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>256</td><td style='text-align: center; word-wrap: break-word;'>3320</td><td style='text-align: center; word-wrap: break-word;'>3071</td><td style='text-align: center; word-wrap: break-word;'>2916</td><td style='text-align: center; word-wrap: break-word;'>2713</td><td style='text-align: center; word-wrap: break-word;'>2432</td></tr></table>

### E.6 Measurements on NVIDIA Hardware

In this section we present the full inference speedup measurements on H100 and A100, as detailed in Section 5.2 of the paper.

<div style="text-align: center;">Table 9: TTFT on H100 and A100. Measured in milliseconds, for different batch sizes and p values.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Device</td><td style='text-align: center; word-wrap: break-word;'>Batch Size</td><td style='text-align: center; word-wrap: break-word;'>p = 1.0</td><td style='text-align: center; word-wrap: break-word;'>p = 0.75</td><td style='text-align: center; word-wrap: break-word;'>p = 0.5</td><td style='text-align: center; word-wrap: break-word;'>p = 0.25</td><td style='text-align: center; word-wrap: break-word;'>p = 0.0</td></tr><tr><td rowspan="4">H100</td><td style='text-align: center; word-wrap: break-word;'>16</td><td style='text-align: center; word-wrap: break-word;'>173</td><td style='text-align: center; word-wrap: break-word;'>166</td><td style='text-align: center; word-wrap: break-word;'>157</td><td style='text-align: center; word-wrap: break-word;'>149</td><td style='text-align: center; word-wrap: break-word;'>136</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>32</td><td style='text-align: center; word-wrap: break-word;'>341</td><td style='text-align: center; word-wrap: break-word;'>338</td><td style='text-align: center; word-wrap: break-word;'>312</td><td style='text-align: center; word-wrap: break-word;'>296</td><td style='text-align: center; word-wrap: break-word;'>270</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>64</td><td style='text-align: center; word-wrap: break-word;'>679</td><td style='text-align: center; word-wrap: break-word;'>663</td><td style='text-align: center; word-wrap: break-word;'>623</td><td style='text-align: center; word-wrap: break-word;'>589</td><td style='text-align: center; word-wrap: break-word;'>545</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>128</td><td style='text-align: center; word-wrap: break-word;'>1360</td><td style='text-align: center; word-wrap: break-word;'>1295</td><td style='text-align: center; word-wrap: break-word;'>1280</td><td style='text-align: center; word-wrap: break-word;'>1179</td><td style='text-align: center; word-wrap: break-word;'>1088</td></tr><tr><td rowspan="4">A100</td><td style='text-align: center; word-wrap: break-word;'>16</td><td style='text-align: center; word-wrap: break-word;'>406</td><td style='text-align: center; word-wrap: break-word;'>415</td><td style='text-align: center; word-wrap: break-word;'>373</td><td style='text-align: center; word-wrap: break-word;'>353</td><td style='text-align: center; word-wrap: break-word;'>328</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>32</td><td style='text-align: center; word-wrap: break-word;'>795</td><td style='text-align: center; word-wrap: break-word;'>764</td><td style='text-align: center; word-wrap: break-word;'>727</td><td style='text-align: center; word-wrap: break-word;'>694</td><td style='text-align: center; word-wrap: break-word;'>643</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>64</td><td style='text-align: center; word-wrap: break-word;'>1568</td><td style='text-align: center; word-wrap: break-word;'>1508</td><td style='text-align: center; word-wrap: break-word;'>1436</td><td style='text-align: center; word-wrap: break-word;'>1363</td><td style='text-align: center; word-wrap: break-word;'>1281</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>128</td><td style='text-align: center; word-wrap: break-word;'>3117</td><td style='text-align: center; word-wrap: break-word;'>2999</td><td style='text-align: center; word-wrap: break-word;'>2927</td><td style='text-align: center; word-wrap: break-word;'>2722</td><td style='text-align: center; word-wrap: break-word;'>2553</td></tr></table>
