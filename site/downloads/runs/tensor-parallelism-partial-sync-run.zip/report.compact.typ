#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[Tensor-Parallelism with Partially Synchronized Activations]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Itay Lamprecht, Asaf Karnieli, Yair Hanani, Niv Giladi, Daniel Soudry]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[张量并行] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[大语言模型训练] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[通信效率] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[分布式训练] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[CAAT-Net]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-28]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

采用张量并行方式训练和推理大语言模型（LLM）需要大量通信来同步激活值。我们的研究发现，只需对现有做法做少量调整，LLM 便可在不完全同步激活值的情况下完成训练，从而降低带宽需求。我们将这一方法命名为"面向张量并行的通信感知架构"（CAAT-Net）。我们训练了一个 70 亿参数的 CAAT-Net 模型，结果表明张量并行通信量最多可降低 50%，且在几乎所有评测基准上预训练精度没有显著下降。我们还在 1.3 亿和 11 亿参数的较小模型上进行了实验，验证了该方法的鲁棒性和可扩展性。我们发现，在某些场景下，减少通信量甚至能改善验证损失。最后，我们展示了 CAAT-Net 在多种设置和模型规模下如何同时加速训练与推理。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [Tensor-Parallelism with Partially Synchronized Activations],
    [作者], [Itay Lamprecht, Asaf Karnieli, Yair Hanani, Niv Giladi, Daniel Soudry],
    [发表场所 / 年份], [文中未说明],
    [研究领域], [分布式深度学习、大语言模型训练系统],
    [关键词], [张量并行，大语言模型训练，通信效率，分布式训练，CAAT-Net],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（5 个）]：`张量并行` · `通信优化` · `大语言模型训练` · `分布式系统` · `CAAT-Net`
]

论文提出 CAAT-Net：用\"部分通道归约\"（只同步隐藏维度中一部分通道，其余通道各设备本地保留，类似几个人分工做同一张报表但只对齐其中几列）替代张量并行中对全部激活的 all-reduce，在 7B 模型上把张量并行通信量降低达 50%，且在几乎所有评测基准上准确率无显著下降 \[作者明确陈述\]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

本次分析覆盖 OCR 提取的正文（约第 1--11、18、20 页片段）及四批图表证据，但论文多个附录（A.1/A.2/B/C/D/E.1--E.6）仅被正文提及标题或结论，具体推导、曲线和数值未包含在当前 OCR 中，均标记为\"无法从当前OCR内容确认\"。发表场所、年份、arXiv 与代码链接均缺失，判断为\"文中未说明\"。以下内容严格区分论文事实、实验支持与背景知识；论文未讨论非 Transformer 架构或微调/强化学习场景的适用性 \[文中未说明\]。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

张量并行是把大权重矩阵切到多个设备上、通过 all-reduce（多设备各算一部分再加总并同步回全体，类似几个分行统计后把总额汇总回传）来协同完成前向/反向计算的技术，被 GPT-3、Llama、BLOOM 等大模型训练广泛采用 \[作者明确陈述\]。该问题重要的原因在于两个物理约束的叠加：张量并行设备数增加时单设备计算量下降，但通信负载基本不变；同时硬件计算能力的增长速度长期快于通信带宽 \[作者明确陈述，引用\[7\]\]。这使通信可能反超计算成为训练/推理的瓶颈，导致即便最大规模模型也通常把张量并行维度限制在 8（以利用节点内快速互联）\[作者明确陈述，引用\[4\]\]。

#strong[本文的 story]：旧路线（流水线重叠、压缩、异步优化、训练后技术）都没有从根本上减少张量并行通信总量本身，其共同的技术症结是都默认\"激活必须完全同步\"这一前提不可动摇；本文的转折点是发现该前提其实并非训练收敛的必要条件，只要相应调整反向传播位置和数值精度，就能直接削减通信总量而非仅仅隐藏或压缩它 \[作者明确陈述\]。

== 4. 旧方法为何不够
<4-旧方法为何不够>

- #strong[通信-计算流水线]（Domino DeepSpeed、Ladder Residual 等 \[6,10-12\]）：原本试图靠重叠通信与计算来隐藏张量并行延迟。前提是\"总有足够的计算量可供重叠\"，但张量并行维度增大时单设备计算量减少而通信量不变，可重叠空间随之收窄；与上下文并行等方式叠加时通信本身已超过计算时间，无计算可隐藏；在 H100/H200 上通信任务还会占用本可用于计算的 SM 资源 \[作者明确陈述\]。本文用部分通道归约（模块1）直接削减通信总量，作者视二者为互补而非替代关系。检验该批判的直接对比实验：论文未提供与流水线方法的联合消融数据------\"无法从当前OCR内容确认\"。
- #strong[压缩通信]（自编码器/Top-K \[14,15\]）：原本试图压缩要传输的激活/梯度以降低数据量。前提是压缩不显著损伤模型效果，但作者称尚未见工作证明压缩对张量并行有效，且自己实测发现即使极小幅度压缩也导致严重准确率下降，压缩本身还引入额外计算开销 \[作者明确陈述+实验支持\]。CAAT-Net 不压缩激活，私有通道完整参与计算只是不跨设备传输；对应实验为 Section 5.3 与 Figure 5。
- #strong[异步优化]（数据并行场景 \[16\]）：针对的是数据并行中设备间权重副本不一致的问题，用异步换扩展性，但带来收敛困难和泛化能力下降 \[作者明确陈述\]。张量并行中每设备本就只持有权重子集而非完整副本，问题性质不同，论文未提供直接对比数值------\"无法从当前OCR内容确认\"。
- #strong[训练后技术]（量化 \[17,18\]、移除注意力后通信点 \[19\]）：只能缓解推理阶段通信瓶颈，不涉及训练阶段 \[作者明确陈述\]。CAAT-Net 从训练阶段起就用部分通道归约，天然同时覆盖两阶段（模块6）；论文未提供与量化方法的直接对比------\"无法从当前OCR内容确认\"。

== 5. 核心洞见与假设
<5-核心洞见与假设>

#strong[核心洞见]：张量并行传统上要求 all-reduce 后各设备激活完全同步，但作者发现只需对训练框架做少量调整，LLM 训练即使激活不完全同步也能收敛 \[作者明确陈述\]。

#strong[支撑该洞见落地的关键前提（数学层面）]：反向传播中，由于矩阵乘法对加法满足分配律，\"跨设备求和\"这一操作在数学上可以插在反向链条不同位置而结果不变，但这一等价性仅在激活完全同步时成立；一旦打破全同步，求和位置必须固定在归一化层导数计算之后 \[作者明确陈述，附推导\]。这是从洞见到可执行方案之间不可缺的桥梁，而非核心洞见本身。

#strong[为落地洞见所需的实现组件]（区别于核心贡献）：反向 all-reduce 位置调整（\"h\"操作）、反向梯度 fp32 累积（消除 16 位精度下的收敛差距）、私有通道 \#mi(\"\\sqrt{r}\") 方差缩放、推理阶段逻辑设备机制 \[作者明确陈述\]。前提可能不成立的场景：若不做位置调整，作者称会\"导致训练发散\"，但未给出对应发散曲线（仅文字陈述）。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入为各设备上不同的激活张量 \#mi(\"X\_1, X\_2\")（不同于标准张量并行中两设备共享同一输入）→ 隐藏维度切分为共享通道（前 \#mi(\"h\\cdot p\") 个，跨设备求和）与私有通道（其余 \#mi(\"(1-p)\\cdot h\") 个，设备本地保留）→ 反向传播中归约位置固定于归一化层导数之后 → 梯度归约以 fp32 累积 → 输出为部分同步的 \#mi(\"Z\_1,Z\_2\")，可选私有通道方差缩放 \[作者明确陈述\]。

+ #strong[部分通道归约]：动机是全 all-reduce 通信量固定且大，希望只同步部分通道即可维持收敛。MLP 中标准计算为 \#mi(\"Y=\\sigma(XA)\")、\#mi(\"Z=Y\_1B\_1+Y\_2B\_2\")（原文公式，页码4-5）；部分归约下 \#mi(\"Y\_1=\\sigma(X\_1A\_1)\")，\#mi(\"Y\_2=\\sigma(X\_2A\_2)\")，\#mi(\"B\") 按行列切为四块，输出 \#mi(\"Z\_1=\[Y\_1B\_{11}+Y\_2B\_{12},,Y\_1B\_{21}\]\")，\#mi(\"Z\_2=\[Y\_1B\_{11}+Y\_2B\_{12},,Y\_2B\_{22}\]\")，其中前者为共享通道、后两者为私有通道 \[原文公式\]。技术优势是通信量随 \#mi(\"p\") 线性可调，\#mi(\"p=1\") 退化为标准全同步。
+ #strong[反向传播位置调整]：动机是若沿用标准框架在归一化层反传前做归约（\"g\"操作），部分同步下会产生 forward-backward mismatch。做法是将求和固定在归一化层导数计算之后（\"h\"操作），归一化参数梯度同理需先反传经归一化函数再归约 \[原文推导\]。技术优势：保证反向数学正确，且归一化参数额外通信量仅为 \#mi(\"\\Theta(h)\")，相对张量并行主通信可忽略。
+ #strong[反向梯度 fp32 累积]：动机是即使数学等价，16 位精度累积仍观测到收敛差距（数值误差非算法错误）。做法是通信仍用 16 位传输，归约累加时上采样为 32 位。技术优势：完全消除该差距且不增加通信带宽。
+ #strong[私有通道方差缩放]：动机是共享通道由 \#mi(\"r\") 个独立同分布量相加（方差 \#mi(\"r\\sigma\_A^2\")），私有通道只有 1 个（方差 \#mi(\"\\sigma\_A^2\")），跨通道方差不均衡 \[原文公式\]。做法是私有通道乘以 \#mi(\"\\sqrt{r}\")。作者明确该项非必需，禁用可换取 1--2% 训练速度提升但伴随轻微准确率下降。
+ #strong[推理阶段逻辑设备机制]：动机是训练/推理张量并行维度不一致时，单设备需处理原本分布式的多份激活。做法是单设备顺序模拟多个逻辑设备；另一路径是微调至 \#mi(\"p=1\")。技术优势：无需为每种推理并行维度重训。该机制本身引入的额外顺序计算成本\"文中未说明\"。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：模块1、2部分通道归约架构设计]
  #image("assets/imgs/img_in_image_box_213_262_1011_576.jpg", width: 100%)
  #emph[Figure 1: CAAT-Net model architecture. Left. We exemplify our approach on a two-layer fully-connected neural network on a single device. Middle. When using tensor-parallelism with two devices, the input activation X is identical on both devices. Each device uses its own set of weights to multiply the inputs, yielding intermediate activations, which are then reduced into identical copies of Z on both devices. Right. CAAT-Net receives different input activations, and , for Device 1 and Device 2, respectively. These yield intermediate activations that are partially synced between the devices, producing and on Device 1 and Device 2, respectively. Private channels are marked P, and shared channels are marked S.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：三组并列对比显示CAAT-Net输入本身即在两设备间不同,输出按共享(S)/私有(P)通道划分,仅S通道跨设备连接

- #strong[论证关系]：直接可视化部分通道归约的公式定义,支撑该设计直觉合理性

- #strong[适用范围]：仅示意张量并行维度=2的简化情形,非真实7B模型架构图
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：模块3反向传播位置调整(h操作)]
  #image("assets/imgs/img_in_image_box_216_149_1000_584.jpg", width: 100%)
  #emph[Figure 2: Partial synchronization and partial channel-reduce. (a) Vanilla transformers in current training frameworks. The operation f is an all-reduce in the forward pass and identity in the backward pass. The operation g is an all-reduce in the backward pass and identity in the forward pass. (b) With partial synchronization, h denotes the reduction operation in both the forward and the backward pass, since both must be done at the same location. Synchronization of the normalization function parameters is necessary. (c) Partial channel-reduce with parameter p over 2 devices.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：全同步下g可置于归一化前/后等价;部分同步下必须合并为固定于归一化导数之后的h操作

- #strong[论证关系]：支撑模块3设计正确性,与Figure 6共同构成\"两项调整缺一不可\"证据链

- #strong[适用范围]：仅为张量并行维度=2的一般性机制推导,反向语义差异需结合正文理解
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制→收益]：只同步部分通道使通信字节数按 \#mi(\"p\") 比例下降，而私有通道仍完整参与本地计算，不损失参数量或总计算量 \[基于文中逻辑的推断\]，因此理论上应能在不牺牲模型容量的前提下降低通信瓶颈。
- #strong[条件]：该收益依赖反向传播位置调整与 fp32 累积两项配套修正，否则会破坏梯度正确性或引入数值发散 \[基于文中逻辑的推断\]。
- #strong[条件]：\#mi(\"p\") 不能过小，否则退化为\"类集成\"结构、且该退化阈值随张量并行维度增大而在更高 \#mi(\"p\") 处出现，说明可安全压缩的通信比例并非固定常数 \[基于文中逻辑的推断\]。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[效果]：7B 模型通信降 50% 是否伴随准确率显著下降 → 对应 Table 1（baseline vs CAAT-Net, \#mi(\"p=0.5\"), TP=8）。
- #strong[机制]：中等 \#mi(\"p\") 是否能改善而非仅维持验证损失，退化阈值是否随 TP 变化 → Figure 3。
- #strong[必要性]：反向位置调整+fp32 累积是否为避免发散的必需项 → 数学推导+Figure 6（Appendix E.1）。
- #strong[鲁棒性]：方法是否在 130M/1.1B/GPT3-XL 等不同规模与架构下稳健 → 正文简述，具体数字在未提供的 Appendix E.2。
- #strong[适用范围]：训练/推理加速在不同硬件、batch size、TP 维度下的表现 → Figure 4。
- #strong[比较效果]：CAAT-Net 相对 Top-K/随机掩码压缩的优势 → Figure 5，Section 5.3。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 数据集：RedPajama（预训练数据）；具体划分比例文中未说明。
- 模型规模：130M（自定义 LLaMA 架构）、1.1B（TinyLlama）、7B（Llama2 架构）、另有 GPT3-XL 用于架构鲁棒性实验。
- 硬件：Intel Gaudi3（主要训练/推理实测）、NVIDIA H100-80GB-HBM3、NVIDIA A100-SXM4-80GB（推理对照）。
- 基准评测：lm-eval-harness 框架下的 LAMBADA、Hellaswag、WinoGrande、PIQA、OpenBookQA、BoolQ 及 WikiText 困惑度。
- 训练加速实验反向传播均使用 16 位精度累积（而非推荐的 fp32）\[作者明确陈述\]；软件基座为 Intel Megatron-LM fork。
- 重复次数、随机种子数、显著性检验之外的统计细节：文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：同步因子 \#mi(\"p\")，隐藏维度中被归约通道的比例，范围 \#mi(\"\[0,1\]\")，为自变量无优劣方向。 #strong[定义与公式]：来源层级为#strong[原文公式]，\"shared channels 被选为最初的 \#mi(\"h\\cdot p\") 个通道\"。 #strong[实验用途]：贯穿所有实验的核心自变量。 #strong[读数与边界]：\#mi(\"p=1\") 退化为标准全同步，\#mi(\"p\\to0\") 退化为类集成结构，具体极端数值未给出。

- #strong[指标与方向]：零样本准确率 (acc, %)，测量对象为分类正确率，越高越好。 #strong[定义与公式]：来源层级为#strong[无可核验公式]------论文仅报告 lm-eval-harness 框架产出的数值，未重新定义计算式。 #strong[实验用途]：验证核心贡献3（准确率维持）。 #strong[读数与边界]：Table 1 中多数基准差异极小；BoolQ 从 64.89 降至 62.51，是唯一\"marginally significant\"（Welch\'s t-test, p=0.046）的下降，构成对\"几乎所有基准无显著下降\"表述的例外 \[实验支持\]。

- #strong[指标与方向]：WikiText 困惑度 (ppl)，越低越好。 #strong[定义与公式]：来源层级为#strong[无可核验公式]，标准定义未在文中重述。 #strong[实验用途]：与验证损失共同衡量语言建模能力。 #strong[读数与边界]：Table 1 中 12.51→12.46，略有改善 \[实验支持\]。

- #strong[指标与方向]：验证损失 (Validation Loss)，交叉熵，越低越好。 #strong[定义与公式]：#strong[无可核验公式]，文中未给出具体计算式。 #strong[实验用途]：贯穿所有规模模型的核心可比较指标，Figure 3/5/6/(私有通道消融图) 均以此为纵轴。 #strong[读数与边界]：7B 在 \#mi(\"p=0.5\") 时略优于基线（1.01→1.00）；130M/1.1B 存在类似\"中等 \#mi(\"p\") 优于基线\"的 U 形趋势 \[实验支持\]。不能证明零样本任务准确率也同步改善（二者为不同指标）。

- #strong[指标与方向]：私有通道缩放因子，无量纲乘数，校正参数无固定优劣。 #strong[定义与公式]：来源层级为#strong[推导关系（非原文公式）]------推理依据：共享通道方差为私有通道的 \#mi(\"r\") 倍（原文给出 \#mi(\"\\mathrm{Var}(Y\_1B\_{11}+Y\_2B\_{12})=2\\sigma\_A^2\")，\#mi(\"\\mathrm{Var}(Y\_1B\_{21})=\\sigma\_A^2\")，页码7）→ 私有通道乘以 \#mi(\"\\sqrt{r}\") 后方差变为 \#mi(\"r\\sigma\_A^2\") 与共享通道一致 → 从而拉齐跨通道方差 \[基于文中逻辑的推断\]。 #strong[实验用途]：说明模块5设计动机。 #strong[读数与边界]：作者称仅带来\"轻微\"改善，非必需。

- #strong[指标与方向]：TTFT (Time-to-First-Token)，推理延迟，越低越好，单位文中未说明。 #strong[定义与公式]：#strong[无可核验公式]，仅描述测量设置（prompt 2K token，不同 batch size）。 #strong[实验用途]：推理速度对比（TP8/16、不同 \#mi(\"p\")、跨硬件）。 #strong[读数与边界]：TP=16、\#mi(\"p=0.25\")、batch=32 时最大加速约 26%；NVIDIA 硬件上最高约 13% \[实验支持\]。

- #strong[指标与方向]：训练吞吐 TPS，越高越好。 #strong[定义与公式]：#strong[无可核验公式]，仅描述测量设置。 #strong[实验用途]：训练加速对比。 #strong[读数与边界]：TP=16 下 \#mi(\"p=0.25\") 提升约14%、\#mi(\"p=0.5\") 提升约9% \[实验支持，但依赖16位反向精度这一非推荐配置\]。

- #strong[指标与方向]：Section 5.3 中的压缩实验 \#mi(\"p\")，激活未被置零的概率，范围 \#mi(\"\[0,1\]\")，自变量。 #strong[定义与公式]：#strong[原文公式（文字定义）]，\"denote by \#mi(\"p\") the probability that an activation is not zeroed\"。 #strong[实验用途]：对比 CAAT-Net 与 Top-K/random mask。 #strong[读数与边界]：小 \#mi(\"p\")（强压缩）时 CAAT-Net 损失显著低于两种压缩基线，\#mi(\"p\\to1\") 时三者趋近 \[实验支持\]。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [流水线（Domino等）], [TP增大时可重叠计算不足；与其他并行方式冲突时无计算可藏], [部分通道归约（模块1）], [无直接联合对比实验------\"无法从当前OCR内容确认\"],
    [压缩通信（Top-K/自编码器）], [轻微压缩即严重降准确率，且增加计算开销], [私有通道本地保留（不压缩）], [Section 5.3/Figure 5，仅130M规模 \[实验支持\]],
    [异步优化（数据并行）], [收敛困难、泛化下降，且问题场景与TP不同], [无直接对应模块], [无对比实验------\"无法从当前OCR内容确认\"],
    [训练后技术（量化等）], [仅覆盖推理阶段], [训练/推理统一的部分同步架构（模块6）], [无直接对比------\"无法从当前OCR内容确认\"],
  )]
  , kind: table
  )

- 表格仅说明当前论文实验设置内谁表现更好，不能证明流水线/异步/量化等方法在所有场景下失效。
- Section 5.3 的压缩基线对比仅在 130M 规模、2.6B token 训练量下进行，远小于 5.1 节 7B 模型的 160B token 规模。

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [7B 模型通信降50%、几乎所有基准无显著下降], [Table 1], [\[实验支持\]，BoolQ 为唯一 marginally significant 例外],
    [中等 \#mi(\"p\") 有时优于全同步基线], [Figure 3 左图], [\[实验支持\]，7B仅一个 \#mi(\"p\") 点，未做完整扫描],
    [反向位置调整+fp32累积为避免发散所必需], [数学推导+Figure 6], [推导\[作者明确陈述\]，Figure 6 直接显示16位累积在15K步后剧烈发散 \[实验支持\]],
    [私有通道缩放非必需], [消融图（页码20）], [\[实验支持\]，差距很小且随 \#mi(\"p\") 增大收窄],
    [CAAT-Net 优于 Top-K/随机掩码], [Figure 5], [\[实验支持\]，仅130M规模],
    [训练/推理加速 9%-26%等], [Figure 4], [\[实验支持\]，训练加速数字为16位精度下的\"performance projection\"，非推荐配置实测],
  )]
  , kind: table
  )

- Table 1 的准确率计算方法本身来自外部框架 lm-eval-harness，论文未重新定义。
- 34B/70B 模型仅测过推理速度，未见准确率评测数据------\"无法从当前OCR内容确认\"。
- GPT3-XL 鲁棒性实验及私有通道消融、fp32/bf16 曲线的具体数字均在未提供的附录中------\"无法从当前OCR内容确认\"。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0008-a4cab5da7676.png", width: 100%)
    #emph[Figure 3: Training accuracy in multiple scenarios. Left. Validation loss of 130M and 1.1B models for different values of , and of the 7B model with , normalized to the loss at . Right. Validation loss for the 130M model with varying values of and tensor-parallel dimension (TP).]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：中等p维持或改善验证损失、退化阈值随TP变化]
    - #strong[图组结论]：130M/1.1B/7B在p≈0.5-0.75损失低于全同步基线;TP越大退化阈值右移

- #strong[论证关系]：支撑\"部分同步可维持甚至改善损失\"核心贡献,为7B选p=0.5/TP=8提供依据

- #strong[适用范围]：仅反映验证损失非零样本准确率;右图参考线含义未标注
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0010-8085d62969b1.png", width: 100%)
    #emph[Figure 4: Speedup in training and inference for a Llama 7B model. Top Left Training speedup for varying values of p and tensor-parallel dimension. Top Right. Inference Time-To-First-Token (TTFT) speedup on different hardware, using batch-size 128. Bottom Left. Inference TTFT speedup using tensor-parallel 8 as a function of batch size, for different values of p. Bottom Right. Inference TTFT speedup using tensor-parallel 16 as a function of batch size, for different values of p.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：训练/推理加速9%-26%等具体数字]
    - #strong[图组结论]：p越小加速越大;Gaudi3低p区间领先H100/A100;TP16、p=0.25在batch=32附近现约26%峰值

- #strong[论证关系]：支撑核心贡献3加速部分,与Table1/Figure3共同构成\"加速且不掉点\"主张,但本图不证明准确率

- #strong[适用范围]：训练加速数字基于16位反向精度非推荐配置,属performance projection;34B/70B数据未含
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_629_976_1006_1180.jpg", width: 100%)
    #emph[Figure 5: Comparison to compression methods. Validation loss vs. p for 130M models using CAAT-Net, Top-k masking and random masking.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：CAAT-Net相对Top-K/随机掩码压缩的优势]
    - #strong[图组结论]：小p强压缩区间CAAT-Net损失显著低于且更平坦于Top-K、随机掩码;p→1时三者趋近

- #strong[论证关系]：直接检验对压缩类相关工作\"轻微压缩即严重降准确率\"的批判,与正文描述互相印证

- #strong[适用范围]：仅130M规模、2.6B token训练量,未覆盖大模型场景;精确数值差距无法读出
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_322_863_903_1154.jpg", width: 100%)
    #emph[Figure 6: Effects of All-Reduce Accumulation Precision in the Backward Pass on TinyLlama Train Loss.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：反向位置调整+fp32累积为避免发散所必需]
    - #strong[图组结论]：训练前15K步三曲线高度重合,之后bfloat16剧烈发散(峰值约8-9),float32与Baseline保持平滑(约2.3-2.5)

- #strong[论证关系]：直接证明模块4 fp32累积的必要性,与Figure2位置调整推导共同构成\"两项调整必需\"证据链

- #strong[适用范围]：未说明该消融实验使用的具体p值------\"文中未说明\"
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_322_148_904_466.jpg", width: 100%)
    #emph[Figure 7: Partial Channel Scaling. Validation loss vs. p for with and without private channel scaling, on a 130M model.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：私有通道缩放带来轻微改善但非必需]
    - #strong[图组结论]：启用/禁用两条曲线形状高度相似,启用组在多数p值上略低,差距很小且随p增大收窄

- #strong[论证关系]：支撑模块5\"轻微改善但非必需\"表述,为工程上禁用缩放换取1-2%速度提升提供依据

- #strong[适用范围]：仅130M模型,未标注张量并行维度,不同TP下是否成立\"文中未说明\"
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1: CAAT-Net vs baseline: Zero-shot accuracy after pretraining. 7B parameter models, with and tensor-parallel 8.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：7B模型通信降50%、几乎所有基准无显著下降]
  - #strong[图组结论]：p=0.5/TP=8下多数基准与基线相当,BoolQ为唯一marginally significant下降项

- #strong[论证关系]：直接支撑\"通信降50%且准确率不降\"核心主张,与Figure3损失证据互补

- #strong[适用范围]：仅7B/TP8/p=0.5设置,准确率计算沿用外部框架lm-eval-harness
  #v(5pt)
  #image("table-groups/page-0008-5e0ccbe02f30.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2: Zero-shot accuracy results on GPT-XL]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：GPT3-XL跨架构鲁棒性实验]
  - #strong[图组结论]：提供GPT3-XL架构上的零样本准确率对照数据

- #strong[论证关系]：补充核心结论的架构鲁棒性证据,与Table1的Llama2结果互补

- #strong[适用范围]：仅覆盖GPT3-XL架构,具体数值未在报告正文中重述
  #v(5pt)
  #image("table-groups/page-0019-cc9473602ec4.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3: Zero-shot accuracy results on TinyLlama for varying values of p]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：中等p维持或改善验证损失（TinyLlama鲁棒性）]
  - #strong[图组结论]：提供TinyLlama在不同p下的零样本准确率对照数据

- #strong[论证关系]：从准确率角度补充检验Figure3左图损失证据反映的中等p趋势

- #strong[适用范围]：仅1.1B TinyLlama规模,具体数值未在报告正文详述
  #v(5pt)
  #image("table-groups/page-0019-f3e6b6155cbb.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 4: Absolute measurements of Llama 70B inference Time-to-First-Token (TTFT) for tensor-parallel 8. Measured in m...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：34B/70B模型仅测速度未测准确率]
  - #strong[图组结论]：给出Llama70B在TP8下不同batch/p的TTFT绝对毫秒数

- #strong[论证关系]：补充Figure4速度趋势的绝对数值,但不涉及准确率验证

- #strong[适用范围]：仅70B/TP8设置,该规模无准确率评测数据
  #v(5pt)
  #image("table-groups/page-0020-ccbede157080.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 5: Absolute measurements of Llama 34B inference Time-to-First-Token (TTFT) for tensor-parallel 8. Measured in m...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：34B/70B模型仅测速度未测准确率]
  - #strong[图组结论]：给出Llama34B在TP8下不同batch/p的TTFT绝对毫秒数

- #strong[论证关系]：与Table4共同补充大模型推理速度的绝对量级证据

- #strong[适用范围]：仅34B/TP8设置,未见对应准确率数据
  #v(5pt)
  #image("table-groups/page-0020-b8424789e8a1.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 6: Absolute measurements of training throughput. Measured in tokens per second (tps) for different tensor-paral...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：TP16下p=0.25/0.5训练吞吐提升14%/9%]
  - #strong[图组结论]：给出不同TP与p下训练吞吐的绝对tokens/s数值

- #strong[论证关系]：为Figure4左上训练加速百分比提供绝对数值依据

- #strong[适用范围]：数字基于16位反向精度,非推荐fp32配置
  #v(5pt)
  #image("table-groups/page-0020-7d9d83291d18.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 7: Absolute measurements of inference Time-to-First-Token (TTFT) for tensor-parallel 16. Measured in millisecon...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：TP16推理batch=32时最大加速约26%]
  - #strong[图组结论]：给出TP16下不同batch/p的TTFT绝对毫秒数

- #strong[论证关系]：为Figure4右下TP16推理加速百分比提供绝对数值基础

- #strong[适用范围]：仅TP16配置,具体硬件文中未逐一说明
  #v(5pt)
  #image("table-groups/page-0021-d8ffb23157ec.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 8: Absolute measurements of inference Time-to-First-Token for tensor-parallel 8. Measured in milliseconds, with...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：TP8推理速度对比]
  - #strong[图组结论]：给出TP8下不同batch/p的TTFT绝对毫秒数

- #strong[论证关系]：为Figure4左下TP8推理加速百分比提供绝对数值基础

- #strong[适用范围]：仅TP8配置,补充相对百分比未含的绝对量级
  #v(5pt)
  #image("table-groups/page-0021-bfca973bae81.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 9: TTFT on H100 and A100. Measured in milliseconds, for different batch sizes and p values.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：NVIDIA硬件上最高约13%加速]
  - #strong[图组结论]：给出H100与A100在不同batch/p下的TTFT绝对毫秒数对比

- #strong[论证关系]：与Figure4右上跨硬件对比互补,提供NVIDIA平台的绝对数值

- #strong[适用范围]：仅H100/A100两种硬件,不含Gaudi3数据
  #v(5pt)
  #image("table-groups/page-0021-284fae4584c0.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：张量并行下激活同步通信是否可能成为训练/推理瓶颈，能否在不牺牲模型质量的前提下降低通信量
  - 旧方法限制：流水线重叠受限于可重叠计算量、与其他并行方式冲突失效；压缩方法损伤准确率；异步优化针对场景不同；训练后技术不覆盖训练阶段
    - 核心洞见/假设：激活完全同步并非训练收敛的必要条件，破坏该前提需配套调整反向传播位置与数值精度
      - 方法模块：部分通道归约（模块1-2）+反向位置调整（模块3）+fp32累积（模块4）+私有通道缩放（模块5）+推理逻辑设备（模块6）
        - 可验证预测：适度降低 \#mi(\"p\") 可维持甚至改善验证损失；不做位置调整/fp32累积会导致发散；缩放非必需；压缩基线效果远逊于CAAT-Net
          - 指标与实验：Table 1（准确率/困惑度）、Figure 3（损失vs p/TP）、Figure 6（精度消融，已被验证）、私有通道消融图（已被验证）、Figure 5（压缩对比，已被验证）、Figure 4（加速，已被验证）
            - 图表证据：见第9节各图组
              - 结论与适用边界：核心结论在7B/1.1B/130M（部分实验）、Gaudi3为主的设置下成立；34B/70B准确率、跨架构鲁棒性具体数字、理论通信降低比例均未被当前证据直接验证------\"无法从当前OCR内容确认\"

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：（1）证明张量并行下LLM训练无需完全同步激活即可收敛；（2）提出CAAT-Net架构通过部分通道归约降低通信；（3）展示其在多设置下同时加速训练与推理且准确率基本持平 \[作者明确陈述\]。

#strong[证据充分的结论]：7B模型在 \#mi(\"p=0.5\")、TP=8 下通信降低、多数基准准确率无显著变化（BoolQ除外）\[实验支持\]；反向位置调整与fp32累积对避免发散是必要的（Figure 6直接证实精度部分）\[实验支持\]；CAAT-Net在小规模模型上优于Top-K/随机掩码压缩 \[实验支持\]。

#strong[尚属推断的意义]：私有通道缩放的\"轻微改善\"在更大模型/不同TP维度下是否同样轻微，缺乏直接证据 \[基于文中逻辑的推断\]；NVIDIA硬件加速可通过软件优化弥补差距为作者推测而非实测。

#strong[适用条件]：结果集中于Transformer架构语言模型预训练（Llama2、TinyLlama、130M自定义、GPT3-XL），硬件覆盖Gaudi3、H100、A100；未讨论其他模型家族或微调/强化学习场景------\"文中未说明\"。

#strong[局限与下一步验证]：训练加速数字基于非推荐的16位反向精度，属\"performance projection\" \[作者明确陈述\]；34B/70B模型缺准确率数据；多项附录细节未提供。

#strong[审稿式风险检查]：

- 贡献新意：核心贡献（打破全同步假设）有明确数学推导与Figure 6实验支持，当前证据未显示该风险。
- 写作/可复现性：代码链接、数据集划分细节均\"文中未说明\"，存在可复现性信息缺口。
- 效果大小：BoolQ的marginally significant下降未被讨论原因，主张\"几乎所有基准无显著下降\"存在一个未解释的例外。
- 实验覆盖：34B/70B仅测速度未测准确率，压缩基线对比仅在130M规模验证，跨规模覆盖不完整。
- 方法设计：私有通道缩放的必要性证据仅限130M模型，未标注TP维度，泛化性未被当前证据完全覆盖。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：张量并行（Tensor-Parallelism）------把权重矩阵切分到多设备分别计算的并行方式。 #strong[第一性原理角色]：受单设备显存约束，用设备间通信换取可训练模型规模。 #strong[本文位置]：论文改造对象，通信瓶颈来源。

- #strong[术语]：All-reduce------多设备各算部分结果后加总并同步回全体。 #strong[第一性原理角色]：连接\"分布式计算的局部结果\"与\"全局一致状态\"这两个基本量，是通信开销的直接来源。 #strong[本文位置]：本文要削减的通信操作对象。

- #strong[术语]：共享通道/私有通道（Shared/Private Channels）------隐藏维度中被归约同步的部分与设备本地保留的部分。 #strong[第一性原理角色]：以通道数比例 \#mi(\"p\") 作为通信量与计算独立性之间的可调约束。 #strong[本文位置]：CAAT-Net架构核心划分。

- #strong[术语]：Forward-backward mismatch------反向传播实现与前向计算在数学上不再等价而导致的错误。 #strong[第一性原理角色]：矩阵乘法分配律在\"全同步\"前提下保证归约位置可互换，前提被打破后该互换性失效。 #strong[本文位置]：模块3调整反向all-reduce位置所要修复的问题。

- #strong[术语]：fp32梯度累积------归约求和时以32位精度进行数值累加。 #strong[第一性原理角色]：受浮点数值误差累积约束，精度不足会在训练后期引发发散。 #strong[本文位置]：模块4，消除16位累积导致的收敛差距。

- #strong[术语]：逻辑设备（Logical Devices）------单个物理设备顺序模拟多个训练时的并行设备。 #strong[第一性原理角色]：解决训练/推理并行维度不一致时的状态映射问题。 #strong[本文位置]：模块6，推理阶段部署机制。

- #strong[术语]：TTFT（Time-to-First-Token）------生成第一个输出token所需延迟。 #strong[第一性原理角色]：连接\"计算+通信总耗时\"与\"用户可感知响应速度\"。 #strong[本文位置]：推理加速评测指标。

=== 12.2 学习路径
<122-学习路径>
+ #strong[矩阵乘法与分配律]：理解\"求和位置可互换\"这一性质，是理解模块3为何在全同步/部分同步下行为不同的前提。
+ #strong[分布式训练中的显存-通信权衡]：理解为什么要切分权重矩阵到多设备，才能理解张量并行存在的意义与代价。
+ #strong[浮点数值精度与误差累积]：理解16位与32位精度的差异，才能理解模块4为何是必要而非可选项。
+ #strong[验证损失/困惑度/零样本准确率的关系]：三者从不同角度衡量语言模型质量，是读懂Table 1与Figure 3证据边界的前提。
+ #strong[通信带宽 vs 算力增长的工程背景]：作为背景知识，帮助理解论文反复强调的\"通信可能反超计算\"这一根问题动机。
