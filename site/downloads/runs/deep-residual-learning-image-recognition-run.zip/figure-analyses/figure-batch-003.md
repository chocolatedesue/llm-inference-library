# 图片批次 3

## 图片 1：Figure 5. A deeper residual function for ImageNet. Left: a building block (on feature maps) as in Fig. 3 for ResNet-34. Right: a “bottleneck” building block for ResNet-50/101/152.

![Figure 5. A deeper residual function for ImageNet. Left: a building block (on feature maps) as in Fig. 3 for ResNet-34. Right: a “bottleneck” building block for ResNet-50/101/152.](../assets/imgs/img_in_image_box_666_142_1071_285.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：本图属于"方法流水线"类证据，展示第 3.3/4.1 节中为控制深层网络训练时间而引入的"瓶颈"（bottleneck）结构设计，回答的是"如何在增加深度（50/101/152 层）的同时控制计算复杂度"这一工程问题，并直接支撑"identity shortcut 对瓶颈结构效率尤为关键"这一论点 [正文支持]。
   - **图表角色**：方法流水线（兼有消融验证背景，因其与 Fig.3 的 2 层 block 构成对照）。
   - **上文呼应**：对应"模块 4：深层瓶颈结构（Bottleneck，50/101/152 层）"及第 6 页正文"Deeper Bottleneck Architectures"段落。

2. **图像类型与布局**：示意图（网络模块结构图），左右两个 Panel 并列。左侧为 2 层残差块（对应 ResNet-34 的常规 building block），右侧为 3 层瓶颈残差块（对应 ResNet-50/101/152）。每个 Panel 内为纵向堆叠的矩形层框，配合箭头表示前向数据流，底部有 "+" 圆圈表示逐元素相加，右侧有从输入直接弯折连到相加节点的曲线箭头（shortcut）。

3. **如何阅读**：从每个 Panel 顶部输入（标注通道数 "64-d" / "256-d"）沿箭头往下读各层（层框内标注卷积核尺寸与通道数，如 "3x3, 64"、"1x1, 64"），层间标注 "relu" 表示激活；最右侧的曲线箭头是从输入端跳过中间层，直接连到底部 "+" 节点，代表 identity shortcut；相加后再经一次 "relu" 输出。左右两个 Panel 应横向对比，看层数、每层通道数及输入输出维度是否一致。

4. **直接可见的结论**：左侧 Panel 为两层结构，输入输出均为 64 维，层依次为 "3x3, 64" → relu → "3x3, 64"，随后与输入相加再 relu；右侧 Panel 为三层结构，输入输出均为 256 维，层依次为 "1x1, 64" → relu → "3x3, 64" → relu → "1x1, 256"，随后与输入相加再 relu；两个 Panel 中 shortcut 均未标注任何卷积核或参数，仅为一条跳过中间层直连到 "+" 的曲线 [图像直接可见]。右侧 Panel 中间层（"3x3, 64"）的输入输出通道数（64）明显小于该模块整体输入输出通道数（256）[图像直接可见]。

5. **它验证的论点与方法设计含义**：该图属于机制/方法设计类证据，直观印证正文所述瓶颈结构"1×1（降维）→3×3（低维卷积）→1×1（恢复维度）"的具体实现方式，以及"两种设计具有相近时间复杂度"的表述——图中可见右侧瓶颈结构虽多一层，但通过先将 256 维降到 64 维再做 3×3 卷积、最后恢复到 256 维，使得计算量集中在低维空间 [正文支持]。同时，图中 shortcut 均直接连接模块两端的高维输入输出（64-d 与 256-d），未见任何卷积/投影标注，这与正文"identity shortcut 连接在两个高维端"、"若替换为投影会使该处时间复杂度和模型大小翻倍"的论证在结构上对应一致 [正文支持]。该图不能单独证明"投影会使复杂度翻倍"这一具体数值结论，该结论来自正文的计算推导而非图本身可见内容 [正文支持]。

6. **适用范围与证据缺口**：本图为 ImageNet 上 ResNet-34（2 层块）与 ResNet-50/101/152（3 层瓶颈块）所用模块的示意图，覆盖论文 3.3/4.1 节所描述的架构设计范围。无额外证据缺口。

---

## 图片 2：Figure 7. Standard deviations (std) of layer responses on CIFAR-10. The responses are the outputs of each layer, after BN and before nonlinearity. Top: the layers are shown in their original order. Bottom: the responses are ranked in descending order.

![Figure 7. Standard deviations (std) of layer responses on CIFAR-10. The responses are the outputs of each layer, after BN and before nonlinearity. Top: the layers are shown in their original order. Bottom: the responses are ranked in descending order.](../assets/imgs/img_in_chart_box_118_420_553_653.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图属于"机制"类证据（兼具对比基线/消融验证性质），用于回答"残差学习为何在优化上更容易"这一核心假设是否有实验支持——具体验证第 3.1 节提出的假设："若恒等映射接近最优，残差函数的响应值应普遍偏小"，即为核心洞见提供间接的定量佐证 [正文支持]。
   - **图表角色**：机制（核心假设的实验支持），同时隐含 plain vs. ResNet 的对比基线角色。
   - **上文呼应**：对应第 8 节"Analysis of Layer Responses"，呼应"核心洞见与假设"中"Fig.7 显示学习到的残差函数普遍响应值较小，支持'恒等映射提供了合理预处理'这一假设"的主张 [页码：3, 8]。

2. **图像类型与布局**：折线图，上下两个 Panel 纵向排列，共享纵轴含义（std，标准差）与相同的图例（plain-20、plain-56、ResNet-20、ResNet-56、ResNet-110，以不同颜色/线型区分：黄色虚线、红色虚线、黄色实线、红色实线、黑色实线）。上方 Panel 横轴为 "layer index (original)"（原始层顺序），下方 Panel 横轴为 "layer index (sorted by magnitude)"（按响应幅度降序排列后的层序）。

3. **如何阅读**：纵轴为各 3×3 卷积层在 BN 之后、非线性之前输出的标准差（std），数值范围约 0～3；横轴为层序号（0 至 100+）。上方 Panel 按网络中层的实际先后顺序展示各层响应标准差的波动；下方 Panel 将同一组数据按响应幅度从大到小重新排序，便于比较不同网络整体的响应幅度分布/衰减趋势。应比较的是：同一层序位置或排序位置上，plain 网络（虚线）与对应深度 ResNet（实线）的 std 曲线高低，以及不同深度 ResNet（20/56/110）之间 std 曲线的相对位置。

4. **直接可见的结论**：在上方 Panel 中，黄/红色虚线（plain-20、plain-56）整体波动幅度较大且部分区段处于较高 std 水平（部分峰值接近或超过 2），而黑色实线（ResNet-110）在多数区段维持在较低且相对平稳的 std 水平（多数低于 1，末端有一处上翘）[图像直接可见]。在下方排序后的 Panel 中，各曲线均呈现从左侧较高值（约 2～3）向右侧迅速下降并趋于较低水平的整体递减趋势，其中黑色曲线（ResNet-110）下降更快、在多数排序位置上位于其余曲线下方或与之接近的较低水平，而黄色虚线（plain-20）在下降后段仍维持相对更高的 std 直至该曲线末端截止 [图像直接可见]。ResNet-20（黄色实线）与 ResNet-56（红色实线）曲线在图中长度覆盖范围小于 ResNet-110（黑色实线），符合各自实际层数由少到多的顺序 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图为"核心洞见与假设"部分的关键实验支持——图中 ResNet 曲线（尤其是层数更深的 ResNet-110，黑色实线）相对 plain 网络曲线呈现出更低、更快衰减的响应标准差，这与正文"ResNets have generally smaller responses than their plain counterparts"及"deeper ResNet has smaller magnitudes of responses"的文字描述在视觉上一致，从而为"残差函数的响应值普遍偏小，恒等映射提供了合理预处理"这一假设提供间接、描述性的支持 [正文支持]。需要注意，该图仅是**关联性观察**（响应幅度小），并不能证明"为何更小的响应就等价于优化更容易"这一因果机制，正文本身也仅将其列为支持性证据（"support our basic motivation"），而非严格证明 [正文支持]。

6. **适用范围与证据缺口**：本图数据来自 CIFAR-10 数据集上训练的 plain-20/56 与 ResNet-20/56/110 五个模型，覆盖论文 4.2 节所述的 CIFAR-10 实验设置，不代表 ImageNet 或其他数据集上的层响应行为。真实证据缺口：图中曲线颜色/线型交叠密集（尤其上方 Panel 中黄/红色曲线在多处重叠），部分区段哪条曲线对应哪个模型无法精确逐点区分，只能依据图例大致辨认整体趋势与色系归属；此外图中纵轴、横轴均无具体数值刻度标签（如具体 std 数值或层序号数值)以外的精细读数，无法读出精确数值，只能做趋势级判断。
