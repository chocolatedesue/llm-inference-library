# 图片批次 2

## 图片 1：Figure 3. Example network architectures for ImageNet. Left: the VGG-19 model [41] (19.6 billion FLOPs) as a reference. Middle: a plain network with 34 parameter layers (3.6 billion FLOPs). Right: a residual network with 34 parameter layers (3.6 billion FLOPs). The dotted shortcuts increase dimensions. Table 1 shows more details and other variants.

![Figure 3. Example network architectures for ImageNet. Left: the VGG-19 model [41] (19.6 billion FLOPs) as a reference. Middle: a plain network with 34 parameter layers (3.6 billion FLOPs). Right: a residual network with 34 parameter layers (3.6 billion FLOPs). The dotted shortcuts increase dimensions. Table 1 shows more details and other variants.](../assets/imgs/img_in_image_box_96_153_581_1233.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：这是方法流水线类证据，展示模块 3（Plain/Residual 网络架构设计）的具体实现方式，用于解释残差学习重构如何被物理地嵌入到与 VGG 风格设计规则一致的 34 层网络中，并与 VGG-19、34 层 plain 网络做结构层面的三方对照，为后续 Table 2/Fig.4 的"相同深度/参数量下 plain vs. ResNet"实验提供架构基础 [正文支持]。
   - **图表角色**：方法流水线（同时兼具对比基线，因为并列展示了 VGG-19 作为复杂度参照）。
   - **上文呼应**：对应第 3.3 节"Network Architectures"，是"核心贡献 1（残差重构与 identity shortcut 实现）"与"模块 3（Plain/Residual 网络架构设计）"的直接图示，也是"34 层 plain 基线仅为 VGG-19 FLOPs 18%"这一复杂度主张的结构性证据 [正文支持][页码：3-4]。

2. **图像类型与布局**：三列并排的网络结构示意图（流程图式方框图），从上到下按前向传播顺序排列，每个方框代表一层或一次操作。左列为 VGG-19，中列为 34 层 plain 网络，右列为 34 层残差网络。方框按不同 feature map 尺寸阶段用不同底色分组（白/蓝/绿/粉/灰等），右列在若干层之间额外画出弧形箭头（跳跃连接）连接非相邻层 [图像直接可见]。

3. **如何阅读**：纵向阅读顺序即为网络的前向计算顺序；每个方框内文字标注卷积核大小与通道数（如"3x3 conv, 64"）及降采样标注（"/2"）；左侧文字标注各阶段的 output size（224→112→56→28→14→7→1）。三列之间应横向比较同一深度阶段的层设计是否一致，重点关注右列中连接跳过若干层的弧线（实线与虚线两种）[图像直接可见]。

4. **直接可见的结论**：
   - VGG-19 在 224 尺寸阶段起始为两次 3×3/64 卷积，随深度增加通道数逐级翻倍（64→128→256→512），并使用全连接层（4096, 4096, 1000）作为分类头 [图像直接可见]。
   - 34 层 plain 网络与 34 层残差网络在卷积层配置（种类、数量、通道数、降采样位置）上完全一致，唯一差异是残差网络额外叠加了跳跃连接弧线；分类头均为 avg pool + fc 1000，无 VGG 式大型全连接层 [图像直接可见]。
   - 残差网络中的跳跃连接绝大多数为实线弧形（连接维度相同的层），但在每次通道数翻倍/尺寸减半处（如 64→128、128→256、256→512 的过渡点）跳跃连接改为虚线 [图像直接可见]。
   - 相比 VGG-19 的两次连续 3×3 全连接式深层堆叠及最终三层全连接（4096/4096/1000），plain/residual 网络在每个尺寸阶段的卷积层数量明显更多但通道数更保守（不含 4096 维全连接层）[图像直接可见]。

5. **它验证的论点与方法设计含义**：图像证实了正文对三种架构"仅跳跚连接一项差异"的文字描述——34 层 plain 与 34 层 residual 在层类型、层数、通道配置上逐层一致，肉眼可见的唯一区别就是弧形跳跃连接的有无，这为"公平对照组"这一实验设计前提（模块 3 动机：控制深度/宽度/参数量相同以隔离残差学习本身效果）提供了直接的结构验证，属于方法设计的必要性证据 [正文支持]。图中虚线跳跃连接的位置与正文"当维度增加时（虚线快捷连接）需要采用选项 A/B 处理维度不匹配"的表述一致，验证了模块 2（Identity Shortcut 与维度匹配）中"实线=identity、虚线=需要处理维度变化"的设计描述 [正文支持][页码：3-4]。VGG-19 与 plain-34/residual-34 并列展示，直观支持了正文"34 层 plain 基线仅为 VGG-19 FLOPs 18%"这一复杂度对比主张的结构成因（层通道数更保守、无大型全连接层）[基于文中逻辑的推断]。但本图本身不包含任何训练/测试误差数值，不能用于验证"残差网络更易优化"或"精度提升"这类效果主张，这些需依赖 Table 2/Fig.4（即图片 2）。

6. **适用范围与证据缺口**：本图覆盖论文报告的 ImageNet 34 层 plain/residual 架构与作为复杂度参照的 VGG-19 结构，是 3.3 节明确描述的具体实例（"we describe two models for ImageNet as follows"），不代表 18/50/101/152 层等其他深度变体的结构（这些细节在 Table 1 中以文字/表格形式给出，非本图内容）。无额外证据缺口。

---

## 图片 2：Figure 4. Training on ImageNet. Thin curves denote training error, and bold curves denote validation error of the center crops. Left: plain networks of 18 and 34 layers. Right: ResNets of 18 and 34 layers. In this plot, the residual networks have no extra parameter compared to their plain counterparts.

![Figure 4. Training on ImageNet. Thin curves denote training error, and bold curves denote validation error of the center crops. Left: plain networks of 18 and 34 layers. Right: ResNets of 18 and 34 layers. In this plot, the residual networks have no extra parameter compared to their plain counterparts.](../figure-groups/page-0005-8b18d192417e.png)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：这是效果类的实验结论证据，直接验证第 4.1 节的核心主张——"退化问题是否被残差学习解决"以及"残差网络是否比 plain 网络更易优化"。左 Panel 对应 plain-18/34 的训练/验证误差曲线，用于展示退化问题在 plain 网络上的真实存在；右 Panel 对应 ResNet-18/34 的对应曲线，用于展示该问题在残差框架下是否消失 [正文支持]。
   - **图表角色**：实验结论（同时承担对比基线角色，因为左右两 Panel 分别是 plain 与 ResNet 的直接对照）。
   - **上文呼应**：对应第 4.1 节"Plain Networks"与"Residual Networks"两段，是"核心贡献 2（ImageNet 受控实验证明 ResNet 更易优化且能从深度获益）"与 Table 2 数值结果的曲线化呈现 [正文支持][页码：5]。

2. **图像类型与布局**：两个并排的折线图（训练曲线）。横轴为迭代次数（iter.,单位 1e4），纵轴为误差（error,%）。每个 Panel 内有 4 条曲线：细线代表训练误差，粗线代表验证误差；青色代表 18 层网络，红色代表 34 层网络。左 Panel 标题为"plain-18/plain-34"，右 Panel 为"ResNet-18/ResNet-34" [图像直接可见]。

3. **如何阅读**：横向对比左右两 Panel 中红色（34 层）曲线相对青色（18 层）曲线的位置关系；纵向看曲线随迭代次数的下降趋势及在约 3×10^5 迭代处的台阶式下降（对应学习率衰减节点）。粗细线区分训练/验证误差，二者越接近说明泛化差距越小 [图像直接可见]。

4. **直接可见的结论**：
   - 左 Panel（plain）：全程红色（34 层）曲线的细线（训练误差）都高于青色（18 层）细线，即使在训练后期两者都趋于平稳，红色训练误差仍明显更高；红色粗线（34 层验证误差）也高于青色粗线（18 层验证误差）[图像直接可见]。
   - 右 Panel（ResNet）：情况反转，红色（34 层）细线（训练误差）在训练后期低于青色（18 层）细线；红色粗线（34 层验证误差）也低于青色粗线（18 层验证误差）[图像直接可见]。
   - 两个 Panel 中 34 层曲线在训练初期（前 15×10^4 迭代内）均有明显波动/更高误差尖峰，但右 Panel 中该阶段红色与青色曲线更贴近，收敛也更快，早期误差下降更平滑 [基于视觉的谨慎推断]。
   - 两个 Panel 均在约 15×10^4 与 30×10^4 迭代处出现台阶式误差骤降，形态一致 [图像直接可见]。

5. **它验证的论点与方法设计含义**：本图是"深度增加是否导致训练误差上升（退化问题）"这一核心限制的直接可视证据：左 Panel 显示 plain-34 训练误差全程高于 plain-18，与正文"adding more layers... leads to higher training error"的文字描述完全吻合，属于机制性主张的实验支持 [正文支持]。右 Panel 显示这一关系在 ResNet 下反转，34 层训练误差低于 18 层，直接支持"残差重构缓解退化问题"这一核心贡献的效果主张，也是 Table 2 中 34 层 ResNet top-1 error（25.03%）优于 18 层 ResNet（27.88%）背后的训练动态证据 [正文支持]。左右两图中 18 层曲线本身（plain-18 vs ResNet-18 精度接近但 ResNet 收敛更快）与正文"18-layer plain/residual nets are comparably accurate ... but ResNet converges faster"的表述相符，支持"当网络不算太深时，ResNet 的优势主要体现在收敛速度而非最终精度"这一细化结论 [正文支持]。需要注意，本图本身不包含梯度范数、损失曲面等信息，不能单独证明"退化问题非梯度消失所致"这一机制排除性主张，该论证依赖正文单独的梯度范数验证陈述 [正文支持][页码：5]。

6. **适用范围与证据缺口**：本图覆盖论文报告的 ImageNet 数据集上 18/34 层 plain 与 ResNet（均使用 option A 恒等快捷、10-crop 相关训练设置）的训练过程曲线，不涉及 50/101/152 层或 CIFAR-10 实验（对应 Fig.6）。真实缺口：图中曲线的具体数值刻度较密且粗细线在训练后期高度重叠，无法从像素上精确读出某一迭代点的具体误差数值（仅可判断相对大小与趋势），此为图像分辨率导致的可辨识度限制。
