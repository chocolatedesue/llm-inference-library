# 图片批次 1

## 图片 1：Figure 1. Training error (left) and test error (right) on CIFAR-10 with 20-layer and 56-layer "plain" networks. The deeper network has higher training error, and thus test error. Similar phenomena on ImageNet is presented in Fig. 4.

![Figure 1. Training error (left) and test error (right) on CIFAR-10 with 20-layer and 56-layer "plain" networks. The deeper network has higher training error, and thus test error. Similar phenomena on ImageNet is presented in Fig. 4.](../figure-groups/page-0001-a500175bbc69.png)

*来源：OCR 第 1 页。*

### 解读

1. **论文角色与验证问题**：本图对应"旧方法的限制"中的核心限制——退化问题（degradation problem），证据类型为**问题严重性**。作者需要用它直接展示"更深的 plain 网络训练误差反而更高"这一反直觉现象，为后文引入残差学习框架提供最初的经验驱动 [正文支持]。
   - **图表角色**：`问题严重性`
   - **上文呼应**：对应"根问题与重要性"及"旧方法的限制—限制二"，即第 1 页 Introduction 部分对退化问题的首次呈现 [页码：1]。

2. **图像类型与布局**：曲线图，两个并列子图（Panel 1、Panel 2）。左图纵轴为 training error (%)，右图纵轴为 test error (%)，两图横轴均为 iter.(1e4)（训练迭代数，单位万次）。每个子图内有两条曲线：黄绿色标注"20-layer"，红色标注"56-layer"。

3. **如何阅读**：横轴表示训练迭代进程（0 到约 6×10⁴ 次），纵轴表示误差百分比（0–20%）。应比较同一子图内红色（56 层）与黄绿色（20 层）曲线在训练过程中的相对高低及收敛趋势；左右两图分别对应训练误差和测试误差，应对照观察同一模型在两个子图中的表现是否一致。

4. **直接可见的结论**：左图（训练误差）中，红色 56 层曲线在整个训练过程中持续高于黄绿色 20 层曲线，即使到训练后期两者都趋于平稳，56 层的训练误差仍明显更高；右图（测试误差）呈现相同模式，56 层曲线始终位于 20 层曲线上方 [图像直接可见]。两条曲线都在约 3×10⁴ 次迭代处出现明显的阶梯式下降（对应学习率衰减）[图像直接可见]。

5. **它验证的论点与方法设计含义**：该图属于**问题严重性**类证据，直接支撑正文所述"56 层 plain 网络训练误差高于 20 层，进而导致测试误差也更高"的论断 [正文支持][页码：1]。它验证的是退化问题的存在性本身——即更深网络的训练误差不降反升，且这种上升在测试集上同样体现，从而排除了"仅仅是过拟合"的简单解释（因为过拟合通常表现为训练误差低而测试误差高，此处训练误差本身就更高）。该图不能证明退化问题的根本机制（是否为梯度消失或收敛速率问题），这一点作者留待正文其他部分论证（见"梯度消失"排除性论证，页码 5），本图本身只呈现现象，不解释成因。

6. **适用范围与证据缺口**：本图覆盖的实验设置为 CIFAR-10 数据集上 20 层与 56 层"plain"（无残差连接）网络的对照训练曲线 [正文支持][页码：1]。无额外证据缺口。

---

## 图片 2：Figure 2. Residual learning: a building block.

![Figure 2. Residual learning: a building block.](../assets/imgs/img_in_image_box_191_156_467_307.jpg)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：本图对应"核心洞见与假设"及"方法推理树—模块 1：残差学习重构"，证据类型为**方法流水线**。作者需要用它具象化残差学习的基本构建单元（building block），即如何通过 shortcut connection 把恒等映射 x 与堆叠层学到的残差 F(x) 相加，实现 Eqn.(1) 所述 y = F(x)+x [正文支持]。
   - **图表角色**：`方法流水线`
   - **上文呼应**：对应第 2 页 Section 2 末与第 3 页 Section 3.1/3.2 关于残差学习重构与 identity shortcut 的方法定义 [页码：2-3]。

2. **图像类型与布局**：示意图（网络结构框图），非曲线或表格。图中从上到下依次为：输入 x → weight layer → relu → weight layer → 一个圆形加号节点（⊕）→ relu 输出；同时有一条从 x 引出、绕过两层 weight layer 直接连到加号节点的曲线箭头，标注为"x identity"；加号节点左侧标注"F(x)+x"，左上角标注"F(x)"指代两层 weight layer+relu 支路的输出。

3. **如何阅读**：应沿主干路径（左侧竖直方向）阅读堆叠的两个 weight layer 与中间的 relu，代表学习残差函数 F(x) 的非线性变换支路；再对照右侧弧形箭头所示的"identity"旁路，理解该旁路直接将输入 x 跳过两层送到加号节点；两条支路在⊕处相加后再经过一次 relu 输出，对应文字中 y=F(x)+x 之后"再做一次非线性激活"的说明。

4. **直接可见的结论**：图中清晰显示输入 x 同时进入两条路径——一条经过两层 weight layer 和一次 relu（生成 F(x)）,另一条通过一条不含任何权重层标注的曲线箭头直接跳到加号节点（"x identity"），两条路径在⊕处相加，得到 F(x)+x，再经过一次 relu 输出 [图像直接可见]。旁路箭头上未标注任何权重符号或运算模块 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图属于**方法流水线**类证据，具体呈现了 Eqn.(1) y=F(x,{Wᵢ})+x 的结构实现方式 [正文支持][页码：3]。它直接支持"identity shortcut 不引入额外参数和计算复杂度"这一技术优势描述——图中旁路箭头未附加任何权重层标注，与正文"identity shortcut connections add neither extra parameter nor computational complexity"一致 [正文支持][页码：2]。该图仅展示两层（two-layer）残差块的示意结构，对应正文中 F=W₂σ(W₁x) 的具体二层情形；它不能证明"残差学习更易优化"这一核心假设本身（该假设的实验支持来自 Table 2、Fig.4、Fig.7 等其他证据），本图只是该方法模块的结构定义图示，不承载效果或机制验证的实验数据。

6. **适用范围与证据缺口**：本图展示的是论文中作为讨论示例的**两层**残差构建块（对应 ResNet-34 及更浅层网络中使用的基本单元），并非 50/101/152 层所用的三层瓶颈结构（后者见 Fig.5）[正文支持][页码：3]。无额外证据缺口。
