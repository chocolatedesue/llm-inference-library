# 图片批次 4

## 图片 1：Figure 6. Training on CIFAR-10. Dashed lines denote training error, and bold lines denote testing error. Left: plain networks. The error of plain-110 is higher than 60% and not displayed. Middle: ResNets. Right: ResNets with 110 and 1202 layers.

![Figure 6. Training on CIFAR-10. Dashed lines denote training error, and bold lines denote testing error. Left: plain networks. The error of plain-110 is higher than 60% and not displayed. Middle: ResNets. Right: ResNets with 110 and 1202 layers.](../figure-groups/page-0008-b5a2900e95e2.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：这是一组三联曲线图（对应正文 Figure 6，"Training on CIFAR-10"），是论文在 CIFAR-10 数据集上对"退化问题"与"残差学习有效性"这一核心机制/效果主张所做的重复验证，同时补充了对"极深网络（超过 1000 层）"适用边界的观察。其证据类型兼具：(a) 问题严重性——用 plain 网络的多个深度（20/32/44/56 层）再次展示退化问题并非 ImageNet 特例；(b) 实验结论/效果主张——ResNet 在相同深度范围内不再出现退化，且能从深度获益；(c) 适用边界——110 层与 1202 层 ResNet 对比揭示极深网络在小数据集上的新问题（过拟合迹象）。`[正文支持]`
   - **图表角色**：`问题严重性`（Panel 1）+ `实验结论`（Panel 2）+ `适用边界`（Panel 3）。
   - **上文呼应**：对应"4.2 CIFAR-10 and Analysis"一节；呼应"旧方法的限制"中退化问题的跨数据集验证（"Similar phenomena are also shown on the CIFAR-10 set...suggesting that the optimization difficulties...are not just akin to a particular dataset"，页码 2），以及"局限"部分中 1202 层测试误差差于 110 层、作者归因于过拟合的主张（页码 8）。

2. **图像类型与布局**：三个独立的折线曲线图（error vs. iteration）并排/分行排布。Panel 1（左上）标题隐含"plain networks"，含 plain-20/32/44/56 四条颜色曲线（黄、青、绿、红），每条深度对应细线（训练误差）与粗线（测试误差）两条曲线；图中用虚线横向标出 "20-layer" 与 "56-layer" 两条水平参考线。Panel 2（右上）为 ResNet-20/32/44/56/110 五条颜色曲线（棕、青、绿、红、黑），同样细线/粗线区分，横向虚线标出 "20-layer" 与 "110-layer" 参考线。Panel 3（左下）仅两条曲线：residual-110（黑）与 residual-1202（品红），聚焦在训练后期（iter. 约 3.5×10^4 之后）的误差走势，纵轴范围与上方一致（0–20%）。所有子图横轴均为 "iter. (1e4)"，纵轴均为 "error (%)"，量程 0–20%。

3. **如何阅读**：横轴为训练迭代次数（单位 1万次），纵轴为误差百分比；按图注（正文 Figure 6 caption）细线/虚线样式代表训练误差，粗线/实线样式代表测试误差。Panel 1 应比较不同深度 plain 网络之间、以及同一深度网络训练误差与测试误差之间的相对高低；重点关注 56 层是否高于 20 层。Panel 2 做同样比较但针对 ResNet 系列，重点关注更深的 110 层是否仍能与/优于 20 层。Panel 3 应比较 110 层与 1202 层两个 ResNet 在训练收敛后期的误差水平差异。

4. **直接可见的结论**：
   - Panel 1 中，plain-56（红色）在训练后期的两条曲线（细线训练误差、粗线测试误差）均明显高于 plain-20（黄色），与图右侧 "56-layer" 参考线高于 "20-layer" 参考线一致；深度更大的 plain-32、plain-44 也整体处于 20 层之上、56 层之下或相近的区间。`[图像直接可见]`
   - Panel 2 中，各深度 ResNet（20/32/44/56/110 层）曲线在训练后期高度重叠、收敛到相近且更低的误差水平，"110-layer" 参考线低于 "20-layer" 参考线，未见类似 Panel 1 中深度越大误差越高的分层现象。`[图像直接可见]`
   - Panel 3 中，residual-1202（品红）曲线在展示区间内持续位于 residual-110（黑）曲线上方，即 1202 层网络的（测试）误差始终略高于 110 层网络。`[图像直接可见]`
   - 三图整体的误差骤降均出现在约 iter=3×10^4 附近，与学习率衰减节点在视觉上对应。`[基于视觉的谨慎推断]`（图中未标注具体衰减点，仅从曲线突降形态推断）

5. **它验证的论点与方法设计含义**：Panel 1 直接支持"旧方法的限制"中的核心限制二——退化问题，并将其从 ImageNet（Fig.1 的 20 vs 56 层）扩展到 CIFAR-10 的多个深度梯度（20/32/44/56 层），强化"这一优化困难是跨数据集的普遍现象"这一适用范围主张（"suggesting that such an optimization difficulty is a fundamental problem"，页码 7）。Panel 2 直接支持核心贡献 2——残差学习使深度增加不再导致训练误差上升，是"效果主张"在 CIFAR-10 上的复现，与 ImageNet 上 Table 2/Fig.4 的结论一致，共同构成"深度残差网络更易优化"的跨数据集证据链。Panel 3 支持"局限、缺失信息与适用边界"部分的机制性主张：110 层与 1202 层训练误差相近但测试误差 1202 层更高，作者据此推断为过拟合而非优化困难（页码 8），本图为该文字论断提供了可视化的曲线证据（尽管该图仅显示后段误差走势，不能单独证明"过拟合"这一因果解释，只能证明"两者测试误差存在差距"这一现象）。三个 Panel 均不能反映具体的架构细节、参数量或计算复杂度对比，这些信息由 Table 6（文字/表格）提供。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文 4.2 节所述 CIFAR-10 实验设置——plain/ResNet 分别为 20/32/44/56 层（n=3,5,7,9），以及 110 层（n=18）与 1202 层（n=200）ResNet，训练集 5 万张、测试集 1 万张，mini-batch 128，双 GPU，学习率 0.1 起始并按文中所述节点衰减（页码 7-8）。真实证据缺口：Panel 3 的横轴范围明显被截断（仅显示约 3.5×10^4 之后的区间，未展示 0 到 3.5×10^4 的完整训练前段曲线），无法从该图判断 110 层与 1202 层在训练早期（含学习率 warm-up 阶段）的误差行为，只能观察训练中后段的相对高低；Panel 1、2 的纵轴上限为 20%，若存在超出该范围的早期峰值（如 plain-56 是否曾高于 20%）无法从图中确认。
