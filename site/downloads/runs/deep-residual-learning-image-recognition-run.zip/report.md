# 论文解构报告

### 论文元数据

| 字段 | 内容 |
|---|---|
| 标题 | Deep Residual Learning for Image Recognition |
| 作者 | Kaiming He, Xiangyu Zhang, Shaoqing Ren, Jian Sun |
| 发表场所 / 年份 | 文中未说明 |
| 研究领域 | 计算机视觉、深度学习 |
| 关键词 | 深度学习, 残差网络, 图像分类, 卷积神经网络, ImageNet |

### 资源链接

- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

> **标签（3–5 个）**：`残差学习` · `深度神经网络` · `图像分类` · `目标检测` · `退化问题`

## 1. 一句话总览

本文提出深度残差学习框架，让堆叠层学习相对于输入的残差映射 $\mathcal{F}(\mathbf{x}) := \mathcal{H}(\mathbf{x}) - \mathbf{x}$ 而非直接学习目标映射，以解决极深网络的"退化问题"（训练误差随深度增加不降反升）[作者明确陈述][页码：1-2]，最终在 ImageNet 上用 152 层网络取得单模型 top-5 验证误差 4.49%、六模型集成 3.57% 的测试误差，并在检测/分割任务上取得显著泛化提升 [实验支持][页码：7-8]。

## 2. 阅读范围与证据状态

OCR 覆盖正文第 1–8 页的引言、方法、ImageNet/CIFAR-10 实验及检测任务迁移部分，包含 Fig.1、Fig.3（结构示意）、Fig.4、Fig.5（瓶颈块）、Fig.6、Fig.7 共 4 组图片批次的证据分析。检测任务（第 4.3 节）具体实现方法注明"见 appendix"，但本 OCR 材料不含 appendix，因此 Faster R-CNN 具体改造方式、ImageNet 定位/COCO 分割细节均"无法从当前 OCR 内容确认"[页码：8]。多个关键指标（top-1/top-5 error、mAP、FLOPs）文中只报告数值，未给出计算公式本身。以上限制均已在正文相应处标注证据类型区分论文事实与背景知识。

## 3. 根问题：论文究竟要解决什么

深度对视觉识别至关重要——层数越多理论上能提炼越丰富的特征层级 [作者明确陈述][页码：1]，由此产生根问题："学习更好的网络是否就是简单地堆叠更多层？"[作者明确陈述][页码：1] 这个问题重要，是因为若深度可无限堆叠且总能带来收益，分类、检测、分割、定位等一系列视觉任务都可能从"更深"这一简单杠杆获得系统性提升，当时最领先的 ImageNet 结果已普遍依赖 16~30 层的"very deep"模型 [作者明确陈述][页码：1]。

难点在于：深层网络一度受梯度消失/爆炸阻碍训练收敛（好比"传声筒游戏"信息传递失真），这一问题已被归一化初始化和 BN 层较大程度解决 [作者明确陈述][页码：1]；但当网络能够开始收敛后，又出现了训练误差本身随深度增加而上升的"退化问题"，且这一现象不能用过拟合解释 [作者明确陈述][实验支持][页码：1]。

本文的 story：旧路线在"用非线性堆叠层直接逼近目标映射"这一优化路径上失效——求解器难以让多层非线性网络逼近恒等映射；本文的核心转折是把学习目标重构为残差 $\mathcal{F}(\mathbf{x})+\mathbf{x}$，使恒等映射对应"把权重推向零"这一更易达成的解，从而让深度成为可自由扩展的资源而非风险。

## 4. 旧方法为何不够

- 梯度消失/爆炸：反向传播误差信号逐层放大或缩小到数值失效，阻碍深层网络从训练一开始收敛 [作者明确陈述][页码：1]；已被归一化初始化与 BN 较大程度缓解，故不是本文要解决的主要限制。
- 退化问题（核心限制）：深度增加到一定程度后，训练误差本身升高，56 层 plain 网络训练误差高于 20 层（Fig.1）[实验支持][页码：1]。理论上存在"构造解"（新增层设为恒等映射、其余层复制浅层参数），深层模型训练误差不应更高，但现有求解器找不到与之相当的解，说明问题出在优化难度而非模型表达能力 [作者明确陈述][页码：1-2]。
- 作者进一步排除梯度消失作为该现象的成因：plain 网络配合 BN 训练时前向信号方差非零，反向梯度范数也健康，34 层 plain 网络仍能达到有竞争力精度；深层机制本身"文中未说明"，只是推测存在指数级低收敛速率，留待未来研究 [作者明确陈述][实验支持][页码：5]。

对已展开比较的相关工作，逐条对应其批判链：

- Highway Networks：原本用带参数、数据依赖的门控快捷连接缓解深度训练难题 [作者明确陈述][页码：2]；本文指出其门"关闭"时退化为非残差函数，且未证明深度超过约 100 层仍有精度收益 [作者明确陈述][页码：2-3]；本文用无参数、恒定开放的 identity shortcut 回应；Table 6 中 Highway-19/32 与 ResNet-20~1202 的对比可直接检验这一批判点 [实验支持][页码：7]。
- VGG-16/19：通过 16/19 层 3×3 卷积堆叠取得当时领先精度 [作者明确陈述][页码：1]；本文未称其"失效"，仅指出计算复杂度更高（34 层 plain 仅为 VGG-19 FLOPs 的 18%）；本文沿用其 3×3 卷积设计规则但降低通道数与复杂度；Table 3/4 及检测任务的骨干替换实验（Table 7/8）检验复杂度与效果两方面对比 [实验支持][页码：3, 6-8]。
- VLAD/Fisher Vector、Multigrid 预处理、早期 shortcut 先例：均为概念启发而非直接对照基线，文中未指出具体失效条件，仅作为历史脉络引用 [作者明确陈述][页码：2]。

## 5. 核心洞见与假设

核心洞见：让堆叠层逼近残差 $\mathcal{F}(\mathbf{x}) := \mathcal{H}(\mathbf{x}) - \mathbf{x}$ 而非目标映射本身，原映射重表示为 $\mathcal{F}(\mathbf{x})+\mathbf{x}$ [作者明确陈述][页码：2]。这属于核心洞见，其可执行落地依赖的实现组件是 identity shortcut 结构（见第 6 节模块 1）。

假设链条：多层非线性网络理论上能逼近任意函数，因此也能逼近残差函数（假定输入输出维度相同）[作者明确陈述][页码：3]；但两种形式的"学习难易程度"可能不同，这是一个未被证明、只是动机的关键假设 [作者明确陈述][页码：3]。若恒等映射恰是最优解，把残差权重推向零比用非线性层拟合恒等映射容易得多 [作者明确陈述][页码：2]；退化现象暗示求解器难以逼近恒等映射，而残差形式下这一优化路径更容易，这是该假设与退化问题之间的联系 [作者明确陈述][页码：3]。作者承认现实中恒等映射不太可能严格最优，但认为残差重构提供一种"预处理"效果——若最优函数更接近恒等而非零映射，参照恒等寻找扰动量应更容易 [作者明确陈述][页码：3]。Fig.7 显示学习到的残差响应普遍较小，为该假设提供间接实验支持 [实验支持][页码：3, 8]。作者用词为"we hypothesize"，即明确承认这是假设而非严格证明的结论，前提可能不成立的边界是：若最优映射远离恒等映射，这一"预处理"优势可能消失，但文中未对此做专门验证。

## 6. 方法：从洞见到可执行系统

总览：输入图像 → 若干残差块堆叠（每块内部为"非线性层学习残差 + identity/投影 shortcut 相加"）→ 全局平均池化 + 全连接分类（或作为骨干网络接入检测框架）。

1. **残差学习重构**：动机是让恒等映射的逼近在优化上变容易，回应退化问题 [作者明确陈述][页码：2-3]。运行方式为输入 $\mathbf{x}$ 经堆叠非线性层学习 $\mathcal{F}(\mathbf{x},\{W_i\})$，输出 $\mathbf{y}=\mathcal{F}(\mathbf{x},\{W_i\})+\mathbf{x}$（Eqn.1）[作者明确陈述][页码：3]。预期技术优势是 identity shortcut 不引入额外参数和计算复杂度，可用标准 SGD 端到端训练 [作者明确陈述][页码：2]，由 Table 2、Fig.4 验证。
2. **Identity Shortcut 与维度匹配**：动机是输入输出通道数不一致时 Eqn.(1) 无法直接相加 [作者明确陈述][页码：3]。通过线性投影 $W_s$ 变换 $\mathbf{x}$，输出 $\mathbf{y}=\mathcal{F}(\mathbf{x},\{W_i\})+W_s\mathbf{x}$（Eqn.2）[作者明确陈述][页码：3]，用于降采样处通道翻倍的场景 [作者明确陈述][页码：4]，与模块 1 相连、承接其维度不匹配的边界情况。
3. **Plain/Residual 18/34 层架构**：动机是构造一对"仅有无残差连接之差异"的公平对照组，用以隔离残差学习效果 [作者明确陈述][页码：3]。遵循 VGG 风格 3×3 卷积规则，stride=2 卷积降采样，全局平均池化+1000 路全连接输出 [作者明确陈述][页码：3-4]；34 层 plain 基线仅 3.6×10^9 FLOPs，为 VGG-19 的 18% [作者明确陈述][页码：3]。
4. **深层瓶颈结构（50/101/152 层）**：动机是控制加深后的可承受训练时间 [作者明确陈述][页码：6]。采用 1×1（降维）→3×3（低维卷积）→1×1（恢复维度）三层构成 $\mathcal{F}$，与（恒等或投影）输入相加 [作者明确陈述][页码：6]；identity shortcut 若替换为投影会使复杂度和模型大小翻倍（因接在两端高维处）[基于文中逻辑的推断][页码：6]，这使得该模块与模块 1/2 的连接方式对效率尤为关键。

## 7. 为什么它可能有效

- 机制→收益：残差形式下恒等映射对应权重趋零，比非线性层直接拟合恒等映射更易达成 → 深度增加不再必然导致优化困难 [基于文中逻辑的推断][页码：2-3]；条件是最优函数确实接近恒等映射。
- 机制→收益：Fig.7 显示残差响应普遍偏小 → 支持"恒等映射提供合理预处理"这一假设 → 但该图仅是关联性观察，不构成"响应小即优化更易"的因果证明 [基于文中逻辑的推断][页码：8]。
- 机制→收益：identity shortcut 不含额外参数 → 可用标准 SGD、常见库直接实现，不需修改求解器 [作者明确陈述][页码：2]，降低了工程落地门槛，但这属于实现优势而非"更易优化"本身的证明。

## 8. 实验与指标：证据是否支撑主张

### 8.1 实验问题与判定标准

- 退化问题是否被残差学习解决？对应 plain vs. ResNet 在相同深度/参数量下的训练误差对比（Table 2、Fig.4）[实验支持][页码：5]，属于机制/效果证据。
- 深度增加能否带来精度收益？对应 18/34/50/101/152 层对比（Table 2/3/4）[实验支持][页码：5-7]，属于效果证据。
- 投影快捷连接是否必要？对应选项 A/B/C 对比（Table 3）[实验支持][页码：6]，属于必要性证据。
- 极深网络（超 100 层甚至 1202 层）能否训练？对应 CIFAR-10 20~1202 层实验（Fig.6、Table 6）[实验支持][页码：7-8]，属于适用边界证据。
- 深度表征能否泛化到检测任务？对应 VGG-16 vs. ResNet-101 骨干替换（Table 7/8）[实验支持][页码：8]，属于泛化证据。

### 8.2 数据、任务、对比与运行设置

- 数据：ImageNet-1000 分类（Table 2-5）、CIFAR-10（Table 6，训练 5 万/测试 1 万张）、PASCAL VOC 与 COCO 检测/分割（Table 7-8）[作者明确陈述][页码：4, 7-8]。
- 模型/系统版本：plain-18/34、ResNet-18/34/50/101/152，CIFAR 上 plain/ResNet-20/32/44/56/110/1202；检测骨干替换实验用 Faster R-CNN 框架，仅替换 VGG-16 为 ResNet-101 [作者明确陈述][页码：8]。
- 硬件/软件：文中未说明具体硬件型号，CIFAR-10 实验用双 GPU 训练 [作者明确陈述][页码：7]；实现库（如 Caffe）仅在讨论 identity shortcut 时提及可用性 [作者明确陈述][页码：2]。
- 超参数：学习率 0.1 起、按误差平台衰减，weight decay 0.0001，momentum 0.9，mini-batch ImageNet 256/CIFAR 128 [作者明确陈述][页码：4, 7]；110 层 CIFAR 网络需用 0.01 warm-up 约 400 迭代后切回 0.1 [作者明确陈述][页码：7]。
- 重复次数/统计方式：文中未说明是否多次重复实验取平均或方差。
- 数据增强/测试策略：10-crop 测试、多尺度全卷积测试为评估方法论 [作者明确陈述][页码：4]。

### 8.3 指标字典与对应公式

- **指标与方向**：Top-1/Top-5 error，分类错误率（%），越低越好。
  **定义与公式**：无可核验公式——文中仅报告数值结果，未给出显式计算式 [页码：5-7]。
  **实验用途**：用于 Table 2/3/4/5 中 plain vs. ResNet、不同深度、单模型与集成对比。
  **读数与边界**：34 层 ResNet 比 18 层 ResNet top-1 error 低 2.8%；34 层 ResNet 相对其 plain 对应版本 top-1 error 降低 3.5%（Table 2）[实验支持][页码：5-6]；152 层单模型 top-5 验证误差 4.49%，六模型集成测试误差 3.57%，获 ILSVRC 2015 分类赛第一名 [实验支持][页码：7]。该指标不能说明模型的计算效率或跨任务泛化性。

- **指标与方向**：FLOPs，计算复杂度（乘加次数），同等精度下越低越好。
  **定义与公式**：无可核验公式，仅报告数值（34 层 plain 3.6×10^9，VGG-19 19.6×10^9，152 层 ResNet 11.3×10^9）[页码：3, 7]。
  **实验用途**：论证"更深但更省算力"。
  **读数与边界**：仅反映理论计算量，不代表实际推理耗时或内存占用，文中未给出实测速度数据。

- **指标与方向**：COCO mAP@[.5,.95] 与 PASCAL VOC mAP，目标检测精度（%），越高越好。
  **定义与公式**：无可核验公式，仅说明是"COCO's standard metric"[页码：8]。
  **实验用途**：验证 VGG-16 vs. ResNet-101 骨干替换的泛化效果。
  **读数与边界**：COCO mAP@[.5,.95] 从 21.2 提升到 27.2，绝对提升 6.0 个百分点 [作者明确陈述][页码：8]；"28% relative improvement"为**推导关系（非原文公式）**：推理依据：VGG-16 为 21.2 → ResNet-101 为 27.2 → 6.0/21.2 ≈ 28.3%，与作者所述一致，分母取 VGG-16 原始值 [基于文中逻辑的推断][页码：8]。该指标不能说明具体哪一层特征贡献最大，作者仅整体归因于"更好的网络"[页码：8]。

- **指标与方向**：3×3 层响应标准差（std），BN 后、非线性前输出的分散程度，无固定优劣方向，属分析性指标。
  **定义与公式**：原文仅文字描述，无显式计算式，对应 Fig.7 [页码：8]。
  **实验用途**：验证"identity mapping 提供合理预处理"假设。
  **读数与边界**：ResNet 曲线整体低于对应 plain 网络，深度越深降幅越明显，但这只是关联性观察，不能证明因果机制 [实验支持][页码：8]。

### 8.4 主结果、消融与证据边界

**比较工作与被批判限制的呼应**

| 比较工作/基线 | 核心限制或失效条件 | 本文对应模块 | 直接实验与仍未验证的边界 |
|---|---|---|---|
| Highway Networks | 门控快捷含参数，门关闭时退化为非残差；未证明超 100 层仍获益 | Identity shortcut（无参数、恒定开放） | Table 6 对比已验证深度获益；未验证门控在其他任务上的表现 |
| VGG-16/19 | 复杂度更高，非"失效"而是效率劣势 | Plain/Residual 架构设计规则沿用但降低复杂度 | Table 3/4 精度对比、检测骨干替换（Table 7/8）已验证；未验证同复杂度下 VGG 若加 BN 等改进后的对比 |

主张与证据：

| 主张 | 直接证据（实验/表图） | 证据强度与边界 |
|---|---|---|
| 残差重构缓解退化问题 | Table 2、Fig.4（ImageNet）、Fig.6（CIFAR-10） | 现象层面证据充分；根本机制"文中未说明"，作者留待未来研究 [页码：5] |
| 深度增加带来精度收益（残差框架下） | Table 2/3/4（18~152 层对比） | 证据充分，覆盖 ImageNet 与 CIFAR-10 两数据集；未验证非视觉任务 |
| 投影快捷连接非必要 | Table 3（选项 A/B/C 差异微小） | 仅在 ImageNet 34 层规模验证，CIFAR-10 未做该消融 [页码：6-7] |
| 深度表征提升检测性能 | Table 7/8（骨干替换） | 证据支持整体归因；未做逐层消融定位贡献来源 [页码：8] |
| 1202 层测试效果差于 110 层因过拟合 | Fig.6 Panel 3、文字论述 | 仅有"训练误差相近、测试误差不同"的间接证据，缺乏加/不加正则化的对照实验，作者明确列为未来工作 [页码：8] |

- Table 2/3/4 中的提升均为绝对百分点差异（如 top-1 error 降低 3.5%），未换算为相对比例，读者需注意口径 [页码：5-6]。
- 检测任务提升（28%）是本文唯一明确给出的相对口径数值，且分母为推断得出，非作者直接写明的计算过程 [页码：8]。
- 消融覆盖范围有限：选项 A/B/C 只在 ImageNet 单一深度做过，不能外推到所有深度设置。

## 9. 图表解读与论证关系

### 图片原件与标题

#### 原始图片 1：Figure 1. Training error (left) and test error (right) on CIFAR-10 with 20-layer and 56-layer "plain" networks. The deeper network has higher training error, and thus test error. Similar phenomena on ImageNet is presented in Fig. 4.

![Figure 1. Training error (left) and test error (right) on CIFAR-10 with 20-layer and 56-layer "plain" networks. The deeper network has higher training error, and thus test error. Similar phenomena on ImageNet is presented in Fig. 4.](figure-groups/page-0001-a500175bbc69.png)

*来源：OCR 第 1 页。*

---

#### 原始图片 2：Figure 2. Residual learning: a building block.

![Figure 2. Residual learning: a building block.](assets/imgs/img_in_image_box_191_156_467_307.jpg)

*来源：OCR 第 2 页。*

---

#### 原始图片 3：Figure 3. Example network architectures for ImageNet. Left: the VGG-19 model [41] (19.6 billion FLOPs) as a reference. Middle: a plain network with 34 parameter layers (3.6 billion FLOPs). Right: a residual network with 34 parameter layers (3.6 billion FLOPs). The dotted shortcuts increase dimensions. Table 1 shows more details and other variants.

![Figure 3. Example network architectures for ImageNet. Left: the VGG-19 model [41] (19.6 billion FLOPs) as a reference. Middle: a plain network with 34 parameter layers (3.6 billion FLOPs). Right: a residual network with 34 parameter layers (3.6 billion FLOPs). The dotted shortcuts increase dimensions. Table 1 shows more details and other variants.](assets/imgs/img_in_image_box_96_153_581_1233.jpg)

*来源：OCR 第 4 页。*

---

#### 原始图片 4：Figure 4. Training on ImageNet. Thin curves denote training error, and bold curves denote validation error of the center crops. Left: plain networks of 18 and 34 layers. Right: ResNets of 18 and 34 layers. In this plot, the residual networks have no extra parameter compared to their plain counterparts.

![Figure 4. Training on ImageNet. Thin curves denote training error, and bold curves denote validation error of the center crops. Left: plain networks of 18 and 34 layers. Right: ResNets of 18 and 34 layers. In this plot, the residual networks have no extra parameter compared to their plain counterparts.](figure-groups/page-0005-8b18d192417e.png)

*来源：OCR 第 5 页。*

---

#### 原始图片 5：Figure 5. A deeper residual function for ImageNet. Left: a building block (on feature maps) as in Fig. 3 for ResNet-34. Right: a “bottleneck” building block for ResNet-50/101/152.

![Figure 5. A deeper residual function for ImageNet. Left: a building block (on feature maps) as in Fig. 3 for ResNet-34. Right: a “bottleneck” building block for ResNet-50/101/152.](assets/imgs/img_in_image_box_666_142_1071_285.jpg)

*来源：OCR 第 6 页。*

---

#### 原始图片 6：Figure 7. Standard deviations (std) of layer responses on CIFAR-10. The responses are the outputs of each layer, after BN and before nonlinearity. Top: the layers are shown in their original order. Bottom: the responses are ranked in descending order.

![Figure 7. Standard deviations (std) of layer responses on CIFAR-10. The responses are the outputs of each layer, after BN and before nonlinearity. Top: the layers are shown in their original order. Bottom: the responses are ranked in descending order.](assets/imgs/img_in_chart_box_118_420_553_653.jpg)

*来源：OCR 第 8 页。*

---

#### 原始图片 7：Figure 6. Training on CIFAR-10. Dashed lines denote training error, and bold lines denote testing error. Left: plain networks. The error of plain-110 is higher than 60% and not displayed. Middle: ResNets. Right: ResNets with 110 and 1202 layers.

![Figure 6. Training on CIFAR-10. Dashed lines denote training error, and bold lines denote testing error. Left: plain networks. The error of plain-110 is higher than 60% and not displayed. Middle: ResNets. Right: ResNets with 110 and 1202 layers.](figure-groups/page-0008-b5a2900e95e2.png)

*来源：OCR 第 8 页。*

### 图/表：Fig.1（20 层 vs 56 层 plain 网络训练/测试误差）

- **图组结论**：56 层 plain 网络训练误差与测试误差全程均高于 20 层，即使训练后期趋于平稳仍是如此 [图像直接可见][页码：1]。
- **论证关系**：直接支撑退化问题的存在性，排除"仅为过拟合"的解释（过拟合通常训练误差低而测试误差高，此处训练误差本身更高）；与 Table 2 的数值结果互补。
- **适用范围**：仅呈现现象，不解释退化的根本机制（梯度消失已被文中其他部分排除，页码 5）。

### 图/表：Fig.3（残差块结构示意图）

- **图组结论**：输入 x 同时经两层 weight layer+relu 生成 F(x)，并通过无权重标注的旁路直接跳到加号节点，两路相加后再 relu 输出 [图像直接可见][页码：3]。
- **论证关系**：具象化 Eqn.(1)，支撑"identity shortcut 不增加参数和计算量"的技术优势描述；与 Table 2/Fig.4 的效果证据互补，本图仅为结构定义图示。
- **适用范围**：仅展示两层残差块（对应 18/34 层网络），不代表 50/101/152 层用的三层瓶颈结构（见 Fig.5）。

### 图/表：网络架构三方对照图（VGG-19/plain-34/ResNet-34）

- **图组结论**：34 层 plain 与 34 层 residual 网络逐层配置完全一致，唯一区别是跳跃连接的有无；虚线跳跃对应通道翻倍/尺寸减半处 [图像直接可见][页码：3-4]。
- **论证关系**：验证"公平对照组"这一实验设计前提，为 Table 2/Fig.4 的 plain vs. ResNet 对比提供结构基础；也印证模块 2 中"实线=identity、虚线=需处理维度变化"的设计。
- **适用范围**：仅覆盖 34 层与 VGG-19 对比，不代表 18/50/101/152 层结构（见 Table 1 文字描述）。

### 图/表：Fig.4（18/34 层 plain 与 ResNet 训练曲线）

- **图组结论**：plain-34 训练/验证误差全程高于 plain-18；ResNet-34 反而低于 ResNet-18，且 18 层两者精度接近但 ResNet 收敛更快 [图像直接可见][页码：5]。
- **论证关系**：直接验证退化问题在 plain 网络存在、在残差框架下反转，是 Table 2 数值结果背后的训练动态证据。
- **适用范围**：仅覆盖 ImageNet 18/34 层，图中曲线后期粗细线高度重叠，无法精确读出具体数值。

### 图/表：Fig.5（2 层块 vs 3 层瓶颈块结构对比）

- **图组结论**：瓶颈块通过 1×1 降维→3×3 低维卷积→1×1 恢复维度，将计算集中在低维空间；shortcut 均未标注参数，直连模块两端高维输入输出 [图像直接可见][页码：6]。
- **论证关系**：印证瓶颈设计"相近时间复杂度"的表述，及"投影会使复杂度翻倍"论证在结构上的对应关系。
- **适用范围**：具体复杂度翻倍的数值结论来自正文计算推导，非图本身可见内容。

### 图/表：Fig.7（层响应标准差）

- **图组结论**：ResNet（尤其 110 层）的层响应标准差整体低于对应 plain 网络，且衰减更快 [图像直接可见][页码：8]。
- **论证关系**：为核心假设"恒等映射提供合理预处理"提供间接支持，与 Table 2/Fig.4 的效果证据互补，但本身只是关联性观察。
- **适用范围**：仅来自 CIFAR-10 的 5 个模型，曲线交叠密集且无精确数值刻度，只能做趋势判断，不代表 ImageNet 上的层响应行为。

### 图/表：Fig.6（CIFAR-10 三联训练曲线）

- **图组结论**：Panel 1 显示 plain-56 误差高于 plain-20，退化问题跨数据集复现；Panel 2 显示 ResNet 各深度收敛到相近更低水平，未见分层现象；Panel 3 显示 1202 层测试误差持续高于 110 层 [图像直接可见][页码：7-8]。
- **论证关系**：将退化问题与残差学习有效性的证据从 ImageNet 扩展到 CIFAR-10，强化跨数据集普遍性；Panel 3 为"1202 层过拟合"论断提供可视化曲线，但不能单独证明过拟合这一因果解释。
- **适用范围**：Panel 3 横轴被截断，无法判断训练早期（含 warm-up）行为；Panel 1/2 纵轴上限 20%，可能遗漏更高的早期峰值。

## 10. 完整因果推理树

- 根问题：深度堆叠是否总能提升视觉识别精度，还是存在优化障碍？[页码：1]
  - 旧方法限制：退化问题——深度增加使训练误差本身上升，非过拟合，也非典型梯度消失所致 [实验支持][页码：1, 5]
  - 核心洞见/假设：学习残差 $\mathcal{F}(\mathbf{x})=\mathcal{H}(\mathbf{x})-\mathbf{x}$ 比直接学习 $\mathcal{H}(\mathbf{x})$ 更容易优化（假设，非证明）[作者明确陈述][页码：2-3]
    - 方法模块：Identity shortcut 残差块（Eqn.1）+ 投影处理维度不匹配（Eqn.2）+ 瓶颈结构控制深层计算量
      - 可验证预测：相同深度/参数量下，ResNet 训练误差不高于甚至低于 plain 网络，且深度增加带来精度提升
        - 指标与实验：Top-1/Top-5 error（Table 2/3/4）、层响应标准差（Fig.7）
          - 图表证据：Fig.1/Fig.4（ImageNet 退化与反转）、Fig.6（CIFAR-10 复现）、Fig.7（响应幅度支持假设）
            - 结论与适用边界：现象层面证据充分（ImageNet + CIFAR-10 两个分类数据集），但"为何更易优化"的根本机制未被严格证明，深层收敛速率原因留待未来研究；极深网络（1202 层）出现的过拟合迹象缺乏正则化对照实验，尚属推断 [页码：5, 8]

## 11. 结论、贡献与边界

**贡献**：(1) 提出显式残差重构与 identity shortcut 实现，直接针对退化问题 [作者明确陈述][页码：2]；(2) 通过受控实验证明残差网络更易优化且能从深度获益 [实验支持][页码：2, 5-6]；(3) 证明该框架在超过 100 层甚至 1202 层下仍可训练，突破 Highway Networks 未证明的深度上限 [实验支持][页码：3, 7-8]；(4) 将深度表征迁移到检测/分割任务，仅替换骨干网络即获显著泛化提升 [实验支持][页码：8]。

**证据充分的结论**：34 层 ResNet 优于 18 层 ResNet 及其 plain 对应版本；152 层单模型优于此前所有集成模型；六模型集成获 ILSVRC 2015 分类赛第一名 [实验支持][页码：5-7]。

**尚属推断的意义**：残差学习"更易优化"的具体数学机制未被证明，仅为假设加间接实验支持（Fig.7）；1202 层测试效果变差归因于过拟合缺乏正则化对照实验 [作者明确陈述][页码：3, 8]。

**适用条件与局限**：核心实验集中于图像分类（ImageNet、CIFAR-10）与目标检测（VOC、COCO），"适用于其他视觉和非视觉问题"仅为作者预期表述，非已验证结论 [作者明确陈述][页码：2]；检测任务具体实现细节因 appendix 缺失而无法确认。

**审稿式风险检查**：
- 贡献新意：核心洞见建立在明确的实验对照（Table 2、Fig.4）之上，当前证据未显示该风险。
- 写作/可复现性：检测任务实现细节依赖未提供的 appendix，可复现性存在缺口 [页码：8]。
- 效果大小：ImageNet/CIFAR-10 提升数值有直接表格支持，当前证据未显示该风险；检测任务"28%"的相对提升分母为推导而非作者直接给出。
- 实验覆盖：投影快捷连接的 A/B/C 消融仅在单一深度规模做过，跨深度/数据集覆盖不足 [页码：6-7]。
- 方法设计：1202 层过拟合解释缺乏正则化对照实验，是当前证据链中最明确的一处空白 [页码：8]。

## 12. 术语与第一性原理学习路径

### 12.1 核心术语

- **术语**：残差映射 $\mathcal{F}(\mathbf{x})=\mathcal{H}(\mathbf{x})-\mathbf{x}$，即目标映射与输入之差。
  **第一性原理角色**：把"学习完整函数"这一约束转化为"学习偏离恒等映射的扰动量"，连接输入状态 x 与目标状态 H(x)。
  **本文位置**：方法核心定义，Eqn.(1)[页码：3]。

- **术语**：Identity shortcut（恒等快捷连接），一条不含参数、直接将输入跳过若干层送到相加节点的路径。
  **第一性原理角色**：不消耗额外参数/计算资源即可保留输入信息，是残差学习在计算图上的物理载体。
  **本文位置**：Eqn.(1)、Fig.3、Fig.5[页码：2-3, 6]。

- **术语**：退化问题（degradation problem），深度增加使训练误差本身升高的现象。
  **第一性原理角色**：区别于表达能力不足或过拟合，反映的是优化算法在给定深度下找到最优解的能力约束。
  **本文位置**：Fig.1、Fig.6 Panel 1[页码：1, 7]。

- **术语**：瓶颈结构（bottleneck），1×1→3×3→1×1 三层堆叠。
  **第一性原理角色**：受"训练时间/计算量"这一资源约束驱动，通过降维再卷积再升维压缩计算成本。
  **本文位置**：Fig.5、模块 4[页码：6]。

- **术语**：投影快捷连接 $W_s\mathbf{x}$，用线性变换匹配维度。
  **第一性原理角色**：连接"输入维度"与"残差输出维度"两个基本量，在其不相等时提供代数上可相加的桥梁。
  **本文位置**：Eqn.(2)[页码：3]。

- **术语**：层响应标准差 std，3×3 层 BN 后、非线性前输出的分散程度。
  **第一性原理角色**：作为残差幅度的可观测量，连接"网络设计假设（恒等映射预处理）"与"实测数据分布"。
  **本文位置**：Fig.7[页码：8]。

### 12.2 学习路径

1. 卷积神经网络（基本对象）：理解图像如何通过卷积核逐层提取特征，是理解本文所有架构讨论的前提。
2. 反向传播与梯度（约束）：理解误差信号如何逐层回传，才能理解梯度消失/爆炸这一历史约束为何存在。
3. 批归一化 BN（机制）：理解 BN 如何稳定各层数值分布，是理解"退化问题非梯度消失"这一排除性论证的前提。
4. 恒等映射与残差（机制）：理解"学习差值比学习整体更容易"这一直觉，是理解本文核心洞见的关键一步。
5. Top-1/Top-5 error 与 mAP（指标/系统行为）：理解这些指标衡量什么、越低/越高代表什么，才能正确解读 Table 2-8 的实验结果。