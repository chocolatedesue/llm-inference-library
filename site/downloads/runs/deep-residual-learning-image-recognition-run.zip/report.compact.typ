#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(size: 9.4pt)
#set par(justify: true, leading: 0.72em, spacing: 0.72em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#show heading.where(level: 1): it => block(above: 1.4em, below: 0.9em)[
  #text(size: 17pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]
  #v(-6pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => block(above: 1.6em, below: 0.7em, inset: (x: 9pt, y: 5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))[#text(size: 12.5pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => block(above: 1.1em, below: 0.4em)[#text(size: 10.6pt, weight: "bold", fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => block(above: 0.9em, below: 0.3em)[#text(size: 9.8pt, weight: "bold", fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(size: 12pt, weight: "bold", tracking: 3pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(6pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(size: 22pt, weight: "bold")[Deep Residual Learning for Image Recognition]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Kaiming He, Xiangyu Zhang, Shaoqing Ren, Jian Sun]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[深度学习] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[残差网络] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[图像分类] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[卷积神经网络] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[ImageNet]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-26]
]
#pagebreak(weak: true)

#set page(numbering: "1")
#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

更深的神经网络更难训练。我们提出一种残差学习框架，以简化比以往使用的网络更深得多的网络的训练。我们将网络层显式地重新表述为学习相对于层输入的残差函数，而不是学习无参照的函数。我们通过大量实验证据表明，这些残差网络更容易优化，并且能够从显著增加的深度中获得准确率提升。在ImageNet数据集上，我们评估了深度最高达152层的残差网络——比VGG网络深8倍，但复杂度仍更低。这些残差网络的集成在ImageNet测试集上取得了3.57%的错误率，该结果获得了ILSVRC 2015分类任务的第一名。我们还在CIFAR-10上对100层和1000层的网络进行了分析。表示的深度对许多视觉识别任务都至关重要。仅凭借极深的表示，我们在COCO目标检测数据集上就获得了28%的相对性能提升。深度残差网络是我们参加ILSVRC和COCO 2015竞赛提交方案的基础，我们还凭此在ImageNet检测、ImageNet定位、COCO检测和COCO分割任务上获得了第一名。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#align(center)[#table(
  columns: 2,
  align: (col, row) => (auto,auto,).at(col),
  inset: 6pt,
  [字段], [内容],
  [标题],
  [Deep Residual Learning for Image Recognition],
  [作者],
  [Kaiming He, Xiangyu Zhang, Shaoqing Ren, Jian Sun],
  [发表场所 / 年份],
  [文中未说明],
  [研究领域],
  [计算机视觉、深度学习],
  [关键词],
  [深度学习, 残差网络, 图像分类, 卷积神经网络, ImageNet],
)
]

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#blockquote[
#strong[标签（3–5 个）]：`残差学习` · `深度神经网络` · `图像分类` · `目标检测` · `退化问题`
]

本文提出深度残差学习框架，让堆叠层学习相对于输入的残差映射 \#mi(\"\\mathcal{F}(\\mathbf{x}) :\= \\mathcal{H}(\\mathbf{x}) - \\mathbf{x}\") 而非直接学习目标映射，以解决极深网络的\"退化问题\"（训练误差随深度增加不降反升）\[作者明确陈述\]\[页码：1-2\]，最终在 ImageNet 上用 152 层网络取得单模型 top-5 验证误差 4.49%、六模型集成 3.57% 的测试误差，并在检测/分割任务上取得显著泛化提升 \[实验支持\]\[页码：7-8\]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

OCR 覆盖正文第 1–8 页的引言、方法、ImageNet/CIFAR-10 实验及检测任务迁移部分，包含 Fig.1、Fig.3（结构示意）、Fig.4、Fig.5（瓶颈块）、Fig.6、Fig.7 共 4 组图片批次的证据分析。检测任务（第 4.3 节）具体实现方法注明\"见 appendix\"，但本 OCR 材料不含 appendix，因此 Faster R-CNN 具体改造方式、ImageNet 定位/COCO 分割细节均\"无法从当前 OCR 内容确认\"\[页码：8\]。多个关键指标（top-1/top-5 error、mAP、FLOPs）文中只报告数值，未给出计算公式本身。以上限制均已在正文相应处标注证据类型区分论文事实与背景知识。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

深度对视觉识别至关重要——层数越多理论上能提炼越丰富的特征层级 \[作者明确陈述\]\[页码：1\]，由此产生根问题：\"学习更好的网络是否就是简单地堆叠更多层？\"\[作者明确陈述\]\[页码：1\] 这个问题重要，是因为若深度可无限堆叠且总能带来收益，分类、检测、分割、定位等一系列视觉任务都可能从\"更深\"这一简单杠杆获得系统性提升，当时最领先的 ImageNet 结果已普遍依赖 16~30 层的\"very deep\"模型 \[作者明确陈述\]\[页码：1\]。

难点在于：深层网络一度受梯度消失/爆炸阻碍训练收敛（好比\"传声筒游戏\"信息传递失真），这一问题已被归一化初始化和 BN 层较大程度解决 \[作者明确陈述\]\[页码：1\]；但当网络能够开始收敛后，又出现了训练误差本身随深度增加而上升的\"退化问题\"，且这一现象不能用过拟合解释 \[作者明确陈述\]\[实验支持\]\[页码：1\]。

本文的 story：旧路线在\"用非线性堆叠层直接逼近目标映射\"这一优化路径上失效——求解器难以让多层非线性网络逼近恒等映射；本文的核心转折是把学习目标重构为残差 \#mi(\"\\mathcal{F}(\\mathbf{x})+\\mathbf{x}\")，使恒等映射对应\"把权重推向零\"这一更易达成的解，从而让深度成为可自由扩展的资源而非风险。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：训练误差随深度上升的退化问题]
  #image("figure-groups/page-0001-a500175bbc69.png", width: 100%)
  #emph[Figure 1. Training error (left) and test error (right) on CIFAR-10 with 20-layer and 56-layer \"plain\" networks. The deeper network has higher training error, and thus test error. Similar phenomena on ImageNet is presented in Fig. 4.] \
来源：OCR 第 1 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：56 层 plain 网络训练误差与测试误差全程均高于 20 层，即使后期趋于平稳仍是如此

- #strong[论证关系]：直接支撑退化问题的存在性，排除\"仅为过拟合\"的解释，与 Table 2 数值结果互补

- #strong[适用范围]：仅呈现现象，不解释退化的根本机制（梯度消失已被文中其他部分排除）
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

- 梯度消失/爆炸：反向传播误差信号逐层放大或缩小到数值失效，阻碍深层网络从训练一开始收敛 \[作者明确陈述\]\[页码：1\]；已被归一化初始化与 BN 较大程度缓解，故不是本文要解决的主要限制。
- 退化问题（核心限制）：深度增加到一定程度后，训练误差本身升高，56 层 plain 网络训练误差高于 20 层（Fig.1）\[实验支持\]\[页码：1\]。理论上存在\"构造解\"（新增层设为恒等映射、其余层复制浅层参数），深层模型训练误差不应更高，但现有求解器找不到与之相当的解，说明问题出在优化难度而非模型表达能力 \[作者明确陈述\]\[页码：1-2\]。
- 作者进一步排除梯度消失作为该现象的成因：plain 网络配合 BN 训练时前向信号方差非零，反向梯度范数也健康，34 层 plain 网络仍能达到有竞争力精度；深层机制本身\"文中未说明\"，只是推测存在指数级低收敛速率，留待未来研究 \[作者明确陈述\]\[实验支持\]\[页码：5\]。

对已展开比较的相关工作，逐条对应其批判链：

- Highway Networks：原本用带参数、数据依赖的门控快捷连接缓解深度训练难题 \[作者明确陈述\]\[页码：2\]；本文指出其门\"关闭\"时退化为非残差函数，且未证明深度超过约 100 层仍有精度收益 \[作者明确陈述\]\[页码：2-3\]；本文用无参数、恒定开放的 identity shortcut 回应；Table 6 中 Highway-19/32 与 ResNet-20~1202 的对比可直接检验这一批判点 \[实验支持\]\[页码：7\]。
- VGG-16/19：通过 16/19 层 3×3 卷积堆叠取得当时领先精度 \[作者明确陈述\]\[页码：1\]；本文未称其\"失效\"，仅指出计算复杂度更高（34 层 plain 仅为 VGG-19 FLOPs 的 18%）；本文沿用其 3×3 卷积设计规则但降低通道数与复杂度；Table 3/4 及检测任务的骨干替换实验（Table 7/8）检验复杂度与效果两方面对比 \[实验支持\]\[页码：3, 6-8\]。
- VLAD/Fisher Vector、Multigrid 预处理、早期 shortcut 先例：均为概念启发而非直接对照基线，文中未指出具体失效条件，仅作为历史脉络引用 \[作者明确陈述\]\[页码：2\]。

== 5. 核心洞见与假设
<5-核心洞见与假设>

核心洞见：让堆叠层逼近残差 \#mi(\"\\mathcal{F}(\\mathbf{x}) :\= \\mathcal{H}(\\mathbf{x}) - \\mathbf{x}\") 而非目标映射本身，原映射重表示为 \#mi(\"\\mathcal{F}(\\mathbf{x})+\\mathbf{x}\") \[作者明确陈述\]\[页码：2\]。这属于核心洞见，其可执行落地依赖的实现组件是 identity shortcut 结构（见第 6 节模块 1）。

假设链条：多层非线性网络理论上能逼近任意函数，因此也能逼近残差函数（假定输入输出维度相同）\[作者明确陈述\]\[页码：3\]；但两种形式的\"学习难易程度\"可能不同，这是一个未被证明、只是动机的关键假设 \[作者明确陈述\]\[页码：3\]。若恒等映射恰是最优解，把残差权重推向零比用非线性层拟合恒等映射容易得多 \[作者明确陈述\]\[页码：2\]；退化现象暗示求解器难以逼近恒等映射，而残差形式下这一优化路径更容易，这是该假设与退化问题之间的联系 \[作者明确陈述\]\[页码：3\]。作者承认现实中恒等映射不太可能严格最优，但认为残差重构提供一种\"预处理\"效果——若最优函数更接近恒等而非零映射，参照恒等寻找扰动量应更容易 \[作者明确陈述\]\[页码：3\]。Fig.7 显示学习到的残差响应普遍较小，为该假设提供间接实验支持 \[实验支持\]\[页码：3, 8\]。作者用词为\"we hypothesize\"，即明确承认这是假设而非严格证明的结论，前提可能不成立的边界是：若最优映射远离恒等映射，这一\"预处理\"优势可能消失，但文中未对此做专门验证。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入图像 → 若干残差块堆叠（每块内部为\"非线性层学习残差 + identity/投影 shortcut 相加\"）→ 全局平均池化 + 全连接分类（或作为骨干网络接入检测框架）。

+ #strong[残差学习重构]：动机是让恒等映射的逼近在优化上变容易，回应退化问题 \[作者明确陈述\]\[页码：2-3\]。运行方式为输入 \#mi(\"\\mathbf{x}\") 经堆叠非线性层学习 \#mi(\"\\mathcal{F}(\\mathbf{x},{W\_i})\")，输出 \#mi(\"\\mathbf{y}\=\\mathcal{F}(\\mathbf{x},{W\_i})+\\mathbf{x}\")（Eqn.1）\[作者明确陈述\]\[页码：3\]。预期技术优势是 identity shortcut 不引入额外参数和计算复杂度，可用标准 SGD 端到端训练 \[作者明确陈述\]\[页码：2\]，由 Table 2、Fig.4 验证。
+ #strong[Identity Shortcut 与维度匹配]：动机是输入输出通道数不一致时 Eqn.(1) 无法直接相加 \[作者明确陈述\]\[页码：3\]。通过线性投影 \#mi(\"W\_s\") 变换 \#mi(\"\\mathbf{x}\")，输出 \#mi(\"\\mathbf{y}\=\\mathcal{F}(\\mathbf{x},{W\_i})+W\_s\\mathbf{x}\")（Eqn.2）\[作者明确陈述\]\[页码：3\]，用于降采样处通道翻倍的场景 \[作者明确陈述\]\[页码：4\]，与模块 1 相连、承接其维度不匹配的边界情况。
+ #strong[Plain/Residual 18/34 层架构]：动机是构造一对\"仅有无残差连接之差异\"的公平对照组，用以隔离残差学习效果 \[作者明确陈述\]\[页码：3\]。遵循 VGG 风格 3×3 卷积规则，stride\=2 卷积降采样，全局平均池化+1000 路全连接输出 \[作者明确陈述\]\[页码：3-4\]；34 层 plain 基线仅 3.6×10^9 FLOPs，为 VGG-19 的 18% \[作者明确陈述\]\[页码：3\]。
+ #strong[深层瓶颈结构（50/101/152 层）]：动机是控制加深后的可承受训练时间 \[作者明确陈述\]\[页码：6\]。采用 1×1（降维）→3×3（低维卷积）→1×1（恢复维度）三层构成 \#mi(\"\\mathcal{F}\")，与（恒等或投影）输入相加 \[作者明确陈述\]\[页码：6\]；identity shortcut 若替换为投影会使复杂度和模型大小翻倍（因接在两端高维处）\[基于文中逻辑的推断\]\[页码：6\]，这使得该模块与模块 1/2 的连接方式对效率尤为关键。

#strong[前排大图（方法流水线）]：先看论文原图把握方法整体流水线，再读本节文字。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：深层瓶颈结构模块 4]
  #image("assets/source-crops/img_in_image_box_666_142_1071_285.png", width: 100%)
  #emph[Figure 5. A deeper residual function for ImageNet. Left: a building block (on feature maps) as in Fig. 3 for ResNet-34. Right: a “bottleneck” building block for ResNet-50/101/152.] \
来源：OCR 第 6 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：瓶颈块 1x1 降维→3x3 低维卷积→1x1 恢复维度，shortcut 直连模块两端高维输入输出

- #strong[论证关系]：印证瓶颈\"相近时间复杂度\"表述及\"投影会使复杂度翻倍\"论证的结构对应

- #strong[适用范围]：复杂度翻倍的具体数值来自正文计算推导，非图本身可见内容
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：残差学习重构模块 1]
  #image("assets/source-crops/img_in_image_box_191_156_467_307.png", width: 100%)
  #emph[Figure 2. Residual learning: a building block.] \
来源：OCR 第 2 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：输入 x 同时走两层 weight layer+relu 生成 F(x)，并经无参数旁路直连加号节点相加输出

- #strong[论证关系]：具象化 Eqn.(1)，支撑 identity shortcut 不增加参数和计算量的技术优势描述

- #strong[适用范围]：仅展示两层残差块（18/34 层用），不代表 50/101/152 层的三层瓶颈结构
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 机制→收益：残差形式下恒等映射对应权重趋零，比非线性层直接拟合恒等映射更易达成 → 深度增加不再必然导致优化困难 \[基于文中逻辑的推断\]\[页码：2-3\]；条件是最优函数确实接近恒等映射。
- 机制→收益：Fig.7 显示残差响应普遍偏小 → 支持\"恒等映射提供合理预处理\"这一假设 → 但该图仅是关联性观察，不构成\"响应小即优化更易\"的因果证明 \[基于文中逻辑的推断\]\[页码：8\]。
- 机制→收益：identity shortcut 不含额外参数 → 可用标准 SGD、常见库直接实现，不需修改求解器 \[作者明确陈述\]\[页码：2\]，降低了工程落地门槛，但这属于实现优势而非\"更易优化\"本身的证明。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 退化问题是否被残差学习解决？对应 plain vs. ResNet 在相同深度/参数量下的训练误差对比（Table 2、Fig.4）\[实验支持\]\[页码：5\]，属于机制/效果证据。
- 深度增加能否带来精度收益？对应 18/34/50/101/152 层对比（Table 2/3/4）\[实验支持\]\[页码：5-7\]，属于效果证据。
- 投影快捷连接是否必要？对应选项 A/B/C 对比（Table 3）\[实验支持\]\[页码：6\]，属于必要性证据。
- 极深网络（超 100 层甚至 1202 层）能否训练？对应 CIFAR-10 20~1202 层实验（Fig.6、Table 6）\[实验支持\]\[页码：7-8\]，属于适用边界证据。
- 深度表征能否泛化到检测任务？对应 VGG-16 vs. ResNet-101 骨干替换（Table 7/8）\[实验支持\]\[页码：8\]，属于泛化证据。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 数据：ImageNet-1000 分类（Table 2-5）、CIFAR-10（Table 6，训练 5 万/测试 1 万张）、PASCAL VOC 与 COCO 检测/分割（Table 7-8）\[作者明确陈述\]\[页码：4, 7-8\]。
- 模型/系统版本：plain-18/34、ResNet-18/34/50/101/152，CIFAR 上 plain/ResNet-20/32/44/56/110/1202；检测骨干替换实验用 Faster R-CNN 框架，仅替换 VGG-16 为 ResNet-101 \[作者明确陈述\]\[页码：8\]。
- 硬件/软件：文中未说明具体硬件型号，CIFAR-10 实验用双 GPU 训练 \[作者明确陈述\]\[页码：7\]；实现库（如 Caffe）仅在讨论 identity shortcut 时提及可用性 \[作者明确陈述\]\[页码：2\]。
- 超参数：学习率 0.1 起、按误差平台衰减，weight decay 0.0001，momentum 0.9，mini-batch ImageNet 256/CIFAR 128 \[作者明确陈述\]\[页码：4, 7\]；110 层 CIFAR 网络需用 0.01 warm-up 约 400 迭代后切回 0.1 \[作者明确陈述\]\[页码：7\]。
- 重复次数/统计方式：文中未说明是否多次重复实验取平均或方差。
- 数据增强/测试策略：10-crop 测试、多尺度全卷积测试为评估方法论 \[作者明确陈述\]\[页码：4\]。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Top-1/Top-5 error，分类错误率（%），越低越好。 #strong[定义与公式]：无可核验公式——文中仅报告数值结果，未给出显式计算式 \[页码：5-7\]。 #strong[实验用途]：用于 Table 2/3/4/5 中 plain vs. ResNet、不同深度、单模型与集成对比。 #strong[读数与边界]：34 层 ResNet 比 18 层 ResNet top-1 error 低 2.8%；34 层 ResNet 相对其 plain 对应版本 top-1 error 降低 3.5%（Table 2）\[实验支持\]\[页码：5-6\]；152 层单模型 top-5 验证误差 4.49%，六模型集成测试误差 3.57%，获 ILSVRC 2015 分类赛第一名 \[实验支持\]\[页码：7\]。该指标不能说明模型的计算效率或跨任务泛化性。

- #strong[指标与方向]：FLOPs，计算复杂度（乘加次数），同等精度下越低越好。 #strong[定义与公式]：无可核验公式，仅报告数值（34 层 plain 3.6×10^9，VGG-19 19.6×10^9，152 层 ResNet 11.3×10^9）\[页码：3, 7\]。 #strong[实验用途]：论证\"更深但更省算力\"。 #strong[读数与边界]：仅反映理论计算量，不代表实际推理耗时或内存占用，文中未给出实测速度数据。

- #strong[指标与方向]：COCO mAP\@\[.5,.95\] 与 PASCAL VOC mAP，目标检测精度（%），越高越好。 #strong[定义与公式]：无可核验公式，仅说明是\"COCO\'s standard metric\"\[页码：8\]。 #strong[实验用途]：验证 VGG-16 vs. ResNet-101 骨干替换的泛化效果。 #strong[读数与边界]：COCO mAP\@\[.5,.95\] 从 21.2 提升到 27.2，绝对提升 6.0 个百分点 \[作者明确陈述\]\[页码：8\]；\"28% relative improvement\"为#strong[推导关系（非原文公式）]：推理依据：VGG-16 为 21.2 → ResNet-101 为 27.2 → 6.0/21.2 ≈ 28.3%，与作者所述一致，分母取 VGG-16 原始值 \[基于文中逻辑的推断\]\[页码：8\]。该指标不能说明具体哪一层特征贡献最大，作者仅整体归因于\"更好的网络\"\[页码：8\]。

- #strong[指标与方向]：3×3 层响应标准差（std），BN 后、非线性前输出的分散程度，无固定优劣方向，属分析性指标。 #strong[定义与公式]：原文仅文字描述，无显式计算式，对应 Fig.7 \[页码：8\]。 #strong[实验用途]：验证\"identity mapping 提供合理预处理\"假设。 #strong[读数与边界]：ResNet 曲线整体低于对应 plain 网络，深度越深降幅越明显，但这只是关联性观察，不能证明因果机制 \[实验支持\]\[页码：8\]。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#align(center)[#table(
  columns: 4,
  align: (col, row) => (auto,auto,auto,auto,).at(col),
  inset: 6pt,
  [比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],
  [Highway Networks],
  [门控快捷含参数，门关闭时退化为非残差；未证明超 100 层仍获益],
  [Identity shortcut（无参数、恒定开放）],
  [Table 6 对比已验证深度获益；未验证门控在其他任务上的表现],
  [VGG-16/19],
  [复杂度更高，非\"失效\"而是效率劣势],
  [Plain/Residual 架构设计规则沿用但降低复杂度],
  [Table 3/4 精度对比、检测骨干替换（Table 7/8）已验证；未验证同复杂度下 VGG 若加 BN 等改进后的对比],
)
]

主张与证据：

#align(center)[#table(
  columns: 3,
  align: (col, row) => (auto,auto,auto,).at(col),
  inset: 6pt,
  [主张], [直接证据（实验/表图）], [证据强度与边界],
  [残差重构缓解退化问题],
  [Table 2、Fig.4（ImageNet）、Fig.6（CIFAR-10）],
  [现象层面证据充分；根本机制\"文中未说明\"，作者留待未来研究 \[页码：5\]],
  [深度增加带来精度收益（残差框架下）],
  [Table 2/3/4（18~152 层对比）],
  [证据充分，覆盖 ImageNet 与 CIFAR-10 两数据集；未验证非视觉任务],
  [投影快捷连接非必要],
  [Table 3（选项 A/B/C 差异微小）],
  [仅在 ImageNet 34 层规模验证，CIFAR-10 未做该消融 \[页码：6-7\]],
  [深度表征提升检测性能],
  [Table 7/8（骨干替换）],
  [证据支持整体归因；未做逐层消融定位贡献来源 \[页码：8\]],
  [1202 层测试效果差于 110 层因过拟合],
  [Fig.6 Panel 3、文字论述],
  [仅有\"训练误差相近、测试误差不同\"的间接证据，缺乏加/不加正则化的对照实验，作者明确列为未来工作 \[页码：8\]],
)
]

- Table 2/3/4 中的提升均为绝对百分点差异（如 top-1 error 降低 3.5%），未换算为相对比例，读者需注意口径 \[页码：5-6\]。
- 检测任务提升（28%）是本文唯一明确给出的相对口径数值，且分母为推断得出，非作者直接写明的计算过程 \[页码：8\]。
- 消融覆盖范围有限：选项 A/B/C 只在 ImageNet 单一深度做过，不能外推到所有深度设置。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_96_153_581_1233.png", width: 100%)
    #emph[Figure 3. Example network architectures for ImageNet. Left: the VGG-19 model \[41\] (19.6 billion FLOPs) as a reference. Middle: a plain network with 34 parameter layers (3.6 billion FLOPs). Right: a residual network with 34 parameter layers (3.6 billion FLOPs). The dotted shortcuts increase dimensions. Table 1 shows more details and other variants.] \
来源：OCR 第 4 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：Plain/Residual 34 层公平对照架构设计]
    - #strong[图组结论]：34 层 plain 与 residual 逐层配置一致，仅跳跃连接有无不同；虚线跳跃对应通道翻倍/尺寸减半处

- #strong[论证关系]：验证公平对照组前提，为 Table2/Fig.4 的 plain vs. ResNet 效果对比提供结构基础

- #strong[适用范围]：仅覆盖 34 层与 VGG-19 对比，不代表 18/50/101/152 层结构
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0005-8b18d192417e.png", width: 100%)
    #emph[Figure 4. Training on ImageNet. Thin curves denote training error, and bold curves denote validation error of the center crops. Left: plain networks of 18 and 34 layers. Right: ResNets of 18 and 34 layers. In this plot, the residual networks have no extra parameter compared to their plain counterparts.] \
来源：OCR 第 5 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：残差重构缓解退化问题]
    - #strong[图组结论]：plain-34 训练/验证误差全程高于 plain-18；ResNet-34 反而低于 ResNet-18，收敛更快

- #strong[论证关系]：验证退化问题在 plain 网络存在、在残差框架下反转，是 Table2 数值背后的训练动态证据

- #strong[适用范围]：仅覆盖 ImageNet 18/34 层，曲线后期重叠无法精确读数
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0008-b5a2900e95e2.png", width: 100%)
    #emph[Figure 6. Training on CIFAR-10. Dashed lines denote training error, and bold lines denote testing error. Left: plain networks. The error of plain-110 is higher than 60% and not displayed. Middle: ResNets. Right: ResNets with 110 and 1202 layers.] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：残差重构缓解退化问题的跨数据集证据]
    - #strong[图组结论]：Panel1 退化问题跨数据集复现；Panel2 ResNet 各深度收敛相近；Panel3 1202 层测试误差持续高于 110 层

- #strong[论证关系]：将退化与残差有效性证据扩展到 CIFAR-10；Panel3 为 1202 层过拟合论断提供曲线佐证但非因果证明

- #strong[适用范围]：Panel3 横轴截断无法判断早期行为；Panel1/2 纵轴上限 20% 可能遗漏早期峰值
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_118_420_553_653.png", width: 100%)
    #emph[Figure 7. Standard deviations (std) of layer responses on CIFAR-10. The responses are the outputs of each layer, after BN and before nonlinearity. Top: the layers are shown in their original order. Bottom: the responses are ranked in descending order.] \
来源：OCR 第 8 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 5 节：恒等映射提供合理预处理假设]
    - #strong[图组结论]：ResNet 尤其 110 层层响应标准差整体低于对应 plain 网络，且衰减更快

- #strong[论证关系]：为核心假设提供间接支持，与 Table2/Fig.4 效果证据互补，但仅为关联性观察

- #strong[适用范围]：仅来自 CIFAR-10 五个模型，曲线交叠密集无精确刻度，不代表 ImageNet 行为
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1. Architectures for ImageNet. Building blocks are shown in brackets (see also Fig. 5), with the numbers of blo...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：Plain/Residual 18/34/50/101/152 层架构设计]
  - #strong[图组结论]：按 building block 列出各深度网络逐阶段层配置，降采样由 conv3\_1/4\_1/5\_1(stride2) 完成

- #strong[论证关系]：补充 Fig.3 仅展示 34 层的局限，覆盖 18/50/101/152 层完整架构定义，支撑模块 3/4 设计描述

- #strong[适用范围]：仅为架构参数表，不含训练/测试误差数值，不能单独验证精度或优化难易
  #v(5pt)
  #image("table-groups/page-0005-8a9434e12d63.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3. Error rates (%, 10-crop testing) on ImageNet validation. VGG-16 is based on our test. ResNet-50/101/152 are...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：投影快捷连接是否必要]
  - #strong[图组结论]：比较 option A/B/C 快捷连接方案及 VGG-16/ResNet-50/101/152 在 ImageNet 验证集 10-crop 错误率

- #strong[论证关系]：直接验证\"投影快捷连接非必要\"这一主张，A/B/C 差异微小支撑 identity shortcut 的充分性

- #strong[适用范围]：仅在 ImageNet 34 层规模验证，CIFAR-10 未做该消融，不可外推至所有深度
  #v(5pt)
  #image("table-groups/page-0006-d86a07d15a3b.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 4. Error rates (%) of single-model results on the ImageNet validation set (except reported on the test set).]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：深度增加带来精度收益]
  - #strong[图组结论]：汇总 18/34/50/101/152 层 ResNet 单模型在 ImageNet 验证集的错误率，随深度增加持续下降

- #strong[论证关系]：支撑\"深度增加带来精度收益\"主张，是 152 层单模型 4.49% 指标的直接数值来源

- #strong[适用范围]：仅覆盖单模型结果，集成模型对比另见其他表格，未说明重复实验次数
  #v(5pt)
  #image("table-groups/page-0006-100ce7790bae.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 7. Object detection mAP (%) on the PASCAL VOC 2007/2012 test sets using baseline Faster R-CNN. See also Table 1...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：深度表征能否泛化到检测任务]
  - #strong[图组结论]：对比 baseline Faster R-CNN 分别用 VGG-16 与 ResNet-101 骨干在 PASCAL VOC 2007/2012 测试集的 mAP

- #strong[论证关系]：直接支撑\"仅替换骨干网络即获显著泛化提升\"这一贡献，是骨干替换实验的核心数值证据

- #strong[适用范围]：仅为 baseline 结果，未含 box refinement/context/多尺度等改进（见 Table 9-11）
  #v(5pt)
  #image("table-groups/page-0008-215afe6a7a9e.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 9. Object detection improvements on MS COCO using Faster R-CNN and ResNet-101.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：COCO mAP\@\[.5,.95\] 提升]
  - #strong[图组结论]：展示 Faster R-CNN 配合 ResNet-101 在 MS COCO 上的检测改进，含 mAP\@\[.5,.95\] 从 21.2 到 27.2 的提升

- #strong[论证关系]：是\"6.0 个百分点/约 28% 相对提升\"这一检测泛化数值主张的直接来源

- #strong[适用范围]：具体改造细节因 appendix 未纳入 OCR 而无法逐项确认，仅数值结果可核验
  #v(5pt)
  #image("table-groups/page-0011-20404a78e580.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 10. Detection results on the PASCAL VOC 2007 test set.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 2 节：appendix 细节未纳入 OCR 的边界]
  - #strong[图组结论]：对比 baseline 与含 box refinement/context/多尺度测试的 baseline++ 在 PASCAL VOC 2007 测试集的检测结果

- #strong[论证关系]：延伸支撑深度表征泛化优势，但 baseline++ 具体改造机制\"见 appendix\"，本 OCR 材料未覆盖

- #strong[适用范围]：仅可确认数值结果，box refinement/context/多尺度的具体实现方式无法从当前 OCR 内容确认
  #v(5pt)
  #image("table-groups/page-0011-b08780dcec4a.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 11. Detection results on the PASCAL VOC 2012 test set (http://host.robots.ox.ac.uk:8080/leaderboard/displaylb.p...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 2 节：appendix 细节未纳入 OCR 的边界]
  - #strong[图组结论]：对比 baseline 与 baseline++ 在 PASCAL VOC 2012 测试集（官方在线排行榜）的检测结果

- #strong[论证关系]：与 Table 10 共同延伸检测泛化证据链，但同样依赖未纳入 OCR 的 appendix 实现细节

- #strong[适用范围]：仅可确认数值结果，具体改造方式及排行榜提交细节无法从当前 OCR 内容确认
  #v(5pt)
  #image("table-groups/page-0011-7474477c0dd5.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 13 compares the localization results. Following \[41\], we first perform “oracle” testing using the ground truth...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 2 节：ImageNet 定位细节无法从当前 OCR 内容确认]
  - #strong[图组结论]：比较定位任务结果，含以真值类别做 oracle 测试的设置，并引用 VGG 论文作对照

- #strong[论证关系]：对应报告\"ImageNet 定位细节因 appendix 缺失无法确认\"这一限制的具体表格证据

- #strong[适用范围]：具体定位方法实现、oracle 测试完整设置\"无法从当前 OCR 内容确认\"，仅表格数值可见
  #v(5pt)
  #image("table-groups/page-0012-7f250e9825f0.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：深度堆叠是否总能提升视觉识别精度，还是存在优化障碍？\[页码：1\]
  - 旧方法限制：退化问题——深度增加使训练误差本身上升，非过拟合，也非典型梯度消失所致 \[实验支持\]\[页码：1, 5\]
    - 核心洞见/假设：学习残差 \#mi(\"\\mathcal{F}(\\mathbf{x})\=\\mathcal{H}(\\mathbf{x})-\\mathbf{x}\") 比直接学习 \#mi(\"\\mathcal{H}(\\mathbf{x})\") 更容易优化（假设，非证明）\[作者明确陈述\]\[页码：2-3\]
      - 方法模块：Identity shortcut 残差块（Eqn.1）+ 投影处理维度不匹配（Eqn.2）+ 瓶颈结构控制深层计算量
        - 可验证预测：相同深度/参数量下，ResNet 训练误差不高于甚至低于 plain 网络，且深度增加带来精度提升
          - 指标与实验：Top-1/Top-5 error（Table 2/3/4）、层响应标准差（Fig.7）
            - 图表证据：Fig.1/Fig.4（ImageNet 退化与反转）、Fig.6（CIFAR-10 复现）、Fig.7（响应幅度支持假设）
              - 结论与适用边界：现象层面证据充分（ImageNet + CIFAR-10 两个分类数据集），但\"为何更易优化\"的根本机制未被严格证明，深层收敛速率原因留待未来研究；极深网络（1202 层）出现的过拟合迹象缺乏正则化对照实验，尚属推断 \[页码：5, 8\]

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献]：(1) 提出显式残差重构与 identity shortcut 实现，直接针对退化问题 \[作者明确陈述\]\[页码：2\]；(2) 通过受控实验证明残差网络更易优化且能从深度获益 \[实验支持\]\[页码：2, 5-6\]；(3) 证明该框架在超过 100 层甚至 1202 层下仍可训练，突破 Highway Networks 未证明的深度上限 \[实验支持\]\[页码：3, 7-8\]；(4) 将深度表征迁移到检测/分割任务，仅替换骨干网络即获显著泛化提升 \[实验支持\]\[页码：8\]。

#strong[证据充分的结论]：34 层 ResNet 优于 18 层 ResNet 及其 plain 对应版本；152 层单模型优于此前所有集成模型；六模型集成获 ILSVRC 2015 分类赛第一名 \[实验支持\]\[页码：5-7\]。

#strong[尚属推断的意义]：残差学习\"更易优化\"的具体数学机制未被证明，仅为假设加间接实验支持（Fig.7）；1202 层测试效果变差归因于过拟合缺乏正则化对照实验 \[作者明确陈述\]\[页码：3, 8\]。

#strong[适用条件与局限]：核心实验集中于图像分类（ImageNet、CIFAR-10）与目标检测（VOC、COCO），\"适用于其他视觉和非视觉问题\"仅为作者预期表述，非已验证结论 \[作者明确陈述\]\[页码：2\]；检测任务具体实现细节因 appendix 缺失而无法确认。

#strong[审稿式风险检查]：

- 贡献新意：核心洞见建立在明确的实验对照（Table 2、Fig.4）之上，当前证据未显示该风险。
- 写作/可复现性：检测任务实现细节依赖未提供的 appendix，可复现性存在缺口 \[页码：8\]。
- 效果大小：ImageNet/CIFAR-10 提升数值有直接表格支持，当前证据未显示该风险；检测任务\"28%\"的相对提升分母为推导而非作者直接给出。
- 实验覆盖：投影快捷连接的 A/B/C 消融仅在单一深度规模做过，跨深度/数据集覆盖不足 \[页码：6-7\]。
- 方法设计：1202 层过拟合解释缺乏正则化对照实验，是当前证据链中最明确的一处空白 \[页码：8\]。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：残差映射 \#mi(\"\\mathcal{F}(\\mathbf{x})\=\\mathcal{H}(\\mathbf{x})-\\mathbf{x}\")，即目标映射与输入之差。 #strong[第一性原理角色]：把\"学习完整函数\"这一约束转化为\"学习偏离恒等映射的扰动量\"，连接输入状态 x 与目标状态 H(x)。 #strong[本文位置]：方法核心定义，Eqn.(1)\[页码：3\]。

- #strong[术语]：Identity shortcut（恒等快捷连接），一条不含参数、直接将输入跳过若干层送到相加节点的路径。 #strong[第一性原理角色]：不消耗额外参数/计算资源即可保留输入信息，是残差学习在计算图上的物理载体。 #strong[本文位置]：Eqn.(1)、Fig.3、Fig.5\[页码：2-3, 6\]。

- #strong[术语]：退化问题（degradation problem），深度增加使训练误差本身升高的现象。 #strong[第一性原理角色]：区别于表达能力不足或过拟合，反映的是优化算法在给定深度下找到最优解的能力约束。 #strong[本文位置]：Fig.1、Fig.6 Panel 1\[页码：1, 7\]。

- #strong[术语]：瓶颈结构（bottleneck），1×1→3×3→1×1 三层堆叠。 #strong[第一性原理角色]：受\"训练时间/计算量\"这一资源约束驱动，通过降维再卷积再升维压缩计算成本。 #strong[本文位置]：Fig.5、模块 4\[页码：6\]。

- #strong[术语]：投影快捷连接 \#mi(\"W\_s\\mathbf{x}\")，用线性变换匹配维度。 #strong[第一性原理角色]：连接\"输入维度\"与\"残差输出维度\"两个基本量，在其不相等时提供代数上可相加的桥梁。 #strong[本文位置]：Eqn.(2)\[页码：3\]。

- #strong[术语]：层响应标准差 std，3×3 层 BN 后、非线性前输出的分散程度。 #strong[第一性原理角色]：作为残差幅度的可观测量，连接\"网络设计假设（恒等映射预处理）\"与\"实测数据分布\"。 #strong[本文位置]：Fig.7\[页码：8\]。

=== 12.2 学习路径
<122-学习路径>
+ 卷积神经网络（基本对象）：理解图像如何通过卷积核逐层提取特征，是理解本文所有架构讨论的前提。
+ 反向传播与梯度（约束）：理解误差信号如何逐层回传，才能理解梯度消失/爆炸这一历史约束为何存在。
+ 批归一化 BN（机制）：理解 BN 如何稳定各层数值分布，是理解\"退化问题非梯度消失\"这一排除性论证的前提。
+ 恒等映射与残差（机制）：理解\"学习差值比学习整体更容易\"这一直觉，是理解本文核心洞见的关键一步。
+ Top-1/Top-5 error 与 mAP（指标/系统行为）：理解这些指标衡量什么、越低/越高代表什么，才能正确解读 Table 2-8 的实验结果。
