# 图片批次 6

## 图片 1：Figure 11. Illustration of our Tree-Based MatMul kernel.

![Figure 11. Illustration of our Tree-Based MatMul kernel.](../assets/imgs/img_in_image_box_615_136_1079_359.jpg)

*来源：OCR 第 14 页。*

### 解读

1. **论文角色与验证问题**：该图是 TBIK 核心组件之一——Intra-GPU Tree-Based MatMul Kernel——的方法流水线示意图，对应正文第 4.2 节"Components of TBIK"中"intra-GPU reduction within a Tree-Based MatMul kernel, as shown in Figure 11"的直接引用，以及 Appendix D.1 对该内核逐字段（$T_K$、$C$、累加器缓冲 $S$、深度 $L=\log_2(T_K/C)$、Count 计数器、carry-over 规则）的算法描述。它不是效果/对比类证据，而是**方法流水线**角色：把第 5 节"固定二叉树规约"这一核心机制假设具象化为可执行的 tile 级计算流程。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：第 4.1/4.2 节核心机制主张"固定二叉树拓扑使本地累加顺序与 TP 规模无关"；Appendix D.1 的算法细节。

2. **图像类型与布局**：示意图（非曲线/柱状/表格）。左侧是标准矩阵分块图示：底部一行三个橙色小方块（沿 BLOCK_M 行、按 BLOCK_K 切分），顶部一列绿色方块（按 BLOCK_N、BLOCK_K 切分），二者交汇处有一个紫色/品红色输出方块，方块下方与右侧各标注一个"Tree Reduce"箭头。右侧用虚线分隔出图例区：上方是"方块×方块=方块"的乘法图例（橙×绿=紫，对应部分乘积的产生）；下方标题"Tree Reduce"，展示四个由浅到深的紫色色块通过灰色方框两两配对、逐级合并，最终指向一个标有 BLOCK_N/BLOCK_M 的输出方块。

3. **如何阅读**：应把左侧的分块矩阵图与右侧图例对照阅读——左侧展示"哪些 tile 参与计算"（沿 BLOCK_K 维度切分出多个部分乘积),右侧图例展示"这些部分乘积如何被合并"（乘法产生叶子节点，Tree Reduce 部分展示叶子节点两两配对逐层向上归约为单一输出）。图中未标注具体数值坐标，只是结构性示意。

4. **直接可见的结论**：图像显示部分乘积（tile 乘法结果）作为叶子节点，通过灰色方框表示的两两配对操作逐级合并，最终收敛到单个输出方块，与文字描述的"pairwise accumulation according to a predefined binary tree topology"在结构上一致。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为**机制类**证据，具象化地展示 Appendix D.1 描述的"固定二叉树累加顺序独立于 TP/GPU 数量"这一设计原理如何在 tile 级别的 Triton 实现中落地——即部分乘积（叶子节点）通过固定拓扑的两两归约（而非按 GPU/线程调度决定的顺序累加）得到本地输出，这是第 5 节"累加路径与 TP 规模解耦从而保证比特级一致"论证链条的可视化环节。但该图本身不能证明"跨 TP 配置下确实产生比特级相同的结果"——这一效果类主张需要由 Table 1/2 的数值指标验证，图 11 仅说明该机制的结构设计，不提供正确性/确定性的实验验证。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：该图对应 Appendix D.1 所述的 Intra-GPU MatMul tile 级实现，展示的是设计原理层面的通用示意（未标注具体 dtype、block size 或某个模型/GPU 的具体运行实例）。图题与正文一致（均指向"Tree-Based MatMul kernel"），无 OCR/图题冲突；无额外证据缺口。

---

## 图片 2：Figure 12. Fine-grained end-to-end latency breakdown of the Qwen3-8B model on four NVIDIA H20 GPUs under varying input/output lengths with a batch size of 64.

![Figure 12. Fine-grained end-to-end latency breakdown of the Qwen3-8B model on four NVIDIA H20 GPUs under varying input/output lengths with a batch size of 64.](../assets/imgs/img_in_chart_box_615_541_1083_732.jpg)

*来源：OCR 第 16 页。*

### 解读

1. **论文角色与验证问题**：该图对应 Appendix H.1"Fine-grained Latency Breakdown of TBIK"，是**消融验证**角色：正文第 5.4 节提到"细粒度分解见 Appendix H，MatMul 内核贡献 2~25% 开销、All-Reduce 最多贡献 10% 开销"，本图正是支撑该量化结论的具体柱状图证据，用于把 BIO+TBIK 相对 BF16 的总开销（22%~63%，Figure 7）拆解为 Tree-Based MatMul 与 Tree-Based All-Reduce 两个组件各自的贡献。`[正文支持]`
   - **图表角色**：消融验证
   - **上文呼应**：第 5.4 节"性能评估"关于开销归因的主张；Appendix H.1 正文对五种配置的定义（BF16、BIO、BIO+All-Reduce-only、BIO+MatMul-only、BIO+TBIK）。

2. **图像类型与布局**：三个并排的分组柱状图（子图），横轴均为同一组 5 个方法类别（浅蓝 BF16、粉色斜纹 BIO、绿色网格 BIO+All-Reduce、橙黄色实心 BIO+MatMul、蓝色点纹 BIO+TBIK），纵轴为 Latency(s)。三个子图分别对应不同 Input/Output 长度设置："Input 1024 Output 1024"、"Input 4096 Output 4096"、"Input 8192 Output 8192"，每根柱子上方标注具体延迟数值。

3. **如何阅读**：横向比较同一子图内 5 根柱子的高度差异，可判断各组件（All-Reduce-only vs MatMul-only）对总延迟的相对贡献；纵向比较三个子图，可判断该开销归因结论是否随输入/输出长度增大而保持一致。图例已明确标出五种方法与对应的填充样式/颜色，无需额外推断。

4. **直接可见的结论**：三个子图中延迟均按 BF16 < BIO < BIO+All-Reduce ≈ BIO+MatMul < BIO+TBIK 的顺序递增（如 Input1024/Output1024：12.54→16.68→17.91→19.84→20.47；Input8192/Output8192：320.39→352.85→370.61→385.42→391.12）；BIO+MatMul-only 柱子始终高于 BIO+All-Reduce-only 柱子，且两者均低于完整的 BIO+TBIK。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为**必要性/机制归因**类证据，验证第 5.4 节"MatMul 内核贡献 2~25% 开销，All-Reduce 最多贡献约 10% 开销"这一细粒度归因主张——图中显示单独加入 Tree-Based MatMul（BIO+MatMul）比单独加入 Tree-Based All-Reduce（BIO+All-Reduce）带来更大的延迟增量，说明在此配置下 MatMul 内核是 TBIK 总开销的主要来源，与正文"row-split 线性层仅占模型总计算的一小部分，因此 All-Reduce 效率的影响有限"的解释相符。该图同时隐含地提供了消融证据：BIO+All-Reduce-only 与 BIO+MatMul-only 均不能达到 BIO+TBIK 的完整效果（即需要两个组件共同作用才能实现完全确定性），但本图仅呈现延迟数字，并未标注这两个"only"配置下的 Count of Unique Outputs 或 Probability Divergence 是否退化为非确定性——因此该图不能单独证明"两个组件同时存在才具备确定性保证的必要性"这一主张，仅能证明延迟归因。`[基于文中逻辑的推断]`

6. **适用范围与证据缺口**：本证据覆盖论文报告的 Qwen3-8B 模型、4×NVIDIA H20 GPU（NVLink）、batch size=64、三种输入/输出长度组合（1024/1024、4096/4096、8192/8192）的设置（与 Figure 7 相同硬件环境，页码 8、16）。正文未说明 BIO+All-Reduce-only 和 BIO+MatMul-only 这两个消融配置下对应的确定性指标（Count of Unique Outputs、Probability Divergence）数值，**无法从当前 OCR 内容确认**这两个单独配置各自能否保证跨 TP 一致性,这属于正文明确未报告的实验设计细节缺口。
