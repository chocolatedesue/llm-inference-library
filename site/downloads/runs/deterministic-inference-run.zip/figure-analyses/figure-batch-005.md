# 图片批次 5

## 图片 1：Figure 8. RL training (GRPO) metrics on GSM8K using Qwen3-1.7B with four L40S GPUs.

![Figure 8. RL training (GRPO) metrics on GSM8K using Qwen3-1.7B with four L40S GPUs.](../assets/imgs/img_in_chart_box_113_132_1083_374.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文第5.5节"Bridging the Probability Gap Between vLLM and FSDP in RL"，图表角色为**实验结论**（效果类主张）。它要验证的具体问题是：TBIK 消除训练/推理引擎概率不一致后，是否能在真实 GRPO 强化学习流程中带来更稳定、更快、更好的训练效果（对应主张地图"TBIK 使 RL 训练收敛更快、奖励和 Pass@1 更高"）[正文支持]。
   - **图表角色**：实验结论。
   - **上文呼应**：第5.5节，图注"RL training (GRPO) metrics on GSM8K using Qwen3-1.7B with four L40S GPUs"，对应页码8-9正文关于 Entropy/KL Divergence/Reward/Pass@1 的描述。

2. **图像类型与布局**：四个并排的折线图（子图），标题分别为 Entropy、KL Divergence、Reward、Pass@1，横轴均为 Step（训练步数，0–100）。每个子图中有三条颜色曲线：橙色=BF16，粉紫色=BIO，绿色=BIO+TBIK；每条曲线背后有一条淡色、抖动更大的细线（原始未平滑数据），主线为平滑后的趋势线。

3. **如何阅读**：横轴为训练步数 Step（0–100），四个子图纵轴分别为 Entropy（0–0.5）、KL Divergence（0–约0.4+）、Reward（0–1.0）、Pass@1（0–约0.7+）；图例位于各子图内部，三种方法用颜色区分；应比较同一步数下三条曲线的相对高低及整体趋势走向。

4. **直接可见的结论**：
   - Entropy：三条曲线均随步数增加而下降，最终收敛在约0.1–0.25区间，曲线间有交叠，绿色（BIO+TBIK）在后段总体偏低 [基于视觉的谨慎推断]。
   - KL Divergence：绿色（BIO+TBIK）曲线在整个训练过程中稳定贴近0；橙色（BF16）在约0.2–0.5之间波动且呈缓慢下降趋势；粉紫色（BIO）介于两者之间、非零但低于BF16 [图像直接可见]。
   - Reward：三条曲线均随步数上升，最终收敛在约0.8–0.9区间，绿色曲线在多个步数段可见略高于另外两条，但存在明显交叠 [基于视觉的谨慎推断]。
   - Pass@1：三条曲线均先上升后趋于平台；绿色（BIO+TBIK）曲线明显高于另外两条，最终达到约0.7以上，橙色与粉紫色曲线大致重叠、平台在约0.6附近 [图像直接可见]。

5. **它验证的论点与方法设计含义**：这是一条**效果类**主张的直接实验证据：图中 KL Divergence 面板中绿色曲线贴近0，直接支持正文"TBIK achieves zero KL divergence, indicating bit-wise identical results between rollout and training"的陈述；Pass@1 面板中绿色曲线持续领先，支持"TBIK surpasses a Pass@1 of 0.6 within the first 20 training steps and ultimately reaches 0.73, compared to 0.68 for BIO and 0.60 for BF16"的具体数值主张（精确数值来自正文，图像上仅能看出趋势与相对高低）[正文支持]。这为"训练/推理引擎概率一致性消除后带来更稳定、更快、更优 RL 训练"这一效果主张提供了直接可视证据，说明模块三（TBIK 在 vLLM/FSDP 中的系统集成）在下游 RL 任务上的实际收益。该图不能证明这一效果能否泛化到其他数据集、模型规模或 RL 算法（如 PPO）[基于文中逻辑的推断]。

6. **适用范围与证据缺口**：本图实验设置为 GSM8K 数据集、Qwen3-1.7B 模型、四张 NVIDIA L40S GPU、vLLM 执行 TP=4 的 rollout、GRPO 算法训练100步左右（正文已明确说明，不作为缺口）。真实剩余缺口：曲线噪声较大且三条线在 Entropy 和 Reward 面板中多处交叠，无法从像素上精确读出每一步的具体数值差异（仅正文给出的 Pass@1 最终数值 0.73/0.68/0.60 可确认，其余步进细节无法逐点验证）；Appendix I.2 中的具体训练超参数未出现在本次 OCR 内容中，无法从当前 OCR 内容确认。

---

## 图片 2：Figure 10. Implementations in Batch Invariant Operations. Left: RMSNorm. Right: MatMul.

![Figure 10. Implementations in Batch Invariant Operations. Left: RMSNorm. Right: MatMul.](../assets/imgs/img_in_image_box_110_1013_575_1220.jpg)

*来源：OCR 第 13 页。*

### 解读

1. **论文角色与验证问题**：本图对应附录 B"Batch Invariant Operations"（正文第3.2节引用该附录作为 BIO 机制的示意说明），图表角色为**对比基线**（机制类主张）。它要解释/验证的问题是：BIO（batch-invariant operations）如何通过固定每个批元素/tile 的独立计算路径来实现"批不变性"，从而为后文论证"BIO 只解决批大小相关的非确定性、对 TP 无效"提供机制背景 [正文支持]。
   - **图表角色**：对比基线（机制说明）。
   - **上文呼应**：附录B正文"For RMSNorm, each token is handled independently... For MatMul, each input row is computed independently with a fixed tiling strategy and a fixed reduction order along the K dimension"；对应第3.2节"Batch-Invariant Operations and System Parallelism"的机制描述。

2. **图像类型与布局**：示意图（非曲线/表格），分为左右两部分，中间以虚线分隔。左侧标题为"Feature"，图为一个竖直矩阵，左侧标注"Batch"，矩阵按行划分为多个不同颜色的水平条带（黄、绿、蓝、红、紫等），底部有一条指向右侧的箭头标注"Reduction"。右侧标题为"N"，包含两个子块：上方是一个高矩阵，右侧有绿色竖条高亮及向下箭头标注"Reduction"；下方左侧是标注"K"和"Batch(M)"的矩阵，左下角橙色区域高亮，向右箭头标注"Reduction"；旁边另一个矩阵有紫色竖条高亮。

3. **如何阅读**：左侧图应按"每一行（不同颜色）= 一个批元素/token，各自独立在 Feature 维度上做规约"的方式解读；右侧图应按"每个 tile／每一行在 K 维度上做本地规约（下方箭头），N 维度上的输出相互独立（上方箭头）"的方式解读；图中无坐标轴刻度或图例数值，只有颜色分区和箭头方向可用于判断计算路径与规约方向。

4. **直接可见的结论**：左侧矩阵按行（Batch 维度）分色分块，每行内部沿 Feature 方向有一个规约箭头，暗示各行（各批元素）独立完成规约、互不干扰 [图像直接可见]；右侧两个子图分别在 K 维度和 N 维度方向标出规约箭头，其中 K 方向规约发生在标注"Batch(M)"的矩阵内部（橙色高亮区域），N 方向的输出以竖条形式独立标出（绿色/紫色高亮）[图像直接可见]。图中未提供任何具体数值或性能指标 [图像直接可见]。

5. **它验证的论点与方法设计含义**：这是一条**机制类**主张的示意证据，直接对应正文"each batch element compute independently...each core computes the dot products for a 2D tile and performs the full reduction locally, following a non-Split-K strategy"的文字描述：左图展示 RMSNorm 中按批行独立处理、固定规约顺序的思想，右图展示 MatMul 中按行/tile 独立完成 K 维度本地规约、N 维度输出相互独立的思想 [正文支持]。这为后文批判 BIO"仅解决批大小相关的非确定性、其规约结构与 GPU/TP 数量无关但也未特别针对 TP 设计"的论点提供了机制背景，帮助读者理解为何 BIO 的独立行处理策略不能扩展到跨 TP 的跨 GPU All-Reduce 场景（TP 场景的非确定性根源在于跨设备求和顺序，而非批内规约顺序）[基于文中逻辑的推断]。该图不能证明 BIO 在 TP>2 时失效的具体实验数据，这部分证据由 Table 1/2 提供，与本图无关。

6. **适用范围与证据缺口**：本图仅覆盖附录B对 BIO（RMSNorm、MatMul）内部实现机制的示意说明，不涉及具体模型、硬件或数值结果（正文已明确说明其为示意图，非实验图）。真实剩余缺口：图中颜色高亮块（如橙色、绿色、紫色区域）与具体矩阵维度（K、N、Batch(M)）的精确对应关系因图像分辨率和标注简略，部分细节（例如紫色竖条具体代表哪一步计算）无法从当前像素清晰确认；正文对该图的说明较简略（仅一句图注），细粒度的示意含义无法进一步从当前 OCR 内容确认。
