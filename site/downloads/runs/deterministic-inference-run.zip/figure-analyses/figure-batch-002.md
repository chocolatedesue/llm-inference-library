# 图片批次 2

## 图片 1：Figure 4. Illustrations of column-parallel and row-parallel MatMul.

![Figure 4. Illustrations of column-parallel and row-parallel MatMul.](../figure-groups/page-0004-49e6cf630ffa.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文第 3.3 节（页码 4-5），是**机制**类证据。作者在文字中给出了 column-parallel（$O=XW=[XW_1,\dots,XW_C]$，直接拼接）与 row-parallel（$XW=\sum_{i=1}^C X_iW_i$，需跨 GPU 求和）两种切分方式的数学公式，本图用示意图把这两个公式可视化，目的是解释"为什么 row-parallel 层需要 All-Reduce、而 column-parallel 层不需要"这一 TP 非确定性根源的具体机制。[正文支持]
   - **图表角色**：机制。
   - **上文呼应**：第 3.3 节"Why BIO Fail Under Different TP Sizes?"，对应 Figure 4 图注"Illustrations of column-parallel and row-parallel MatMul"。

2. **图像类型与布局**：示意图（非曲线/柱状/表格），两个并列 Panel。Panel 1（标注"Panel 1"，对应 (a) column-parallel）：输入 X（蓝色，标注"GPU 0 & GPU 1"，表示两 GPU 共享完整输入）× 权重 W（拆成绿色"GPU 0"块和橙色"GPU 1"块，虚线框分别框住）= 输出（绿橙两色并排拼接的矩阵，标"Output"）。Panel 2（对应 (b) row-parallel）：输入 X 拆成绿色"GPU 0"和橙色"GPU 1"两块（左右并排）× 权重 W 拆成绿色"GPU 0"（上）和橙色"GPU 1"（下）两块（上下堆叠）= 输出（单一紫色矩阵，标"Output"）。

3. **如何阅读**：每个 Panel 内部用"×"和"="连接三个矩阵示意块，颜色区分不同 GPU 的数据/计算归属（绿=GPU0，橙=GPU1）；重点比较两个 Panel 的"Output"矩阵颜色构成——Panel 1 输出是否保留双色分块、Panel 2 输出是否变为单一新颜色。

4. **直接可见的结论**：Panel 1（column-parallel）的输出矩阵仍清晰保留绿、橙两色并排分块，与两个 GPU 各自的部分结果一一对应，未发生颜色混合，说明输出只是两个 GPU 结果的直接拼接，没有跨 GPU 的求和步骤。Panel 2（row-parallel）的输出矩阵变为统一的紫色（不同于输入的绿色和橙色），说明该矩阵是两个 GPU 部分结果混合/合并后的产物，暗示存在一次跨 GPU 的求和（All-Reduce）操作。[图像直接可见]

5. **它验证的论点与方法设计含义**：该图为**机制类**主张提供可视化支持——"Row-parallel 层是 TP 非确定性的根源，column-parallel 层不受影响"（见主张地图）。可见证据（Panel 1 输出保持分块、Panel 2 输出发生颜色融合）直观印证了正文公式：column-parallel 各 GPU 输出相互独立、无需累加，因此改变 GPU 数量不影响计算顺序；row-parallel 需要对 K 维度的部分乘积求和，这一求和操作正是 All-Reduce 顺序依赖 GPU 数量、从而引入非确定性的具体环节。这为后续 TBIK 方法设计中"为何要同时约束 intra-GPU MatMul 与 inter-GPU All-Reduce 的规约顺序"提供了架构层面的直观解释。但该图本身不能证明"固定二叉树能保证比特级一致"这一效果类主张，那需要 Table 1/2 的实验数据支撑。[正文支持]

6. **适用范围与证据缺口**：本图是以 C=2（GPU 0、GPU 1）为例的示意性插图，用于解释正文中对任意 C 个 GPU 成立的一般公式，不代表实验测量数据。无额外证据缺口。

---

## 图片 2：Figure 3. Illustration of tensor-parallel weight partitioning in the Transformer model architecture (e.g., Qwen3 Dense) in vLLM. In this configuration, the QKV proj, gate proj, up proj, and lm head layers are column-parallel, while the o proj and down proj layers are row-parallel. For non-MatMul operations such as RMSNorm and RoPE, parameters and computations are not split across GPUs, and these layers are omitted from the figure for clarity.

![Figure 3. Illustration of tensor-parallel weight partitioning in the Transformer model architecture (e.g., Qwen3 Dense) in vLLM. In this configuration, the QKV proj, gate proj, up proj, and lm head layers are column-parallel, while the o proj and down proj layers are row-parallel. For non-MatMul operations such as RMSNorm and RoPE, parameters and computations are not split across GPUs, and these layers are omitted from the figure for clarity.](../assets/imgs/img_in_image_box_134_166_1052_430.jpg)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本图对应正文第 3.3 节（页码 4）与 Figure 3 图注，是**方法背景/机制**类证据。它把"column-parallel vs row-parallel"这一抽象切分方式，落到 Qwen3 Dense 这类真实 Transformer Decoder Layer 的具体模块（QKV proj、O proj、Gate/Up proj、Down proj、lm_head）上，回答的问题是"TP 到底在 Transformer 的哪些层、以何种方式切分权重，哪些层最终需要跨 GPU 求和"。[正文支持]
   - **图表角色**：机制。
   - **上文呼应**：第 3.3 节"Why BIO Fail Under Different TP Sizes?"，对应 Figure 3 图注"Illustration of tensor-parallel weight partitioning in the Transformer model architecture (e.g., Qwen3 Dense) in vLLM"。

2. **图像类型与布局**：架构示意图，三个虚线/实线分组框从左到右排列：橙色虚线框"Multi-Head Attention"（含 QKV proj、O proj）、灰色虚线框"Feed Forward Network"（含 Gate/Up proj、Down proj）、蓝色实线框"lm_head"。整体是一条从输入 X 经注意力、FFN 到输出 logits 的数据流，用箭头连接；每个子模块内部按颜色区分 GPU 0/GPU 1 的权重分片（如 $W_q^1,W_k^1,W_v^1$ 绿/蓝/橙 vs $W_q^2,W_k^2,W_v^2$），并用"⊕"符号标出求和节点，用"Concat"标出拼接节点。

3. **如何阅读**：沿箭头从左侧 X 输入开始，依次经过 QKV proj（分裂为 h¹/h² 两路，标注公式 head_dim*n_heads/tp_size 表示每 GPU 切分后的维度）→ Attention → O proj（输出 O¹/O²经"⊕"合并回单一 X）→ 残差流入 FFN 的 Gate/Up proj（同样分裂为 h¹/h²，标注 hidden_dim/tp_size）→ Down proj（输出 O¹/O² 经"⊕"合并）→ 最终经 lm_head（标注 vocab_size/tp_size，拆分为 lm_h¹/lm_h²）后用"Concat"（而非"⊕"）得到 Output。需重点比较各模块末端是"⊕"求和还是"Concat"拼接。

4. **直接可见的结论**：QKV proj、Gate/Up proj、lm_head 这几个模块在图中的分支路径上没有出现"⊕"求和符号，各 GPU 的分片（h¹/h²、lm_h¹/lm_h²）以并行分支形式存在，lm_head 末端明确用"Concat"框拼接为 Output；而 O proj 和 Down proj 的输出（O¹、O²）在流回主干前都经过一个明确的"⊕"圆圈符号合并为单一张量。这与图注文字"QKV proj、gate proj、up proj、lm head 为 column-parallel，o proj 和 down proj 为 row-parallel"直接对应。[图像直接可见]

5. **它验证的论点与方法设计含义**：该图为**机制类**主张"O proj 和 Down proj（row-parallel 层）是 TP 非确定性的具体触发点"提供了架构级的可视化定位，把 Figure 4 中抽象的 column/row-parallel 数学结构映射到真实 Transformer 的每个子层，说明 TBIK 需要处理 All-Reduce 的位置正是这些"⊕"节点。这支持了论文 Story 第 3 步"作者深入分析了 TP 下 column-parallel 和 row-parallel 两种切分方式的数学结构"，也为后续 TBIK 设计（约束这些"⊕"节点背后的规约顺序）提供架构依据。该图不涉及性能或确定性的实验数据，不能单独证明 TBIK 有效，需结合 Table 1/2、Figure 8/9 的实验证据。[正文支持]

6. **适用范围与证据缺口**：图注已明确说明本图以 Qwen3 Dense 在 vLLM 中的实现为例，且明确指出"RMSNorm、RoPE 等非 MatMul 操作的参数和计算未跨 GPU 切分，为清晰起见从图中省略"——这是作者主动声明的呈现范围，不构成证据缺口。无额外证据缺口。
