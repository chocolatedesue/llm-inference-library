# 图片批次 4

## 图片 1：Figure 7. End-to-end latency of the Qwen3-8B model on four NVIDIA H20 GPUs with NVLink, evaluated under varying input and output lengths with a batch size of 64.

![Figure 7. End-to-end latency of the Qwen3-8B model on four NVIDIA H20 GPUs with NVLink, evaluated under varying input and output lengths with a batch size of 64.](../assets/imgs/img_in_chart_box_612_1161_1085_1357.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：效果（代价）类证据，图表角色为**实验结论**——回答第5节提出的 RQ2「我们的方法引入了多少开销？」，量化 BIO+TBIK 相对 BF16 的端到端延迟代价。`[正文支持]`
   - **图表角色**：实验结论
   - **上文呼应**：第5.4节「End-to-End Latency Comparison」（页码8）；对应「局限」部分「BIO+TBIK 相对 BF16 引入 22%~63% 端到端延迟开销」的主张。

2. **图像类型与布局**：三组并列柱状图（grouped bar chart），每组包含 BF16（蓝色实心）、BIO（红色斜线）、BIO+TBIK（绿色网格）三根柱，柱顶标注具体数值；三组分别对应「Input 1024 Output 1024」「Input 4096 Output 4096」「Input 8192 Output 8192」三种输入/输出长度设置，纵轴为 Latency(s)。图例位于顶部。

3. **如何阅读**：横向比较三组不同输入/输出长度设置；每组内纵向比较三种方法的柱高差异（单位：秒）；应重点关注同一组内 BIO+TBIK 相对 BF16 的涨幅比例，以及该比例是否随输入/输出长度变化。

4. **直接可见的结论**：三组柱状图中 BF16 始终最低，BIO+TBIK 始终最高（三组数值分别为 12.54/16.68/20.47，95.55/125.64/130.36，320.39/352.85/391.12 秒）；BIO 均居中。计算可得：BIO 相对 BF16 涨幅分别约为 33.0%、31.5%、10.1%；BIO+TBIK 相对 BF16 总涨幅分别约为 63.2%、36.4%、22.1%。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图是效果（代价）类主张的直接数值来源，证实正文所述「BIO 单独贡献约 10~33% 开销，TBIK 在 BIO 基础上再贡献约 5~30%，合计 BIO+TBIK 总开销 22%~63%」这一区间陈述（页码8）`[正文支持]`；三组数值分别落在该区间的不同位置（63%、36%、22%），说明开销比例随输入/输出长度增大呈下降趋势，但图中未解释这一趋势的底层机制（正文也未展开），仅可作为代价量化的证据，不能扩展为对开销来源的因果解释。该图不能证明此开销比例在其他 batch size、模型规模或 GPU 型号下同样成立。

6. **适用范围与证据缺口**：本图覆盖 Qwen3-8B 模型、4×NVIDIA H20 GPU（NVLink 互联）、TP=4、batch size=64，三种输入/输出长度组合（1024/1024、4096/4096、8192/8192），BIO 采用 SGLang 实现（页码8，正文已明确说明）。无额外证据缺口。

---

## 图片 2：Figure 9. Statistics of per-token probability differences between vLLM (TP = 4) and FSDP (TP = 1) on Qwen3-8B with four NVIDIA L40S GPUs. Our method eliminates all probability gaps.

![Figure 9. Statistics of per-token probability differences between vLLM (TP = 4) and FSDP (TP = 1) on Qwen3-8B with four NVIDIA L40S GPUs. Our method eliminates all probability gaps.](../assets/imgs/img_in_chart_box_616_452_1079_732.jpg)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：效果类证据，图表角色为**对比基线**——检验 BIO 这一比较方法「只解决批大小相关非确定性、无法消除跨 TP/跨引擎概率差异」的具体局限，并验证 TBIK 能否完全消除 vLLM 与 FSDP 之间的逐 token 概率差距。`[正文支持]`
   - **图表角色**：对比基线
   - **上文呼应**：第5.5节「Bridging the Probability Gap Between vLLM and FSDP in RL」（页码8）；对应贡献边界中「解决 RL 中的概率不一致问题，达成真正的 on-policy RL」的核心主张。

2. **图像类型与布局**：直方图（histogram），横轴为 Probability Difference (%)，纵轴为 Frequency（对数刻度，1 至 10^4）；三组半透明填色柱状分布叠加显示——BF16（蓝色）、BIO（粉红色）、BIO+TBIK（绿色），图例位于右上角。

3. **如何阅读**：横轴表示 vLLM(TP=4) 与 FSDP(TP=1) 之间逐 token 概率差异的百分比区间，纵轴（对数刻度）表示落入该区间的 token 数量；应重点比较三种方法在 0% 附近的柱高，以及分布向右延伸（即出现较大概率差异）的范围和尾部形态。

4. **直接可见的结论**：BIO+TBIK（绿色）几乎全部质量集中在 0% 处，频率约 3×10^4，其余区间几乎不可见；BF16（蓝色）与 BIO（粉红色）均呈现从 0% 延伸至约 12% 的宽分布，频率随差异增大逐级衰减，BF16 在约 16%~20% 区间还出现若干孤立的低频柱（约1次量级），BIO 的分布形态与 BF16 大致相近、整体略窄。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图直接印证正文陈述「TBIK completely eliminates the probability gap, producing bit-wise identical probabilities across all tokens」（页码8）`[正文支持]`，绿色分布几乎全部落在 0% 印证"逐 token 概率差为零"的效果主张；同时印证「BIO slightly reduces the probability discrepancy between the two engines, but a noticeable gap still remains」`[正文支持]`——BF16 与 BIO 分布均延伸到较大差异区间，说明 BIO 对 TP 引发的引擎间概率差距缓解有限。这支撑模块三（TBIK 在 vLLM/FSDP 中的系统集成）的必要性论证：只有同时约束 GPU 内外规约顺序才能彻底消除该差距。该图不能证明这一效果在 MoE 模型或其他 TP 规模组合（例如 TP=8）下同样成立。

6. **适用范围与证据缺口**：本图覆盖 Qwen3-8B 模型、4×NVIDIA L40S GPU，比较对象为 vLLM(TP=4) 与 FSDP(TP=1)，统计对象为 AIME prompts 上的逐 token 概率差异（页码8，正文已明确）。图中横轴延伸至约20%但12%以上仅剩若干孤立柱，这些孤立柱各自对应的具体 token 数量和坐标轴是否存在截断，正文未说明，**无法从当前图像内容确认**。
