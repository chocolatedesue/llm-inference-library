# 图片批次 1

## 图片 1：Figure 1. Illustration of probability discrepancies in RL training. Different frameworks and TP sizes produce noticeably probability gap for the same response, hindering stable and truly on-policy RL.

![Figure 1. Illustration of probability discrepancies in RL training. Different frameworks and TP sizes produce noticeably probability gap for the same response, hindering stable and truly on-policy RL.](../assets/imgs/img_in_image_box_133_141_1057_522.jpg)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：这是复合的 Figure 1，展示论文根问题的具体量化实例——同一 response 在推理引擎（vLLM, TP=8）与训练引擎（FSDP, TP=1）下产生的概率差距 [正文支持]。
   - **图表角色**：问题严重性
   - **上文呼应**：摘要与第1节"Motivation"关于 RL 场景（场景3）——"训练与推理引擎/TP 配置不同导致概率计算出现明显差距……使 on-policy 更新变得像 off-policy"[页码：1]。

2. **图像类型与布局**：三部分复合图。(a) 左侧为流程示意图：Rollout System（vLLM, TP=8，含 Policy Model→Decode Step→Sampling）与 Training System（FSDP, TP=1，含 Actor Model→Model Forward→Loss & Backward）通过中间的"Responses"（绿色方块）相连；(b) 右上为柱状/条形图，纵轴"Max Prob Difference (%)"，横轴"Token Index"（0~7000）；(c) 底部为具体 token 序列示例，每个 token 位置给出两个候选词及各自概率，蓝色框=vLLM Rollout 候选词/概率，橙色框=FSDP Forward 候选词/概率，红色字体为 vLLM 实际采样得到的 token。

3. **如何阅读**：左图按数据流方向从左到右——Prompt 输入 vLLM 生成 Responses，再将同一 Responses 送入 FSDP 做前向/反传；右上图横轴为生成序列中的位置，纵轴为该位置两引擎间最大概率差异；底部示例逐 token 对照 vLLM 与 FSDP 给出的候选词排序与概率百分比。

4. **直接可见的结论**：
   - 右上图中大多数 token 位置的 Max Prob Difference 集中在约 2%~8%，但存在若干显著尖峰（约在 token index 1000 附近及 4000 附近），最高接近 12%~14% [图像直接可见]。
   - 底部示例显示同一位置上两引擎给出的候选词概率排序发生反转：例如首个位置 vLLM 给"Which"65%/"Let"31%，而 FSDP 给"Let"53%/"Which"41%，即 vLLM 实际采样出的"Which"在 FSDP 侧反而不是概率最高的候选；类似反转在"the/what"、"Alternatively/Since/But"等位置重复出现 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图把摘要及引言中"训练/推理引擎间存在概率差距"的抽象陈述转化为具体、可观察的量化与逐 token 证据，属于效果类主张的问题严重性展示 [正文支持]；底部候选词排序反转的例子直接支撑"这种不匹配隐性地把 on-policy 更新变成 off-policy，可能损害甚至使训练崩溃"的论断（第1节、页码1）。这构成 TBIK 方法设计的直接动机（第4节核心洞见：需统一 GPU 内外规约顺序）。但本图本身仅展示问题存在于未处理（baseline）情形下，不能证明 TBIK 能解决该问题——该验证证据见 Figure 9 与 Figure 8，本图不能替代 [正文支持]。

6. **适用范围与证据缺口**：图注仅泛称"Different frameworks and TP sizes produce noticeably probability gap"，未指明该具体示例所用的模型名称、GPU 型号、prompt 来源或 token 总长度对应哪个数据集/模型；右上图 Token Index 跨度约至 7000，与正文 Qwen 模型 thinking mode 最大输出长度 8192 接近，但正文未明确将本图指认为某一具体模型/数据集组合，**无法从当前 OCR 内容确认**这些细节。

---

## 图片 2：Figure 2. Accuracy standard deviation of Qwen3-8B on AIME24 dataset under different TP sizes (TP = 1/2/4/8).

![Figure 2. Accuracy standard deviation of Qwen3-8B on AIME24 dataset under different TP sizes (TP = 1/2/4/8).](../assets/imgs/img_in_chart_box_638_135_1061_381.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：图片清单将该图标注为对应"Figure 2. Accuracy standard deviation of Qwen3-8B on AIME24 dataset under different TP sizes (TP = 1/2/4/8)"，但图像中实际可见的横轴是"BS=8/16/32"（批大小），图例只有"BF16"与"BIO"两种方法，并未出现 TP=1/2/4/8 的分组或图例 [图像直接可见]。这构成一处**图题与可见内容的冲突**，无法确认该图像是否确为图注所指的 Figure 2，还是裁剪范围/图题关联有误。
   - **图表角色**：若按图注文字，应为问题严重性（展示 TP 变化对准确率的影响，对应页码4"超过4%准确率变化"）；但由于自变量（BS 而非 TP）和方法 legend（BF16/BIO 而非具体 TP 值）均与图注不符，本分析仅如实描述图像可见内容，不强行套用该图注所在段落的论证角色。
   - **上文呼应**：图注文字关联第4页正文"solely changing the TP size leads to over 4% accuracy variation on the AIME24 dataset for Qwen3-8B"[页码：4]，但该陈述与图像可见的 BS/BF16-BIO 对比内容无法可靠对应 [正文支持，但与图像内容的关联存疑]。

2. **图像类型与布局**：单一分组柱状图。横轴分三组：BS=8、BS=16、BS=32；每组内两根柱——蓝色为 BF16，粉色斜纹为 BIO；纵轴为"Accuracy Standard Deviation(%)"，范围 0~6；每根柱顶标注具体数值；图例位于图像顶部。

3. **如何阅读**：横轴为批大小分组，纵轴为准确率标准差（百分比），同一批大小组内比较 BF16（蓝）与 BIO（粉色斜纹）两种方法的准确率标准差高低。

4. **直接可见的结论**［图像直接可见］：
   - BS=8 时，BF16 标准差为 6.03%，BIO 为 4.34%（BIO 更低）。
   - BS=16 时，BF16 为 1.73%，BIO 为 3.30%（此时 BIO 反而更高）。
   - BS=32 时，BF16 为 5.57%，BIO 为 1.93%（BIO 更低）。
   - 三组之间 BF16 与 BIO 孰高孰低没有一致方向；BF16 自身在三个批大小间的数值波动也无单调趋势（6.03→1.73→5.57）。

5. **它验证的论点与方法设计含义**：由于图注（TP=1/2/4/8）与图像可见内容（BS=8/16/32，仅 BF16 vs BIO）无法对应，本图不能被可靠关联到"TP 变化导致 Qwen3-8B 在 AIME24 上超过4%准确率波动"这一具体主张 [基于视觉的谨慎推断，关联不可靠]。若仅依据图像本身，其至多反映"不同批大小下 BF16 与 BIO 的准确率标准差相对大小不稳定"，但正文中并无与此对应的"BF16 vs BIO 在不同批大小下准确率标准差对比"讨论段落，其确切论证角色**无法从当前 OCR 内容确认**。不应将 BS=16 时 BIO 高于 BF16 这一数值差异扩展为"BIO 在特定批大小下失效或使方差变差"的一般性结论，正文未提供支持这类推断的论述。

6. **适用范围与证据缺口**：真实缺口在于图题文字（Figure 2，TP=1/2/4/8，Qwen3-8B，AIME24）与图像可见内容（BS=8/16/32，BF16 vs BIO 图例）之间存在不可调和的冲突，无法确认是图片清单标注有误、图像裁剪区域与图题不匹配，还是二者本非同一图——此为规则允许写入的 OCR/图题冲突。因该冲突，本图对应的模型、数据集等实验设置细节也**无法从当前图像与图注组合中可靠确认**。
