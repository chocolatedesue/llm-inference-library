# 图片批次 3

## 图片 1：Figure 5. Comparison between the cuBLAS GEMM with NCCL Ring Reduce (left) and our Tree-Based Invariant Kernels (right). In the Ring Reduce, inter-GPU communication follows a ring pattern, while intra-GPU reduction is performed sequentially. In contrast, TBIK adopts a hierarchical tree structure for both intra- and inter-GPU reductions, ensuring a consistent reduction order across different TP sizes.

![Figure 5. Comparison between the cuBLAS GEMM with NCCL Ring Reduce (left) and our Tree-Based Invariant Kernels (right). In the Ring Reduce, inter-GPU communication follows a ring pattern, while intra-GPU reduction is performed sequentially. In contrast, TBIK adopts a hierarchical tree structure for both intra- and inter-GPU reductions, ensuring a consistent reduction order across different TP sizes.](../assets/imgs/img_in_image_box_114_140_1080_461.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：这是 Figure 5，作者用它直观展示第 3.3 节诊断出的机制根源以及第 4 节提出的解法设计原理——即为何 TP 规模变化会改变累加顺序（旧方法/现有系统实践的缺陷），以及 TBIK 如何通过固定二叉树拓扑消除这种依赖。证据类型为**机制**（同时兼具"方法流水线"角色，图右半部分展示 TBIK 的内部结构设计）。`[正文支持]`
   - **图表角色**：机制 / 方法流水线。
   - **上文呼应**：第 3.3 节"Why BIO Fail Under Different TP Sizes"（cuBLAS GEMM + NCCL Ring Reduce 的规约顺序依赖 GPU 数）与第 4.2 节"Components of TBIK"（固定二叉树同时约束 intra-GPU MatMul 与 inter-GPU All-Reduce）。

2. **图像类型与布局**：示意图（树形结构图），左右两大块，中间用"≠"和"="符号分隔对比结论。左块标题"cuBLAS GEMM + NCCL Ring All Reduce"，展示 TP=2（2 个 GPU，各 4 个 Tile）与 TP=4（4 个 GPU，各 2 个 Tile）两种配置下的规约树结构，二者之间标注"≠"；右块标题"Binary Tree based MatMul + All Reduce"，同样展示 TP=2 与 TP=4 两种配置，二者之间标注"="。每个子图用方块（Accumulator，灰色）、圆角矩形分组（GPU）、色块（T1=Tile，蓝色标签；P1=Partial Result，蓝色）、顶部橙色圆角块（R=Result）、虚线箭头（Intra-GPU reduce）和实线箭头（Inter-GPU reduce）构成。

3. **如何阅读**：从下往上读——底层是每个 GPU 内部的 Tile（T1-T8 按 GPU 数量切分），经过 Intra-GPU reduce（虚线箭头）汇总为该 GPU 的 Partial Result（P1、P2...），再经过 Inter-GPU reduce（实线箭头）逐级汇总为最终 Result（R）。比较的核心是同一份 8 个 Tile 的数据，在 TP=2 与 TP=4 两种切分下，规约树的**形状/层级结构**是否相同。左侧对比 GEMM+Ring 方案下 TP=2 与 TP=4 的树形状，右侧对比 Tree-Based 方案下 TP=2 与 TP=4 的树形状。图例区分了 Tile、Accumulator、Partial Result、Result 四种节点，以及 Intra-GPU reduce（虚线）与 Inter-GPU reduce（实线）两种边。

4. **直接可见的结论**：左侧 cuBLAS+Ring 方案中，TP=2 时每 GPU 内部先做两级顺序（链状）规约得到 P1/P2，再经 Ring 方式两两规约得到 R；TP=4 时每 GPU 只有 2 个 Tile 做一级规约得到 P1-P4，随后 Inter-GPU 规约呈现不同的层级路径（先 P1+P2、P3+P4，再合并），与 TP=2 时的树结构明显不同，故标注"≠"。右侧 Tree-Based 方案中，无论 TP=2 还是 TP=4，最终汇总到 R 之前的整体二叉树形状/合并顺序保持一致（TP=2 时每 GPU 内部先用二叉树合并 4 个 Tile 得到 Partial Result，再一步 Inter-GPU 合并成 R；TP=4 时每 GPU 内部二叉树合并 2 个 Tile 得到 Partial Result，再经两级二叉树 Inter-GPU 合并成 R，两种配置下从叶子到根的树拓扑一致），故标注"="。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图直接支撑第 3.3 节"BIO 无法保证跨 TP 配置可复现性"这一机制类主张——可见左侧两棵树在 TP=2 与 TP=4 下结构不同，印证"参与规约的 GPU 数量本身改变了计算顺序"；同时支撑第 4.1/4.2 节的核心方法设计主张——右侧显示固定二叉树拓扑使得 TP=2 与 TP=4 的整体累加路径保持一致，直观解释了为何 TBIK 能做到"累加顺序与 TP 规模无关"。这属于机制类证据，说明的是"为什么/如何"而非直接的数值效果；图中并未展示实际运行数值或误差数据，比特级一致性的量化验证需依赖 Table 1、Table 2（非本图内容）。`[正文支持]`

6. **适用范围与证据缺口**：本图为示意性架构对比图，展示的是 8-Tile、TP=2 与 TP=4 两种配置下的规约树结构原理，并非实测数据可视化。正文与图注均未说明该示意图是否对应某一具体层（column/row-parallel）或具体模型配置，但这是原理性图解，不需要具体实验参数。无额外证据缺口。

---

## 图片 2：Figure 6. Throughput comparison between our Tree-Based MatMul kernels and cuBLAS MatMul kernels on BF16 and FP32 as M varies, with K = 6144 and N = 2048.

![Figure 6. Throughput comparison between our Tree-Based MatMul kernels and cuBLAS MatMul kernels on BF16 and FP32 as M varies, with K = 6144 and N = 2048.](../assets/imgs/img_in_chart_box_614_522_1083_716.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：这是 Figure 6，属于第 5.4 节"Performance Evaluation"中的**实验结论**类证据（兼具对比基线角色），用于回答 RQ2"我们的方法引入了多大的开销"，具体验证 Tree-Based MatMul 内核相对 cuBLAS MatMul 内核（现有系统实践基线）在吞吐量上的性能代价。`[正文支持]`
   - **图表角色**：实验结论 / 对比基线。
   - **上文呼应**：第 5.4 节"Kernel-Level Comparison"，对应"贡献边界"中 Tree-Based MatMul 内核吞吐与 22%-63% 端到端延迟开销主张。

2. **图像类型与布局**：两个并列的折线图（曲线图）。左侧标题"BF16"，右侧标题"FP32"。每个子图内有两条曲线：蓝色"cuBLAS BF16/FP32"和橙色"Tree-Based BF16/FP32"，均带有浅色阴影（可能代表波动范围/误差带）。

3. **如何阅读**：横轴均为 M（矩阵维度参数，对应正文"K=6144, N=2048"设置下的变量），纵轴为 TFLOPs（吞吐性能）。左图纵轴范围约 0-200，右图纵轴范围约 0-40。应比较同一子图内蓝色（cuBLAS）与橙色（Tree-Based）曲线随 M 增大时的吞吐差距。

4. **直接可见的结论**：左侧 BF16 图中，两条曲线在 M 较小时都从低值快速上升，cuBLAS（蓝色）迅速攀升并稳定在接近 190 TFLOPs 附近且带有轻微高频锯齿波动，而 Tree-Based（橙色）上升较缓、最终稳定在约 110-120 TFLOPs 附近，且呈现更明显的锯齿状周期性波动，两者之间存在持续的可见差距（蓝色始终高于橙色）。右侧 FP32 图中，两条曲线在 M 增大后的中后段几乎重合，均稳定在约 35 TFLOPs 附近，橙色与蓝色差距很小。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于效果类（性能代价）证据，直接支撑正文"随批增大，Tree-Based MatMul 在 BF16 下达到 cuBLAS 约 63% 的性能（约 120 vs 190 TFLOPS）；FP32 下两者性能接近"的陈述,量化了 TBIK 引入的核心开销来源之一(树形累加需要额外临时累加器,增加 I/O 与计算量)。这为读者理解"22%-63% 端到端延迟开销"这一代价主张的来源提供了内核级别的直接证据,并划定了适用边界:该开销主要体现在 BF16 精度下,而非 FP32 精度下（FP32 本身吞吐量较低使内核实现细节的相对影响被稀释）。这只是内核微基准，不能直接等同于端到端延迟（端到端结论见 Figure 7,非本图内容）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖的实验设置为 K=6144、N=2048 固定,M 作为变量扫描,分别测试 BF16 和 FP32 两种精度下 cuBLAS 与 Tree-Based MatMul 内核的吞吐对比(图注明确说明)。曲线阴影带具体代表的统计量(如多次运行的标准差或方差范围)正文与图注均未说明,**无法从当前 OCR 内容确认**其含义。
