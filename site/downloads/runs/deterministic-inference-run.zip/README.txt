这是「Deterministic Inference across Tensor Parallel Sizes That Eliminates Training–Inference Mismatch」解构报告的原始运行数据（仅文本）。

  job id        ea5b81966db54e0ea6b1bc2340c343a3
  运行日期      2026-07-29
  prompt 版本   v11
  报告模型      claude-sonnet-5
  OCR 页数      17
  发布的 PDF    /downloads/deterministic-inference.pdf

full-text.md 是模型实际读到的 OCR 文本，pages/ 是逐页版本；report*.md 是合成的报告正文，
report*.layout.yaml 是排版 DSL，report*.typ 是 Typst 编译输入，usage.json 是 token 账本。

不含论文原文（input/source.pdf）与从原文切出的图片：第三方版权内容，且已发布的 PDF 里
嵌了实际用到的图。要重新渲染，取回原文重跑流水线，或用 report*.typ 配自己的图片资源编译。
