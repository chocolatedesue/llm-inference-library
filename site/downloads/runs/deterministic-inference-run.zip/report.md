# 论文解构报告

### 论文元数据

| 字段 | 内容 |
|---|---|
| 标题 | Deterministic Inference across Tensor Parallel Sizes That Eliminates Training–Inference Mismatch |
| 作者 | Ziyang Zhang, Xinheng Ding, Jiayi Yuan, Rixin Liu, Huizi Mao, Jiarong Xing, Zirui Liu |
| 发表场所 / 年份 | 文中未说明 |
| 研究领域 | LLM系统 |
| 关键词 | 确定性推理，张量并行，强化学习，浮点非结合性，LLM推理服务 |

### 资源链接

- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

> **标签（3–5 个）**：`确定性推理` · `张量并行` · `强化学习` · `浮点非结合性` · `LLM推理服务`

## 1. 一句话总览

论文识别出改变张量并行（TP）规模会使大模型在贪婪解码下产生不同输出、且现有"批不变算子（BIO）"无法解决这一问题[作者明确陈述][页码：1-2]，提出 Tree-Based Invariant Kernels（TBIK），用固定二叉树统一 GPU 内矩阵乘法与 GPU 间 All-Reduce 的累加顺序，实现跨 TP 规模的逐位（bit-wise）确定性推理，并消除强化学习中训练引擎与推理引擎间的概率差异[作者明确陈述][页码：1，4-5，8-9]，代价是相对 BF16 引入 22%-63% 的端到端延迟开销[作者明确陈述][页码：8]。

## 2. 阅读范围与证据状态

- OCR 覆盖正文第 1-9 页的文字与 6 批共 12 张图片/图表，包括问题动机、机制分析、方法设计与主实验（Table 1、2，Figure 1-2、4-9、11）[作者明确陈述]。
- Appendix A、C、D.1/D.2、E/F、G、H（部分）、I.1/I.2 等章节被正文引用但内容不在本次 OCR 范围内，理论证明步骤、内核实现细节、超参数等**无法从当前 OCR 内容确认**。
- 存在一处明确的图题与图像内容冲突：图片清单标注的"Figure 2（TP=1/2/4/8）"，实际可见图像横轴为 BS=8/16/32、图例仅 BF16/BIO，二者无法可靠对应，本报告不强行套用该图注[基于视觉的谨慎推断，关联不可靠]。
- 全文事实均来自论文文本与图表；涉及"批不变性""浮点非结合律"等背景解释已在术语部分标注，不作为论文结论。

## 3. 根问题：论文究竟要解决什么

- 问题定义：大模型推理结果不应只依赖模型参数与输入，但现实中相同输入、相同随机种子下，仅改变批大小（batch size）或 TP 规模，输出就会不同[作者明确陈述][页码：1]。
- 为什么重要：这在三类场景中造成实际危害——LLM-as-a-judge 评测的可比性被破坏、多智能体系统中不确定性级联放大、强化学习（RL）中训练引擎（FSDP，TP=1）与推理引擎（vLLM，TP>1）算出的概率不一致，使本应"同策略（on-policy）"的更新退化为"异策略（off-policy）"，可能损害甚至使训练崩溃[作者明确陈述][页码：1]。已有实验显示仅改变批大小和 TP 规模，AIME 数据集准确率波动可达 9%[作者明确陈述，引用 Yuan et al., 2025a][页码：1]；本文实测单独改变 TP 就能让 Qwen3-8B 在 AIME24 上产生超过 4% 的准确率波动[作者明确陈述][页码：4]。
- 难点来源：浮点加法不满足结合律（$(a+b)+c \neq a+(b+c)$），任何"求和顺序依赖设备数量"的操作都会引入非确定性[作者明确陈述][页码：3]；而 TP 的 row-parallel 层恰好需要跨 GPU 求和，规约顺序天然随参与 GPU 数变化[作者明确陈述][页码：5]。
- 本文的 story：已有的批不变算子（BIO）通过固定批维度的规约顺序解决了"批大小"这一来源的非确定性，但它没有触及"参与规约的设备数量"这一变量；本文的转折是指出并证明——只有同时固定 GPU 内和 GPU 间的累加树形结构，使其与设备数解耦，才能堵上这最后一个来源[作者明确陈述][页码：2，5]。

## 4. 旧方法为何不够

- BIO（批不变算子，He & Lab, 2025）原本解决什么：让每个批元素独立计算（如 RMSNorm 逐 token 处理，MatMul 每核心本地完成 2D tile 的完整规约、采用 Non-Split-K 策略），以保证结果不随批大小变化[作者明确陈述][页码：2-3]。
- 依赖前提：规约顺序只需与批维度无关，未考虑参与规约的物理设备数量（如 TP 的 GPU 数）本身也会改变计算路径[作者明确陈述][页码：2]。
- 失效条件：对流水线并行（PP）天然不受影响、对数据并行（DP）等价于批大小变化可保持一致；但对 TP，尤其 row-parallel 层需要跨 GPU All-Reduce 求和 K 维度部分结果，参与设备数改变即改变累加顺序[作者明确陈述][页码：3，5]。实测中 BIO 在 TP=1、2 时批不变，TP>2 或跨 TP 比较时一致性失效，Table 1 中 Count of Unique Outputs 从 BF16 的约 12 降到 BIO 的约 7-8，仍未收敛为 1[作者明确陈述][页码：7-8]。
- 本文回应：TBIK 用固定二叉树同时约束 intra-GPU MatMul 与 inter-GPU All-Reduce 的累加顺序，直接检验实验为 Table 1、2（BIO+TBIK 恒为 1/0）[作者明确陈述][页码：5，7-8]。
- 标准实现 cuBLAS GEMM + NCCL Ring All-Reduce：原本用于高效完成矩阵乘法和跨 GPU 通信，是主流推理系统默认实现[作者明确陈述][页码：5-6]；其局限是本地顺序规约与 Ring 通信的累加顺序均随 TP/GPU 数变化[作者明确陈述][页码：5]；本文用固定二叉树替代（Figure 5）[作者明确陈述][页码：5-6]；检验实验为 Kernel 吞吐对比（Figure 6）及 Table 1、2[作者明确陈述][页码：7-8]。

## 5. 核心洞见与假设

- 核心洞见（作者原话）：要实现跨 TP 规模的确定性，必须让"GPU 内矩阵乘法"与"GPU 间规约"共同设计（co-design），使浮点运算的全局累加顺序与 TP 规模无关[作者明确陈述][页码：5]。
- 实现该洞见所需的组件：Triton 实现的 Tree-Based MatMul 内核（intra-GPU）与自定义 Tree-Based All-Reduce 内核（inter-GPU），二者是支撑洞见落地的技术组件，而非独立于洞见之外的贡献[作者明确陈述][页码：5]。
- 可行性依据：若给所有 TP 配置强加同一棵固定满二叉树拓扑（部分乘积为叶子节点，内部节点两两确定性累加），无论 GPU 数 $C$ 为多少，累加路径完全相同[作者明确陈述][页码：5]。
- 第一性原理链条：浮点加法不满足结合律（页码3）→ row-parallel 输出 $XW=\sum_{i=1}^C X_iW_i$，当前系统的本地与跨 GPU 规约顺序都依赖 $C$（页码5）→ 若规约树结构固定并与 $C$ 解耦，则该运算路径唯一、结果比特级相同[基于文中逻辑的推断，推理依据：第2.1节浮点非结合律事实+第5节row-parallel求和公式+第4.1节固定二叉树设计][页码：3，5]。
- 前提可能不成立之处：文中未说明该保证在极端数值范围（如溢出/下溢边界）或非二叉可整除 tile 数下是否仍严格成立，**无法从当前 OCR 内容确认**。

## 6. 方法：从洞见到可执行系统

总览：输入为待并行执行的 MatMul（沿 K 维度按 TP 切分成 tile），经 intra-GPU 树形规约得到各 GPU 本地部分结果，再经 inter-GPU 树形 All-Reduce 得到全局一致输出，最终以打补丁方式接入 vLLM（推理）与 FSDP（训练），使二者概率计算完全一致[作者明确陈述][页码：5，8]。

1. **模块一：Intra-GPU Tree-Based MatMul Kernel**
   - **动机**：cuBLAS 等标准 GEMM 沿 K 维度顺序规约，其顺序随每 GPU 分到的 tile 数（$T_K/C$）变化，是非确定性来源之一[作者明确陈述][页码：5]。
   - **运行方式**：Triton 实现，将 $T_K/C$ 个 tile 组织成深度 $L=\log_2(T_K/C)$ 的固定二叉树，叶子节点为部分乘积，内部节点两两确定性累加，输出该 GPU 的本地累加结果[作者明确陈述][页码：5]。
   - **技术优势**：本地累加顺序与 TP 规模 $C$ 无关，跨 TP 配置时同一 GPU 内计算路径完全相同[作者明确陈述][页码：5]。
2. **模块二：Inter-GPU Tree-Based All-Reduce**
   - **动机**：标准 NCCL Ring All-Reduce 的规约顺序依赖参与 GPU 数量，是 row-parallel 层输出依赖 TP 规模的直接原因[作者明确陈述][页码：5]。
   - **运行方式**：沿用与模块一相同的二叉树拓扑跨 GPU 规约，输出全局一致结果[作者明确陈述][页码：5]。
   - **技术优势**：全局累加路径与 GPU 数解耦，作者称 Appendix C 有理论证明，但证明内容未出现在本 OCR 中[作者明确陈述，证明细节无法从当前 OCR 内容确认][页码：5]。
3. **模块三：TBIK 在 vLLM / FSDP 中的系统集成**
   - **动机**：RL 中 rollout（vLLM，TP>1）与训练（FSDP，通常 TP=1）引擎配置不同，使同一参数 $\theta$ 算出不同概率，隐性把 on-policy 更新变为 off-policy[作者明确陈述][页码：3]。
   - **运行方式**：以打补丁方式接入两个框架（Appendix I.1 细节未在 OCR 中）[作者明确陈述][页码：8]。
   - **技术优势**：实现两引擎间逐 token 概率差为零，避免 MoE 模型路由器因微小概率扰动选择不同专家的后果[作者明确陈述][页码：3-4，8]。

## 7. 为什么它可能有效

- 机制 → 收益：固定二叉树使累加路径与设备数解耦 → 跨 TP 配置下浮点运算路径唯一 → 结果比特级相同[基于文中逻辑的推断][页码：5]，该链条已由 Table 1（Count of Unique Outputs=1）与 Table 2（Divergence=0）实证支撑[作者明确陈述，实验支持][页码：7-8]。
- 机制 → 收益：intra 与 inter 两个模块共同约束 → 消除 vLLM/FSDP 之间的概率差距 → RL 更新真正 on-policy，减少策略与数据分布偏差 → 训练更稳定、收敛更快[基于文中逻辑的推断，实验支持见 Figure 8、9][页码：8-9]。
- 需要的条件：该保证依赖二叉树拓扑在不同 TP 规模下均可构造（如 tile 数可被 2 整除的层级划分），文中未展开非理想切分情形下的处理方式，**无法从当前 OCR 内容确认**。

## 8. 实验与指标：证据是否支撑主张

### 8.1 实验问题与判定标准

- 效果问题：跨 TP/batch 配置下输出是否比特级一致？对应比较 BF16 vs BIO vs BIO+TBIK，判定标准为 Table 1 的 Count of Unique Outputs 是否收敛为 1[作者明确陈述][页码：6-7]。
- 效果问题：训练/推理引擎间概率差距是否被消除？对应 Table 2 的 Maximum Probability Divergence 是否为 0，以及 Figure 9 分布形态[作者明确陈述][页码：7-8]。
- 必要性问题：是否需要同时具备 intra 与 inter 两个模块？对应 Figure 6 消融图（BIO+All-Reduce-only vs BIO+MatMul-only）的延迟归因，但未报告两个 only 配置各自的确定性指标[作者明确陈述，缺口见后文][页码：16]。
- 效果问题：TBIK 对下游 RL 训练效果的影响？对应 Figure 8 的 Entropy/KL/Reward/Pass@1[作者明确陈述][页码：8-9]。
- 代价问题：TBIK 引入多少性能开销？对应 Figure 6（内核吞吐）与 Figure 7（端到端延迟）[作者明确陈述][页码：7-8]。

### 8.2 数据、任务、对比与运行设置

- 模型：Qwen3-8B、Qwen3-32B、Mistral-7B-Instruct、Llama-3.1-8B-Instruct（确定性主实验）；Qwen3-1.7B（RL 实验）[作者明确陈述][页码：6-9]。
- 数据集：AIME24、AMC23（确定性实验）；GSM8K（RL 训练）；AIME prompts（Figure 9 概率差异统计）[作者明确陈述][页码：6-8]。
- 系统/框架：vLLM（推理）、FSDP（训练）、BIO 部分实现引用 SGLang[作者明确陈述][页码：8]。
- 硬件：4×NVIDIA H20（NVLink，延迟实验）、4×NVIDIA L40S（RL 与概率差实验）；RTX PRO 6000 结果见 Appendix G，未在本 OCR 中[作者明确陈述][页码：6-8]；**无法从当前 OCR 内容确认**RTX PRO 6000 具体数值。
- 运行配置：12/9 种运行时配置（TP×batch 组合）；TP=4、batch size=64（延迟实验）[作者明确陈述][页码：6-8]。
- 重复次数/统计方式、具体超参数：文中未说明。

### 8.3 指标字典与对应公式

- **指标与方向**：Count of Unique Outputs（唯一输出数量），测量对象为同一输入在多种运行时配置下产生的不同输出字符串数量，取值范围为正整数，越小越好，理想值为 1[作者明确陈述][页码：6-7]。
  - **来源层级**：无可核验公式；作者文字定义为"跨配置产生的不同输出的计数"，未给出具体计算公式或 Eq. 编号[作者明确陈述][页码：6-7]。
  - **实验用途**：检验跨 TP/batch 配置下是否比特级一致，用于比较 BF16、BIO、BIO+TBIK[作者明确陈述][页码：6-7]。
  - **读数与边界**：BF16 接近配置总数（如 Qwen3-8B/AIME24 为 12.00），BIO 降至约 7-8 但未到 1，BIO+TBIK 四模型两数据集全部为 1[作者明确陈述，实验支持][页码：6-7]；该指标只反映最终输出字符串是否相同，不直接反映中间概率数值差异。
- **指标与方向**：Maximum Probability Divergence（最大概率散度），测量对象为不同配置间逐 token 概率的最大差异，单位 $\times10^{-3}$，越小越好，理想值为 0[作者明确陈述][页码：7-8]。
  - **来源层级**：无可核验公式；仅有文字定义与数值表，未给出显式公式或 Eq. 编号[作者明确陈述][页码：7-8]。
  - **实验用途**：量化跨配置概率分布一致性，与 Count of Unique Outputs 互补（后者看离散输出，前者看连续概率）[作者明确陈述][页码：7-8]。
  - **读数与边界**：BIO+TBIK 在所有模型/数据集组合下为 0；BF16、BIO 均非零（如 Llama-3.1-8B-Instruct/AMC23：BF16=31.09、BIO=21.06）[作者明确陈述，实验支持][页码：7-8]；该指标未说明具体统计口径（如取全体 token 的最大值还是均值），**无法从当前 OCR 内容确认**其聚合方式细节。
- **指标与方向**：Kernel 吞吐（TFLOPs），测量对象为 MatMul 内核吞吐率，越大越好[作者明确陈述][页码：7-8]。
  - **来源层级**：无可核验公式；来自 Figure 6 图像趋势与文字描述[作者明确陈述][页码：7-8]。
  - **实验用途**：定位 TBIK 相对 cuBLAS 的性能代价来源[作者明确陈述][页码：7-8]。
  - **读数与边界**：BF16 下 Tree-Based 约为 cuBLAS 的 63%（约120 vs 190 TFLOPS）；FP32 下二者接近[作者明确陈述][页码：7-8]；仅为内核微基准，不等同端到端延迟。
- **指标与方向**：端到端延迟（秒），测量对象为完整推理请求耗时，越小越好[作者明确陈述][页码：8]。
  - **来源层级**：无可核验公式；来自 Figure 7 实测柱状数值[作者明确陈述][页码：8]。
  - **实验用途**：量化 BIO、TBIK 各自及合计相对 BF16 的开销比例[作者明确陈述][页码：8]。
  - **读数与边界**：BIO+TBIK 总开销 22%~63%，随输入/输出长度增大呈下降趋势（三组分别约63.2%、36.4%、22.1%）[作者明确陈述，实验支持][页码：8]；未解释该趋势的底层机制。

### 8.4 主结果、消融与证据边界

**比较工作与被批判限制的呼应**

| 比较工作/基线 | 核心限制或失效条件 | 本文对应模块 | 直接实验与仍未验证的边界 |
|---|---|---|---|
| BIO（批不变算子） | 只解决批大小非确定性，TP>2 时 All-Reduce 仍随 GPU 数变化 | TBIK 的 intra+inter 树形规约 | Table 1/2 直接验证；MoE 模型、TP=8 等场景**文中未说明** |
| cuBLAS+NCCL Ring | 本地/跨 GPU 累加顺序均随 GPU 数变化 | TBIK 固定二叉树替代 | Figure 6 内核吞吐对比；仅覆盖 K=6144,N=2048 一种矩阵形状 |
| vanilla BF16 | 无任何确定性处理，波动最大 | TBIK 整体方案 | Table 1/2、Figure 8 直接验证；未覆盖其他 RL 算法（如 PPO） |

- **主张 -> 直接证据 -> 证据强度与边界**：

| 主张 | 直接证据（实验/表图） | 证据强度与边界 |
|---|---|---|
| BIO+TBIK 实现跨 TP/batch 逐位一致 | Table 1（Count=1）、Table 2（Divergence=0） | [实验支持]，覆盖4模型×2数据集；MoE 及更大 TP 未验证 |
| TBIK 消除 vLLM/FSDP 概率差距 | Figure 9 直方图 | [实验支持]，仅 Qwen3-8B、TP=4 vs TP=1 一组配置 |
| TBIK 提升 RL 训练效果 | Figure 8（Pass@1: 0.73 vs 0.68 vs 0.60） | [实验支持]，仅 GSM8K+Qwen3-1.7B 单一设置，未验证泛化性 |
| 开销主要来自 MatMul 内核而非 All-Reduce | Figure 6（图片2，附录H细分柱状图） | [基于文中逻辑的推断]，未报告两个 only 配置的确定性指标，无法证明"两模块同时存在才具备确定性必要性" |

- 三组延迟数值均为绝对秒数直接对比，未见相对基线的统计显著性检验，**文中未说明**。
- Table 1/2 覆盖 4 模型×2 数据集，但均为稠密模型，MoE 场景仅为理论推测。
- 消融实验（Figure 6 图2）只给出延迟归因，未给出对应的确定性指标退化情况，是明确的证据缺口。

## 9. 图表解读与论证关系

### 图片原件与标题

#### 原始图片 1：Figure 1. Illustration of probability discrepancies in RL training. Different frameworks and TP sizes produce noticeably probability gap for the same response, hindering stable and truly on-policy RL.

![Figure 1. Illustration of probability discrepancies in RL training. Different frameworks and TP sizes produce noticeably probability gap for the same response, hindering stable and truly on-policy RL.](assets/imgs/img_in_image_box_133_141_1057_522.jpg)

*来源：OCR 第 2 页。*

---

#### 原始图片 2：Figure 2. Accuracy standard deviation of Qwen3-8B on AIME24 dataset under different TP sizes (TP = 1/2/4/8).

![Figure 2. Accuracy standard deviation of Qwen3-8B on AIME24 dataset under different TP sizes (TP = 1/2/4/8).](assets/imgs/img_in_chart_box_638_135_1061_381.jpg)

*来源：OCR 第 3 页。*

---

#### 原始图片 3：Figure 4. Illustrations of column-parallel and row-parallel MatMul.

![Figure 4. Illustrations of column-parallel and row-parallel MatMul.](figure-groups/page-0004-49e6cf630ffa.png)

*来源：OCR 第 4 页。*

---

#### 原始图片 4：Figure 3. Illustration of tensor-parallel weight partitioning in the Transformer model architecture (e.g., Qwen3 Dense) in vLLM. In this configuration, the QKV proj, gate proj, up proj, and lm head layers are column-parallel, while the o proj and down proj layers are row-parallel. For non-MatMul operations such as RMSNorm and RoPE, parameters and computations are not split across GPUs, and these layers are omitted from the figure for clarity.

![Figure 3. Illustration of tensor-parallel weight partitioning in the Transformer model architecture (e.g., Qwen3 Dense) in vLLM. In this configuration, the QKV proj, gate proj, up proj, and lm head layers are column-parallel, while the o proj and down proj layers are row-parallel. For non-MatMul operations such as RMSNorm and RoPE, parameters and computations are not split across GPUs, and these layers are omitted from the figure for clarity.](assets/imgs/img_in_image_box_134_166_1052_430.jpg)

*来源：OCR 第 4 页。*

---

#### 原始图片 5：Figure 5. Comparison between the cuBLAS GEMM with NCCL Ring Reduce (left) and our Tree-Based Invariant Kernels (right). In the Ring Reduce, inter-GPU communication follows a ring pattern, while intra-GPU reduction is performed sequentially. In contrast, TBIK adopts a hierarchical tree structure for both intra- and inter-GPU reductions, ensuring a consistent reduction order across different TP sizes.

![Figure 5. Comparison between the cuBLAS GEMM with NCCL Ring Reduce (left) and our Tree-Based Invariant Kernels (right). In the Ring Reduce, inter-GPU communication follows a ring pattern, while intra-GPU reduction is performed sequentially. In contrast, TBIK adopts a hierarchical tree structure for both intra- and inter-GPU reductions, ensuring a consistent reduction order across different TP sizes.](assets/imgs/img_in_image_box_114_140_1080_461.jpg)

*来源：OCR 第 6 页。*

---

#### 原始图片 6：Figure 6. Throughput comparison between our Tree-Based MatMul kernels and cuBLAS MatMul kernels on BF16 and FP32 as M varies, with K = 6144 and N = 2048.

![Figure 6. Throughput comparison between our Tree-Based MatMul kernels and cuBLAS MatMul kernels on BF16 and FP32 as M varies, with K = 6144 and N = 2048.](assets/imgs/img_in_chart_box_614_522_1083_716.jpg)

*来源：OCR 第 7 页。*

---

#### 原始图片 7：Figure 7. End-to-end latency of the Qwen3-8B model on four NVIDIA H20 GPUs with NVLink, evaluated under varying input and output lengths with a batch size of 64.

![Figure 7. End-to-end latency of the Qwen3-8B model on four NVIDIA H20 GPUs with NVLink, evaluated under varying input and output lengths with a batch size of 64.](assets/imgs/img_in_chart_box_612_1161_1085_1357.jpg)

*来源：OCR 第 7 页。*

---

#### 原始图片 8：Figure 9. Statistics of per-token probability differences between vLLM (TP = 4) and FSDP (TP = 1) on Qwen3-8B with four NVIDIA L40S GPUs. Our method eliminates all probability gaps.

![Figure 9. Statistics of per-token probability differences between vLLM (TP = 4) and FSDP (TP = 1) on Qwen3-8B with four NVIDIA L40S GPUs. Our method eliminates all probability gaps.](assets/imgs/img_in_chart_box_616_452_1079_732.jpg)

*来源：OCR 第 8 页。*

---

#### 原始图片 9：Figure 8. RL training (GRPO) metrics on GSM8K using Qwen3-1.7B with four L40S GPUs.

![Figure 8. RL training (GRPO) metrics on GSM8K using Qwen3-1.7B with four L40S GPUs.](assets/imgs/img_in_chart_box_113_132_1083_374.jpg)

*来源：OCR 第 8 页。*

---

#### 原始图片 10：Figure 10. Implementations in Batch Invariant Operations. Left: RMSNorm. Right: MatMul.

![Figure 10. Implementations in Batch Invariant Operations. Left: RMSNorm. Right: MatMul.](assets/imgs/img_in_image_box_110_1013_575_1220.jpg)

*来源：OCR 第 13 页。*

---

#### 原始图片 11：Figure 11. Illustration of our Tree-Based MatMul kernel.

![Figure 11. Illustration of our Tree-Based MatMul kernel.](assets/imgs/img_in_image_box_615_136_1079_359.jpg)

*来源：OCR 第 14 页。*

---

#### 原始图片 12：Figure 12. Fine-grained end-to-end latency breakdown of the Qwen3-8B model on four NVIDIA H20 GPUs under varying input/output lengths with a batch size of 64.

![Figure 12. Fine-grained end-to-end latency breakdown of the Qwen3-8B model on four NVIDIA H20 GPUs under varying input/output lengths with a batch size of 64.](assets/imgs/img_in_chart_box_615_541_1083_732.jpg)

*来源：OCR 第 16 页。*

### 图/表：Figure 1（训练/推理引擎概率差距实例）

- **图组结论**：vLLM(TP=8)与FSDP(TP=1)之间逐token最大概率差异集中在2%~8%，存在若干尖峰近12%~14%；底部示例显示候选词排序发生反转[图像直接可见][页码：1-2]。
- **论证关系**：把摘要中"训练/推理引擎存在概率差距"的抽象陈述转化为具体证据，构成TBIK方法设计的直接动机；本身不证明TBIK能解决该问题，该验证见Figure 8、9[正文支持]。
- **适用范围**：未指明具体模型/数据集，**无法从当前 OCR 内容确认**。

### 图/表：Figure 2（准确率标准差，图题与图像内容存疑）

- **图组结论**：图像显示BS=8/16/32下BF16与BIO的准确率标准差无一致高低方向[图像直接可见][页码：4]。
- **论证关系**：因图题（TP=1/2/4/8）与图像可见内容（BS分组、BF16/BIO图例）无法对应，本图不能可靠关联到"TP变化导致超4%准确率波动"这一具体主张[基于视觉的谨慎推断，关联不可靠]。
- **适用范围**：图题与图像内容冲突未解决，具体实验设置**无法从当前 OCR 内容确认**。

### 图/表：Figure 4（column-parallel vs row-parallel 机制示意）

- **图组结论**：column-parallel输出保持双色分块（拼接），row-parallel输出变为单色（求和融合）[图像直接可见][页码：4-5]。
- **论证关系**：为"row-parallel是TP非确定性根源"提供可视化支撑，衔接方法设计中对All-Reduce的处理[正文支持]。
- **适用范围**：为C=2的示意性插图，不代表实测数据；无额外缺口。

### 图/表：Figure 3（Transformer各层TP切分方式）

- **图组结论**：QKV proj、Gate/Up proj、lm_head为column-parallel（Concat），O proj、Down proj为row-parallel（⊕求和）[图像直接可见][页码：4]。
- **论证关系**：将抽象切分方式定位到真实Transformer子层，为TBIK需处理的具体位置提供架构依据[正文支持]。
- **适用范围**：以Qwen3 Dense在vLLM中的实现为例，RMSNorm/RoPE等非MatMul操作被作者主动省略，非证据缺口。

### 图/表：Figure 5（规约树结构对比）

- **图组结论**：cuBLAS+Ring方案下TP=2与TP=4的规约树结构不同（标注"≠"）；Tree-Based方案下两种TP的树拓扑一致（标注"="）[图像直接可见][页码：5-6]。
- **论证关系**：直接支撑"BIO无法保证跨TP复现性"的机制诊断，以及TBIK"累加顺序与TP规模无关"的设计原理；不提供数值验证，量化证据见Table 1/2[正文支持]。
- **适用范围**：8-Tile示意性架构图，非实测数据；无额外缺口。

### 图/表：Figure 6（Kernel级吞吐对比）

- **图组结论**：BF16下Tree-Based吞吐约为cuBLAS的63%（约120 vs 190 TFLOPS）；FP32下二者接近[图像直接可见][页码：7-8]。
- **论证关系**：定位22%-63%端到端开销的内核级来源，与Figure 7互补（内核级 vs 端到端）[正文支持]。
- **适用范围**：仅K=6144、N=2048一种矩阵形状；阴影带含义**无法从当前 OCR 内容确认**。

### 图/表：Figure 7（端到端延迟对比）

- **图组结论**：三组输入/输出长度下延迟均为BF16<BIO<BIO+TBIK，总开销分别约63.2%、36.4%、22.1%，随长度增大而下降[图像直接可见][页码：8]。
- **论证关系**：直接量化代价类主张，是"22%-63%开销"陈述的数值来源[正文支持]。
- **适用范围**：仅Qwen3-8B、4×H20、TP=4、batch=64场景，未验证其他配置。

### 图/表：Figure 9（vLLM/FSDP概率差异分布）

- **图组结论**：BIO+TBIK几乎全部集中在0%；BF16与BIO均延伸至约12%甚至更远[图像直接可见][页码：8]。
- **论证关系**：直接支撑"TBIK完全消除概率差距"的效果主张，同时印证"BIO对该差距缓解有限"的批判，支撑模块三必要性[正文支持]。
- **适用范围**：仅Qwen3-8B、4×L40S、TP=4 vs TP=1、AIME prompts场景；MoE或TP=8场景未验证。

### 图/表：Appendix B 示意图（BIO机制说明）

- **图组结论**：左图展示RMSNorm按批行独立规约，右图展示MatMul沿K维度本地规约、N维度输出独立[图像直接可见][页码：附录B]。
- **论证关系**：为"BIO规约结构与批维度绑定、未特别处理TP场景"提供机制背景[基于文中逻辑的推断]。
- **适用范围**：纯机制示意图，不涉及数值结果，无额外缺口。

### 图/表：Figure 11（Intra-GPU Tree-Based MatMul结构）

- **图组结论**：部分乘积作为叶子节点，经两两配对逐级合并为单一输出[图像直接可见][页码：附录D.1]。
- **论证关系**：具象化固定二叉树累加原理如何在tile级Triton实现中落地，是第5节机制论证的可视化环节；不提供正确性/确定性的实验验证[基于文中逻辑的推断]。
- **适用范围**：通用设计原理图，未标注具体dtype/block size/模型实例，无额外缺口。

### 图/表：Appendix H.1 细粒度延迟分解

- **图组结论**：延迟按BF16<BIO<BIO+All-Reduce≈BIO+MatMul<BIO+TBIK递增，MatMul-only贡献大于All-Reduce-only[图像直接可见][页码：16]。
- **论证关系**：支撑"MatMul内核贡献2%~25%开销、All-Reduce最多贡献10%"的归因主张；不能单独证明两组件同时存在才具备确定性必要性（缺少对应确定性指标）[基于文中逻辑的推断]。
- **适用范围**：仅覆盖Qwen3-8B、4×H20场景；两个only配置的确定性指标**无法从当前 OCR 内容确认**。

## 10. 完整因果推理树

- 根问题：为何相同输入+相同随机种子，仅改变TP规模就会得到不同输出？[页码：1]
  - 旧方法限制：BIO只固定批维度规约顺序，未处理跨GPU设备数变化导致的累加顺序变化[页码：2-3]
  - 核心洞见/假设：需co-design GPU内MatMul与GPU间All-Reduce，使全局累加顺序与TP规模解耦[页码：5]
    - 方法模块：Intra-GPU Tree-Based MatMul（固定二叉树本地规约）[页码：5]
      - 可验证预测：本地累加路径与GPU数无关
        - 指标与实验：Count of Unique Outputs（Table 1）
          - 图表证据：Figure 11（结构示意，未被当前证据直接验证正确性/确定性）
            - 结论与适用边界：结构设计合理但无独立单元测试，[基于文中逻辑的推断]
    - 方法模块：Inter-GPU Tree-Based All-Reduce（固定二叉树跨GPU规约）[页码：5]
      - 可验证预测：全局累加路径与GPU数解耦，实现比特级一致
        - 指标与实验：Count of Unique Outputs=1、Maximum Probability Divergence=0（Table 1、2）
          - 图表证据：Figure 5（树结构对比示意）
            - 结论与适用边界：4模型×2数据集验证，[实验支持]；MoE/更大TP未被当前证据直接验证
    - 方法模块：vLLM/FSDP系统集成（RL场景）[页码：8]
      - 可验证预测：训练/推理引擎逐token概率差为零，提升RL训练效果
        - 指标与实验：Figure 9概率差分布、Figure 8（Entropy/KL/Reward/Pass@1）
          - 图表证据：Figure 9直方图、Figure 8四子图
            - 结论与适用边界：单一GSM8K+Qwen3-1.7B设置下验证，[实验支持]；其他任务/算法/模型规模未被当前证据直接验证

## 11. 结论、贡献与边界

- 贡献：（1）识别并分析TP引发的非确定性根源及其对评测和RL训练的影响；（2）提出TBIK固定二叉树方案消除该非确定性；（3）将TBIK集成进vLLM/FSDP实现完全确定性推理与真正on-policy RL[作者明确陈述][页码：2]。
- 证据充分的结论：跨TP/batch配置下BIO+TBIK实现Count of Unique Outputs=1、Maximum Probability Divergence=0（Table 1、2）[实验支持][页码：7-8]；相对BF16引入22%-63%端到端延迟开销（Figure 7）[实验支持][页码：8]。
- 尚属推断的意义：固定二叉树设计原理具备理论可推广性（不限于本文测试的4个模型），但MoE模型、更大TP规模、其他RL算法上的效果为[基于文中逻辑的推断]而非直接实验验证。
- 适用条件：稠密Transformer模型、vLLM/FSDP框架、本文测试的GPU型号（H20、L40S）；RTX PRO 6000结果未在本OCR中确认。
- 局限：性能代价明确（22%-63%开销）；内核实现为概念验证阶段，未做block size调优、warp specialization等工程优化[作者明确陈述][页码：7-8]；MoE模型与更大规模RL训练场景缺乏直接实验。
- **审稿式风险检查**：
  - 贡献新意：核心贡献（固定二叉树同时约束intra/inter规约）在本OCR范围内表述清晰，未发现明显与已有工作重叠的证据；当前证据未显示该风险。
  - 写作/可复现性：多处关键细节（内核实现Appendix D.2、理论证明Appendix C、训练超参Appendix I.2）未在OCR中出现，复现所需信息不完整，属真实风险。
  - 效果大小：主张的确定性效果（Count=1、Divergence=0）证据扎实；但RL收益（Pass@1提升）仅在单一小规模设置下验证，效果外推存在不确定性。
  - 实验覆盖：仅稠密模型、两个评测数据集、单一RL任务，MoE与其他RL算法未覆盖，为真实覆盖缺口。
  - 方法设计：消融实验（Appendix H.1）只报告延迟归因，未报告two-only配置下的确定性指标，无法完全确认两模块的必要性，属真实证据缺口。

## 12. 术语与第一性原理学习路径

### 12.1 核心术语

- **术语**：张量并行（Tensor Parallelism, TP）——把一层的权重矩阵切分到多个GPU并行计算的并行策略。
  - **第一性原理角色**：连接"计算资源（多GPU）"与"单层计算延迟"两个基本量，受限于跨设备通信带宽。
  - **本文位置**：TP的row-parallel层是非确定性根源，本文核心方法围绕其展开[页码：4-5]。
- **术语**：批不变算子（Batch-Invariant Operations, BIO）——固定每个批元素独立计算路径的算子实现。
  - **第一性原理角色**：约束的是"批维度"这一变量对累加顺序的影响，不涉及设备数变量。
  - **本文位置**：作为主要比较基线，是本文批判与对照的对象[页码：2-3]。
- **术语**：浮点非结合律——计算机浮点加法 $(a+b)+c \neq a+(b+c)$，源于每步舍入误差。
  - **第一性原理角色**：是所有本文讨论的非确定性现象的数学根源。
  - **本文位置**：第2.1节给出，贯穿全文机制解释[页码：3]。
- **术语**：All-Reduce——多GPU间把各自部分结果求和并同步给所有GPU的通信操作。
  - **第一性原理角色**：连接"分布式部分计算结果"与"全局一致结果"，其规约顺序受参与设备数约束。
  - **本文位置**：row-parallel层输出依赖的关键操作，是TBIK的Inter-GPU模块直接改造对象[页码：5]。
- **术语**：Tree-Based Invariant Kernels（TBIK）——本文提出的固定二叉树规约内核集合。
  - **第一性原理角色**：把"累加路径"这一因果链条与"设备数"变量解耦。
  - **本文位置**：全文核心方法，第4-5节[页码：5]。
- **术语**：on-policy / off-policy——RL中训练数据是否严格来自当前策略。
  - **第一性原理角色**：连接"数据生成路径"与"训练更新有效性"两个基本量。
  - **本文位置**：解释为何训练/推理引擎不一致会损害RL训练[页码：1，3]。
- **术语**：Count of Unique Outputs / Maximum Probability Divergence——本文自定义的确定性度量指标。
  - **第一性原理角色**：分别从离散输出与连续概率两个层面观测"计算路径是否唯一"这一因果结果。
  - **本文位置**：Table 1、2主实验的核心指标[页码：6-8]。

### 12.2 学习路径

1. 浮点数与舍入误差——理解为何计算机加法不满足结合律，是全文一切非确定性讨论的地基。
2. 张量并行的两种切分方式（column/row-parallel）——理解为何有些层不受GPU数影响、有些层必须求和。
3. All-Reduce通信操作——理解跨GPU求和如何依赖参与设备数，进而理解非确定性的具体触发点。
4. 强化学习中的on-policy要求——理解为何"训练/推理引擎计算路径不同"会实际损害模型训练效果，而不只是理论瑕疵。
5. 二叉树规约结构——理解固定拓扑如何把"求和顺序"这一变量从"设备数量"中解耦出来，是本文方法能成立的关键机制。

---

*本报告由 paper-pipeline 生成 · prompt `v11` · backend `cli_agent` · model `claude-sonnet-5` · 2026-07-26T11:57:13*
