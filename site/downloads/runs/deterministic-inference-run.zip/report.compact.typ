#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#set table(
  inset: (x: 5pt, y: 4.2pt),
  stroke: (x, y) => (top: 0.4pt + luma(205), bottom: 0.4pt + luma(205)),
  fill: (x, y) => if y == 0 { rgb(25, 79, 95, 11%) } else if calc.odd(y) { luma(250) } else { none },
)
#show table: set text(size: 8.7pt, hyphenate: false)
#show table: set par(leading: 0.62em, spacing: 0.5em)
#show table.cell.where(y: 0): set text(weight: "bold", fill: rgb(25, 79, 95))
#let comparison-card(title, body) = block(
  width: 100%,
  inset: (x: 7pt, y: 6pt),
  radius: 3pt,
  fill: luma(252),
  stroke: 0.6pt + rgb(25, 79, 95, 45%),
)[
  #text(font: "Noto Sans CJK SC", size: 9.5pt, weight: "bold", fill: rgb(25, 79, 95))[#title]
  #v(2.5pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.68em, spacing: 0.5em)
  #set list(indent: 0.55em, body-indent: 0.4em, spacing: 0.42em)
  #body
]
#let critique-card(name, premise, limit, response, evidence) = block(
  width: 100%,
  inset: (x: 8pt, y: 7pt),
  radius: 3pt,
  fill: luma(253),
  stroke: 0.6pt + luma(208),
)[
  #text(font: "Noto Sans CJK SC", size: 9.8pt, weight: "bold", fill: rgb(25, 79, 95))[#name]
  #if premise != [] [
    #v(1.5pt)
    #text(size: 8.3pt, fill: luma(105))[前提：#premise]
  ]
  #v(4pt)
  #set text(size: 8.9pt, hyphenate: false)
  #set par(leading: 0.66em, spacing: 0.45em, justify: true)
  #grid(
    columns: (1.12fr, 22pt, 0.88fr),
    align: horizon,
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(176, 74, 40, 9%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(150, 58, 28))[本文指出的失效点]
      #v(2pt)
      #limit
    ],
    align(center)[#text(size: 15pt, fill: rgb(25, 79, 95))[#sym.arrow.r]],
    block(width: 100%, inset: (x: 6pt, y: 5pt), radius: 3pt, fill: rgb(25, 79, 95, 10%))[
      #text(size: 8.2pt, weight: "bold", fill: rgb(25, 79, 95))[本文对应模块]
      #v(2pt)
      #response
    ],
  )
  #if evidence != [] [
    #v(4pt)
    #text(size: 8.3pt, fill: luma(95))[检验：#evidence]
  ]
]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[Deterministic Inference across Tensor Parallel Sizes That Eliminates Training–Inference Mismatch]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Ziyang Zhang, Xinheng Ding, Jiayi Yuan, Rixin Liu, Huizi Mao, Jiarong Xing, Zirui Liu]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[确定性推理] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[张量并行] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[强化学习] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[浮点非结合性] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM推理服务]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：本地上传文件（无外部链接）]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-29]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

确定性推理对于大语言模型（LLM）应用（如以LLM作为评判者的评估、多智能体系统和强化学习（RL））日益重要。然而，现有的LLM服务框架在张量并行（TP）规模或批大小变化时，即使在贪心解码下也会对相同输入产生不同输出。这源于浮点运算的非结合性以及各GPU间不一致的归约顺序。尽管已有工作通过批不变（batch-invariant）内核解决了与批大小相关的不确定性问题，但不同TP规模下的确定性仍是一个未解决的问题，在RL场景中尤为突出：训练引擎通常使用全分片数据并行（FSDP，即TP=1），而rollout引擎依赖多GPU TP以最大化推理吞吐量，这会造成概率不匹配，从而降低甚至导致训练崩溃。我们识别并分析了TP导致不一致性的根本原因，提出了基于树结构的不变内核（Tree-Based Invariant Kernels, TBIK）------一套自定义的矩阵乘法与归约内核，可保证在不同TP规模下获得逐位相同的结果。我们的核心思路是在GPU之间及GPU内部强制统一的归约顺序。我们用Triton实现了TBIK，并将其集成到vLLM和FSDP中，实现了不同TP规模下逐位确定的推理，以及RL流水线中rollout引擎与训练引擎之间零概率偏差。通过消除不同并行策略导致的不匹配，TBIK首次使大规模真正的on-policy RL成为可能，从而提升模型性能并加快收敛速度。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [Deterministic Inference across Tensor Parallel Sizes That Eliminates Training--Inference Mismatch],
    [作者], [Ziyang Zhang, Xinheng Ding, Jiayi Yuan, Rixin Liu, Huizi Mao, Jiarong Xing, Zirui Liu],
    [发表场所 / 年份], [文中未说明],
    [研究领域], [LLM系统],
    [关键词], [确定性推理，张量并行，强化学习，浮点非结合性，LLM推理服务],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：文中未说明

#quote(block: true)[
#strong[标签（3--5 个）]：`确定性推理` · `张量并行` · `强化学习` · `浮点非结合性` · `LLM推理服务`
]

论文识别出改变张量并行（TP）规模会使大模型在贪婪解码下产生不同输出、且现有\"批不变算子（BIO）\"无法解决这一问题\*\*\[作者明确陈述\]#strong[，提出 Tree-Based Invariant Kernels（TBIK），用固定二叉树统一 GPU 内矩阵乘法与 GPU 间 All-Reduce 的累加顺序，实现跨 TP 规模的逐位（bit-wise）确定性推理，并消除强化学习中训练引擎与推理引擎间的概率差异]\[作者明确陈述\]#strong[，代价是相对 BF16 引入 22%-63% 的端到端延迟开销]\[作者明确陈述\]\*\*。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- OCR 覆盖正文第 1-9 页的文字与 6 批共 12 张图片/图表，包括问题动机、机制分析、方法设计与主实验（Table 1、2，Figure 1-2、4-9、11）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- Appendix A、C、D.1/D.2、E/F、G、H（部分）、I.1/I.2 等章节被正文引用但内容不在本次 OCR 范围内，理论证明步骤、内核实现细节、超参数等#strong[无法从当前 OCR 内容确认]。
- 存在一处明确的图题与图像内容冲突：图片清单标注的\"Figure 2（TP=1/2/4/8）\"，实际可见图像横轴为 BS=8/16/32、图例仅 BF16/BIO，二者无法可靠对应，本报告不强行套用该图注\*\*\[基于视觉的谨慎推断，关联不可靠\]\*\*。
- 全文事实均来自论文文本与图表；涉及\"批不变性\"\"浮点非结合律\"等背景解释已在术语部分标注，不作为论文结论。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

- 问题定义：大模型推理结果不应只依赖模型参数与输入，但现实中相同输入、相同随机种子下，仅改变批大小（batch size）或 TP 规模，输出就会不同\*\*\[作者明确陈述\]\*\*。
- 为什么重要：这在三类场景中造成实际危害------LLM-as-a-judge 评测的可比性被破坏、多智能体系统中不确定性级联放大、强化学习（RL）中训练引擎（FSDP，TP=1）与推理引擎（vLLM，TP\>1）算出的概率不一致，使本应\"同策略（on-policy）\"的更新退化为\"异策略（off-policy）\"，可能损害甚至使训练崩溃\*\*\[作者明确陈述\]#strong[。已有实验显示仅改变批大小和 TP 规模，AIME 数据集准确率波动可达 9%]\[作者明确陈述，引用 Yuan et al., 2025a\]#strong[；本文实测单独改变 TP 就能让 Qwen3-8B 在 AIME24 上产生超过 4% 的准确率波动]\[作者明确陈述\]\*\*。
- 难点来源：浮点加法不满足结合律（$\(a + b\)+ c eq.not a +\(b + c\)$），任何\"求和顺序依赖设备数量\"的操作都会引入非确定性\*\*\[作者明确陈述\]#strong[；而 TP 的 row-parallel 层恰好需要跨 GPU 求和，规约顺序天然随参与 GPU 数变化]\[作者明确陈述\]\*\*。
- 本文的 story：已有的批不变算子（BIO）通过固定批维度的规约顺序解决了\"批大小\"这一来源的非确定性，但它没有触及\"参与规约的设备数量\"这一变量；本文的转折是指出并证明------只有同时固定 GPU 内和 GPU 间的累加树形结构，使其与设备数解耦，才能堵上这最后一个来源\*\*\[作者明确陈述\]\*\*。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：训练与推理引擎概率不一致主张]
  #image("assets/imgs/img_in_image_box_133_141_1057_522.jpg", width: 100%)
  #emph[Figure 1. Illustration of probability discrepancies in RL training. Different frameworks and TP sizes produce noticeably probability gap for the same response, hindering stable and truly on-policy RL.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：vLLM(TP=8)与FSDP(TP=1)间逐token概率差异集中在2%-8%，存在近14%尖峰且候选词排序反转。

- #strong[论证关系]：将引擎间概率不一致转化为直观证据，构成TBIK方法设计的直接动机。

- #strong[适用范围]：未指明具体模型与数据集设置。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[问题严重性]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 3 节：TP引发准确率波动主张]
  #image("assets/imgs/img_in_chart_box_638_135_1061_381.jpg", width: 100%)
  #emph[Figure 2. Accuracy standard deviation of Qwen3-8B on AIME24 dataset under different TP sizes (TP = 1/2/4/8).]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：图像显示不同批大小下BF16与BIO的准确率标准差无一致高低方向。

- #strong[论证关系]：因图题与图像可见内容存疑，无法可靠关联到TP变化导致准确率波动的主张。

- #strong[适用范围]：图题与图像内容冲突未解决。
]

== 4. 旧方法为何不够
<4-旧方法为何不够>

#critique-card(
  [BIO（批不变算子，He & Lab, 2025）],
  [让每个批元素独立计算（如 RMSNorm 逐 token 处理，MatMul 每核心本地完成 2D tile 的完整规约、采用 Non-Split-K 策略），以保证结果不随批大小变化\*\*\[作者明确陈述\]#strong[；规约顺序只需与批维度无关，未考虑参与规约的物理设备数量（如 TP 的 GPU 数）本身也会改变计算路径]\[作者明确陈述\]\*\*。],
  [对流水线并行（PP）天然不受影响、对数据并行（DP）等价于批大小变化可保持一致；但对 TP，尤其 row-parallel 层需要跨 GPU All-Reduce 求和 K 维度部分结果，参与设备数改变即改变累加顺序\*\*\[作者明确陈述\]#strong[。实测中 BIO 在 TP=1、2 时批不变，TP\>2 或跨 TP 比较时一致性失效，Table 1 中 Count of Unique Outputs 从 BF16 的约 12 降到 BIO 的约 7-8，仍未收敛为 1]\[作者明确陈述\]\*\*。],
  [TBIK 用固定二叉树同时约束 intra-GPU MatMul 与 inter-GPU All-Reduce 的累加顺序\*\*\[作者明确陈述\]\*\*。],
  [Table 1、2（BIO+TBIK 恒为 1/0）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
)

#critique-card(
  [标准实现 cuBLAS GEMM + NCCL Ring All-Reduce],
  [原本用于高效完成矩阵乘法和跨 GPU 通信，是主流推理系统默认实现\*\*\[作者明确陈述\]\*\*。],
  [其局限是本地顺序规约与 Ring 通信的累加顺序均随 TP/GPU 数变化\*\*\[作者明确陈述\]\*\*。],
  [本文用固定二叉树替代（Figure 5）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。],
  [Kernel 吞吐对比（Figure 6）及 Table 1、2\*\*\[作者明确陈述\]\*\*。],
)

== 5. 核心洞见与假设
<5-核心洞见与假设>

- 核心洞见（作者原话）：要实现跨 TP 规模的确定性，必须让\"GPU 内矩阵乘法\"与\"GPU 间规约\"共同设计（co-design），使浮点运算的全局累加顺序与 TP 规模无关\*\*\[作者明确陈述\]\*\*。
- 实现该洞见所需的组件：Triton 实现的 Tree-Based MatMul 内核（intra-GPU）与自定义 Tree-Based All-Reduce 内核（inter-GPU），二者是支撑洞见落地的技术组件，而非独立于洞见之外的贡献\*\*\[作者明确陈述\]\*\*。
- 可行性依据：若给所有 TP 配置强加同一棵固定满二叉树拓扑（部分乘积为叶子节点，内部节点两两确定性累加），无论 GPU 数 $C$ 为多少，累加路径完全相同\*\*\[作者明确陈述\]\*\*。
- 第一性原理链条：浮点加法不满足结合律 → row-parallel 输出 $X W = sum_(i = 1)^C X_i W_i$，当前系统的本地与跨 GPU 规约顺序都依赖 $C$ → 若规约树结构固定并与 $C$ 解耦，则该运算路径唯一、结果比特级相同\*\*\[基于文中逻辑的推断，推理依据：第2.1节浮点非结合律事实+第5节row-parallel求和公式+第4.1节固定二叉树设计\]\*\*。
- 前提可能不成立之处：文中未说明该保证在极端数值范围（如溢出/下溢边界）或非二叉可整除 tile 数下是否仍严格成立，#strong[无法从当前 OCR 内容确认]。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入为待并行执行的 MatMul（沿 K 维度按 TP 切分成 tile），经 intra-GPU 树形规约得到各 GPU 本地部分结果，再经 inter-GPU 树形 All-Reduce 得到全局一致输出，最终以打补丁方式接入 vLLM（推理）与 FSDP（训练），使二者概率计算完全一致\*\*\[作者明确陈述\]\*\*。

+ #strong[模块一：Intra-GPU Tree-Based MatMul Kernel]
  - #strong[动机]：cuBLAS 等标准 GEMM 沿 K 维度顺序规约，其顺序随每 GPU 分到的 tile 数（$T_K\/C$）变化，是非确定性来源之一\*\*\[作者明确陈述\]\*\*。
  - #strong[运行方式]：Triton 实现，将 $T_K\/C$ 个 tile 组织成深度 $L = log_2\(T_K\/C\)$ 的固定二叉树，叶子节点为部分乘积，内部节点两两确定性累加，输出该 GPU 的本地累加结果\*\*\[作者明确陈述\]\*\*。
  - #strong[技术优势]：本地累加顺序与 TP 规模 $C$ 无关，跨 TP 配置时同一 GPU 内计算路径完全相同\*\*\[作者明确陈述\]\*\*。
+ #strong[模块二：Inter-GPU Tree-Based All-Reduce]
  - #strong[动机]：标准 NCCL Ring All-Reduce 的规约顺序依赖参与 GPU 数量，是 row-parallel 层输出依赖 TP 规模的直接原因\*\*\[作者明确陈述\]\*\*。
  - #strong[运行方式]：沿用与模块一相同的二叉树拓扑跨 GPU 规约，输出全局一致结果\*\*\[作者明确陈述\]\*\*。
  - #strong[技术优势]：全局累加路径与 GPU 数解耦，作者称 Appendix C 有理论证明，但证明内容未出现在本 OCR 中\*\*\[作者明确陈述，证明细节无法从当前 OCR 内容确认\]\*\*。
+ #strong[模块三：TBIK 在 vLLM / FSDP 中的系统集成]
  - #strong[动机]：RL 中 rollout（vLLM，TP\>1）与训练（FSDP，通常 TP=1）引擎配置不同，使同一参数 $theta$ 算出不同概率，隐性把 on-policy 更新变为 off-policy\*\*\[作者明确陈述\]\*\*。
  - #strong[运行方式]：以打补丁方式接入两个框架（Appendix I.1 细节未在 OCR 中）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
  - #strong[技术优势]：实现两引擎间逐 token 概率差为零，避免 MoE 模型路由器因微小概率扰动选择不同专家的后果\*\*\[作者明确陈述\]\*\*。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：张量并行切分方式与跨GPU求和机制主张]
  #image("figure-groups/page-0004-49e6cf630ffa.png", width: 100%)
  #emph[Figure 4. Illustrations of column-parallel and row-parallel MatMul.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：column-parallel输出保持双色分块拼接，row-parallel输出融合为单色求和结果。

- #strong[论证关系]：直观展示row-parallel层是TP非确定性的根源，支撑All-Reduce处理逻辑。

- #strong[适用范围]：为C=2的机制示意图，无实测数值。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：Transformer模型各层张量并行切分架构主张]
  #image("assets/imgs/img_in_image_box_134_166_1052_430.jpg", width: 100%)
  #emph[Figure 3. Illustration of tensor-parallel weight partitioning in the Transformer model architecture (e.g., Qwen3 Dense) in vLLM. In this configuration, the QKV proj, gate proj, up proj, and lm head layers are column-parallel, while the o proj and down proj layers are row-parallel. For non-MatMul operations such as RMSNorm and RoPE, parameters and computations are not split across GPUs, and these layers are omitted from the figure for clarity.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：QKV与Gate/Up层为column-parallel，O与Down层为row-parallel且包含求和节点。

- #strong[论证关系]：将抽象切分映射到真实Transformer子层，确定TBIK需处理的树形规约位置。

- #strong[适用范围]：以Qwen3 Dense为例，省略非MatMul操作。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：固定二叉树规约结构解耦TP规模主张]
  #image("assets/imgs/img_in_image_box_114_140_1080_461.jpg", width: 100%)
  #emph[Figure 5. Comparison between the cuBLAS GEMM with NCCL Ring Reduce (left) and our Tree-Based Invariant Kernels (right). In the Ring Reduce, inter-GPU communication follows a ring pattern, while intra-GPU reduction is performed sequentially. In contrast, TBIK adopts a hierarchical tree structure for both intra- and inter-GPU reductions, ensuring a consistent reduction order across different TP sizes.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：cuBLAS+Ring方案在不同TP下规约树拓扑不同，而Tree-Based方案保持二叉树拓扑一致。

- #strong[论证关系]：对比展示传统方案缺陷与TBIK的核心设计原理，证明累加顺序与GPU数解耦。

- #strong[适用范围]：8-Tile示意图，不含实测数值。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：Intra-GPU Tree-Based MatMul内核设计主张]
  #image("assets/imgs/img_in_image_box_615_136_1079_359.jpg", width: 100%)
  #emph[Figure 11. Illustration of our Tree-Based MatMul kernel.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：部分乘积作为叶子节点，经两两配对逐级合并为单一输出。

- #strong[论证关系]：具象化固定二叉树累加原理如何在tile级Triton内核中落地执行。

- #strong[适用范围]：通用设计原理图，未标注具体dtype和维度。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 机制 → 收益：固定二叉树使累加路径与设备数解耦 → 跨 TP 配置下浮点运算路径唯一 → 结果比特级相同\*\*\[基于文中逻辑的推断\]#strong[，该链条已由 Table 1（Count of Unique Outputs=1）与 Table 2（Divergence=0）实证支撑]\[作者明确陈述，实验支持\]\*\*。
- 机制 → 收益：intra 与 inter 两个模块共同约束 → 消除 vLLM/FSDP 之间的概率差距 → RL 更新真正 on-policy，减少策略与数据分布偏差 → 训练更稳定、收敛更快\*\*\[基于文中逻辑的推断，实验支持见 Figure 8、9\]\*\*。
- 需要的条件：该保证依赖二叉树拓扑在不同 TP 规模下均可构造（如 tile 数可被 2 整除的层级划分），文中未展开非理想切分情形下的处理方式，#strong[无法从当前 OCR 内容确认]。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- 效果问题：跨 TP/batch 配置下输出是否比特级一致？对应比较 BF16 vs BIO vs BIO+TBIK，判定标准为 Table 1 的 Count of Unique Outputs 是否收敛为 1\*\*\[作者明确陈述\]\*\*。
- 效果问题：训练/推理引擎间概率差距是否被消除？对应 Table 2 的 Maximum Probability Divergence 是否为 0，以及 Figure 9 分布形态\*\*\[作者明确陈述\]\*\*。
- 必要性问题：是否需要同时具备 intra 与 inter 两个模块？对应 Figure 6 消融图（BIO+All-Reduce-only vs BIO+MatMul-only）的延迟归因，但未报告两个 only 配置各自的确定性指标\*\*\[作者明确陈述，缺口见后文\]\*\*。
- 效果问题：TBIK 对下游 RL 训练效果的影响？对应 Figure 8 的 Entropy/KL/Reward/Pass\@1\*\*\[作者明确陈述\]\*\*。
- 代价问题：TBIK 引入多少性能开销？对应 Figure 6（内核吞吐）与 Figure 7（端到端延迟）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- 模型：Qwen3-8B、Qwen3-32B、Mistral-7B-Instruct、Llama-3.1-8B-Instruct（确定性主实验）；Qwen3-1.7B（RL 实验）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- 数据集：AIME24、AMC23（确定性实验）；GSM8K（RL 训练）；AIME prompts（Figure 9 概率差异统计）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- 系统/框架：vLLM（推理）、FSDP（训练）、BIO 部分实现引用 SGLang\*\*\[作者明确陈述\]\*\*。
- 硬件：4×NVIDIA H20（NVLink，延迟实验）、4×NVIDIA L40S（RL 与概率差实验）；RTX PRO 6000 结果见 Appendix G，未在本 OCR 中\*\*\[作者明确陈述\]\*\*；#strong[无法从当前 OCR 内容确认]RTX PRO 6000 具体数值。
- 运行配置：12/9 种运行时配置（TP×batch 组合）；TP=4、batch size=64（延迟实验）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
- 重复次数/统计方式、具体超参数：文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：Count of Unique Outputs（唯一输出数量），测量对象为同一输入在多种运行时配置下产生的不同输出字符串数量，取值范围为正整数，越小越好，理想值为 1\*\*\[作者明确陈述\]\*\*。
  - #strong[来源层级]：无可核验公式；作者文字定义为\"跨配置产生的不同输出的计数\"，未给出具体计算公式或 Eq. 编号\*\*\[作者明确陈述\]\*\*。
  - #strong[实验用途]：检验跨 TP/batch 配置下是否比特级一致，用于比较 BF16、BIO、BIO+TBIK\*\*\[作者明确陈述\]\*\*。
  - #strong[读数与边界]：BF16 接近配置总数（如 Qwen3-8B/AIME24 为 12.00），BIO 降至约 7-8 但未到 1，BIO+TBIK 四模型两数据集全部为 1\*\*\[作者明确陈述，实验支持\]\*\*；该指标只反映最终输出字符串是否相同，不直接反映中间概率数值差异。
- #strong[指标与方向]：Maximum Probability Divergence（最大概率散度），测量对象为不同配置间逐 token 概率的最大差异，单位 $times 10^(- 3)$，越小越好，理想值为 0\*\*\[作者明确陈述\]\*\*。
  - #strong[来源层级]：无可核验公式；仅有文字定义与数值表，未给出显式公式或 Eq. 编号\*\*\[作者明确陈述\]\*\*。
  - #strong[实验用途]：量化跨配置概率分布一致性，与 Count of Unique Outputs 互补（后者看离散输出，前者看连续概率）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(19, 109, 143, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(15, 86, 118))[作者明确陈述]]。
  - #strong[读数与边界]：BIO+TBIK 在所有模型/数据集组合下为 0；BF16、BIO 均非零（如 Llama-3.1-8B-Instruct/AMC23：BF16=31.09、BIO=21.06）#strong[\[作者明确陈述，实验支持\]]；该指标未说明具体统计口径（如取全体 token 的最大值还是均值），#strong[无法从当前 OCR 内容确认]其聚合方式细节。
- #strong[指标与方向]：Kernel 吞吐（TFLOPs），测量对象为 MatMul 内核吞吐率，越大越好\*\*\[作者明确陈述\]\*\*。
  - #strong[来源层级]：无可核验公式；来自 Figure 6 图像趋势与文字描述\*\*\[作者明确陈述\]\*\*。
  - #strong[实验用途]：定位 TBIK 相对 cuBLAS 的性能代价来源\*\*\[作者明确陈述\]\*\*。
  - #strong[读数与边界]：BF16 下 Tree-Based 约为 cuBLAS 的 63%（约120 vs 190 TFLOPS）；FP32 下二者接近\*\*\[作者明确陈述\]\*\*；仅为内核微基准，不等同端到端延迟。
- #strong[指标与方向]：端到端延迟（秒），测量对象为完整推理请求耗时，越小越好\*\*\[作者明确陈述\]\*\*。
  - #strong[来源层级]：无可核验公式；来自 Figure 7 实测柱状数值\*\*\[作者明确陈述\]\*\*。
  - #strong[实验用途]：量化 BIO、TBIK 各自及合计相对 BF16 的开销比例\*\*\[作者明确陈述\]\*\*。
  - #strong[读数与边界]：BIO+TBIK 总开销 22%\~63%，随输入/输出长度增大呈下降趋势（三组分别约63.2%、36.4%、22.1%）#strong[\[作者明确陈述，实验支持\]]；未解释该趋势的底层机制。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [BIO（批不变算子）], [只解决批大小非确定性，TP\>2 时 All-Reduce 仍随 GPU 数变化], [TBIK 的 intra+inter 树形规约], [Table 1/2 直接验证；MoE 模型、TP=8 等场景#strong[文中未说明]],
    [cuBLAS+NCCL Ring], [本地/跨 GPU 累加顺序均随 GPU 数变化], [TBIK 固定二叉树替代], [Figure 6 内核吞吐对比；仅覆盖 K=6144,N=2048 一种矩阵形状],
    [vanilla BF16], [无任何确定性处理，波动最大], [TBIK 整体方案], [Table 1/2、Figure 8 直接验证；未覆盖其他 RL 算法（如 PPO）],
  )]
  , kind: table
  )

- #strong[主张 -\> 直接证据 -\> 证据强度与边界]：

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [BIO+TBIK 实现跨 TP/batch 逐位一致], [Table 1（Count=1）、Table 2（Divergence=0）], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]，覆盖4模型×2数据集；MoE 及更大 TP 未验证],
    [TBIK 消除 vLLM/FSDP 概率差距], [Figure 9 直方图], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]，仅 Qwen3-8B、TP=4 vs TP=1 一组配置],
    [TBIK 提升 RL 训练效果], [Figure 8（Pass\@1: 0.73 vs 0.68 vs 0.60）], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]，仅 GSM8K+Qwen3-1.7B 单一设置，未验证泛化性],
    [开销主要来自 MatMul 内核而非 All-Reduce], [Figure 6（图片2，附录H细分柱状图）], [#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]，未报告两个 only 配置的确定性指标，无法证明\"两模块同时存在才具备确定性必要性\"],
  )]
  , kind: table
  )

- 三组延迟数值均为绝对秒数直接对比，未见相对基线的统计显著性检验，#strong[文中未说明]。
- Table 1/2 覆盖 4 模型×2 数据集，但均为稠密模型，MoE 场景仅为理论推测。
- 消融实验（Figure 6 图2）只给出延迟归因，未给出对应的确定性指标退化情况，是明确的证据缺口。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_614_522_1083_716.jpg", width: 100%)
    #emph[Figure 6. Throughput comparison between our Tree-Based MatMul kernels and cuBLAS MatMul kernels on BF16 and FP32 as M varies, with K = 6144 and N = 2048.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：内核级吞吐开销主张]
    - #strong[图组结论]：BF16下Tree-Based吞吐约为cuBLAS的63%，FP32下二者吞吐接近。

- #strong[论证关系]：定位端到端延迟开销的内核级来源，量化树形累加带来的算力代价。

- #strong[适用范围]：仅测试K=6144、N=2048矩阵形状。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_612_1161_1085_1357.jpg", width: 100%)
    #emph[Figure 7. End-to-end latency of the Qwen3-8B model on four NVIDIA H20 GPUs with NVLink, evaluated under varying input and output lengths with a batch size of 64.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：端到端延迟开销主张]
    - #strong[图组结论]：BIO+TBIK相对BF16引入22%-63%端到端延迟开销，开销比例随序列长度增加而下降。

- #strong[论证关系]：直接量化TBIK方案付出的端到端性能代价，为使用边界提供依据。

- #strong[适用范围]：仅覆盖Qwen3-8B在4×H20、TP=4、BS=64场景。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_113_132_1083_374.jpg", width: 100%)
    #emph[Figure 8. RL training (GRPO) metrics on GSM8K using Qwen3-1.7B with four L40S GPUs.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：RL训练效果提升主张]
    - #strong[图组结论]：BIO+TBIK在GRPO训练中实现KL散度贴零，#link("mailto:Pass@1达到0.73显著优于基线")[Pass\@1达到0.73显著优于基线]。

- #strong[论证关系]：证明消除引擎间概率差异后能带来更稳定、更好的强化学习训练收益。

- #strong[适用范围]：仅GSM8K上Qwen3-1.7B单设置。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_616_452_1079_732.jpg", width: 100%)
    #emph[Figure 9. Statistics of per-token probability differences between vLLM (TP = 4) and FSDP (TP = 1) on Qwen3-8B with four NVIDIA L40S GPUs. Our method eliminates all probability gaps.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：概率差距消除主张]
    - #strong[图组结论]：BIO+TBIK逐token概率差几乎全部集中在0%，而BF16与BIO分布均延伸至12%以上。

- #strong[论证关系]：证实TBIK完全消除训练与推理引擎间概率差距，同时印证BIO无法消除该差距的局限。

- #strong[适用范围]：仅Qwen3-8B在4×L40S、TP=4场景。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_image_box_110_1013_575_1220.jpg", width: 100%)
    #emph[Figure 10. Implementations in Batch Invariant Operations. Left: RMSNorm. Right: MatMul.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 4 节：BIO算子批独立计算机制主张]
    - #strong[图组结论]：RMSNorm按批行独立规约，MatMul在K维度本地规约且N维度输出独立。

- #strong[论证关系]：阐明BIO仅针对批维度固定规约顺序的原理，为批判其无法应对TP多设备规约提供背景。

- #strong[适用范围]：纯机制示意图，无实测数值。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/imgs/img_in_chart_box_615_541_1083_732.jpg", width: 100%)
    #emph[Figure 12. Fine-grained end-to-end latency breakdown of the Qwen3-8B model on four NVIDIA H20 GPUs under varying input/output lengths with a batch size of 64.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：延迟细粒度拆解主张]
    - #strong[图组结论]：延迟按BF16\<BIO\<BIO+All-Reduce≈BIO+MatMul\<BIO+TBIK递增，MatMul贡献大于All-Reduce。

- #strong[论证关系]：分解各组件延迟贡献，验证MatMul内核是主要开销来源。

- #strong[适用范围]：仅Qwen3-8B在4×H20场景，未包含确定性指标。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1. Average Count of Unique Outputs on AIME24 and AMC23. For each prompt, outputs are generated under 12 runtime...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：跨配置输出一致性主张]
  - #strong[图组结论]：BIO+TBIK在所有测试模型与数据集上 Count of Unique Outputs 恒为1。

- #strong[论证关系]：直接验证TBIK在离散文本生成层面实现了跨TP和批大小的比特级完全一致。

- #strong[适用范围]：覆盖4个稠密模型与2个数学评测集。
  #v(5pt)
  #image("table-groups/page-0007-15ebae118e22.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 2. Average Maximum Probability Divergence on AIME24 and AMC23( ). A larger value indicates greater numerical di...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：连续概率散度归零主张]
  - #strong[图组结论]：BIO+TBIK在所有测试模型和数据集上 Maximum Probability Divergence 恒为0。

- #strong[论证关系]：从连续概率层面验证TBIK消除了不同配置间的浮点累加偏差。

- #strong[适用范围]：覆盖4个稠密模型与2个评测集。
  #v(5pt)
  #image("table-groups/page-0007-87556361838f.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3. Average Count of Unique Outputs on AIME24 and AMC23. For each prompt, outputs are generated under 12 runtime...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：附录扩展配置一致性验证主张]
  - #strong[图组结论]：扩展测试配置下 BIO+TBIK 的唯一输出计数同样恒为1。

- #strong[论证关系]：补充验证TBIK跨配置输出一致性在更大范围内的稳健性。

- #strong[适用范围]：附录扩展测试配置。
  #v(5pt)
  #image("table-groups/page-0015-f4dfe0901dab.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 4. Average Maximum Probability Divergence on AIME24 and AMC23( ). A larger value indicates greater numerical di...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 8 节：附录扩展配置概率一致性主张]
  - #strong[图组结论]：扩展配置下 BIO+TBIK 预测概率分布的散度保持为0。

- #strong[论证关系]：进一步证实比特级确定性在更多运行组合下的通用有效性。

- #strong[适用范围]：附录扩展测试配置。
  #v(5pt)
  #image("table-groups/page-0016-b6157859d3e8.png", width: 100%)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 5. Block size setting for TBiK.]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第 6 节：TBIK内核Block Size超参数配置主张]
  - #strong[图组结论]：给出TBIK在不同维度与硬件下采用的固定分块参数组合。

- #strong[论证关系]：为复现TBIK内核提供具体的硬件与分块参数配置依据。

- #strong[适用范围]：仅限本文内核实现的块大小配置。
  #v(5pt)
  #image("table-groups/page-0016-d1c273387527.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：为何相同输入+相同随机种子，仅改变TP规模就会得到不同输出？
  - 旧方法限制：BIO只固定批维度规约顺序，未处理跨GPU设备数变化导致的累加顺序变化
  - 核心洞见/假设：需co-design GPU内MatMul与GPU间All-Reduce，使全局累加顺序与TP规模解耦
    - 方法模块：Intra-GPU Tree-Based MatMul（固定二叉树本地规约）
      - 可验证预测：本地累加路径与GPU数无关
        - 指标与实验：Count of Unique Outputs（Table 1）
          - 图表证据：Figure 11（结构示意，未被当前证据直接验证正确性/确定性）
            - 结论与适用边界：结构设计合理但无独立单元测试，#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(214, 136, 31, 18%))[#text(size: 8.1pt, weight: "bold", fill: rgb(148, 85, 0))[基于文中逻辑的推断]]
    - 方法模块：Inter-GPU Tree-Based All-Reduce（固定二叉树跨GPU规约）
      - 可验证预测：全局累加路径与GPU数解耦，实现比特级一致
        - 指标与实验：Count of Unique Outputs=1、Maximum Probability Divergence=0（Table 1、2）
          - 图表证据：Figure 5（树结构对比示意）
            - 结论与适用边界：4模型×2数据集验证，#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；MoE/更大TP未被当前证据直接验证
    - 方法模块：vLLM/FSDP系统集成（RL场景）
      - 可验证预测：训练/推理引擎逐token概率差为零，提升RL训练效果
        - 指标与实验：Figure 9概率差分布、Figure 8（Entropy/KL/Reward/Pass\@1）
          - 图表证据：Figure 9直方图、Figure 8四子图
            - 结论与适用边界：单一GSM8K+Qwen3-1.7B设置下验证，#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；其他任务/算法/模型规模未被当前证据直接验证

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- 贡献：（1）识别并分析TP引发的非确定性根源及其对评测和RL训练的影响；（2）提出TBIK固定二叉树方案消除该非确定性；（3）将TBIK集成进vLLM/FSDP实现完全确定性推理与真正on-policy RL\*\*\[作者明确陈述\]\*\*。
- 证据充分的结论：跨TP/batch配置下BIO+TBIK实现Count of Unique Outputs=1、Maximum Probability Divergence=0（Table 1、2）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]；相对BF16引入22%-63%端到端延迟开销（Figure 7）#box(inset: (x: 4.5pt, y: 1.3pt), radius: 3pt, fill: rgb(38, 137, 86, 14%))[#text(size: 8.1pt, weight: "bold", fill: rgb(24, 102, 60))[实验支持]]。
- 尚属推断的意义：固定二叉树设计原理具备理论可推广性（不限于本文测试的4个模型），但MoE模型、更大TP规模、其他RL算法上的效果为\*\*\[基于文中逻辑的推断\]\*\*而非直接实验验证。
- 适用条件：稠密Transformer模型、vLLM/FSDP框架、本文测试的GPU型号（H20、L40S）；RTX PRO 6000结果未在本OCR中确认。
- 局限：性能代价明确（22%-63%开销）；内核实现为概念验证阶段，未做block size调优、warp specialization等工程优化\*\*\[作者明确陈述\]\*\*；MoE模型与更大规模RL训练场景缺乏直接实验。
- #strong[审稿式风险检查]：
  - 贡献新意：核心贡献（固定二叉树同时约束intra/inter规约）在本OCR范围内表述清晰，未发现明显与已有工作重叠的证据；当前证据未显示该风险。
  - 写作/可复现性：多处关键细节（内核实现Appendix D.2、理论证明Appendix C、训练超参Appendix I.2）未在OCR中出现，复现所需信息不完整，属真实风险。
  - 效果大小：主张的确定性效果（Count=1、Divergence=0）证据扎实；但RL收益（Pass\@1提升）仅在单一小规模设置下验证，效果外推存在不确定性。
  - 实验覆盖：仅稠密模型、两个评测数据集、单一RL任务，MoE与其他RL算法未覆盖，为真实覆盖缺口。
  - 方法设计：消融实验（Appendix H.1）只报告延迟归因，未报告two-only配置下的确定性指标，无法完全确认两模块的必要性，属真实证据缺口。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：张量并行（Tensor Parallelism, TP）------把一层的权重矩阵切分到多个GPU并行计算的并行策略。
  - #strong[第一性原理角色]：连接\"计算资源（多GPU）\"与\"单层计算延迟\"两个基本量，受限于跨设备通信带宽。
  - #strong[本文位置]：TP的row-parallel层是非确定性根源，本文核心方法围绕其展开。
- #strong[术语]：批不变算子（Batch-Invariant Operations, BIO）------固定每个批元素独立计算路径的算子实现。
  - #strong[第一性原理角色]：约束的是\"批维度\"这一变量对累加顺序的影响，不涉及设备数变量。
  - #strong[本文位置]：作为主要比较基线，是本文批判与对照的对象。
- #strong[术语]：浮点非结合律------计算机浮点加法 $\(a + b\)+ c eq.not a +\(b + c\)$，源于每步舍入误差。
  - #strong[第一性原理角色]：是所有本文讨论的非确定性现象的数学根源。
  - #strong[本文位置]：第2.1节给出，贯穿全文机制解释。
- #strong[术语]：All-Reduce------多GPU间把各自部分结果求和并同步给所有GPU的通信操作。
  - #strong[第一性原理角色]：连接\"分布式部分计算结果\"与\"全局一致结果\"，其规约顺序受参与设备数约束。
  - #strong[本文位置]：row-parallel层输出依赖的关键操作，是TBIK的Inter-GPU模块直接改造对象。
- #strong[术语]：Tree-Based Invariant Kernels（TBIK）------本文提出的固定二叉树规约内核集合。
  - #strong[第一性原理角色]：把\"累加路径\"这一因果链条与\"设备数\"变量解耦。
  - #strong[本文位置]：全文核心方法，第4-5节。
- #strong[术语]：on-policy / off-policy------RL中训练数据是否严格来自当前策略。
  - #strong[第一性原理角色]：连接\"数据生成路径\"与\"训练更新有效性\"两个基本量。
  - #strong[本文位置]：解释为何训练/推理引擎不一致会损害RL训练。
- #strong[术语]：Count of Unique Outputs / Maximum Probability Divergence------本文自定义的确定性度量指标。
  - #strong[第一性原理角色]：分别从离散输出与连续概率两个层面观测\"计算路径是否唯一\"这一因果结果。
  - #strong[本文位置]：Table 1、2主实验的核心指标。

=== 12.2 学习路径
<122-学习路径>
+ 浮点数与舍入误差------理解为何计算机加法不满足结合律，是全文一切非确定性讨论的地基。
+ 张量并行的两种切分方式（column/row-parallel）------理解为何有些层不受GPU数影响、有些层必须求和。
+ All-Reduce通信操作------理解跨GPU求和如何依赖参与设备数，进而理解非确定性的具体触发点。
+ 强化学习中的on-policy要求------理解为何\"训练/推理引擎计算路径不同\"会实际损害模型训练效果，而不只是理论瑕疵。
+ 二叉树规约结构------理解固定拓扑如何把\"求和顺序\"这一变量从\"设备数量\"中解耦出来，是本文方法能成立的关键机制。
