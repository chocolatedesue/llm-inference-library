# 图片批次 2

## 图片 1：Figure 3: Overall architecture and workflow of DynaPipe. "S/T" means source/target stage.

![Figure 3: Overall architecture and workflow of DynaPipe. "S/T" means source/target stage.](../assets/imgs/img_in_image_box_217_147_1000_527.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：证据类型为**方法流水线**。对应第3节开篇"DynaPipe consists of three core components: an execution time predictor, a bubble-aware scheduler, and a migration coordinator"（页5正文），本图是这三个模块串联工作流程的整体架构图，目的是让读者直观理解"预测→决策→迁移"这一核心机制如何协同运作，而非报告某项具体实验数值。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：第3节 Design 总览段落及3.1（执行时间预测器）、3.2（气泡感知调度器）、3.3（迁移协调器）三个小节；图注"Figure 3: Overall architecture and workflow of DynaPipe. 'S/T' means source/target stage."（页5）。

2. **图像类型与布局**：示意图/流程图，横向三段式并配一个纵向延伸模块。左侧为输入示意（柱状条形icon，标注 n、L、"Batch size"）；中上为绿色 §3.1 框（时钟图标，内含"Predicted Time" vs "Number of token"折线）；右上为粉色 §3.2 框（沙漏/箭头图标，内含两组层分配条形，中间以"window threshold"箭头连接）；下方为大面积蓝色 §3.3 框（双箭头图标，内含三行流水线时间轴条形，标注 S、T 虚线及❶❷编号）。灰色粗箭头把三个彩色框按从左到右、从上到下的顺序连接。

3. **如何阅读**：从左上输入（chunk 内请求的 n、L）沿箭头进入 §3.1，得到随 token 数增长的 predicted time 曲线；再进入 §3.2 的层分配条形对比，左组四段等长条形（15/15/15/15，配哭脸与"k=3"标注）经"window threshold"箭头变为右组四段不等长条形（16/16/16/12，配笑脸与"m=3"标注）；最后进入 §3.3 的三行时间轴，比较各行彩色分段边界的位置变化，虚线 S/T 标记源/目标 stage，❶"adjust to uneven"、❷"adjust to even"标记调整时间点。

4. **直接可见的结论**：
   - §3.1 框内曲线随 token 数增加而单调上升。`[图像直接可见]`
   - §3.2 框内左侧四段等长条形标"k=3"和哭脸，右侧四段不等长条形标"m=3"和笑脸，末段长度从与其余三段相同（15）变为明显更短（12），其余三段从 15 变为 16。`[图像直接可见]`
   - §3.3 框内三行流水线条形均由多个彩色分段（绿/黄/红等）组成，S、T 虚线及❶❷标记随行数呈现不同的分段边界位置，行与行之间边界发生偏移。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：本图是机制类证据，图解对应核心贡献第2、3条（页2）：§3.1 部分直观呈现"预测时间随 token 数增长"这一预测器建模动机，对应 $T_{layer}$、$T_{sample}$ 公式（页5）；§3.2 部分直观呈现"从末级移出 $k$ 层、分给 $m$ 个上游 stage，使失衡（哭脸）变为对齐（笑脸）"这一调度器决策逻辑，对应 $\Delta$ 公式与 $m=\min(k,\text{num}_{stages}-1)$ 定义（页6）；§3.3 部分直观呈现"迁移在流水线时间轴上异步进行、源/目标 stage 标注、先调整为不均衡状态再调整为均衡状态"这一迁移协调器"计算与通信重叠、非阻塞"的设计（页6正文描述）。`[正文支持]` 该图为示意性架构图，不提供任何数值实验结果，不能作为效果类主张（如"8%–41% 时延降低"、"19% 更高请求速率"）的直接证据，这些需依赖 Figure 4–8。

6. **适用范围与证据缺口**：本图覆盖论文方法设计的三个核心模块（预测器、调度器、迁移协调器）的抽象工作流，不代表具体实验配置。图中出现的具体数字（15/16/12、k=3、m=3）用于说明层重分配的一般逻辑，正文 4.1–4.6 节的实验叙述中未指出这组数字对应哪一次具体实验运行，因此这组数字究竟是纯示意举例还是取自某次真实实验结果，无法从当前 OCR 内容确认。`[无法从当前OCR内容确认]`

---

## 图片 2：Figure 4: The average latency and SLO attainment rate of different LLM serving systems. DynaPipe achieves the lowest average latency and the highest SLO compliance across all workloads.

![Figure 4: The average latency and SLO attainment rate of different LLM serving systems. DynaPipe achieves the lowest average latency and the highest SLO compliance across all workloads.](../assets/imgs/img_in_chart_box_216_149_1006_415.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：证据类型为**实验结论**与**对比基线**（效果类主张的主要证据）。对应第4.2节 Overall Performance，验证摘要中"DynaPipe reduces average end-to-end request latency by 8% to 41%"以及"DynaPipe can also sustain up to 19% higher request rates than gLLM under 90% SLO attainment"（页1、8）两条量化效果主张。`[正文支持]`
   - **图表角色**：实验结论 / 对比基线
   - **上文呼应**：第4.2节"Overall Performance"；图注"Figure 4: The average latency and SLO attainment rate of different LLM serving systems. DynaPipe achieves the lowest average latency and the highest SLO compliance across all workloads."（页7）。

2. **图像类型与布局**：2×4 网格折线图，共8个子图。行方向：上排为 ShareGPT 数据集，下排为 Azure-Conv 数据集；列方向分为两组，左两列对应 (a) Qwen2.5-14B，右两列对应 (b) Qwen2.5-32B（组标注在图下方），每组内左列为 E2EL(s)，右列为 SLO Att.(%)。每子图四条曲线，图例区分：gLLM（红色三角）、vLLM（橙色方块）、SGLang（绿色菱形）、DynaPipe（黑色圆点）。

3. **如何阅读**：横轴均为 Request Rate (reqs/s)，随子图/模型不同刻度范围不同；E2EL 子图纵轴为时延（秒，越低越好），应比较同一 request rate 下四条曲线纵坐标高度；SLO Att. 子图纵轴为达标率（%，越高越好），应关注各曲线维持在高达标率（图上以竖直虚线标出跌落点）的最大 request rate 范围。曲线上标注的倍数数字（如 0.59x、1.06x、6.10x 等）附着在各数据点旁。

4. **直接可见的结论**：
   - 在多数子图中，黑色 DynaPipe 曲线在 E2EL 图中随 request rate 上升的斜率最缓、纵坐标位置最低；在 SLO Att. 图中维持接近满值（高位）的 request rate 区间最长（跌落最晚）。`[图像直接可见]`
   - 橙色 vLLM 与绿色 SGLang 曲线在 E2EL 图中普遍上升最快、位置最高，在 SLO Att. 图中最早出现明显下跌。`[图像直接可见]`
   - 红色 gLLM 曲线在多数子图中整体位于 DynaPipe 与 vLLM/SGLang 之间。`[图像直接可见]`
   - Azure-Conv（下排）各子图横轴刻度上限明显小于 ShareGPT（上排）对应子图。`[图像直接可见]`
   - SLO Att. 子图中出现彩色竖直虚线，大致对应相应颜色曲线达标率明显跌落的 request rate 位置。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：本图是效果类核心证据，直接支撑摘要及第4.2节的两条量化主张——"E2EL 降低 8%–41%"与"DynaPipe 比 gLLM 支持高 19% 请求速率（90% SLO 约束下）"（页1、8）。`[正文支持]` 图中 DynaPipe 曲线在 E2EL 上全面低于三条基线、在 SLO Att. 上维持达标区间更长，呼应图注原文"DynaPipe achieves the lowest average latency and the highest SLO compliance across all workloads"。正文对三个基线的批判（SGLang 受高并发 TP 通信开销限制、vLLM 受固定 chunk 批间气泡限制、gLLM 受采样导致的阶段间气泡限制，页8）是文字论证的具体机制归因；本图只能提供整体时延/达标率排序这一**结果层面**的证据，无法单独可视化验证"通信开销""批间气泡""阶段间气泡"这些内部机制的因果来源，读者不应把曲线相对位置差异直接等同于对这些具体机制的图像验证。`[基于文中逻辑的推断]` 曲线旁的倍数标签数值本身缺乏正文定义，不能据此扩展出逐点精确量化结论。

6. **适用范围与证据缺口**：本证据覆盖论文4.1节所述实验设置——ShareGPT/Azure-Conv 两个数据集、Qwen2.5-14B/32B 两个模型规模、四卡 A100-PCIe-40GB（PCIe 互联）、chunk size 2048、DynaPipe 窗口阈值 25，基线为 vLLM(v0.8.5 V1)/gLLM/SGLang(v0.4.3.post2)（页6-7正文）。真实缺口：（1）图中各曲线数据点旁标注的倍数标签（如 0.59x、1.06x、6.10x、3.02x 等）的具体计算定义（分子/分母对应哪条曲线）在正文与图例中均未给出文字说明，无法核验其含义；（2）SLO Att. 子图中竖直虚线所标记的达标率跌破阈值是否精确对应正文所述的 90% 界限，因图像裁剪和线条细节，部分刻度无法精确读出。`[无法从当前OCR内容确认]` `[基于视觉的谨慎推断]`
