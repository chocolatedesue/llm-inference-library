# 图片批次 1

## 图片 1：Figure 1: Illustration of pipeline bubbles during autoregressive decoding. Top: Conventional even layer allocation leads to idle upstream stages due to tail-stage sampling delays. Bottom: Uneven layer assignments to reduce idle time and improve hardware efficiency. "S0:15L" means stage 0 consists of 15 layers.

![Figure 1: Illustration of pipeline bubbles during autoregressive decoding. Top: Conventional even layer allocation leads to idle upstream stages due to tail-stage sampling delays. Bottom: Uneven layer assignments to reduce idle time and improve hardware efficiency. "S0:15L" means stage 0 consists of 15 layers.](../assets/imgs/img_in_image_box_217_142_1006_412.jpg)

*来源：OCR 第 2 页。*

### 解读

1. **论文角色与验证问题**：本图是全文开篇的机制示意图，用于直观呈现根问题——末级采样操作打破流水线各阶段的计算平衡，并对比作者提出的解决方向。证据类型为**问题严重性**（上半部分：均匀分配下的气泡成因）与**机制**（下半部分：不均匀层分配如何缓解气泡）。图并非实验数据，而是原理性说明，帮助读者在阅读后续预测器/调度器设计前先建立直觉。`[正文支持]`
   - **图表角色**：问题严重性 + 方法流水线（机制示意）。
   - **上文呼应**：对应第2页引言部分“PP因末级采样导致上游stage空转、产生气泡”的论述，以及"DynaPipe通过将部分层从末级重分配到上游stage来减小不均衡"的方案介绍（页码2）。

2. **图像类型与布局**：示意图（非真实测量数据的Gantt风格时间线图）。上下两组，分别标题为"Even Layer Assignment"和"Uneven Layer Assignment"，每组包含4行（S0–S3，代表4个pipeline stage），每行由多个彩色方块序列组成，用图例区分为"Layer"（浅色）、"Sample"（红色）、"Redistributed layer"（多色条纹）；箭头分两种：虚线竖箭头表示"Inter-batch dependence"，实线斜箭头表示"Layer adjustment"。每个stage标注层数（如"S0:15L"）。

3. **如何阅读**：每行代表一个pipeline stage随时间（横轴，未标数值刻度）执行的操作序列；不同颜色块代表不同micro-batch或层类型的计算单元；红色块代表采样（Sample）操作，仅出现在最后一个stage（S3）的行末；竖直虚线箭头连接S3的采样输出与上游stage下一步输入，表示stage间的等待依赖；对比上下两组同一时间窗口内各stage行的“空白/延迟”程度即可判断气泡大小。图例明确区分四种视觉元素含义。

4. **直接可见的结论**：上半部分（均匀分配，各stage均为15层）中，S3行末尾的红色采样块比其他stage的对应块更长/更靠后，且竖直虚线箭头显示S0–S2在等待S3完成采样后才能开始下一批次计算，表现出错位的"阶梯状"延迟依赖 `[图像直接可见]`。下半部分（不均匀分配，S0:15L、S1:16L、S2:16L、S3:13L，即减少S3层数、增加上游层数）中，各stage行的起止位置更加对齐，跨stage的箭头间距比上半部分更短更规整 `[图像直接可见]`。下半部分S1–S3还标注了"Redistributed layer"（多色条纹方块），代表从S3迁移来的层 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：该图属于**机制类**证据，用于直观论证"末级采样导致上游stage空转"这一根问题（对应主张地图中"末级采样操作是被忽视的PP效率瓶颈"），以及"通过减少末级层数、增加上游层数可以对齐各stage执行时间、缩小气泡"这一核心设计思路（对应组件二气泡感知调度器的动机）`[正文支持]`。它为后续用$k$、$m$、$\Delta$公式量化层重分配、以及3.2节"当$\Delta \approx 0$且$m=\text{num}_{stages}-1$时各stage对齐"的设计提供了直觉铺垫。需要注意：该图是示意性说明，图中的具体层数分配（15/16/16/13）和时间线长度并非来自真实profiling测量或实验数据，不能作为量化效果的证据——量化的气泡/时延改善数据由Figure 4等实验图表提供，本图不能替代 `[基于文中逻辑的推断]`。

6. **适用范围与证据缺口**：本图覆盖的是一个4-stage pipeline的示意场景（S0–S3），用于说明一般性机制，未指定具体模型/数据集/硬件。无额外证据缺口。

---

## 图片 2：Figure 2: The overhead analysis of sampling and forwarding.

![Figure 2: The overhead analysis of sampling and forwarding.](../figure-groups/page-0004-01adf4b54616.png)

*来源：OCR 第 4 页。*

### 解读

1. **论文角色与验证问题**：本组图（Figure 2，三个子图(a)(b)(c)）是第2.3节"PP面临的挑战"部分的核心实证支撑，用于量化证明"采样开销并非可忽略的末端步骤，而是显著且动态变化的性能因子"这一核心洞见，并为后续执行时间预测器的建模（$T_{sample}=\alpha N_{decode}+\beta$、$T_{layer}$公式）提供数据依据。证据类型为**问题严重性**（论证采样开销量级不小、且动态变化，故静态方案失效）。`[正文支持]`
   - **图表角色**：问题严重性（同时是方法设计的必要性证据，因为该分布直接推动了预测器和动态调度的设计）。
   - **上文呼应**：对应第4页正文"Figure 2 presents profiling results that analyze this overhead in detail"，即2.3节对采样/前向开销的量化分析，以及主张地图中"采样/单层前向时延比≈3.09×，近似正态分布"的主张。

2. **图像类型与布局**：三个独立的散点图/直方图组成一组profiling结果，横向两个在上排（(a)(b)），一个在下排左侧（(c)）。(a)为散点图：横轴"Sample Tokens"、纵轴"Sample Time (ms)"；(b)为直方图（密度分布）：横轴"Sample Time / Layer Time"（比值）、纵轴"Density"，并标注红色虚线及"Mean: 3.09"；(c)为散点图：横轴"Forward Tokens"、纵轴"Layer Time (ms)"。

3. **如何阅读**：(a)图中每个点代表一次实测的（采样token数，采样耗时）组合，判断整体趋势（线性/非线性）；(b)图为比值的统计分布，红色虚线标出均值位置，判断分布形状（是否近似对称、单峰）；(c)图每个点代表一次实测的（前向计算总token数，单层前向耗时）组合，判断趋势及是否存在分段/跳变。三图共同构成"采样耗时 vs 前向耗时"的关系论证链条：(a)说明采样耗时如何随token数变化，(c)说明前向耗时如何随token数变化，(b)综合前两者给出两者比值的整体分布。

4. **直接可见的结论**：(a) 采样token数从约0增至约120时，采样耗时从约1.5ms近似线性上升至约7ms，散点紧密贴合一条近似直线，无明显曲折或饱和迹象 `[图像直接可见]`。(b) 比值分布呈现集中在2–5区间的单峰、大致对称（略右偏）的钟形分布，峰值密度出现在约2.3附近，均值线标注在3.09处 `[图像直接可见]`。(c) 前向token数从0增至约900时，单层前向耗时从约0.8ms增至约5.5ms，散点整体也呈近似线性上升趋势，但在约150–400 token区间可见若干个纵向密集的"条带状"聚集（同一token数附近有明显耗时跳变，如约150处耗时在1.5–2.3ms间分层聚集），显示出比(a)更多的局部离散/分段现象 `[图像直接可见]`。

5. **它验证的论点与方法设计含义**：三个子图共同支撑主张地图中的核心论点——"采样延迟与被采样token数近似线性增长"（子图a）、"单层前向计算时间与批内总token数正相关"（子图c）、"采样/单层前向时延比近似服从正态分布，均值约3.09倍"（子图b），均为**效果类/机制类**主张，且均标注`[作者明确陈述，实验支持]` `[正文支持]`。这组证据的方法设计含义在于：(1) 子图(a)(c)的线性趋势为组件一"执行时间预测器"中$T_{layer}$和$T_{sample}$的线性回归建模形式（$\phi_1 n+\phi_2 nL+\epsilon$ 和 $\alpha N_{decode}+\beta$）提供了实证依据——线性关系是拟合这些线性模型的前提；(2) 子图(b)的分布形态（均值3.09但存在较宽的密度范围，非退化的单点值）直接论证了"采样开销相对前向开销的比例并非常数"，从而构成"静态层重分配方法在动态负载下失效"这一必要性主张的核心证据，推动了动态调度设计（组件二）而非一次性静态配置 `[正文支持]`。需要注意：本图仅证明比值分布"存在动态性"和均值量级，并不直接证明后文DynaPipe调度算法本身的有效性——那部分由Figure 5/6等实验图表验证，本图不能替代。

6. **适用范围与证据缺口**：本组profiling结果覆盖的是论文4×A100-PCIe-40GB实验平台下的实测数据，但正文未明确说明该profiling具体基于哪个模型（14B或32B）、哪个数据集（ShareGPT或Azure-Conv）——"无法从当前OCR内容确认"。子图(c)中约150–400 token区间出现的分层聚集现象，其成因（如批处理规模跳变、GPU kernel调度边界等）正文未讨论，图中也无法进一步区分具体原因，属于图像可见但无法归因的细节；由于该现象未被论文主张依赖，不计入证据缺口影响主张有效性，仅作视觉观察记录。除此之外无额外证据缺口。
