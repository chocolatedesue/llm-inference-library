# 图片批次 5

## 图片 1：Figure 9: Performance comparison on MoE and Dense LLM models. DynaPipe consistently outperforms the baseline in both average latency and SLO compliance across all workloads.

![Figure 9: Performance comparison on MoE and Dense LLM models. DynaPipe consistently outperforms the baseline in both average latency and SLO compliance across all workloads.](../assets/imgs/img_in_chart_box_216_265_1006_550.jpg)

*来源：OCR 第 15 页。*

### 解读

1. **论文角色与验证问题**：该图对应附录 A（第15页）"Performance Evaluation on Other Models"，证据类型为**适用边界**（兼具对比基线结构）。正文明确说明其目的：验证"采样导致的阶段间负载不均"这一根问题以及 DynaPipe 的收益，是否在主实验（Qwen2.5-14B/32B）之外的**其他模型架构**（MoE 与 Dense）上依然成立，用以支撑"该问题具有普遍性、方法具有泛化性"这一论断 `[正文支持]`。
   - **图表角色**：适用边界（辅以对比基线：DynaPipe vs. gLLM）。
   - **上文呼应**：附录 A，呼应正文 4.2 节"DynaPipe reduces average end-to-end latency by 8–41% across diverse workloads"这一总体效果主张的模型泛化延伸，以及 2.3 节"采样开销是被忽视的通用瓶颈"这一根问题的普适性论证。

2. **图像类型与布局**：多panel曲线图，2×2大网格外加内部子分组：行方向按数据集分组（上行 ShareGPT，下行 Azure-Conv），列方向按模型分组（左列 (a) Qwen3-30B-A3B，右列 (b) Meta-Llama-3-8B-Instruct）；每个数据集×模型组合内又并列两个子图（E2EL 曲线图 + SLO Attainment 曲线图），共8个子图。两条曲线用颜色和形状区分：红色三角为 gLLM，黑色圆点为 DynaPipe，图例位于顶部。

3. **如何阅读**：横轴为 Request Rate (reqs/s)；左侧子图纵轴为 E2EL (s)（越低越好），右侧子图纵轴为 SLO Attainment (%)（越高越好）。E2EL 曲线上标注的是 DynaPipe 相对 gLLM 的耗时比例（如 0.89x 表示 DynaPipe 耗时为 gLLM 的 89%）；SLO 曲线上标注的是类似比例（如 1.01x、5.96x 等），并有竖直虚线标记某个请求速率阈值（红色对应 gLLM、黑色对应 DynaPipe，可能表示各自达到某 SLO 边界或速率上限的位置）。应重点比较同一横轴位置下两条曲线的纵轴数值差异，以及标注比例数字随请求速率增大的变化趋势。

4. **直接可见的结论**：在四个"模型×数据集"组合中，E2EL 子图里 DynaPipe（黑色）曲线始终低于或接近 gLLM（红色）曲线，标注比例均为1.0以下（0.67x–0.89x区间，表示 DynaPipe 耗时更低）`[图像直接可见]`。SLO Attainment 子图中，两条曲线在较低请求速率下接近或均维持高位（比例接近1.0x），但随请求速率增大，gLLM（红色）的 SLO 达标率下降更快、更早，DynaPipe（黑色）维持更高达标率更久，标注比例数字随速率增大而显著增大（如右上角达到5.96x、右下角8.65x）`[图像直接可见]`。四组"模型×数据集"组合均呈现相似的定性模式（DynaPipe 更低时延、更高且更持久的SLO达标率）`[图像直接可见]`。

5. **它验证的论点与方法设计含义**：这属于**适用边界**类主张——正文明确指出该图用于证明"无论底层模型架构（MoE 还是 Dense）如何，PP 下采样导致的阶段间负载不均都是普遍问题，DynaPipe 能够普遍适应并加速推理"，从而支撑方法的**通用性与可扩展性**（generality and scalability）`[正文支持]`。图中四组不同模型/数据集组合下 DynaPipe 相对 gLLM 均呈现一致的时延降低和 SLO 达标率提升模式，为"8%-41%时延降低"这一效果主张提供了超出主实验模型范围（Qwen2.5-14B/32B）的泛化证据 `[正文支持]`。但该图仅与 gLLM 一个基线比较，不能证明 DynaPipe 相对 vLLM/SGLang 在这些新模型上同样占优，也不能用于判断窗口阈值、预测器精度等其他模块设计的普适性。

6. **适用范围与证据缺口**：本证据覆盖论文报告的单节点、四张 NVIDIA A100 40GB GPU 环境，模型为 Qwen3-30B-A3B（MoE）与 Meta-Llama-3-8B-Instruct（Dense），数据集为 ShareGPT 与 Azure-Conv，基线仅为 gLLM `[正文支持]`。曲线标注的竖直虚线（红/黑）具体代表的阈值含义（例如是否对应某一 SLO 达标率边界点或最大可支撑请求速率）正文未给出文字说明，属于图中标注符号含义不明的缺口——“无法从当前 OCR 内容确认”。除此之外无额外证据缺口。
