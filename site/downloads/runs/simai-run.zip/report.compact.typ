#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(font: "Noto Serif CJK SC", size: 9.6pt)
#set par(justify: true, leading: 0.92em, spacing: 0.86em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.55em)
#show heading.where(level: 1): set block(above: 1.05em, below: 0.62em)
#show heading.where(level: 2): set block(above: 0.95em, below: 0.52em, inset: (x: 10pt, y: 5.5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))
#show heading.where(level: 3): set block(above: 0.95em, below: 0.55em)
#show heading.where(level: 4): set block(above: 0.50em, below: 0.30em)
#show heading.where(level: 1): it => [
  #text(font: "Noto Sans CJK SC", size: 17.4pt, weight: "bold", tracking: 0.025em, fill: rgb(25, 79, 95))[#it.body]
  #v(-4pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => [#text(font: "Noto Sans CJK SC", size: 13.1pt, weight: "bold", tracking: 0.018em, fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => [#text(font: "Noto Sans CJK SC", size: 11.3pt, weight: "bold", tracking: 0.014em, fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => [#text(font: "Noto Sans CJK SC", size: 10.2pt, weight: "bold", tracking: 0.008em, fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", tracking: 0.005em, fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(font: "Noto Sans CJK SC", size: 12.2pt, weight: "bold", tracking: 2.4pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(7pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(font: "Noto Sans CJK SC", size: 22.5pt, weight: "bold", tracking: 0.012em)[SimAI: Unifying Architecture Design and Performance Tuning for Large-Scale Large Language Model Training with Scalability and Precision]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Xizheng Wang, Qingxu Li, Yichi Xu, Gang Lu, Dan Li, Li Chen, Heyang Zhou, Linkang Zheng, Sen Zhang, Yikai Zhu, Yang Liu, Pengcheng Zhang, Kun Qian, Kunling He, Jiaqi Gao, Ennan Zhai, Dennis Cai, Binzhang Fu]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[USENIX Symposium on Networked Systems Design and Implementation (NSDI) · 2025]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[LLM训练模拟器] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[大规模分布式训练] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[网络与集合通信模拟] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU性能建模] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[系统架构设计]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：https://www.usenix.org/system/files/nsdi25-wang-xizheng-simai.pdf]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[代码：https://github.com/aliyun/SimAI]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-28]
]
#pagebreak(weak: true)

#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

单次大语言模型（LLM）训练所需的大量GPU严重阻碍了对新设计、调优和优化方案的验证，因此需要高效的模拟器。然而，现有模拟器仅针对整个训练流程中的特定粒度进行建模，这从本质上导致了不精确性。本文提出了SimAI，一个旨在精确、高效地大规模模拟LLM训练过程的统一模拟器。通过对训练框架、内核计算和集合通信库进行有选择的高保真集成，SimAI在模拟中实现了高精度。SimAI进一步采用多线程加速，并实现了无锁的全局上下文共享，以提升执行速度。其性能结果验证了SimAI的有效性：在各种测试场景下，SimAI与真实结果的平均对齐度达到98.1%，证明了其从小规模实验室到大规模工业环境的稳健性与适应性。SimAI为新的主机设计和参数设置提供了有意义的指导，直接惠及生产环境中的LLM训练。我们还分享了SimAI演进过程中的经验与教训。SimAI已在 #link("https://github.com/aliyun/SimAI") 开源。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#figure(
  align(center)[#table(
    columns: 2,
    align: (auto,auto,),
    table.header([字段], [内容],),
    table.hline(),
    [标题], [SimAI: Unifying Architecture Design and Performance Tuning for Large-Scale Large Language Model Training with Scalability and Precision],
    [作者], [Xizheng Wang, Qingxu Li, Yichi Xu, Gang Lu, Dan Li, Li Chen, Heyang Zhou, Linkang Zheng, Sen Zhang, Yikai Zhu, Yang Liu, Pengcheng Zhang, Kun Qian, Kunling He, Jiaqi Gao, Ennan Zhai, Dennis Cai, Binzhang Fu],
    [发表场所 / 年份], [USENIX Symposium on Networked Systems Design and Implementation (NSDI), 2025],
    [研究领域], [系统、人工智能基础设施],
    [关键词], [LLM训练模拟器, 大规模分布式训练, 网络与集合通信模拟, GPU性能建模, 系统架构设计],
  )]
  , kind: table
  )

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：#link("https://github.com/aliyun/SimAI")

#quote(block: true)[
#strong[标签（3--5 个）]：`LLM训练模拟器` · `集合通信仿真` · `GPU性能建模` · `分布式训练系统` · `容量规划`
]

SimAI 是通过\"劫持\"真实训练框架（Megatron/DeepSpeed）、通信库（NCCL）与细粒度算子实测数据三条路径来联合仿真计算与通信的统一化 LLM 训练模拟器，在多种测试场景下与真实集群偏差平均约 1.9%\~3.9%（摘要另称对齐度 98.1%）\[实验支持\]，其可靠边界为最大 1024 GPU 规模、已验证的多导轨拓扑与 Megatron/DeepSpeed 两个框架\[基于文中逻辑的推断\]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- OCR 覆盖论文正文第 2--13 页的文字内容，并对 6 批共 10 幅图/表进行了独立视觉分析（第 5、6、7、8、9、10、11、12 页），文字与图表证据链一致，未发现明显冲突\[作者明确陈述\]。
- 已知缺口：摘要\"98.1% alignment\"与正文\"1.9% average deviation\"两个数字之间的精确换算关系未被作者明确给出\[文中未说明\]；图 7、图 8 的坐标轴单位（GPU 型号标注、执行时间量纲）存在缺失或模糊\[文中未说明\]。
- 本报告仅以论文文字与图表 OCR 内容为事实来源，涉及 Roofline 模型、NCCL、离散事件仿真等背景解释均已标注为\"背景知识\"性质的通俗类比，不构成论文结论的一部分。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

训练一个先进 LLM 需要海量 GPU（例如 GPT-4 级别约 2.5 万块最先进 GPU）\[作者明确陈述\]，这是全文的基本约束：任何新架构、参数或机制若要在真实硬件上验证，都要承担极高的试错成本。这类似于每改一个汽车零件就要建一整条生产线来测试------没人敢轻易迭代。

这一困难直接催生模拟器的价值：它需要同时服务两个阶段------基础设施规划期（评估需要多大规模、什么架构）与运营期（提升资源利用率、保证投资回报）\[作者明确陈述\]。但论文指出，行业现状是容量规划仿真（flow/job 级别）与性能调优仿真（packet 级别）历来使用不同粒度的独立工具链\[作者明确陈述\]，这种粒度分裂正是根问题的具体形态：没有一个工具能同时兼顾\"够快、能跑大规模\"与\"够准、能指导具体调优\"。

#strong[本文的 story]：旧路线在\"精度\"与\"速度\"这一对矛盾上失效------细粒度模拟器精确但跑不动大规模，粗粒度模拟器能跑但不准。SimAI 的转折点在于：与其重新建模训练框架、通信库和硬件的行为，不如直接复用真实系统组件本身在单机上运行，天然继承其精度，同时只承担单机成本。

== 4. 旧方法为何不够
<4-旧方法为何不够>

论文明确列出的三层挑战为：粒度分裂导致成本-性能分析不准、精度与速度难以两全、多工具链导致结果偏差风险增大\[作者明确陈述\]。具体到各条相关工作：

- #strong[Chakra]：原本解决 trace 驱动的 workload 生成问题，依赖 PyTorch Execution Trace；前提是\"相同参数与规模\"的 LLM 才能复用 trace；本文批判其无法泛化到新模型/新配置\[作者明确陈述\]；SimAI-WG 用框架\"劫持\"法回应；但论文未给出与 Chakra 的直接对比实验，故该批判的量化验证\[无法从当前 OCR 内容确认\]。
- #strong[NS-3/OMNeT++]：解决通用包级网络仿真，但不处理分布式训练所用的集合通信逻辑，从零仿真导致低保真\[作者明确陈述\]；SimAI-CM/SimCCL 通过劫持真实 NCCL 而非重写来回应，检验实验为 §4.2 图 6/7 的通信精度对比。
- #strong[ASTRA-sim]：SimAI 的直接灵感来源，原用于分布式训练软硬件协同仿真；限制是不支持多种 GPU 类型或精度不足\[作者明确陈述\]，小消息、大规模场景偏差达 204%\~530%\[实验支持\]；SimAI-CM/SimCCL 对应回应，§4.2/§4.4 图 6/7/9 为检验实验。
- #strong[SCALE-sim（ASTRA-sim 所用计算模拟器）]：只能成功运行矩阵乘法核，其余核靠 FLOPS 比例换算，导致总误差 H100 49.8%、A100 117.9%、H20 224%\[实验支持\]；SimAI-CP 细粒度操作库 + Roofline 迁移公式对应回应，§4.3 图 8 为检验实验。
- #strong[GPGPU-Sim / Accel-Sim]：分别因\"耗时过长\"和\"仅支持六年前的 PyTorch 0.4、无法运行现代 LLM 任务\"而失效\[作者明确陈述\]；论文未给出与二者的直接量化对比实验\[无法从当前 OCR 内容确认\]。

== 5. 核心洞见与假设
<5-核心洞见与假设>

核心洞见（区别于实现组件）：不从零建模训练框架、通信库和 GPU 硬件行为，而是直接\"劫持\"（hijack）真实系统组件本身在单机上运行，让其误以为处于目标规模集群中，从而天然继承真实系统精度，同时只需承担单机运行成本\[作者明确陈述\]。类比：给演员一个逼真布景按剧本表演，不需要真建一座城市。

三个支撑该洞见落地的假设均为作者明确陈述：①训练框架在单机被\"欺骗\"后可生成与真实任务一致的操作序列（）；②核函数执行时间可按\"计算密集型/内存带宽密集型\"分类，用 Roofline 关系把已知 GPU 实测数据迁移到未发布 GPU（）；③修改版 NCCL（SimCCL）能复现真实 NCCL 的算法选择逻辑（）。此外论文假设专家并行（EP）门控的 token 分配可用均衡分布近似，作者称\"影响很小\"，但未给出量化实验验证该假设本身的偏差\[作者明确陈述，但量化程度无法从当前 OCR 内容确认\]。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

总览：输入描述（模型、框架、CCL 参数、拓扑）→ SimAI-WG 生成 workload 文件 → 由 Scheduler 协调 SimAI-CP（计算）与 SimAI-CM/SimCCL（通信）两条并行仿真通道 → 输出仿真加速结果\[作者明确陈述\]。

+ #strong[SimAI-WG（工作负载生成器）]：动机是现有生成方法要么太粗（仅按 FLOPS）要么依赖真实 trace 无法泛化；做法是劫持 Megatron/DeepSpeed，使其在单机误以为运行于目标规模集群，同时跳过真实 NCCL 通信，输出含子模块、通信操作及依赖关系的描述文件，依赖关系已用 Nvidia Nsight Systems 在 1024-GPU 集群上验证\[作者明确陈述\]；优势是无需物理大规模集群且与框架解耦\[作者明确陈述\]。
+ #strong[SimAI-CP（计算模拟器）]：对已有 GPU 直接查操作数据库中的实测执行时间（精度 96.9%\~99.5%）\[实验支持\]；对未发布 GPU 用计算密集型/带宽密集型分类结合 Roofline 关系换算（SimAI-CP-Model，偏差 13%-15%）\[作者明确陈述，实验支持\]。
+ #strong[SimAI-CM/SimCCL（通信模拟器）]：劫持 NcclCommInitAll、拓扑发现改为读用户指定 topo.xml、跳过真实节点信息收集、将集合通信拆为点对点操作，输出 FlowModel；仅修改 NCCL 原代码 572 行，支持 PXN 特性\[作者明确陈述\]。
+ #strong[多线程加速 + 无锁全局上下文共享]：基于 UNISON 引入多线程后发现全局变量原子锁成为瓶颈，改为按节点 ID 将全局变量隔离到线程独立表中消除全局锁；相对单线程提速 23 倍，相对未去锁多线程再提升 15%\[作者明确陈述，实验支持\]。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：统一框架整体架构与四大模块组合]
  #image("assets/source-crops/img_in_image_box_154_144_1063_356.png", width: 100%)
  #emph[Figure 1: The SimAI architecture]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示输入描述经Workload Generator至计算/通信双通道经Scheduler输出加速结果的完整流水线

- #strong[论证关系]：机制层面支撑\"统一框架\"设计主张，说明四模块如何组合成单一系统

- #strong[适用范围]：仅为架构示意，精度与速度数值需依赖后续实验图
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：SimAI-WG生成与真实任务一致操作序列的假设]
  #image("assets/source-crops/img_in_image_box_132_145_553_512.png", width: 100%)
  #emph[Figure 2: Demonstration of the dependencies among the algorithm submodules and the communication operations.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示TP/DP/PP并行下算法子模块与通信操作的阻塞/非阻塞依赖关系

- #strong[论证关系]：为\"生成一致操作序列\"假设提供机制可视化支持，不含量化吻合度数据

- #strong[适用范围]：仅覆盖Megatron框架依赖示意，无进一步量化缺口
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：SimAI-CM/SimCCL劫持NCCL而非重写的实现路径]
  #image("assets/source-crops/img_in_image_box_634_408_1122_724.png", width: 100%)
  #emph[Figure 3: Illustration of how SimAI transforms a collective communication operation to a list of peer-to-peer communication operations.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：展示AllReduce调用经NCCL Hack API与拓扑读取转换为P2P操作列表的完整流程

- #strong[论证关系]：具体化\"劫持NCCL\"设计，解释仅需修改572行代码的非侵入性

- #strong[适用范围]：架构示意图，不含精度数值，需与图6/7互补解读
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：无锁化多线程加速的瓶颈根源与解决方案]
  #image("figure-groups/page-0008-707c3c78f92f.png", width: 100%)
  #emph[Figure 4: Multi-thread implementation and optimization in SimAI.]
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Panel(a)三线程共享锁访问全局表，Panel(b)线程独立分区无锁图标

- #strong[论证关系]：可视化瓶颈根源到解决方案的机制变化，不能证明23倍/15%加速具体数值

- #strong[适用范围]：仅为机制对比，不含线程数量以外的实现细节
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- #strong[机制→收益]：劫持真实 NCCL 算法选择逻辑而非重写，使仿真能复现算法在不同消息大小/规模下的真实切换行为，从而在中小消息区显著优于从零建模的 ASTRA-sim\[基于文中逻辑的推断\]，此点已由 §4.2 实验直接支撑。
- #strong[机制→收益]：细粒度实测算子数据库替代整体 FLOPS 缩放，避免了\"仅矩阵乘法核可模拟、其余靠比例换算\"带来的系统性误差\[基于文中逻辑的推断\]，需要的条件是操作数据库需预先在目标 GPU 上完成实测，对未发布 GPU 则依赖 Roofline 迁移，其精度天然弱于直接实测（13%-15% vs 0.5%-3.1%）。
- #strong[机制→收益]：无锁化设计消除多线程对全局变量的争用，使仿真规模可扩展至 1024 GPU 而不被单线程速度瓶颈限制\[作者明确陈述\]，条件是该收益依赖 UNISON 离散事件仿真框架本身的正确性，论文未单独验证该前提是否随规模变化而衰减。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[效果类]：SimAI 通信/计算/端到端仿真精度是否优于 ASTRA-sim/SCALE-sim？对应 §4.2/§4.3/§4.4，判定标准为偏差百分比是否显著更低\[实验支持\]。
- #strong[必要性类]：细粒度操作数据库、劫持 NCCL 等设计是否为精度提升所必需？对应 ASTRA-sim/SCALE-sim 的失效数据（如仅能跑矩阵乘法核）间接反证，但论文未做严格的组件消融实验（如去掉 Roofline 迁移后的对照）\[文中未说明\]。
- #strong[鲁棒性类]：SimAI 是否能从小规模适应到 1024 GPU 工业规模？对应 §4.1/§4.4 的多规模测试\[实验支持，但上限止于 1024 GPU\]。
- #strong[适用范围类]：TP 组大小是否应匹配模型层结构？对应 §5.2 图 11 的参数敏感性实验\[实验支持\]。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- #strong[测试床]：A100 与 H100 两套真实集群，共享与仿真相同的 intra-host/inter-host 拓扑（多导轨 fat-tree，128 台服务器）\[作者明确陈述\]。
- #strong[任务/模型]：GPT-3 13B、GPT-3 175B、LLaMA 65B，来自基准测试套件（基于生产任务统计挑选）\[作者明确陈述\]。
- #strong[规模]：128/512/1024 GPU\[实验支持\]。
- #strong[对比基线]：ASTRA-sim（含其计算模拟组件 SCALE-sim）\[作者明确陈述\]。
- #strong[硬件/软件版本、重复次数、统计方式]：文中未说明。
- #strong[超参数（如学习率等训练配置）]：文中未说明。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：端到端仿真偏差（End-to-End Deviation）。测量对象为仿真迭代时间与真实集群迭代时间之差，单位为百分比，越小越好。

  - #strong[定义与公式]：无可核验公式；作者文字定义为仿真与真实结果的相对偏差\[作者明确陈述\]。
  - #strong[来源层级]：无可核验公式（论文未给出显式 Eq.）。
  - #strong[实验用途]：检验 SimAI 整体（计算+通信联合）在端到端场景下是否逼近真实硬件，回答效果类问题。
  - #strong[读数与边界]：1024 GPU 规模下偏差 \<4%，比 ASTRA-sim 精确 36.1 倍\[实验支持\]；不能证明该精度在超过 1024 GPU 或非 fat-tree 拓扑下同样成立。

- #strong[指标与方向]：通信总线带宽偏差（Bus Bandwidth Deviation）。测量对象为集合通信（AllReduce/AllGather/ReduceScatter）仿真带宽与真实带宽之差，单位 GB/s 对应的相对百分比，越小越好。

  - #strong[定义与公式]：无可核验公式；作者文字给出具体数值而非公式（）。
  - #strong[来源层级]：无可核验公式。
  - #strong[实验用途]：检验 SimCCL 通信仿真精度，是否优于 ASTRA-sim 的从零建模方式。
  - #strong[读数与边界]：intra-host A100 上 3.9% vs 74.8%，H100 上 2.3% vs 51.7%\[实验支持\]；inter-host 场景 ASTRA-sim 偏差随规模从 128→512 GPU 由 45.9%升至 530.2%\[实验支持\]；不能说明该趋势在非 NCCL 通信库场景下是否成立。

- #strong[指标与方向]：计算核函数执行时间总误差。测量对象为各 GPU（A100/H100/H20）上 GPT-3 175B 计算 kernel 仿真总耗时与真实值之差，单位为百分比，越小越好。

  - #strong[定义与公式]：无可核验公式；作者以数值形式直接给出（）。
  - #strong[来源层级]：无可核验公式。
  - #strong[实验用途]：检验 SimAI-CP 与 SimAI-CP-Model 相对 ASTRA-sim（依赖 SCALE-sim）的精度。
  - #strong[读数与边界]：SimAI-CP 偏差 0.5%-3.1%，SimAI-CP-Model 偏差 13%-15%；ASTRA-sim 总误差 H100 49.8%、A100 117.9%、H20 224%\[实验支持\]；SimAI-CP-Model 误差集中在 Attention-QKV 与 MLP-linear 核函数，但具体分项误差\[文中未说明\]。

- #strong[指标与方向]：多线程加速比（Speedup）。测量对象为仿真执行时间相对单线程/未去锁多线程版本的倍数，越大越好。

  - #strong[定义与公式]：无可核验公式；仅给出倍数结果（）。
  - #strong[来源层级]：无可核验公式。
  - #strong[实验用途]：检验无锁化设计对仿真效率/可扩展性是否必要。
  - #strong[读数与边界]：相对单线程提速 23 倍，相对多线程再提升 15%\[实验支持\]；未说明该加速比是否随 GPU 规模变化而改变\[文中未说明\]。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#figure(
  align(center)[#table(
    columns: 4,
    align: (auto,auto,auto,auto,),
    table.header([比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],),
    table.hline(),
    [ASTRA-sim], [不支持多 GPU 类型、小消息与大规模场景严重失真（偏差达 204%\~530%）], [SimAI-CM/SimCCL], [§4.2 图 6/7、§4.4 图 9 已验证；非 fat-tree 拓扑下是否仍成立未验证],
    [SCALE-sim（ASTRA-sim 计算组件）], [仅矩阵乘法核可运行，其余靠 FLOPS 比例换算], [SimAI-CP 细粒度操作库 + Roofline 迁移], [§4.3 图 8 已验证；分项 kernel 级误差未验证],
    [Chakra/GPGPU-Sim/Accel-Sim], [分别无法泛化新模型、耗时过长、框架版本过旧], [SimAI-WG / SimAI-CP], [论文未给出直接对比实验，无法从当前 OCR 内容确认],
  )]
  , kind: table
  )

- 比较结果仅说明本文实验设置内谁表现更好，不能证明基线在所有场景下失效，尤其 Chakra/GPGPU-Sim/Accel-Sim 三项缺乏直接对比数据。
- ASTRA-sim 的失真在图 7 中被可视化为小消息区曲线分离，且随规模递增（128→1024 GPU）而扩大，与文字数据方向一致\[实验支持\]。
- SimAI-CP-Model 相较 ASTRA-sim 更贴近真实值，但仍落后于 SimAI-CP 本身，符合作者自陈的 13%-15% 局限\[作者明确陈述\]。

#figure(
  align(center)[#table(
    columns: 3,
    align: (auto,auto,auto,),
    table.header([主张], [直接证据（实验/表图）], [证据强度与边界],),
    table.hline(),
    [SimAI 通信/计算仿真精度显著优于 ASTRA-sim/SCALE-sim], [§4.2 图 6/7、§4.3 图 8], [实验支持，覆盖 A100/H100/H20、128-1024 GPU；分项误差来源未逐一验证],
    [SimAI 端到端精度\<4%，36.1倍优于ASTRA-sim], [§4.4 图 9], [实验支持，止于 1024 GPU；万卡级未测试],
    [模型越大端到端精度越高（因通信消息更大）], [§4.4 文字陈述], [因果部分为作者基于 §4.2 结果的推断，未做单独消融隔离该变量],
    [无锁化带来 23倍/15%加速], [§3.5 文字陈述], [实验支持；未测试不同规模下是否稳定],
    [TP 组大小应匹配模型层而非主机 GPU 数], [§5.2 图 11], [实验支持；该图本身不包含与真实硬件的精度校验，依赖读者已认可 SimAI 整体精度],
  )]
  , kind: table
  )

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_image_box_129_142_564_283.png", width: 100%)
    #emph[Figure 5: Multi-rail network topology of cluster H100. For cluster A100, two GPUs share a single NIC]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：测试床拓扑一致性前提]
    - #strong[图组结论]：H100/A100共享三层多导轨fat-tree拓扑，128台服务器，NVLink/网络带宽标注一致

- #strong[论证关系]：证明仿真与真实集群拓扑相同，精度差异可归因于仿真方法本身

- #strong[适用范围]：精度主张仅在该拓扑与规模下验证，非通用网络架构结论
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_632_140_1113_277.png", width: 100%)
    #emph[Figure 9: The iteration time of different workloads running on ASTRA-sim, SimAI, and real clusters.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：端到端仿真精度\<4%、优于ASTRA-sim36.1倍]
    - #strong[图组结论]：6子面板中SimAI柱高与真实值几乎贴合，AstraSim普遍偏高

- #strong[论证关系]：直接支撑端到端精度主张，跨GPU型号与规模一致

- #strong[适用范围]：仅验证至1024GPU，各分段耗时占比无法像素级精确读出
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_105_390_579_646.png", width: 100%)
    #emph[Figure 7: Bus bandwidths of inter-host collective communication operations with different message sizes and cluster scales.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：通信仿真精度显著优于ASTRA-sim]
    - #strong[图组结论]：9子图中SimAI与真实值几乎重合，AstraSim在小消息区系统性偏高

- #strong[论证关系]：可视化验证ASTRA-sim小消息、大规模场景失真随规模扩大的批判

- #strong[适用范围]：图题未标注对应A100或H100集群，与正文两组偏差数字对应关系存疑
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_111_729_582_922.png", width: 100%)
    #emph[Figure 8: The execution time of the computation kernels of GPT-3 175B on different GPUs.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：计算仿真精度显著优于ASTRA-sim/SCALE-sim]
    - #strong[图组结论]：A100/H100/H20三组中AstraSim条形远超真实值，差距逐组扩大

- #strong[论证关系]：定性印证误差顺序H100\<A100\<H20，SimAI-CP-Model优于AstraSim但逊于SimAI-CP

- #strong[适用范围]：X轴时间单位未标注，A100组缺失SimAI-CP-Model数据原因不明
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_119_145_609_275.png", width: 100%)
    #emph[Figure 6: Bus bandwidths of intra-host collective communication operations vary with different message sizes and GPU types. Note that the performance is not related to the cluster scales.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：通信仿真精度3.9%对74.8%、2.3%对51.7%]
    - #strong[图组结论]：三种通信操作中SimAI与真实值高度重合，AstraSim小消息区明显偏离

- #strong[论证关系]：支撑SimCCL劫持NCCL设计优于ASTRA-sim从零建模

- #strong[适用范围]：H100\_Ring曲线含义未说明，部分纵轴刻度因分辨率无法精确读出
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_114_135_586_286.png", width: 100%)
    #emph[Figure 10: The iteration time of GPT-3 175B with different network bandwidths.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：生产案例带宽选型19%/11%/6%性能提升]
    - #strong[图组结论]：H100/H20两子图中带宽提升伴随E2E时长下降，SimAI与真实值高度贴近

- #strong[论证关系]：支撑量化性能提升主张及SimAI-CP-Model作为未发布GPU替代方案的适用性

- #strong[适用范围]：\"No\_Comp\"段含义未说明，精确数值受分辨率限制无法逐一读出
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0012-712f1152cbf4.png", width: 100%)
    #emph[Figure 11: Training performance of different hosts and different TP sizes. The x-axis denotes the number of GPUs in a single host. Because of the big model size and limited GPU memory, TP should be larger than 2 for GPT-3 13B and 4 for GPT-3 175B and LLaMA 65B. And we can not run TP = 64 or TP = 48 for GPT-3 175B because the TP size should be the factor of both the number of feedforward neural network (FNN) layers (96) and the world size (1024). We do not let TP exceed the number of GPUs in a single host as the RDMA network is the bottleneck.]
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：TP组大小应匹配模型层而非主机GPU数]
    - #strong[图组结论]：三个Panel均显示中间TP值表现最优，过大TP导致性能明显变差

- #strong[论证关系]：直接支撑该必要性主张，即GPU数增加但TP不当仍会拖累性能

- #strong[适用范围]：本图不含与真实硬件的精度校验，依赖读者已接受SimAI整体精度前提
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 3: The SimAI benchmark suite v1.0]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[适用边界]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第8节：任务/模型选自生产统计基准套件]
  - #strong[图组结论]：列出SimAI基准测试套件v1.0涵盖的模型与任务配置

- #strong[论证关系]：界定精度实验（GPT-3 13B/175B、LLaMA65B）所依据的任务来源范围

- #strong[适用范围]：套件基于生产任务统计挑选，未覆盖套件外的模型架构
  #v(5pt)
  #image("table-groups/page-0007-5671e07545b3.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：LLM训练GPU需求巨大，新设计/调优难以在真实硬件上低成本验证，且容量规划与性能调优所需仿真粒度历史上分裂
  - 旧方法限制：ASTRA-sim/SCALE-sim精度不足或速度过慢，GPGPU-Sim/Accel-Sim/Chakra各有泛化或效率缺陷
    - 核心洞见/假设：劫持真实训练框架、通信库与实测算子数据而非从零建模，可继承真实系统精度并只承担单机成本
      - 方法模块：SimAI-WG / SimAI-CP / SimAI-CM-SimCCL / 无锁多线程加速
        - 可验证预测：仿真结果应在通信、计算、端到端三个层面均显著逼近真实硬件，且能扩展至千卡级规模
          - 指标与实验：§4.2通信偏差、§4.3计算偏差、§4.4端到端偏差、§3.5加速比
            - 图表证据：图6/7/8/9及生产案例图（第10-11页）\[实验支持\]
              - 结论与适用边界：精度主张在1024 GPU、H100/A100多导轨拓扑、Megatron/DeepSpeed框架内已验证；万卡级规模、非fat-tree拓扑、EP门控假设的量化偏差未被当前证据直接验证

== 11. 结论、贡献与边界
<11-结论贡献与边界>

#strong[贡献总结]：SimAI-WG（工作负载生成）、SimAI-CP（计算仿真+未发布GPU迁移）、SimAI-CM/SimCCL（通信仿真）、无锁多线程加速四项，均为论文明确提出且可对应到具体解决的挑战与实验\[作者明确陈述\]。

#strong[证据充分的结论]：通信/计算/端到端仿真精度显著优于ASTRA-sim/SCALE-sim，且在128-1024 GPU、A100/H100/H20多种配置下一致成立\[实验支持\]；无锁化带来23倍加速\[实验支持\]。

#strong[尚属推断的意义]：模型越大端到端精度越高是因通信消息更大更易精确仿真，此为作者自身推断而非独立消融验证\[基于文中逻辑的推断\]；TP组大小应匹配模型层的结论依赖读者预先接受SimAI整体精度这一前提\[基于文中逻辑的推断\]。

#strong[适用条件与局限]：验证规模上限为1024 GPU\[实验支持\]；仅支持Megatron与DeepSpeed两个框架\[文中未说明其他框架支持情况\]；SimCCL不做真实数据完整性校验，EP门控均衡分布假设未量化验证\[作者明确陈述\]；SimAI-CP-Model偏差13%-15%，作者建议仅在无法获取真实GPU时使用\[作者明确陈述\]；故障仿真为未来工作，非当前贡献\[作者明确陈述\]。

#strong[审稿式风险检查]：

- 贡献新意：论文自陈受ASTRA-sim启发，新意限于工作负载生成、计算/通信保真度、可扩展性三方面改进，非全新范式\[作者明确陈述\]，当前证据未显示夸大新意的风险。
- 写作/可复现性：代码已开源（GitHub链接），但摘要\"98.1%\"与正文\"1.9%/3.9%\"两套数字未说明换算关系，存在表述不统一的风险\[文中未说明\]。
- 效果大小：主要精度对比均有具体数值支撑，当前证据未显示效果被夸大的风险。
- 实验覆盖：未测试超过1024 GPU的规模，也未提供更多未发布GPU的事后验证案例（仅H100/H20两例），样本量有限的风险确实存在。
- 方法设计：EP门控均衡分布假设、通信数据完整性未校验均为作者自陈但未量化的简化，存在未被证据覆盖的动态行为风险\[作者明确陈述\]。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：集合通信（Collective Communication，如AllReduce/AllGather/ReduceScatter）。多GPU间需要\"对齐信息\"的通信模式。

  - #strong[第一性原理角色]：连接\"各卡局部计算结果\"与\"全局一致模型参数\"这两个基本量，受网络带宽与拓扑约束。
  - #strong[本文位置]：是SimCCL仿真的核心对象，直接决定通信仿真精度指标。

- #strong[术语]：NCCL。NVIDIA提供的GPU间集合通信优化软件库。

  - #strong[第一性原理角色]：在硬件拓扑约束下选择通信算法（如ring/tree），是通信延迟的决定因素之一。
  - #strong[本文位置]：SimCCL通过劫持NCCL关键函数复现其算法选择逻辑。

- #strong[术语]：Roofline模型。判断程序性能瓶颈在\"计算能力\"还是\"内存带宽\"的分析框架\[背景知识\]。

  - #strong[第一性原理角色]：连接\"算子的计算量/访存量比值\"与\"硬件峰值算力/带宽\"两个基本量，决定该算子的理论执行时间上界。
  - #strong[本文位置]：SimAI-CP-Model用其将已知GPU实测数据迁移到未发布GPU。

- #strong[术语]：离散事件仿真（DES）。按事件发生时刻跳跃式推进的仿真方法，而非逐微秒推进\[背景知识\]。

  - #strong[第一性原理角色]：以\"事件\"而非\"时间步\"为基本状态更新单元，在稀疏事件场景下大幅降低计算量。
  - #strong[本文位置]：SimAI的执行引擎基于UNISON（NS-3上的并行DES框架）。

- #strong[术语]：张量并行（TP，Tensor Parallelism）。把单层模型计算拆分到多张GPU上并行执行。

  - #strong[第一性原理角色]：受模型层内维度（如注意力头数）与主机内互联带宽（NVLink）双重约束。
  - #strong[本文位置]：§5.2实验的核心变量，TP组大小与模型层结构、主机GPU数共同决定性能。

- #strong[术语]：Roofline式核函数分类（计算密集型/内存带宽密集型）。将GPU算子按其瓶颈来源二分类。

  - #strong[第一性原理角色]：分类依据是算子的算术强度（计算量/数据搬运量）与硬件算力-带宽比的相对关系。
  - #strong[本文位置]：SimAI-CP-Model迁移公式的分类前提。

- #strong[术语]：FlowModel。SimCCL输出的、记录数据量、发送/接收rank、路由信息的点对点操作描述。

  - #strong[第一性原理角色]：是集合通信操作分解到底层网络流的最小可仿真单元。
  - #strong[本文位置]：SimAI-CM据此计算最终通信耗时。

- #strong[术语]：无锁化（Lock-free）设计。避免多线程访问共享资源时使用互斥锁的编程方式\[背景知识\]。

  - #strong[第一性原理角色]：把\"共享全局状态\"改造为\"线程私有状态+按ID隔离\"，从根本上消除锁竞争这一并发瓶颈。
  - #strong[本文位置]：SimAI多线程加速的关键机制，带来23倍加速。

=== 12.2 学习路径
<122-学习路径>
+ #strong[GPU并行策略（DP/TP/PP）]：先理解模型如何被拆分到多卡协同训练，是理解SimAI-WG生成workload的前提。
+ #strong[集合通信与NCCL]：理解多卡间\"对齐信息\"的通信模式与其底层软件库，是理解SimCCL劫持机制的基础。
+ #strong[Roofline模型]：理解\"计算瓶颈vs带宽瓶颈\"的判断逻辑，是理解SimAI-CP-Model迁移公式的前提。
+ #strong[离散事件仿真]：理解事件驱动而非时间步驱动的仿真范式，是理解SimAI效率优化（多线程/无锁化）动机的基础。
+ #strong[网络拓扑（Spine-Leaf、NVLink/PCIe/RDMA）]：理解intra-host与inter-host两类通信路径的物理差异，是理解通信精度实验分组设计的前提。
