# 论文解构报告

### 论文元数据

| 字段 | 内容 |
|---|---|
| 标题 | SimAI: Unifying Architecture Design and Performance Tuning for Large-Scale Large Language Model Training with Scalability and Precision |
| 作者 | Xizheng Wang, Qingxu Li, Yichi Xu, Gang Lu, Dan Li, Li Chen, Heyang Zhou, Linkang Zheng, Sen Zhang, Yikai Zhu, Yang Liu, Pengcheng Zhang, Kun Qian, Kunling He, Jiaqi Gao, Ennan Zhai, Dennis Cai, Binzhang Fu |
| 发表场所 / 年份 | USENIX Symposium on Networked Systems Design and Implementation (NSDI), 2025 |
| 研究领域 | 系统、人工智能基础设施 |
| 关键词 | LLM训练模拟器, 大规模分布式训练, 网络与集合通信模拟, GPU性能建模, 系统架构设计 |

### 资源链接

- 原始文件：本地上传文件（无外部链接）
- arXiv：文中未说明
- DOI：文中未说明
- 代码 / 数据集：https://github.com/aliyun/SimAI

> **标签（3–5 个）**：`LLM训练模拟器` · `集合通信仿真` · `GPU性能建模` · `分布式训练系统` · `容量规划`

## 1. 一句话总览

SimAI 是通过"劫持"真实训练框架（Megatron/DeepSpeed）、通信库（NCCL）与细粒度算子实测数据三条路径来联合仿真计算与通信的统一化 LLM 训练模拟器，在多种测试场景下与真实集群偏差平均约 1.9%~3.9%（摘要另称对齐度 98.1%）[实验支持，页码：2, 9]，其可靠边界为最大 1024 GPU 规模、已验证的多导轨拓扑与 Megatron/DeepSpeed 两个框架[基于文中逻辑的推断，页码：5, 9]。

## 2. 阅读范围与证据状态

- OCR 覆盖论文正文第 2–13 页的文字内容，并对 6 批共 10 幅图/表进行了独立视觉分析（第 5、6、7、8、9、10、11、12 页），文字与图表证据链一致，未发现明显冲突[作者明确陈述]。
- 已知缺口：摘要"98.1% alignment"与正文"1.9% average deviation"两个数字之间的精确换算关系未被作者明确给出[文中未说明，页码：2-3]；图 7、图 8 的坐标轴单位（GPU 型号标注、执行时间量纲）存在缺失或模糊[文中未说明，页码：9-10]。
- 本报告仅以论文文字与图表 OCR 内容为事实来源，涉及 Roofline 模型、NCCL、离散事件仿真等背景解释均已标注为"背景知识"性质的通俗类比，不构成论文结论的一部分。

## 3. 根问题：论文究竟要解决什么

训练一个先进 LLM 需要海量 GPU（例如 GPT-4 级别约 2.5 万块最先进 GPU）[作者明确陈述，页码：2]，这是全文的基本约束：任何新架构、参数或机制若要在真实硬件上验证，都要承担极高的试错成本。这类似于每改一个汽车零件就要建一整条生产线来测试——没人敢轻易迭代。

这一困难直接催生模拟器的价值：它需要同时服务两个阶段——基础设施规划期（评估需要多大规模、什么架构）与运营期（提升资源利用率、保证投资回报）[作者明确陈述，页码：2]。但论文指出，行业现状是容量规划仿真（flow/job 级别）与性能调优仿真（packet 级别）历来使用不同粒度的独立工具链[作者明确陈述，页码：2]，这种粒度分裂正是根问题的具体形态：没有一个工具能同时兼顾"够快、能跑大规模"与"够准、能指导具体调优"。

**本文的 story**：旧路线在"精度"与"速度"这一对矛盾上失效——细粒度模拟器精确但跑不动大规模，粗粒度模拟器能跑但不准。SimAI 的转折点在于：与其重新建模训练框架、通信库和硬件的行为，不如直接复用真实系统组件本身在单机上运行，天然继承其精度，同时只承担单机成本。

## 4. 旧方法为何不够

论文明确列出的三层挑战为：粒度分裂导致成本-性能分析不准、精度与速度难以两全、多工具链导致结果偏差风险增大[作者明确陈述，页码：2]。具体到各条相关工作：

- **Chakra**：原本解决 trace 驱动的 workload 生成问题，依赖 PyTorch Execution Trace；前提是"相同参数与规模"的 LLM 才能复用 trace；本文批判其无法泛化到新模型/新配置[作者明确陈述，页码：4]；SimAI-WG 用框架"劫持"法回应；但论文未给出与 Chakra 的直接对比实验，故该批判的量化验证[无法从当前 OCR 内容确认]。
- **NS-3/OMNeT++**：解决通用包级网络仿真，但不处理分布式训练所用的集合通信逻辑，从零仿真导致低保真[作者明确陈述，页码：4]；SimAI-CM/SimCCL 通过劫持真实 NCCL 而非重写来回应，检验实验为 §4.2 图 6/7 的通信精度对比。
- **ASTRA-sim**：SimAI 的直接灵感来源，原用于分布式训练软硬件协同仿真；限制是不支持多种 GPU 类型或精度不足[作者明确陈述，页码：4]，小消息、大规模场景偏差达 204%~530%[实验支持，页码：9]；SimAI-CM/SimCCL 对应回应，§4.2/§4.4 图 6/7/9 为检验实验。
- **SCALE-sim（ASTRA-sim 所用计算模拟器）**：只能成功运行矩阵乘法核，其余核靠 FLOPS 比例换算，导致总误差 H100 49.8%、A100 117.9%、H20 224%[实验支持，页码：10]；SimAI-CP 细粒度操作库 + Roofline 迁移公式对应回应，§4.3 图 8 为检验实验。
- **GPGPU-Sim / Accel-Sim**：分别因"耗时过长"和"仅支持六年前的 PyTorch 0.4、无法运行现代 LLM 任务"而失效[作者明确陈述，页码：4, 10]；论文未给出与二者的直接量化对比实验[无法从当前 OCR 内容确认]。

## 5. 核心洞见与假设

核心洞见（区别于实现组件）：不从零建模训练框架、通信库和 GPU 硬件行为，而是直接"劫持"（hijack）真实系统组件本身在单机上运行，让其误以为处于目标规模集群中，从而天然继承真实系统精度，同时只需承担单机运行成本[作者明确陈述，页码：3, 5, 7]。类比：给演员一个逼真布景按剧本表演，不需要真建一座城市。

三个支撑该洞见落地的假设均为作者明确陈述：①训练框架在单机被"欺骗"后可生成与真实任务一致的操作序列（页码：5）；②核函数执行时间可按"计算密集型/内存带宽密集型"分类，用 Roofline 关系把已知 GPU 实测数据迁移到未发布 GPU（页码：6-7）；③修改版 NCCL（SimCCL）能复现真实 NCCL 的算法选择逻辑（页码：7-8）。此外论文假设专家并行（EP）门控的 token 分配可用均衡分布近似，作者称"影响很小"，但未给出量化实验验证该假设本身的偏差[作者明确陈述，但量化程度无法从当前 OCR 内容确认，页码：8]。

## 6. 方法：从洞见到可执行系统

总览：输入描述（模型、框架、CCL 参数、拓扑）→ SimAI-WG 生成 workload 文件 → 由 Scheduler 协调 SimAI-CP（计算）与 SimAI-CM/SimCCL（通信）两条并行仿真通道 → 输出仿真加速结果[作者明确陈述，页码：4-5]。

1. **SimAI-WG（工作负载生成器）**：动机是现有生成方法要么太粗（仅按 FLOPS）要么依赖真实 trace 无法泛化；做法是劫持 Megatron/DeepSpeed，使其在单机误以为运行于目标规模集群，同时跳过真实 NCCL 通信，输出含子模块、通信操作及依赖关系的描述文件，依赖关系已用 Nvidia Nsight Systems 在 1024-GPU 集群上验证[作者明确陈述，页码：4-5]；优势是无需物理大规模集群且与框架解耦[作者明确陈述，页码：5-6]。
2. **SimAI-CP（计算模拟器）**：对已有 GPU 直接查操作数据库中的实测执行时间（精度 96.9%~99.5%）[实验支持，页码：6]；对未发布 GPU 用计算密集型/带宽密集型分类结合 Roofline 关系换算（SimAI-CP-Model，偏差 13%-15%）[作者明确陈述，实验支持，页码：6-7, 9]。
3. **SimAI-CM/SimCCL（通信模拟器）**：劫持 NcclCommInitAll、拓扑发现改为读用户指定 topo.xml、跳过真实节点信息收集、将集合通信拆为点对点操作，输出 FlowModel；仅修改 NCCL 原代码 572 行，支持 PXN 特性[作者明确陈述，页码：7-8]。
4. **多线程加速 + 无锁全局上下文共享**：基于 UNISON 引入多线程后发现全局变量原子锁成为瓶颈，改为按节点 ID 将全局变量隔离到线程独立表中消除全局锁；相对单线程提速 23 倍，相对未去锁多线程再提升 15%[作者明确陈述，实验支持，页码：8-9]。

## 7. 为什么它可能有效

- **机制→收益**：劫持真实 NCCL 算法选择逻辑而非重写，使仿真能复现算法在不同消息大小/规模下的真实切换行为，从而在中小消息区显著优于从零建模的 ASTRA-sim[基于文中逻辑的推断，页码：7-9]，此点已由 §4.2 实验直接支撑。
- **机制→收益**：细粒度实测算子数据库替代整体 FLOPS 缩放，避免了"仅矩阵乘法核可模拟、其余靠比例换算"带来的系统性误差[基于文中逻辑的推断，页码：6-7, 10]，需要的条件是操作数据库需预先在目标 GPU 上完成实测，对未发布 GPU 则依赖 Roofline 迁移，其精度天然弱于直接实测（13%-15% vs 0.5%-3.1%）。
- **机制→收益**：无锁化设计消除多线程对全局变量的争用，使仿真规模可扩展至 1024 GPU 而不被单线程速度瓶颈限制[作者明确陈述，页码：8-9]，条件是该收益依赖 UNISON 离散事件仿真框架本身的正确性，论文未单独验证该前提是否随规模变化而衰减。

## 8. 实验与指标：证据是否支撑主张

### 8.1 实验问题与判定标准

- **效果类**：SimAI 通信/计算/端到端仿真精度是否优于 ASTRA-sim/SCALE-sim？对应 §4.2/§4.3/§4.4，判定标准为偏差百分比是否显著更低[实验支持]。
- **必要性类**：细粒度操作数据库、劫持 NCCL 等设计是否为精度提升所必需？对应 ASTRA-sim/SCALE-sim 的失效数据（如仅能跑矩阵乘法核）间接反证，但论文未做严格的组件消融实验（如去掉 Roofline 迁移后的对照）[文中未说明]。
- **鲁棒性类**：SimAI 是否能从小规模适应到 1024 GPU 工业规模？对应 §4.1/§4.4 的多规模测试[实验支持，但上限止于 1024 GPU]。
- **适用范围类**：TP 组大小是否应匹配模型层结构？对应 §5.2 图 11 的参数敏感性实验[实验支持]。

### 8.2 数据、任务、对比与运行设置

- **测试床**：A100 与 H100 两套真实集群，共享与仿真相同的 intra-host/inter-host 拓扑（多导轨 fat-tree，128 台服务器）[作者明确陈述，页码：9]。
- **任务/模型**：GPT-3 13B、GPT-3 175B、LLaMA 65B，来自基准测试套件（基于生产任务统计挑选）[作者明确陈述，页码：6-7, 9]。
- **规模**：128/512/1024 GPU[实验支持，页码：9]。
- **对比基线**：ASTRA-sim（含其计算模拟组件 SCALE-sim）[作者明确陈述，页码：9-10]。
- **硬件/软件版本、重复次数、统计方式**：文中未说明。
- **超参数（如学习率等训练配置）**：文中未说明。

### 8.3 指标字典与对应公式

- **指标与方向**：端到端仿真偏差（End-to-End Deviation）。测量对象为仿真迭代时间与真实集群迭代时间之差，单位为百分比，越小越好。
  - **定义与公式**：无可核验公式；作者文字定义为仿真与真实结果的相对偏差[作者明确陈述，页码：10]。
  - **来源层级**：无可核验公式（论文未给出显式 Eq.）。
  - **实验用途**：检验 SimAI 整体（计算+通信联合）在端到端场景下是否逼近真实硬件，回答效果类问题。
  - **读数与边界**：1024 GPU 规模下偏差 <4%，比 ASTRA-sim 精确 36.1 倍[实验支持，页码：10]；不能证明该精度在超过 1024 GPU 或非 fat-tree 拓扑下同样成立。

- **指标与方向**：通信总线带宽偏差（Bus Bandwidth Deviation）。测量对象为集合通信（AllReduce/AllGather/ReduceScatter）仿真带宽与真实带宽之差，单位 GB/s 对应的相对百分比，越小越好。
  - **定义与公式**：无可核验公式；作者文字给出具体数值而非公式（页码：9）。
  - **来源层级**：无可核验公式。
  - **实验用途**：检验 SimCCL 通信仿真精度，是否优于 ASTRA-sim 的从零建模方式。
  - **读数与边界**：intra-host A100 上 3.9% vs 74.8%，H100 上 2.3% vs 51.7%[实验支持，页码：9]；inter-host 场景 ASTRA-sim 偏差随规模从 128→512 GPU 由 45.9%升至 530.2%[实验支持，页码：9]；不能说明该趋势在非 NCCL 通信库场景下是否成立。

- **指标与方向**：计算核函数执行时间总误差。测量对象为各 GPU（A100/H100/H20）上 GPT-3 175B 计算 kernel 仿真总耗时与真实值之差，单位为百分比，越小越好。
  - **定义与公式**：无可核验公式；作者以数值形式直接给出（页码：9-10）。
  - **来源层级**：无可核验公式。
  - **实验用途**：检验 SimAI-CP 与 SimAI-CP-Model 相对 ASTRA-sim（依赖 SCALE-sim）的精度。
  - **读数与边界**：SimAI-CP 偏差 0.5%-3.1%，SimAI-CP-Model 偏差 13%-15%；ASTRA-sim 总误差 H100 49.8%、A100 117.9%、H20 224%[实验支持，页码：9-10]；SimAI-CP-Model 误差集中在 Attention-QKV 与 MLP-linear 核函数，但具体分项误差[文中未说明]。

- **指标与方向**：多线程加速比（Speedup）。测量对象为仿真执行时间相对单线程/未去锁多线程版本的倍数，越大越好。
  - **定义与公式**：无可核验公式；仅给出倍数结果（页码：9）。
  - **来源层级**：无可核验公式。
  - **实验用途**：检验无锁化设计对仿真效率/可扩展性是否必要。
  - **读数与边界**：相对单线程提速 23 倍，相对多线程再提升 15%[实验支持，页码：9]；未说明该加速比是否随 GPU 规模变化而改变[文中未说明]。

### 8.4 主结果、消融与证据边界

**比较工作与被批判限制的呼应**

| 比较工作/基线 | 核心限制或失效条件 | 本文对应模块 | 直接实验与仍未验证的边界 |
|---|---|---|---|
| ASTRA-sim | 不支持多 GPU 类型、小消息与大规模场景严重失真（偏差达 204%~530%） | SimAI-CM/SimCCL | §4.2 图 6/7、§4.4 图 9 已验证；非 fat-tree 拓扑下是否仍成立未验证 |
| SCALE-sim（ASTRA-sim 计算组件） | 仅矩阵乘法核可运行，其余靠 FLOPS 比例换算 | SimAI-CP 细粒度操作库 + Roofline 迁移 | §4.3 图 8 已验证；分项 kernel 级误差未验证 |
| Chakra/GPGPU-Sim/Accel-Sim | 分别无法泛化新模型、耗时过长、框架版本过旧 | SimAI-WG / SimAI-CP | 论文未给出直接对比实验，无法从当前 OCR 内容确认 |

- 比较结果仅说明本文实验设置内谁表现更好，不能证明基线在所有场景下失效，尤其 Chakra/GPGPU-Sim/Accel-Sim 三项缺乏直接对比数据。
- ASTRA-sim 的失真在图 7 中被可视化为小消息区曲线分离，且随规模递增（128→1024 GPU）而扩大，与文字数据方向一致[实验支持，页码：9]。
- SimAI-CP-Model 相较 ASTRA-sim 更贴近真实值，但仍落后于 SimAI-CP 本身，符合作者自陈的 13%-15% 局限[作者明确陈述，页码：9]。

| 主张 | 直接证据（实验/表图） | 证据强度与边界 |
|---|---|---|
| SimAI 通信/计算仿真精度显著优于 ASTRA-sim/SCALE-sim | §4.2 图 6/7、§4.3 图 8 | 实验支持，覆盖 A100/H100/H20、128-1024 GPU；分项误差来源未逐一验证 |
| SimAI 端到端精度<4%，36.1倍优于ASTRA-sim | §4.4 图 9 | 实验支持，止于 1024 GPU；万卡级未测试 |
| 模型越大端到端精度越高（因通信消息更大） | §4.4 文字陈述 | 因果部分为作者基于 §4.2 结果的推断，未做单独消融隔离该变量 |
| 无锁化带来 23倍/15%加速 | §3.5 文字陈述 | 实验支持；未测试不同规模下是否稳定 |
| TP 组大小应匹配模型层而非主机 GPU 数 | §5.2 图 11 | 实验支持；该图本身不包含与真实硬件的精度校验，依赖读者已认可 SimAI 整体精度 |

## 9. 图表解读与论证关系

### 图片原件与标题

#### 原始图片 1：Figure 1: The SimAI architecture

![Figure 1: The SimAI architecture](assets/imgs/img_in_image_box_154_144_1063_356.jpg)

*来源：OCR 第 5 页。*

---

#### 原始图片 2：Figure 2: Demonstration of the dependencies among the algorithm submodules and the communication operations.

![Figure 2: Demonstration of the dependencies among the algorithm submodules and the communication operations.](assets/imgs/img_in_image_box_132_145_553_512.jpg)

*来源：OCR 第 6 页。*

---

#### 原始图片 3：Figure 3: Illustration of how SimAI transforms a collective communication operation to a list of peer-to-peer communication operations.

![Figure 3: Illustration of how SimAI transforms a collective communication operation to a list of peer-to-peer communication operations.](assets/imgs/img_in_image_box_634_408_1122_724.jpg)

*来源：OCR 第 7 页。*

---

#### 原始图片 4：Figure 4: Multi-thread implementation and optimization in SimAI.

![Figure 4: Multi-thread implementation and optimization in SimAI.](figure-groups/page-0008-707c3c78f92f.png)

*来源：OCR 第 8 页。*

---

#### 原始图片 5：Figure 5: Multi-rail network topology of cluster H100. For cluster A100, two GPUs share a single NIC

![Figure 5: Multi-rail network topology of cluster H100. For cluster A100, two GPUs share a single NIC](assets/imgs/img_in_image_box_129_142_564_283.jpg)

*来源：OCR 第 9 页。*

---

#### 原始图片 6：Figure 9: The iteration time of different workloads running on ASTRA-sim, SimAI, and real clusters.

![Figure 9: The iteration time of different workloads running on ASTRA-sim, SimAI, and real clusters.](assets/imgs/img_in_chart_box_632_140_1113_277.jpg)

*来源：OCR 第 10 页。*

---

#### 原始图片 7：Figure 7: Bus bandwidths of inter-host collective communication operations with different message sizes and cluster scales.

![Figure 7: Bus bandwidths of inter-host collective communication operations with different message sizes and cluster scales.](assets/imgs/img_in_chart_box_105_390_579_646.jpg)

*来源：OCR 第 10 页。*

---

#### 原始图片 8：Figure 8: The execution time of the computation kernels of GPT-3 175B on different GPUs.

![Figure 8: The execution time of the computation kernels of GPT-3 175B on different GPUs.](assets/imgs/img_in_chart_box_111_729_582_922.jpg)

*来源：OCR 第 10 页。*

---

#### 原始图片 9：Figure 6: Bus bandwidths of intra-host collective communication operations vary with different message sizes and GPU types. Note that the performance is not related to the cluster scales.

![Figure 6: Bus bandwidths of intra-host collective communication operations vary with different message sizes and GPU types. Note that the performance is not related to the cluster scales.](assets/imgs/img_in_chart_box_119_145_609_275.jpg)

*来源：OCR 第 10 页。*

---

#### 原始图片 10：Figure 10: The iteration time of GPT-3 175B with different network bandwidths.

![Figure 10: The iteration time of GPT-3 175B with different network bandwidths.](assets/imgs/img_in_chart_box_114_135_586_286.jpg)

*来源：OCR 第 11 页。*

---

#### 原始图片 11：Figure 11: Training performance of different hosts and different TP sizes. The x-axis denotes the number of GPUs in a single host. Because of the big model size and limited GPU memory, TP should be larger than 2 for GPT-3 13B and 4 for GPT-3 175B and LLaMA 65B. And we can not run TP = 64 or TP = 48 for GPT-3 175B because the TP size should be the factor of both the number of feedforward neural network (FNN) layers (96) and the world size (1024). We do not let TP exceed the number of GPUs in a single host as the RDMA network is the bottleneck.

![Figure 11: Training performance of different hosts and different TP sizes. The x-axis denotes the number of GPUs in a single host. Because of the big model size and limited GPU memory, TP should be larger than 2 for GPT-3 13B and 4 for GPT-3 175B and LLaMA 65B. And we can not run TP = 64 or TP = 48 for GPT-3 175B because the TP size should be the factor of both the number of feedforward neural network (FNN) layers (96) and the world size (1024). We do not let TP exceed the number of GPUs in a single host as the RDMA network is the bottleneck.](figure-groups/page-0012-712f1152cbf4.png)

*来源：OCR 第 12 页。*

### 图/表：图 1（SimAI 整体架构图）

- **图组结论**：展示 Input Description → Workload Generator → Execution Engine（计算/通信双通道经 Scheduler）→ Simulation Speedup 的完整流水线[页码：4-5]。
- **论证关系**：架构层面直观支撑"统一框架"设计主张，说明四项贡献模块如何组合成单一系统；不含任何精度或速度数值。
- **适用范围**：本图为机制示意，精度/速度数值需依赖图 6-9。

### 图/表：图 2（操作依赖关系图）

- **图组结论**：展示 Megatron 下 TP/DP/PP 三种并行的算法子模块与通信操作的阻塞/非阻塞依赖关系，标注 Attention Backward 与 AllReduce 可重叠[页码：5]。
- **论证关系**：为 SimAI-WG"生成与真实任务一致操作序列"的假设提供机制层面可视化支持；不含依赖关系与 1024-GPU Nsight Systems 实测结果吻合度的量化数据。
- **适用范围**：仅覆盖 Megatron 框架下的依赖示意，无进一步量化缺口。

### 图/表：SimCCL 服务流程图（第7页图1）

- **图组结论**：展示 AllReduce 调用经 NCCL Hack API 拦截与拓扑读取转换为 P2P 操作列表、再经 Map Database/Scheduler 输出至 SimAI-CM 的完整流程[页码：7-8]。
- **论证关系**：具体化"劫持真实 NCCL"的实现路径，解释 SimCCL 仅需修改 572 行代码的非侵入性；与 §4.2 精度数据互补而非重复。
- **适用范围**：架构示意图，不含精度数值。

### 图/表：多线程锁竞争对比图（第8页图2，Fig.4a/4b）

- **图组结论**：Panel(a)三线程共享一把锁访问同一全局变量表，Panel(b)线程各自独立访问专属分区，无锁图标[页码：8-9]。
- **论证关系**：可视化"瓶颈根源→解决方案"的机制变化，支撑无锁化设计合理性；不能证明 23 倍/15%加速的具体数值。
- **适用范围**：仅为机制对比，不含线程数量以外的实现细节。

### 图/表：多导轨网络拓扑图（第9页图1）

- **图组结论**：展示 Spine-Leaf-Server 三层多导轨拓扑，H100 NVLink 900GB/s/网络400Gbps，A100 600GB/s/200Gbps[页码：9]。
- **论证关系**：为 §4.2-4.4 精度对比提供物理拓扑基准，证明仿真与真实集群拓扑一致，从而使精度差异可归因于仿真方法本身。
- **适用范围**：精度主张仅在该多导轨 fat-tree、128 台主机规模下验证，非任意网络架构通用。

### 图/表：端到端迭代时间对比图（第10页图2，Fig.9）

- **图组结论**：6子面板（128/512/1024×H100/A100）中 SimAI 柱高与 Groundtruth 高度贴合，AstraSim 明显偏高[页码：9-10]。
- **论证关系**：直接支撑端到端精度<4%、36.1倍优于ASTRA-sim的量化主张；跨规模跨型号一致。
- **适用范围**：TP/DP/Computation 各分段贡献的精确数值无法从图像像素级读出，属基于视觉的谨慎推断而非精确验证。

### 图/表：跨机通信带宽对比图（第10页图1，Fig.7）

- **图组结论**：9子图中 SimAI 与 GroundTruth 几乎重合，AstraSim 在小消息区系统性偏高，且偏差随规模增大而扩大[页码：9]。
- **论证关系**：可视化验证"小消息场景 ASTRA-sim 严重失真"的批判，支撑 SimCCL 设计必要性。
- **适用范围**：图题未标注对应 A100 还是 H100 集群，与正文两组独立偏差数字的对应关系存在冲突未澄清[OCR/图题冲突]。

### 图/表：计算核函数执行时间对比图（第10页图2，Fig.8）

- **图组结论**：A100/H100/H20三组中 AstraSim 条形长度远超 GroundTruth，且差距随GPU组(A100→H100→H20)扩大[页码：9-10]。
- **论证关系**：定性支撑正文误差数字大小顺序（H100<A100<H20），验证 SimAI-CP-Model 更贴近真实值但仍逊于 SimAI-CP。
- **适用范围**：X轴时间单位未标注；A100组缺失 SimAI-CP-Model 数据原因[无法从当前 OCR 内容确认]。

### 图/表：intra-host通信带宽对比图（第11页图1，Fig.6）

- **图组结论**：三种通信操作中 SimAI 与 GroundTruth 高度重合，AstraSim 在小消息区明显偏离[页码：9]。
- **论证关系**：可视化支撑 A100/H100 上 3.9% vs 74.8%、2.3% vs 51.7% 的量化结论。
- **适用范围**：H100_Ring曲线含义未说明；部分纵轴刻度因分辨率无法精确读出。

### 图/表：生产案例带宽选型图（第11页图2）

- **图组结论**：H100/H20两子图中带宽从100G→400G带来E2E时长下降，SimAI/SimAI-Model与GroundTruth高度贴近[页码：10-11]。
- **论证关系**：支撑§5.1中19%/11%/6%性能提升的量化主张，及SimAI-CP-Model作为未发布GPU替代方案的适用性。
- **适用范围**："No_Comp"段含义未说明；精确数值刻度受分辨率限制无法逐一读出。

### 图/表：TP组大小敏感性图（第12页图1，Fig.11）

- **图组结论**：三个Panel显示中间TP值表现最优，过大TP导致性能明显变差，即使GPU数增加[页码：11-12]。
- **论证关系**：直接支撑"TP应匹配模型层而非简单等于主机GPU数"的必要性主张。
- **适用范围**：该图本身不含与真实硬件的精度校验，其可信度依赖于读者已接受SimAI整体精度这一前提[文中未说明是否单独验证]。

## 10. 完整因果推理树

- 根问题：LLM训练GPU需求巨大，新设计/调优难以在真实硬件上低成本验证，且容量规划与性能调优所需仿真粒度历史上分裂[页码：2]
  - 旧方法限制：ASTRA-sim/SCALE-sim精度不足或速度过慢，GPGPU-Sim/Accel-Sim/Chakra各有泛化或效率缺陷[页码：4]
  - 核心洞见/假设：劫持真实训练框架、通信库与实测算子数据而非从零建模，可继承真实系统精度并只承担单机成本[页码：3, 5, 7]
    - 方法模块：SimAI-WG / SimAI-CP / SimAI-CM-SimCCL / 无锁多线程加速[页码：4-9]
      - 可验证预测：仿真结果应在通信、计算、端到端三个层面均显著逼近真实硬件，且能扩展至千卡级规模
        - 指标与实验：§4.2通信偏差、§4.3计算偏差、§4.4端到端偏差、§3.5加速比[页码：9-10]
          - 图表证据：图6/7/8/9及生产案例图（第10-11页）[实验支持]
            - 结论与适用边界：精度主张在1024 GPU、H100/A100多导轨拓扑、Megatron/DeepSpeed框架内已验证；万卡级规模、非fat-tree拓扑、EP门控假设的量化偏差未被当前证据直接验证[页码：8-9]

## 11. 结论、贡献与边界

**贡献总结**：SimAI-WG（工作负载生成）、SimAI-CP（计算仿真+未发布GPU迁移）、SimAI-CM/SimCCL（通信仿真）、无锁多线程加速四项，均为论文明确提出且可对应到具体解决的挑战与实验[作者明确陈述，页码：3-9]。

**证据充分的结论**：通信/计算/端到端仿真精度显著优于ASTRA-sim/SCALE-sim，且在128-1024 GPU、A100/H100/H20多种配置下一致成立[实验支持，页码：9-10]；无锁化带来23倍加速[实验支持，页码：9]。

**尚属推断的意义**：模型越大端到端精度越高是因通信消息更大更易精确仿真，此为作者自身推断而非独立消融验证[基于文中逻辑的推断，页码：10]；TP组大小应匹配模型层的结论依赖读者预先接受SimAI整体精度这一前提[基于文中逻辑的推断，页码：11-12]。

**适用条件与局限**：验证规模上限为1024 GPU[实验支持，页码：9]；仅支持Megatron与DeepSpeed两个框架[文中未说明其他框架支持情况，页码：5]；SimCCL不做真实数据完整性校验，EP门控均衡分布假设未量化验证[作者明确陈述，页码：8]；SimAI-CP-Model偏差13%-15%，作者建议仅在无法获取真实GPU时使用[作者明确陈述，页码：9]；故障仿真为未来工作，非当前贡献[作者明确陈述，页码：13]。

**审稿式风险检查**：
- 贡献新意：论文自陈受ASTRA-sim启发，新意限于工作负载生成、计算/通信保真度、可扩展性三方面改进，非全新范式[作者明确陈述，页码：13]，当前证据未显示夸大新意的风险。
- 写作/可复现性：代码已开源（GitHub链接），但摘要"98.1%"与正文"1.9%/3.9%"两套数字未说明换算关系，存在表述不统一的风险[文中未说明，页码：2-3, 9]。
- 效果大小：主要精度对比均有具体数值支撑，当前证据未显示效果被夸大的风险。
- 实验覆盖：未测试超过1024 GPU的规模，也未提供更多未发布GPU的事后验证案例（仅H100/H20两例），样本量有限的风险确实存在[页码：9, 11]。
- 方法设计：EP门控均衡分布假设、通信数据完整性未校验均为作者自陈但未量化的简化，存在未被证据覆盖的动态行为风险[作者明确陈述，页码：8]。

## 12. 术语与第一性原理学习路径

### 12.1 核心术语

- **术语**：集合通信（Collective Communication，如AllReduce/AllGather/ReduceScatter）。多GPU间需要"对齐信息"的通信模式。
  - **第一性原理角色**：连接"各卡局部计算结果"与"全局一致模型参数"这两个基本量，受网络带宽与拓扑约束。
  - **本文位置**：是SimCCL仿真的核心对象，直接决定通信仿真精度指标[页码：7-9]。

- **术语**：NCCL。NVIDIA提供的GPU间集合通信优化软件库。
  - **第一性原理角色**：在硬件拓扑约束下选择通信算法（如ring/tree），是通信延迟的决定因素之一。
  - **本文位置**：SimCCL通过劫持NCCL关键函数复现其算法选择逻辑[页码：7-8]。

- **术语**：Roofline模型。判断程序性能瓶颈在"计算能力"还是"内存带宽"的分析框架[背景知识]。
  - **第一性原理角色**：连接"算子的计算量/访存量比值"与"硬件峰值算力/带宽"两个基本量，决定该算子的理论执行时间上界。
  - **本文位置**：SimAI-CP-Model用其将已知GPU实测数据迁移到未发布GPU[页码：6-7]。

- **术语**：离散事件仿真（DES）。按事件发生时刻跳跃式推进的仿真方法，而非逐微秒推进[背景知识]。
  - **第一性原理角色**：以"事件"而非"时间步"为基本状态更新单元，在稀疏事件场景下大幅降低计算量。
  - **本文位置**：SimAI的执行引擎基于UNISON（NS-3上的并行DES框架）[页码：8-9]。

- **术语**：张量并行（TP，Tensor Parallelism）。把单层模型计算拆分到多张GPU上并行执行。
  - **第一性原理角色**：受模型层内维度（如注意力头数）与主机内互联带宽（NVLink）双重约束。
  - **本文位置**：§5.2实验的核心变量，TP组大小与模型层结构、主机GPU数共同决定性能[页码：11-12]。

- **术语**：Roofline式核函数分类（计算密集型/内存带宽密集型）。将GPU算子按其瓶颈来源二分类。
  - **第一性原理角色**：分类依据是算子的算术强度（计算量/数据搬运量）与硬件算力-带宽比的相对关系。
  - **本文位置**：SimAI-CP-Model迁移公式的分类前提[页码：6-7]。

- **术语**：FlowModel。SimCCL输出的、记录数据量、发送/接收rank、路由信息的点对点操作描述。
  - **第一性原理角色**：是集合通信操作分解到底层网络流的最小可仿真单元。
  - **本文位置**：SimAI-CM据此计算最终通信耗时[页码：7-8]。

- **术语**：无锁化（Lock-free）设计。避免多线程访问共享资源时使用互斥锁的编程方式[背景知识]。
  - **第一性原理角色**：把"共享全局状态"改造为"线程私有状态+按ID隔离"，从根本上消除锁竞争这一并发瓶颈。
  - **本文位置**：SimAI多线程加速的关键机制，带来23倍加速[页码：8-9]。

### 12.2 学习路径

1. **GPU并行策略（DP/TP/PP）**：先理解模型如何被拆分到多卡协同训练，是理解SimAI-WG生成workload的前提。
2. **集合通信与NCCL**：理解多卡间"对齐信息"的通信模式与其底层软件库，是理解SimCCL劫持机制的基础。
3. **Roofline模型**：理解"计算瓶颈vs带宽瓶颈"的判断逻辑，是理解SimAI-CP-Model迁移公式的前提。
4. **离散事件仿真**：理解事件驱动而非时间步驱动的仿真范式，是理解SimAI效率优化（多线程/无锁化）动机的基础。
5. **网络拓扑（Spine-Leaf、NVLink/PCIe/RDMA）**：理解intra-host与inter-host两类通信路径的物理差异，是理解通信精度实验分组设计的前提。

---

*本报告由 paper-pipeline 生成 · prompt `v11` · backend `cli_agent` · model `claude-sonnet-5` · 2026-07-26T11:41:34*
