# 图片批次 4

## 图片 1：Figure 7: Bus bandwidths of inter-host collective communication operations with different message sizes and cluster scales.

![Figure 7: Bus bandwidths of inter-host collective communication operations with different message sizes and cluster scales.](../assets/imgs/img_in_chart_box_105_390_579_646.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：证据类型为**实验结论**兼**对比基线**。该图针对 §4.2 通信仿真精度实验，回答"SimAI 的跨机（inter-host）集合通信仿真精度是否显著优于 ASTRA-sim，且随消息大小与集群规模变化时是否保持稳定"这一具体问题，对应主张地图中"SimAI 通信仿真精度显著优于 ASTRA-sim"[实验支持]，以及对 ASTRA-sim 的具体批判"小消息、大规模场景下偏差可达 204%~530%"（页码9）。**图表角色**：实验结论 + 对比基线。**上文呼应**：第 4.2 节"Precision of Communication Simulation"，图注对应正文"Figure 7: Bus bandwidths of inter-host collective communication operations with different message sizes and cluster scales"。[正文支持]

2. **图像类型与布局**：3×3 网格折线/散点图。行分组为集群规模（128 / 512 / 1024 GPUs，自上而下），列分组为通信操作类型（Allreduce / Allgather / ReduceScatter）。每个子图内三条曲线：蓝色 AstraSim、橙色 SimAI、绿色虚线 GroundTruth。

3. **如何阅读**：X 轴为 Data Size（MB，对数刻度，8–8192），Y 轴为 Bus Bandwidth（GB/s，0–50 区间）。应在每个子图内比较三条曲线与绿色虚线（GroundTruth）的贴合程度，重点关注小消息区（左侧）曲线分离程度，并纵向比较同一列在不同行（规模增大）下曲线分离是否加剧。

4. **直接可见的结论**：所有九个子图中，SimAI（橙）与 GroundTruth（绿虚线）几乎完全重合，尤其从约 32MB 以上两者不可区分；AstraSim（蓝）在小消息区（8–64MB）系统性高于 GroundTruth，形成明显差距。随着行从 128 GPU 到 1024 GPU 递增，AstraSim 与 GroundTruth 之间在中小消息区的纵向差距随之扩大（1024 GPU 行中该差距最为显著）。Allreduce/Allgather/ReduceScatter 三列呈现相似的分离模式。[图像直接可见]

5. **它验证的论点与方法设计含义**：证据类型为效果主张 + 对比基线批判。该图直接支持"SimAI 通信仿真精度显著优于 ASTRA-sim"的效果主张，并将正文中"ASTRA-sim 偏差随消息增大与规模扩大而恶化"（如 128 GPU 时 45.9%，512 GPU 时升至 530.2%）的文字描述可视化为曲线分离随规模行递增而扩大的现象。这也具体验证了论文对 ASTRA-sim 的批判——"小消息场景严重失真（不模拟 libibverbs 及 NIC pipeline）"——图中可见小消息区正是三条曲线分离最明显的位置。方法设计含义：该证据支持 SimAI 选择"劫持"真实 NCCL（SimCCL）而非从零重建集合通信算法逻辑，因为图中显示从零建模（ASTRA-sim）无法复现 NCCL 在不同消息大小/规模下的真实算法选择行为。该图不能证明：AstraSim 失真的具体软件原因（libibverbs、NIC pipeline 未仿真）是正文陈述而非图像本身可验证的内容；图像本身也不能证明该结论在非 fat-tree/RoCEv2 拓扑下同样成立。[正文支持]

6. **适用范围与证据缺口**：本图覆盖论文报告的 inter-host 场景，128/512/1024 GPU 规模，8MB–8GB 消息范围，Allreduce/Allgather/ReduceScatter 三种操作。真实缺口：图题及图像本身均未标注该图对应 A100 集群还是 H100 集群（正文 §4.2 分别给出了 A100 与 H100 两组偏差数字，3.9%/74.8% 与 2.3%/51.7%，但图 7 本身无 GPU 型号标注），故无法从当前图像内容判断该 3×3 网格具体对应哪一个测试床——[OCR/图题冲突]。

---

## 图片 2：Figure 8: The execution time of the computation kernels of GPT-3 175B on different GPUs.

![Figure 8: The execution time of the computation kernels of GPT-3 175B on different GPUs.](../assets/imgs/img_in_chart_box_111_729_582_922.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：证据类型为**实验结论** + **对比基线** + **适用边界**。该图针对 §4.3 计算仿真精度实验，回答"SimAI-CP（及面向未发布 GPU 的 SimAI-CP-Model）在模拟 GPT-3 175B 计算 kernel 执行时间上，相较 AstraSim（依赖 SCALE-sim）在 A100/H100/H20 三种 GPU 上的精度差异"这一问题，对应主张地图中"SimAI 计算仿真精度显著优于 ASTRA-sim/SCALE-sim"[实验支持]与"SimAI-CP-Model 可作为未发布 GPU 的可行替代方案"[作者明确陈述]两条主张。**图表角色**：实验结论 + 对比基线 + 适用边界。**上文呼应**：第 4.3 节"Precision of Computation Simulation"，对应图注"Figure 8: The execution time of the computation kernels of GPT-3 175B on different GPUs"。[正文支持]

2. **图像类型与布局**：水平堆叠条形图，按 GPU 类型分为三组（A100、H100、H20，自上而下）。A100 组含 GroundTruth、SimAI-CP、AstraSim 三根条；H100 与 H20 组各含 GroundTruth、SimAI-CP、SimAI-CP-Model、AstraSim 四根条。每根条形按颜色分段堆叠，代表不同计算子模块/kernel（对应 Table 1 中的 Embedding、Layernorm、Attention_QKV、Core_attention、Attention_linear、Mlp_linear_4h、GeLU/Swiglu、Mlp_linear_h、Logits_parallel、Grad_param 等类别）对总执行时间的贡献。

3. **如何阅读**：X 轴为执行时间（数值范围约 0–300000+，单位未在图上或正文中标注），Y 轴为 GPU 类型分组。应在同一 GPU 组内比较各条形的总长度（代表总执行时间）以判断整体精度，并比较各颜色分段长度以判断各 kernel 层面的偏差来源；核心比较对象是每组内 AstraSim/SimAI-CP/SimAI-CP-Model 条形相对 GroundTruth 条形的长度差。

4. **直接可见的结论**：A100 组中 GroundTruth 与 SimAI-CP 总长度接近，AstraSim 条形明显更长，其黄色段（对应 Mlp_linear_4h/Mlp_linear_h 一类）比例可见地被拉长。H100 组中 GroundTruth、SimAI-CP、SimAI-CP-Model 三者总长度彼此接近，AstraSim 条形显著更长。H20 组中 GroundTruth 与 SimAI-CP 总长度接近且最短，SimAI-CP-Model 略长于二者，AstraSim 条形远超其余各条、长度逼近或超出图表右边界，是三组中 AstraSim 与 GroundTruth 差距最悬殊的一组。跨 A100→H100→H20，AstraSim 条形相对 GroundTruth 的绝对长度差依次扩大。[图像直接可见]

5. **它验证的论点与方法设计含义**：图直接支持"SimAI 计算仿真精度显著优于 ASTRA-sim/SCALE-sim"的效果主张，将正文数值（AstraSim 总误差 H100 49.8%、A100 117.9%、H20 224%）可视化为条形长度差距，且该差距在图中随 GPU 组（A100→H100→H20）扩大的趋势与正文误差数字的大小顺序（H100<A100<H20）定性吻合[正文支持]。该图同时纳入 SimAI-CP-Model 一栏（仅 H100/H20 组出现），可视化验证了"SimAI-CP-Model 可作为未发布 GPU 替代方案"这一适用边界主张——其条形明显比 AstraSim 更贴近 GroundTruth，但仍略长于 SimAI-CP，与正文自陈的 13%–15% 偏差局限一致。方法设计含义：AstraSim/SCALE-sim 的误差被正文归因于"只能成功运行矩阵乘法核、其余核靠 FLOPS 比例换算"，该图中 AstraSim 条形黄色段比例的失真为此提供了间接可视化佐证，支持 SimAI 选择"细粒度 kernel 实测数据库 + Roofline 分类迁移"而非"整体 FLOPS 缩放"的设计动机。该图不能证明：正文所称 SimAI-CP-Model 误差集中在 Attention-QKV 与 MLP-linear 两类 kernel 的具体量化差异，因为图中各颜色段边界较细，无法逐段精确读出各 kernel 的独立误差数值。[正文支持]

6. **适用范围与证据缺口**：本图覆盖论文报告的 GPT-3 175B 模型在 A100/H100/H20 三种 GPU 上的计算 kernel 执行时间对比（§4.3），且 AstraSim 数据仅包含 SCALE-sim 可运行的矩阵乘法核（按 Nvidia/TPU 有效 FLOPS 比例换算得到，正文已说明此局限）。真实缺口：X 轴数值的时间单位在图像与正文中均未标注，无法确认执行时间的具体量纲（μs/ms）；此外 A100 组条形中不含 SimAI-CP-Model 分段，此为图像直接可见的事实，但正文未说明 A100 组是否曾测试 SimAI-CP-Model 或为何缺失该数据——[无法从当前 OCR 内容确认]。
