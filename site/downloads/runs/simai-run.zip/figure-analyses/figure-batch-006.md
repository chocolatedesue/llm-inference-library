# 图片批次 6

## 图片 1：Figure 11: Training performance of different hosts and different TP sizes. The x-axis denotes the number of GPUs in a single host. Because of the big model size and limited GPU memory, TP should be larger than 2 for GPT-3 13B and 4 for GPT-3 175B and LLaMA 65B. And we can not run TP = 64 or TP = 48 for GPT-3 175B because the TP size should be the factor of both the number of feedforward neural network (FNN) layers (96) and the world size (1024). We do not let TP exceed the number of GPUs in a single host as the RDMA network is the bottleneck.

![Figure 11: Training performance of different hosts and different TP sizes. The x-axis denotes the number of GPUs in a single host. Because of the big model size and limited GPU memory, TP should be larger than 2 for GPT-3 13B and 4 for GPT-3 175B and LLaMA 65B. And we can not run TP = 64 or TP = 48 for GPT-3 175B because the TP size should be the factor of both the number of feedforward neural network (FNN) layers (96) and the world size (1024). We do not let TP exceed the number of GPUs in a single host as the RDMA network is the bottleneck.](../figure-groups/page-0012-712f1152cbf4.png)

*来源：OCR 第 12 页。*

### 解读

1. **论文角色与验证问题**：这是 Figure 11（(a) GPT-3 13B、(b) GPT-3 175B、(c) LLaMA 65B 三个 Panel 构成的同一图表组，不可拆分），对应第 5.2 节"Quantifying Scaling-up Benefits"。其证据类型为**实验结论**（兼具参数敏感性/消融特征）：作者用 SimAI 自身在 8/16/32/64 GPU 主机配置下扫描不同 TP（张量并行）组大小，试图验证正文提出的具体主张——"TP 组大小应与模型层结构匹配，而非简单等于主机内 GPU 数""GPU 数增加不必然带来性能提升，若 TP 设置不当反而会下降"[正文支持]。
   - **图表角色**：实验结论（参数敏感性验证）。
   - **上文呼应**：对应主张地图中"TP（张量并行）组大小应与实际模型层匹配，而非简单等于主机内 GPU 数"（必要性，§5.2，页码 11）。

2. **图像类型与布局**：三组分组柱状图（Panel 1/2/3），每组内部再分为"H100 Cluster"（上）与"H20 Cluster"（下）两个子图，y 轴均为 Norm. Iteration time（0–1.0）。Panel 1（对应 (a) GPT-3 13B）x 轴只有单一分组"8GPUs"，含 2 根柱（橙色、蓝色）；Panel 2（对应 (b) GPT-3 175B）x 轴为 8/16/32/64GPUs 四组，每组柱数随 GPU 数递增（1→2→3→3 根）；Panel 3（对应 (c) LLaMA 65B）x 轴为 8/16/32GPUs 三组，每组柱数递增（2→3→4 根），并附带唯一图例：橙=TP=4，蓝=TP=8，绿=TP=16，粉=TP=32，青=TP=64。

3. **如何阅读**：x 轴为单主机内 GPU 数量（对应主机内互联规模），柱子颜色区分 TP 组大小，y 轴为归一化迭代时间（数值越低代表训练越快、性能越好）。应比较：同一 GPU 数下不同颜色柱子的高低（TP 选择的影响），以及同一颜色（同一 TP）柱子随 GPU 数增加时的变化趋势（规模扩展收益）。图例仅出现在 Panel 3，但颜色编码在三个 Panel 中一致[基于视觉的谨慎推断]。

4. **直接可见的结论**：
   - Panel 1（GPT-3 13B）：在 8GPUs 主机上，TP=4（橙）明显低于 TP=8（蓝），即 TP=4 迭代时间更短[图像直接可见]。
   - Panel 2（GPT-3 175B）：同一 TP（如 TP=8，蓝）柱高随 GPU 数从 8→64 递增而持续下降；64GPUs 分组中未出现 TP=64（青）柱子，只有 TP=8/16/32 三根[图像直接可见]。
   - Panel 2：32GPUs 分组中 TP=32（粉）柱明显高于同组的 TP=8/16 柱，即 GPU 数增至 32 但选用过大 TP 时性能反而变差[图像直接可见]。
   - Panel 3（LLaMA 65B）：x 轴最大只到 32GPUs（无 64GPUs 分组），且 32GPUs 分组出现 TP=64（青）柱且为该组最高（最差）[图像直接可见]。
   - 三个 Panel 中，各分组内柱子高度并非随 TP 增大单调上升或下降，而是存在中间 TP 值表现最优、过大 TP 明显更差的模式[图像直接可见]。

5. **它验证的论点与方法设计含义**：本图直接支撑正文§5.2 三条要点性主张（必要性类）：(1) "8-GPU 主机上 GPT-3 13B 最优 TP=4"——由 Panel 1 中 TP=4 柱低于 TP=8 柱可见证实[正文支持][图像直接可见]；(2) "同一 TP 下 GPU 数越多性能越好"——由 Panel 2/3 中同色柱随 x 轴右移持续走低可见证实[正文支持][图像直接可见]；(3) "GPU 数增加但 TP 不合适时性能仍会下降"——由 Panel 2 中 32GPUs 分组 TP=32 柱高于同组更小 TP 柱、以及 Panel 3 中 32GPUs 分组 TP=64 柱为组内最高可见证实[正文支持][图像直接可见]。这为方法设计含义提供依据：生产环境中主机内 GPU 数（决定可用 TP 上限）应基于模型层结构（如 175B 的 96 层限制 TP 不能取 64/48）来设计，而非简单让 TP 等于主机内 GPU 数，呼应正文两条设计准则（TP 应贴合模型层、主机 GPU 数应服务于 scale-out 而非一味扩大 TP）[正文支持]。需要注意：该图本身**不**证明 SimAI 模拟结果与真实硬件的一致性（那是 §4.4 图 9 的任务），此图的可信度依赖于读者已经接受 SimAI 模拟精度这一前提，本图只回答"在 SimAI 模拟下，TP/GPU 数如何影响性能"这一参数敏感性问题，不能单独作为精度证据使用。

6. **适用范围与证据缺口**：本图覆盖论文报告的设置——三个代表性模型（GPT-3 13B、GPT-3 175B、LLaMA 65B），主机内 GPU 数 8/16/32/64（NVSwitch 互联），TP 取值 4/8/16/32/64（受模型层数与主机 GPU 数上限约束，如 175B 不可取 TP=64/48），H100 与 H20 两种集群[正文支持]。正文与图注均未说明本图（Figure 11）的模拟结果是否与真实硬件迭代时间做过对照验证——§5.2 全文只描述"我们在 SimAI 内进行了全面模拟"并据此得出生产准则，未像§4.4（图9）那样给出与真实集群的偏差数值——[文中未说明]，故本图证据链依赖于读者已认可 SimAI 整体精度（图6-9），其自身不含独立的真实性校验。
