# 图片批次 1

## 图片 1：Figure 1: The SimAI architecture

![Figure 1: The SimAI architecture](../assets/imgs/img_in_image_box_154_144_1063_356.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：这是全文首个架构总览图，用于让读者在阅读 §3 各模块细节前先建立整体流水线认知。它对应根问题"多套不同粒度模拟器分裂"与核心贡献"统一化框架"——图示展示 Input Description → Workload Generator（SimAI-WG）→ Execution Engine（SimAI-CP 计算模拟器 + SimAI-CM 通信模拟器，经 Scheduler 调度）→ Simulation Speedup 的完整链路，是"方法流水线"类证据，说明四大贡献模块（SimAI-WG、SimAI-CP、SimAI-CM、多线程加速）如何组合成一个单一系统，而非展示某项具体实验数值。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：对应 §3.1 "SimAI Overview" 及正文第 3 段"Figure 1 illustrates the key components of SimAI"[页码：4-5]，是贡献边界表中四项核心贡献（SimAI-WG、SimAI-CP、SimAI-CM/SimCCL、多线程加速）在架构图上的具象化呈现。

2. **图像类型与布局**：示意图（架构框图），横向分为四个虚线框区块：左侧"Input Description"（模型参数、框架参数、xCCL 参数、集群拓扑图标），第二区块"Workload Generator §3.2"（内含 Module→SubModule 转换，LLM 结构：Loss/Transformer×N/Embedding，右侧展开为 Self-Attention/TP Comm/MLP/PP Comm/DP Comm），第三区块（绿色虚线框）"Execution Engine"内并列两个子模块：上方绿色框"Computation Simulator §3.3"（GEMM/LayerN/GeLU 汇入 Computation Kernel 图标）与下方蓝色框"Communication Simulator §3.4"（AllReduce/P2P/P2P 汇入 Send/Recv 图标），中间由"Scheduler"图标连接两者；最右侧独立区块"Simulation Speedup"配多线程/文档图标。区块间以实心箭头连接，表示数据流向。

3. **如何阅读**：整体按从左到右的流水线顺序阅读：输入→工作负载生成→执行引擎（计算/通信双通道经调度器协同）→加速输出。各区块标题旁标注对应章节号（§3.2/§3.3/§3.4/§3.5），可用于定位图中每个框对应正文哪一节的详细描述；框内文字为具体操作/算子名称，不代表数值或坐标轴。

4. **直接可见的结论**：图中显式展示计算模拟器与通信模拟器是并列的两条独立通道，由同一个 Scheduler 统一调度后再汇入下游模块；Workload Generator 的输出（Self-Attention/TP Comm/MLP/PP Comm/DP Comm 等子模块序列）同时作为计算与通信模拟器的输入来源。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于机制类证据，直观支撑论文"统一框架"的核心设计主张——即通过单一 Workload Generator 产出的描述文件同时驱动计算与通信两个独立仿真通道，并由 Scheduler 协同，从而在架构层面实现"容量规划"与"性能调优"需求的合并，呼应贡献边界中"新意在于工作负载生成、计算/通信高保真、以及可扩展性三方面改进"的表述[正文支持]。但该图本身不能证明任何精度或速度数值（如 1.9% 偏差、23 倍加速），这些需依赖后续实验图（图 6-9）。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文所述 SimAI 整体架构设计，涵盖 Megatron/DeepSpeed 框架劫持、计算/通信双模拟器与调度器的组织关系；无额外证据缺口。

---

## 图片 2：Figure 2: Demonstration of the dependencies among the algorithm submodules and the communication operations.

![Figure 2: Demonstration of the dependencies among the algorithm submodules and the communication operations.](../assets/imgs/img_in_image_box_132_145_553_512.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：该图针对 SimAI-WG 模块中"操作依赖关系（operation dependencies）"这一具体设计问题，展示训练框架中 TP/DP/PP 三种并行策略下算法子模块与通信操作之间的执行顺序及重叠关系，是"方法流水线"（更细粒度地说，是机制类证据），用于解释 workload 描述文件为何需要显式编码依赖信息，而不是单纯罗列操作序列。`[正文支持]`
   - **图表角色**：方法流水线（机制）
   - **上文呼应**：对应 §3.2.1 "Defining operation dependencies"，正文明确说明"Dependencies are determined based on the parallelization framework used and are validated using Nvidia Nsight Systems on a 1,024-GPU cluster"[页码：5]，及"the MLPbackward submodule starts only after the Attentionbackward submodule and the AllReduce operation are complete"[页码：5]。

2. **图像类型与布局**：示意图（依赖关系流程图），纵向分为上下两大灰色虚线区域"Layer N Forward"（顶部省略号，表示重复层）与主体的"Layer 0 Forward"/"Layer 0 Backward"两个白色圆角框，右侧还有一个缩略的"Same to Left"灰色区域表示对称重复结构。Forward 区域内含 Attention Forward → AllReduce（伴随"Sync Activation"标注）→ MLP Forward → AllReduce；Backward 区域内含 Attention Backward → AllReduce（伴随红框"TP Comm"标注及"Can Overlap"标注）→ MLP Backward，再经 Update Weight/ReduceScatter（"Sync Grads"）/Update Params/AllGather（"Gather Params"）。左侧另有 Data0/Full Model 图标，通过 Send/Recv（紫色）连接到 Forward 与 Backward 区块。右上角图例说明三种箭头（实心箭头=Bloking Dependency，虚线箭头=Nobloking Dependency，双向虚线箭头=Communication）及三色标签框（红=TP Comm，蓝=DP Comm，紫=PP Comm）。

3. **如何阅读**：应按图例先区分三类箭头（阻塞依赖/非阻塞依赖/通信）与三种通信类型颜色编码（TP/DP/PP），再沿纵向顺序追踪 Forward→Backward→Update 的执行流，重点关注标注"Can Overlap"处（Attention Backward 与 AllReduce 之间）与"Sync Activation"/"Sync Grads"/"Gather Params"等标签，判断哪些操作是严格顺序依赖、哪些可以并行重叠。

4. **直接可见的结论**：图中显式标出 MLP Backward 与其上游的 Attention Backward、AllReduce（TP Comm）之间为非阻塞（虚线）"Can Overlap"关系，而 Forward 阶段的子模块转换（如 Attention Forward→AllReduce→MLP Forward）多以实心箭头连接表示阻塞依赖；PP Comm（紫色 Send/Recv）连接左侧 Full Model 与 Layer 0 Forward/Backward 区块，DP Comm（蓝色）体现在底部 ReduceScatter/AllGather 环节，TP Comm（红色）体现在层内 AllReduce。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：这是机制类证据，直接支撑正文"Megatron's attention and MLP backward phases benefit from overlapping optimizations"的具体说法[正文支持]——图像可见的"Can Overlap"虚线标注正是该重叠优化在依赖图中的呈现，证明 workload 描述文件必须携带此类细粒度的阻塞/非阻塞标记，否则会退化为无重叠信息的粗粒度序列，无法精确复现真实训练中的计算-通信重叠行为。这为 SimAI-WG"生成与真实任务一致的操作序列"这一假设（对应论文核心洞见的假设 1）提供了具体机制层面的可视化支持，但该图本身不包含时间/性能数值，因此不能用来验证依赖关系标注的"精度"（即该依赖图与 1024-GPU Nsight Systems 实测结果的吻合程度），这部分数值验证正文亦未单独给出量化实验。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖的是 Megatron 框架下 TP+DP+PP 混合并行策略的依赖关系示意（据正文，该依赖关系已用 Nvidia Nsight Systems 在 1024-GPU 集群上验证，但验证的量化结果未在文中单独报告）。图中未标注具体的通信量、时间刻度或消息大小信息，属于图像裁剪/设计本身即为示意性质，非数值图表，故此处无进一步可提取的缺口；无额外证据缺口。
