# 图片批次 2

## 图片 1：Figure 3: Illustration of how SimAI transforms a collective communication operation to a list of peer-to-peer communication operations.

![Figure 3: Illustration of how SimAI transforms a collective communication operation to a list of peer-to-peer communication operations.](../assets/imgs/img_in_image_box_634_408_1122_724.jpg)

*来源：OCR 第 7 页。*

### 解读

1. **论文角色与验证问题**：这张图对应正文 §3.4（Precise Simulation of Communication）中 SimCCL 五个步骤的机制描述——NCCL 初始化拦截、拓扑发现、channel 创建、集合通信到点对点通信的转换。图表角色为**方法流水线**：它把文字描述的"劫持 NCCL 关键流程"过程可视化为一个完整数据流，回答的是"SimAI-CM/SimCCL 具体如何把一次 AllReduce 调用转换为可仿真的 P2P 操作列表"这一机制问题，而非展示某个实验结果。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：对应"方法推理树·模块三：SimAI-CM / SimCCL（通信模拟器）"中的输入/过程/输出描述，以及 §3.4 正文五步骤（NCCL Initialization → Topology Discovery → Intra-Host Channel → Inter-Host Channel → Collective Communication Transformation）。

2. **图像类型与布局**：单幅流程/架构示意图（非多 Panel），非表格。顶部两个输入框("AllReduce (size, group...)"与"Cluster Description, NCCL Envs")指向中部一个大虚线框标注"SimCCL Service"，内部再分两个子虚线区块："NCCL Hack API"（含 ncclCommInitAll、ncclAllGather 等函数框，并通过 dlopen 指向 libhacknccl.so）与"NCCL Init"（含 Graph Search、Channel Connect、Algo Tuning 三个标签及 ring/tree 拓扑图标）；中部还有 GenerateFlowModel、ConfigInit 两个处理框，并标注"No Init"/"Server Topo Simulation"/"If Group have Initialized"等条件分支箭头及 topo.xml 图标。下方是一张"List of P2P Ops"表格（列：ID、parent、src、dst、Byte、channel、type、op，含若干示例行如 nvlink、mlx2、mlx1、reduce）。最底部是三个串联框：Map Database → Scheduler → SimAI-CM，末端接一个时钟图标。

3. **如何阅读**：整体应按从上到下、从输入到输出的顺序阅读——顶部两个输入决定进入 SimCCL Service 的两条路径（一条走 ConfigInit/topo 模拟,一条走 NCCL Hack API 的函数拦截），中间的虚线框和箭头表示控制流/条件分支（如"No Init"表示跳过真实初始化)，下方表格是该流程的中间产物（P2P 操作列表），最后三个框表示该列表如何被 SimAI-CM 消费并输出通信耗时。图例主要靠框内文字与图标（锁形拓扑图、树/环形拓扑图）区分,而非颜色编码。

4. **直接可见的结论**：图中显示一次集合通信调用（AllReduce）与拓扑/环境配置共同进入一个统一的"SimCCL Service"模块，该模块通过挂钩 NCCL API（并经 dlopen 载入 libhacknccl.so）和读取拓扑（topo.xml）两条路径生成通信拓扑信息，最终产出一张包含 src/dst/channel/type/op 字段的点对点操作列表，再经 Map Database 与 Scheduler 送入 SimAI-CM 计算最终通信时间。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图属于**机制**类证据，具体化了"论文核心洞见"中"劫持真实 NCCL 而非从零建模集合通信"的实现路径——图中明确显示 NCCL 的关键函数（ncclCommInitAll、ncclAllGather 等）被 Hack API 拦截、拓扑信息来自用户指定的 topo.xml 而非真实 PCIe 搜索，这与正文 §3.4 所述"SimCCL 拦截 NcclCommInitAll""读取用户指定拓扑文件"等步骤逐一对应，从视觉上支持了"SimCCL 通过挂钩而非重写实现高保真通信仿真"这一方法设计主张。它同时解释了为什么该模块能保持"仅需修改 572 行 NCCL 代码"的非侵入性（图中 Hack API 与真实 NCCL 代码路径是分离挂钩关系，而非替换实现）。该图本身不能证明这种设计带来的精度提升数值（如 3.9% vs 74.8% 的偏差对比），精度数据由 §4.2 图 6/7 提供，二者是互补而非重复的证据。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖的是 SimCCL 服务内部的通信操作转换流程（AllReduce 等集合通信到 P2P 操作列表的映射机制），是架构/流程示意图而非实测数据图。无额外证据缺口。

---

## 图片 2：Figure 4: Multi-thread implementation and optimization in SimAI.

![Figure 4: Multi-thread implementation and optimization in SimAI.](../figure-groups/page-0008-707c3c78f92f.png)

*来源：OCR 第 8 页。*

### 解读

1. **论文角色与验证问题**：对应正文 §3.5（Large Scale Simulation Speedup）中"多线程加速+无锁全局上下文共享"的机制描述，回答的问题是"多线程集成 UNISON 后为何出现性能瓶颈、以及无锁化具体如何消除该瓶颈"。图表角色为**方法流水线**（前后对比式机制图，而非单纯效果柱状图）：Panel (a) 呈现问题根源（全局锁竞争），Panel (b) 呈现解决方案（线程私有化）。`[正文支持]`
   - **图表角色**：方法流水线
   - **上文呼应**：对应"方法推理树·模块四：多线程加速+无锁全局上下文共享"及正文"Lock-free sharing of global variables"段落，支撑"23x/15% 加速"这一实验结论（图 4 本身不含该数值，数值在正文中单独给出）。

2. **图像类型与布局**：两个并列示意图（Panel 1 对应原文 Figure 4(a) Multi-thread implementation，Panel 2 对应 Figure 4(b) Lock-free optimization）。左侧 Panel 1：Thread 1（蓝）、Thread 2（黄）、Thread 3（绿）三条曲折箭头汇聚到一个锁形图标，再统一指向一个共享的"Global variable"表格（含 Data sent、Switch port length、TX/RX QP 三行）。右侧 Panel 2：同样三条线程的曲折箭头，但分别直接指向各自独立颜色的小方块（蓝/黄/绿），这些方块再各自对应到右侧同一份"Global variable"标签下的三行（Data sent、Switch port length、TX/RX QP），中间不再出现锁形图标。

3. **如何阅读**：横向对比两个 Panel——关键差异点在于线程与全局变量之间是否存在共享汇聚点（锁）：左图三条线交汇于锁图标后共用一张表，右图三条线不交汇、各自对应专属颜色方块。颜色（蓝/黄/绿）用于标识线程身份并贯穿两个 Panel，帮助识别"同一线程在两种方案下访问路径的差异"。

4. **直接可见的结论**：Panel 1 中三个线程的访问路径都必须先经过一个锁形图标才能到达同一张共享全局变量表，显示出访问是集中、互斥式的；Panel 2 中三个线程各自直接连到专属颜色的方块（无锁图标出现），显示访问路径被拆分为线程独立的通道，且不同线程的方块虽标签相同（Data sent 等）但视觉上分离。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图是**机制**类证据，具体化了正文所述"多线程集成 UNISON 后，全局变量的原子锁操作造成性能瓶颈；通过按节点 ID 将全局变量隔离到线程独立的表中消除全局锁需求"这一设计变更。Panel 1 视觉化了"瓶颈根源"（多线程争抢同一把锁访问同一份全局状态），Panel 2 视觉化了"解决方案"（变量按线程/节点分区，访问路径不再交汇）,这直接支持"无锁化设计"作为方法模块的合理性说明。该图仅展示机制变化，**不能**证明"23x 加速、相对多线程版本再提升 15%"这一具体量化效果——这些数值来自正文文字陈述而非图中可读的坐标轴或数值,读者不应从本图直接推断加速倍数的大小。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖的是 SimAI 多线程加锁 vs 无锁两种实现方案的示意性架构对比，用于说明设计动机与思路，图中未标注具体线程数量以外的更多细节（如具体节点 ID 分配规则或表结构字段的完整清单）。无额外证据缺口。
