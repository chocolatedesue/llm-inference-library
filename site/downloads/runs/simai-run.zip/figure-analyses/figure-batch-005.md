# 图片批次 5

## 图片 1：Figure 6: Bus bandwidths of intra-host collective communication operations vary with different message sizes and GPU types. Note that the performance is not related to the cluster scales.

![Figure 6: Bus bandwidths of intra-host collective communication operations vary with different message sizes and GPU types. Note that the performance is not related to the cluster scales.](../assets/imgs/img_in_chart_box_119_145_609_275.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：这是一张**实验结论**类证据（兼具**对比基线**角色），用于验证 §4.2 提出的核心比较主张——SimAI 相对 ASTRA-sim 在 intra-host 集合通信仿真上的精度优势，对应根问题中"细粒度模拟器精度/性能权衡"与"ASTRA-sim 不支持不同 GPU 类型或精度不足"这一旧方法局限。`[正文支持]`
   - **图表角色**：实验结论（对比基线）
   - **上文呼应**：第 4.2 节"通信精度实验"（图 6）；对应主张地图"SimAI 通信仿真精度显著优于 ASTRA-sim"一条。

2. **图像类型与布局**：三个并排的折线图，分别对应 AllReduce、AllGather、ReduceScatter 三种集合通信操作。每张子图内含多条曲线，用颜色区分方法（蓝=AstraSim，橙=SimAI，绿=GroundTruth），用形状/线型区分 GPU 与通信模式（圆点实线=A100，方块虚线=H100，三角虚线=H100_Ring）。

3. **如何阅读**：横轴为通信消息 Data Size(MB)，对数刻度（8→64→512→8192）；纵轴为 Bus Bandwidth(GB/s)。应比较同一子图内橙色（SimAI）曲线与绿色（GroundTruth）曲线的贴合程度，以及蓝色（AstraSim）曲线相对绿色曲线的偏离程度，尤其关注小消息区段（8-64MB）。

4. **直接可见的结论**：三个子图中，橙色 SimAI 曲线与绿色 GroundTruth 曲线在几乎所有数据点上高度重合；蓝色 AstraSim 曲线在小消息区段（8-64MB）明显偏离/偏低于 GroundTruth，AllGather 和 ReduceScatter 子图中这一偏离尤为显著，AllReduce 子图中偏离相对较小。H100_Ring 三角曲线出现在 AllGather、ReduceScatter 子图但 AllReduce 子图中未见。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为"效果"类证据，可视化支撑正文 §4.2 给出的量化结论（A100 上 SimAI 3.9% vs ASTRA-sim 74.8%；H100 上 2.3% vs 51.7%），确认 SimCCL "劫持"真实 NCCL 算法选择逻辑（而非重新实现）在中小消息尺寸下比 ASTRA-sim 从零建模更贴近真实值，从而支撑 SimAI-CM/SimCCL 模块设计的必要性。该图本身不能单独给出具体偏差百分比数值，只能确认趋势方向与相对贴合程度，具体数值仍需依赖正文陈述。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的 intra-host 场景、A100/H100 两种 GPU、AllReduce/AllGather/ReduceScatter 三种集合通信操作，消息尺寸范围 8MB-8GB。`[正文支持]` 图例中 H100_Ring 曲线所代表的具体通信算法/配置差异，正文未展开说明——[文中未说明]。受图像分辨率限制，纵轴部分刻度数字较模糊，无法逐一精确读出——[图像裁剪/像素确实遮挡的信息]。

---

## 图片 2：Figure 10: The iteration time of GPT-3 175B with different network bandwidths.

![Figure 10: The iteration time of GPT-3 175B with different network bandwidths.](../assets/imgs/img_in_chart_box_114_135_586_286.jpg)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：这是一张**实验结论**类证据（生产案例），用于验证第 5.1 节"Guiding Host Design for New GPUs"中关于 H100/H20 集群网络带宽选型的量化主张，属于该案例研究所依赖的核心仿真-实测对比数据。`[正文支持]`
   - **图表角色**：实验结论
   - **上文呼应**：第 5.1 节"生产案例"；主张地图中"H100 集群从 200Gbps 升到 400Gbps 带来 19% 性能提升""H20…提升 11%/6%"两条。

2. **图像类型与布局**：两个并排的堆叠柱状图，(a) H100、(b) H20；每个子图横轴为三档网络带宽（100G/200G/400G），每档下有三根柱子分别代表 GroundTruth、SimAI、SimAI-Model（以不同填充图案区分：无填充=GroundTruth，单斜线=SimAI，交叉斜线=SimAI-Model），每根柱子内部按颜色堆叠为 TP_Comm（蓝）、DP_Comm（绿）、Computation（红）、No_Comp（白/无填充）。

3. **如何阅读**：纵轴为 E2E Duration(μs) ×10⁶（端到端总迭代时长），横轴为带宽配置分组，组内三根柱代表三种方法给出的总时长；应比较同一带宽下三根柱的总高度是否接近（衡量整体精度），以及柱内堆叠比例是否一致（衡量各分项时间构成的精度）。

4. **直接可见的结论**：两个子图中，随带宽从 100G→200G→400G 增加，柱子总高度（E2E 时长）呈下降趋势；同一带宽组内 GroundTruth、SimAI、SimAI-Model 三根柱的总高度及内部堆叠比例非常接近，SimAI 与 GroundTruth 尤为贴近；(b) H20 子图在对应带宽下的柱高整体低于 (a) H100 子图；红色 Computation 段在多数柱中占比最大，绿色 DP_Comm 段次之。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为"效果"类证据，可视化支撑 §5.1 中"H100 从 200Gbps 升到 400Gbps 带来 19% 性能提升""H20 从 100→200Gbps 提升 11%，200→400Gbps 仅提升 6%"的具体量化主张；同时通过 SimAI-Model 与 GroundTruth 柱高的贴近程度，支持"SimAI-CP-Model 可作为未发布 GPU 的可行替代方案"这一适用范围类主张（正文称 SimAI-CP 精度超 98%，SimAI-CP-Model 低约 5%以上）。图中的堆叠分解（TP_Comm/DP_Comm/Computation）说明总时长的构成来源，但具体提升百分比数值仍依赖正文陈述，图像本身不能独立给出精确百分比。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的 GPT-3 175B 模型、1024-GPU 规模下的 H100 集群与对应 H20 场景，网络带宽 100G/200G/400G 三档。`[正文支持]` 图例中"No_Comp"段的具体含义正文未明确定义——[文中未说明]。受图像分辨率限制，柱状图的精确数值刻度难以逐一读出——[图像裁剪/像素确实遮挡的信息]。
