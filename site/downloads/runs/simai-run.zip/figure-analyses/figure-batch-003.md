# 图片批次 3

## 图片 1：Figure 5: Multi-rail network topology of cluster H100. For cluster A100, two GPUs share a single NIC

![Figure 5: Multi-rail network topology of cluster H100. For cluster A100, two GPUs share a single NIC](../assets/imgs/img_in_image_box_129_142_564_283.jpg)

*来源：OCR 第 9 页。*

### 解读

1. **论文角色与验证问题**：本图呈现 §4.1 中 H100/A100 测试床所使用的多导轨（multi-rail）网络拓扑，属于实验设置类证据，角色为**适用边界**（同时兼具方法流水线属性，因为它说明仿真与真实集群共享同一拓扑的前提）。它要回答的具体问题是：SimAI 与 ASTRA-sim 在 §4.2-4.4 中报告的通信/端到端精度对比，是在什么样的物理网络结构下测得的，从而界定这些精度数字（3.9%、2.3%、45.9%→530.2% 等）的适用范围。`[正文支持]`
   - **图表角色**：适用边界
   - **上文呼应**：对应第 4.1 节"Testbeds and Benchmarks"——正文明确"Both the simulations and physical clusters shared identical intra-host and inter-host network topologies"[页码：9]。

2. **图像类型与布局**：网络拓扑示意图（非曲线/柱状）。顶部为 Spine Switches 一整条横向机框；其下通过绿色虚线（Network Link，标注"Multi Connections"）连接多个 Leaf Switch（Leaf Switch_0、Leaf Switch_1、Leaf Switch_2 … Leaf Switch_N）；再下方为多组"GPU Server"框（GPU Server 0、GPU Server 1 … GPU Server 127，中间以省略号表示重复结构），每组内部包含一排 NIC（NIC_0…NIC_N）与一排 GPU（GPU_0…GPU_N），GPU 之间以绿色 NVLink Link 汇入一个"NVSwitch"框，GPU 与 NIC 之间以黑色 PCIe Link 连接。图右上角有一个独立信息框，列出"M=8, N=4"及"H100: NVLINK:900GB/s, Network:400Gbps"、"A100: NVLINK:600GB/s, Network:200Gbps"两组参数。左上角有图例，用不同颜色/线型区分 NVLINK Link、Network Link、PCIe Link。

3. **如何阅读**：自上而下代表网络层级——Spine（骨干层）→ Leaf（叶层）→ 服务器内 NIC/GPU（接入层）；服务器数量（0…127）对应集群规模 128 台主机；每台服务器内 GPU 通过 NVSwitch 互联（intra-host），通过 NIC 经 Leaf/Spine 与其他服务器互联（inter-host）；右上信息框给出两种 GPU 型号在该拓扑下的关键带宽参数，用于与正文数值对照。

4. **直接可见的结论**：拓扑为标准三层（GPU-NIC-Leaf-Spine）多导轨结构，每台服务器有独立的 GPU 组与 NIC 组，NIC 与 Leaf Switch 之间存在多条交叉连接（图中线条显示 Leaf Switch 与多个 Server 的 NIC 交叉相连，体现"multi-rail"设计）；GPU 间通过 NVSwitch 汇聚而非直接两两互联；信息框显示 H100 配置的 NVLink 带宽（900GB/s）与网络带宽（400Gbps）均高于 A100（600GB/s、200Gbps）。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图不直接呈现仿真精度数据，而是为 §4.2-4.4 所有精度对比实验提供物理拓扑基准——证明"仿真与物理集群使用完全相同的 intra-host/inter-host 拓扑"这一实验控制条件成立[正文支持]，从而使读者能够将后续的通信/端到端精度差异归因于仿真方法本身而非拓扑不一致。它属于"适用边界"类证据：明确了 SimAI 精度主张的验证环境局限于该多导轨 fat-tree 架构、128 台主机规模的 H100/A100 集群，而非任意网络架构。它不能单独证明 SimAI 的精度优势，须结合 §4.2/§4.4 的实测数据图共同解读。`[正文支持]`

6. **适用范围与证据缺口**：本图覆盖论文报告的 H100 集群（128 台服务器、8×H100、8×CX7 NIC）拓扑，并注明 A100 集群"两块 GPU 共享一个 NIC"的差异点，与正文 §4.1、§2.1 对 A100/H100 硬件配置的描述一致。无额外证据缺口。

---

## 图片 2：Figure 9: The iteration time of different workloads running on ASTRA-sim, SimAI, and real clusters.

![Figure 9: The iteration time of different workloads running on ASTRA-sim, SimAI, and real clusters.](../assets/imgs/img_in_chart_box_632_140_1113_277.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：本图为 §4.4"Precision of End-to-end Simulation"的核心证据，角色为**实验结论**（效果类），同时隐含**对比基线**属性（SimAI vs ASTRA-sim vs 真实集群）。它验证的具体问题是：在不同集群规模（128/512/1024 GPU）、不同 GPU 型号（H100/A100）、不同模型（GPT-3 13B、GPT-3 175B、LLaMA 65B）下，SimAI 的端到端迭代时间是否能同时贴近真实硬件结果并显著优于既有基线 ASTRA-sim。`[正文支持]`
   - **图表角色**：实验结论 / 对比基线
   - **上文呼应**：对应报告"实验、指标与文字可确认的结论"中的端到端精度实验（§4.4），以及主张地图"SimAI 端到端仿真精度显著优于 ASTRA-sim"一条。

2. **图像类型与布局**：分组堆叠柱状图，2 行 × 3 列共 6 个子面板。上排标题为 128\*H100、512\*H100、1024\*H100（左上角标注纵轴单位量级 ×10³），下排为 128\*A100、512\*A100、1024\*A100（标注量级 ×10²）。每个子面板内横轴为三个模型（GPT-3 13B、GPT-3 175B、LLaMA 65B），每个模型下并列三根柱子，分别对应 AstraSim（实心/纯色填充）、SimAI（白色/无填充轮廓）、Groundtruth（斜线阴影填充）三种方法，图例位于图像顶部说明三者的填充样式，同时另有颜色图例区分柱内堆叠的三种成分：TP Comm（浅蓝）、DP Comm（绿色）、Computation（粉红/珊瑚色）。

3. **如何阅读**：纵轴为端到端迭代耗时（End-to-End Duration，配合各子图左上角的量级标注读取绝对数值）；横轴按模型分组，每组内左中右分别为 AstraSim / SimAI / Groundtruth 三根柱；柱内颜色分段代表 TP 通信、DP 通信、计算三部分耗时的堆叠构成；应比较的量是同一模型分组下三根柱的总高度差异（即三种方法预测/实测的总迭代时间差），以及同一方法在不同规模（128→512→1024）或不同 GPU（H100 vs A100）子面板间的变化趋势。

4. **直接可见的结论**：在全部 6 个子面板、所有模型分组中，SimAI（白色柱）柱高与 Groundtruth（斜线阴影柱）柱高非常接近，二者几乎贴合；AstraSim（实心柱）柱高在多数分组中明显高于 SimAI 与 Groundtruth，即预测的迭代时间偏高；这一 SimAI≈Groundtruth 而 AstraSim 偏离的模式在 H100 与 A100、128/512/1024 GPU 规模下均一致出现。`[图像直接可见]`

5. **它验证的论点与方法设计含义**：该图为效果类主张"SimAI 端到端仿真精度显著优于 ASTRA-sim 且与真实集群偏差小"提供了跨规模、跨 GPU 型号、跨模型的直接可视证据，支撑正文"gap is less than 4% even under the scale of 1024 GPUs...36.1× better than ASTRA-sim"的量化陈述[正文支持]。柱内 TP/DP/Computation 的堆叠划分进一步呼应方法设计——SimAI 需要同时精确仿真计算（SimAI-CP）与两类并行通信（SimAI-CM/SimCCL），本图的总柱高一致性间接说明这两部分模块的联合仿真在端到端层面收敛为低误差，但**具体是哪一段（TP Comm/DP Comm/Computation）分别贡献了 SimAI 与 AstraSim 之间的差距，需要逐色块像素级读数才能精确判断，本报告基于整图判断柱高整体接近，不代表已核实各分段的精确数值差异**。该图不能单独证明消息大小与精度提升的因果关系（正文§4.4 提到的"模型越大精度越高、因为消息更大"的解释属于文字推断，非本图直接可见）。`[基于视觉的谨慎推断]`（分段贡献部分）/`[图像直接可见]`（总体柱高趋势）

6. **适用范围与证据缺口**：本图覆盖论文报告的 128/512/1024 GPU 规模、A100/H100 两种集群、GPT-3 13B/175B 与 LLaMA 65B 三个代表性模型（对应 SimAI benchmark suite 中的选定配置），与正文 §4.1 描述的评测范围一致。真实剩余缺口：由于图像分辨率限制，各柱内 TP Comm/DP Comm/Computation 三个堆叠分段的具体数值边界在像素上较难精确读取，无法据此给出分段级别的误差百分比（该数值本身正文亦未单独报告）。
