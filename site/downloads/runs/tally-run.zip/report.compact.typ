#import "@preview/mitex:0.2.7": *
#set page(paper: "a4", margin: (x: 32pt, y: 34pt))
#set text(size: 9.4pt)
#set par(justify: true, leading: 0.72em, spacing: 0.72em)
#set list(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#set enum(indent: 1.35em, body-indent: 0.55em, spacing: 0.45em)
#show heading.where(level: 1): it => block(above: 1.4em, below: 0.9em)[
  #text(size: 17pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]
  #v(-6pt); #line(length: 100%, stroke: 0.6pt + rgb(25, 79, 95))
]
#show heading.where(level: 2): it => block(above: 1.6em, below: 0.7em, inset: (x: 9pt, y: 5pt), fill: luma(245), radius: 3pt, stroke: (rest: none, left: 4pt + rgb(25, 79, 95)))[#text(size: 12.5pt, weight: "bold", fill: rgb(25, 79, 95))[#it.body]]
#show heading.where(level: 3): it => block(above: 1.1em, below: 0.4em)[#text(size: 10.6pt, weight: "bold", fill: rgb(40, 110, 130))[#it.body]]
#show heading.where(level: 4): it => block(above: 0.9em, below: 0.3em)[#text(size: 9.8pt, weight: "bold", fill: luma(80))[#it.body]]
#show strong: it => text(weight: "bold", fill: rgb(25, 79, 95))[#it]
#let blockquote(body) = block(width: 100%, inset: (left: 12pt, top: 5pt, bottom: 5pt), fill: luma(248), stroke: (left: 3pt + rgb(25, 79, 95)))[#body]

#page(numbering: none, margin: (top: 64pt, bottom: 40pt, left: 44pt, right: 44pt))[
  #set align(center)
  #v(2fr)
  #text(size: 12pt, weight: "bold", tracking: 3pt, fill: rgb(25, 79, 95))[论文解构报告]
  #v(6pt)
  #line(length: 26%, stroke: 1.2pt + rgb(25, 79, 95))
  #v(34pt)
  #text(size: 22pt, weight: "bold")[Tally: Non-Intrusive Performance Isolation for Concurrent Deep Learning Workloads]
  #v(14pt)
  #text(size: 11pt, fill: luma(90))[Wei Zhao, Anand Jayarajan, Gennady Pekhimenko]
  #v(6pt)
  #text(size: 10pt, fill: luma(120))[ASPLOS '25 (30th ACM International Conference on Architectural Support for Programming Languages and Operating Systems) · 2025]
  #v(26pt)
  #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[GPU sharing] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[performance isolation] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[deep learning systems] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[kernel scheduling] #box(inset: (x: 7pt, y: 2.5pt), stroke: 0.5pt + rgb(25, 79, 95), radius: 4pt, fill: rgb(25, 79, 95, 8%))[cloud infrastructure]
  #v(1fr)
  #line(length: 50%, stroke: 0.5pt + luma(220))
  #v(8pt)
  #text(size: 9pt, fill: luma(120))[源文件：https://arxiv.org/pdf/2410.07381]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[arXiv：2410.07381]
  #v(3pt)
  #text(size: 9pt, fill: luma(120))[DOI：https://doi.org/10.1145/3669940.3707282]
  #v(3pt)
  #v(4pt)
  #text(size: 9pt, fill: luma(120))[生成时间：2026-07-26]
]
#pagebreak(weak: true)

#set page(numbering: "1")
#outline(title: "目录", indent: 1em, depth: 2)
#pagebreak(weak: true)

#heading(level: 1)[摘要翻译]

GPU利用率不足是许多生产环境深度学习集群面临的重要问题，会导致作业排队时间延长和运营成本增加。GPU共享是缓解该低效问题的一种有前景的方案，它允许多个工作负载在单块GPU上并发执行，从而提高资源利用率。然而，现有GPU共享机制存在集成成本高、性能隔离不足以及应用兼容性有限等缺陷，导致其在生产环境中的部署面临关键障碍。为解决这些问题，我们提出了Tally，一种非侵入式的GPU共享机制，能够提供稳健的性能隔离和全面的工作负载兼容性。Tally实现稳健性能隔离能力的关键在于其细粒度的线程块级GPU内核调度策略，该策略能有效缓解工作负载并发执行所带来的干扰。我们在多种工作负载上对Tally进行了评估，结果表明：当高优先级推理任务与尽力而为（best-effort）训练工作负载并发执行时，Tally在推理任务第99百分位延迟上仅带来平均7.2%的开销，而当前最先进的GPU共享系统（如TGS）的开销高达188.9%；与此同时，Tally的系统吞吐量达到了TGS的80%以上。

== 1. 一句话总览
<1-一句话总览>

=== 论文元数据
<论文元数据>
#align(center)[#table(
  columns: 2,
  align: (col, row) => (auto,auto,).at(col),
  inset: 6pt,
  [字段], [内容],
  [标题],
  [Tally: Non-Intrusive Performance Isolation for Concurrent Deep Learning Workloads],
  [作者],
  [Wei Zhao, Anand Jayarajan, Gennady Pekhimenko],
  [发表场所 / 年份],
  [ASPLOS \'25（第 30 届 ACM 国际编程语言与操作系统体系结构支持会议），2025],
  [研究领域],
  [计算机系统（GPU 资源管理 / 深度学习系统）],
  [关键词],
  [GPU sharing, performance isolation, deep learning systems, kernel scheduling, cloud infrastructure],
)
]

=== 资源链接
<资源链接>
- 原始文件：本地上传文件（无外部链接）
- arXiv：#link("https://arxiv.org/pdf/2410.07381（编号") 2410.07381）
- DOI：#link("https://doi.org/10.1145/3669940.3707282")
- 代码 / 数据集：文中未说明

#blockquote[
#strong[标签（3–5 个）]：`GPU共享` · `性能隔离` · `内核调度` · `深度学习系统` · `云基础设施`
]

Tally 是部署在应用与 GPU 之间的非侵入式虚拟化层，通过对 GPU 内核做线程块（thread block，GPU 上可独立调度的最小执行单元，类比车间里彼此不依赖的独立工位）级别的\"切片\"与\"抢占\"代码变换，使高优先级推理任务与 best-effort 训练任务共享同一 GPU 时，前者的 P99 尾延迟平均仅增加 7.2%，远低于现有最优方案 TGS 的 188.9%，同时无需修改用户代码 \[作者明确陈述\]\[实验支持\]\[页码：1, 9-10\]。

== 2. 阅读范围与证据状态
<2-阅读范围与证据状态>

- #strong[OCR 覆盖范围]：文本证据覆盖论文第 1–6 节及部分附录内容，图表证据覆盖第 3、5、6、10、11、12 页共 3 批次 6 张图（Figure 1、2、3、5、6、7）\[页码：3-14\]。
- #strong[明显缺失或损坏]：P99 延迟、吞吐、系统吞吐等核心指标未给出可逐字定位的数学公式，仅有文字定义 \[文中未给出公式编号\]\[页码：9\]；论文与 MIG、REEF、AntMan、Orion 等多个基线缺乏统一定量对比实验，相关比较停留在定性讨论 \[页码：12-14\]。
- #strong[背景知识边界]：本报告中对 GPU 架构、线程块等概念的类比说明属于`[背景知识]`，用于辅助理解，不代表论文原文表述。

== 3. 根问题：论文究竟要解决什么
<3-根问题论文究竟要解决什么>

生产级深度学习集群的 GPU 利用率长期偏低——阿里巴巴数据显示中位数仅 4.2% \[作者明确陈述\]\[页码：1\]。这一问题重要，是因为 GPU 采购成本极高（Meta 两座数据中心各配数十万块 H100，估计成本达 5 亿美元）\[作者明确陈述\]\[页码：1\]，利用率不足直接转化为巨额浪费与作业排队延迟。

低利用率的难点来自两个互相独立的物理/资源约束：训练任务常受 CPU 端数据读取瓶颈限制、无法\"喂饱\"GPU；在线推理任务的 GPU 需求随实时请求率剧烈波动（峰值可达均值 50 倍），迫使运维方为保证服务质量而过度预留资源 \[作者明确陈述\]\[页码：1-2\]。GPU 共享（让多个任务并发使用同一 GPU）是候选解法，阿里巴巴仿真显示有效共享可平均减少 50%（高峰达 73%）所需 GPU \[作者明确陈述\]\[页码：2\]。

#strong[成功标准]：一个可在生产环境落地的共享机制必须同时做到非侵入、强性能隔离、广泛工作负载兼容 \[作者明确陈述\]\[页码：2, 5\]。

#strong[本文的 story]：既有方案在\"调度粒度\"这一技术维度上失效——粒度太粗（迭代级、内核级）无法把高优先级任务的排队延迟压到毫秒级以下；本文的转折是发现\"线程块级调度\"可以在不依赖特定框架、不要求内核幂等的前提下非侵入地实现，从而同时满足三条标准。

== 4. 旧方法为何不够
<4-旧方法为何不够>

论文在第 3 节归纳三类根本限制：集成成本高、缺乏隔离保证、依赖狭窄工作负载特征 \[作者明确陈述\]\[页码：4-5\]。以下按论文实际比较的路线逐项展开因果链：

- #strong[Time-Slicing / MPS（NVIDIA 驱动层）]：它原本解决\"透明共享 GPU 资源、最大化利用率\"的问题 \[作者明确陈述\]\[页码：4\]；依赖的前提是\"尽量多派发内核\"的调度策略；本文批判的具体限制是优先级无关设计导致高优先级任务排队，实验中 P99 延迟开销分别为 252.3%/345.0%，MPS 尾延迟最高达独立运行的 20 倍 \[实验支持\]\[页码：4, 9\]；Tally 用 Priority-aware 调度器 + 块级内核变换回应；由 Figure 5 端到端对比检验 \[页码：10\]。
- #strong[MPS-Priority]：在 MPS 上加入优先级控制 \[作者明确陈述\]\[页码：9\]；其遗留限制是调度粒度仍为内核级（粗粒度），实验开销 195.5% \[作者明确陈述\]\[页码：9\]；本文用块级调度（切片+抢占）回应；由 Figure 5、Table 1 粒度对比检验 \[页码：4, 10\]。
- #strong[TGS]：专为 DL 工作负载设计，通过自适应速率控制在容器编排中实现隔离 \[作者明确陈述\]\[页码：9\]；其前提是内核级调度足够应对干扰，限制是对长内核工作负载（如 Whisper）退化严重，跨负载延迟退化波动 15.6%–751.7% \[实验支持\]\[页码：9-10\]；本文用块级调度+profile-guided 配置选择回应；由 Figure 5、Figure 6a/6b 检验 \[页码：10-11\]。
- #strong[Salus（应用层）]：暴露训练迭代边界实现迭代级管理 \[作者明确陈述\]\[页码：3\]；限制是调度粒度为迭代级（Table 1 中 turnaround ≈3s），远高于亚毫秒级需求 \[基于文中逻辑的推断，推理依据：Table 1 数值与原文\"迭代级/内核级带来 2.5–760× 开销\"的整体陈述，未针对 Salus 单独重跑实验\]\[页码：4\]；本文用块级调度回应；仅由 Table 1 单一案例检验。
- #strong[AntMan、EffiSha、Orion、REEF、GPES、Kernelet 等]：各自依赖训练模式可预测（AntMan）、需要源码访问（EffiSha、GPES）、需要离线 profiling（Orion）、需要内核幂等（REEF）等前提，均限制了通用性或非侵入性 \[作者明确陈述\]\[页码：3-5, 14\]；本文分别用任务无关设计、拦截设备代码而非源码、透明在线 profiler、不依赖幂等假设的统一同步+抢占变换回应；但这些比较均无直接定量对比实验，写为\"无法从当前 OCR 内容确认\"\[页码：14\]。

== 5. 核心洞见与假设
<5-核心洞见与假设>

- #strong[核心洞见（隔离效果由调度粒度决定）]：要达到毫秒级隔离，调度粒度必须细至块级或线程级，粗粒度调度无法满足 \[作者明确陈述，Table 1 实验支持\]\[页码：4-5\]。
- #strong[核心洞见（块级调度可非侵入且通用地实现）]：GPU 编程模型保证同一内核内的线程块彼此独立、调度顺序不确定，这一硬件特性使块级调度不像线程级调度那样依赖\"幂等\"假设，因而可对所有内核通用适用 \[作者明确陈述\]\[页码：3, 5\]。
- #strong[经验判断（块级调度\"足够好\"）]：线程级调度理论隔离更强，但作者认为块级调度对多数实际场景已足够——这是一个未经严格定量证明的经验判断，实验部分以整体结果间接支持 \[作者明确陈述，间接实验支持\]\[页码：5\]。
- #strong[实现落地思路]：切片与抢占可通过对内核设备代码（PTX）的变换实现，设备代码经拦截设备 API 调用获得，无需用户配合 \[作者明确陈述\]\[页码：2, 5\]。
- #strong[隐含假设]：拦截到的内核代码可被安全反汇编、修改并重新编译执行；论文未讨论该假设何时可能失效（如加密/混淆内核）\[基于文中逻辑的推断，推理依据：4.3 节描述的实现路径\]\[页码：13\]。

== 6. 方法：从洞见到可执行系统
<6-方法从洞见到可执行系统>

Tally 采用客户端-服务端架构：客户端库通过 `LD_PRELOAD`（Linux 提供的函数调用拦截机制，类似给程序\"加装外置行车记录仪\"而不拆改发动机）拦截应用的 GPU API 调用，转发给独立 server 进程；server 对内核做变换、profiling 并统一调度后交给 GPU 执行 \[作者明确陈述\]\[页码：13\]。

+ #strong[切片变换]：动机是需要一种轻量方式把大内核拆成可控小单元，便于调度器细粒度插入高优先级任务 \[作者明确陈述\]\[页码：6\]。做法是把原内核（如 16 个线程块）拆成多个子内核（如 4 个各 4 块），新增 `offset` 参数把 `blockIdx` 替换为 `offset+原blockIdx` 以恢复真实块索引 \[作者明确陈述\]\[页码：6\]。优势是实现简单、语义天然不变；代价是多次内核启动带来额外开销（并入 5.7 节\"内核变换平均 25% 开销\"，未拆分切片专属占比）\[文中未说明该拆分\]\[页码：13\]。
+ #strong[抢占变换]：动机是切片仍可能有排队延迟，需要能中断正在执行的内核 \[作者明确陈述\]\[页码：6\]。借鉴 Persistent Thread Block 范式，发射固定数量 worker 线程块，通过全局计数器迭代领取原始 block 的工作，并检查\"抢占标志\"以便随时中断、之后恢复 \[作者明确陈述\]\[页码：6-7\]。优势是只需一次启动；代价是需额外控制流与同步开销 \[作者明确陈述\]\[页码：7\]。
+ #strong[统一同步变换]：动机是抢占把 `return` 改为跳转指令，可能导致同一 block 内线程在不同同步点调用同步指令（同步分歧，GPU 编程模型下的未定义行为，会导致内核无限停滞）\[作者明确陈述\]\[页码：7\]。做法是将所有同步点与 return 重定向到一个统一同步点，检测是否全部线程到达返回状态，未到达则循环回退，直至全部对齐 \[作者明确陈述\]\[页码：7\]。这是抢占变换能自动安全应用于所有内核的前置保障 \[作者明确陈述\]\[页码：7\]。
+ #strong[透明分析器（Profiler）]：动机是切片/抢占的性能权衡因内核而异，参数需按内核调优，人工静态设定不可行 \[作者明确陈述\]\[页码：7-8\]。对候选配置实测或估算 turnaround latency（切换延迟，指 best-effort 内核释放资源所需的估计时间，类比\"占用会议室的人被通知后需要多久才能腾出房间\"）：

\#mitex(`turnaround\_latency=\frac{kernel\_latency\cdot worker\_blocks}{total\_blocks}`)

用于抢占配置的估算（`kernel_latency`：内核整体执行时间；`worker_blocks`：分配 worker 数；`total_blocks`：总线程块数），选出满足阈值（默认 0.0316ms）且性能最优的配置，按内核复用不重复 profiling \[作者明确陈述，原文公式\]\[页码：8\]。 5. #strong[Priority-aware 调度器]：动机是需要总控算法整合前述能力，兼顾高优先级即时响应与 best-effort 吞吐 \[作者明确陈述\]\[页码：5, 8\]。策略是优先立即派发高优先级内核（若有 best-effort 内核在执行则抢占之），仅在高优先级空闲时以可分片/可抢占形式调度 best-effort 内核 \[作者明确陈述\]\[页码：8-9\]。反应式设计的代价是若高优先级请求恰好在 best-effort 内核刚启动时到达，仍需等待完成或抢占 \[作者明确陈述\]\[页码：8\]。 6. #strong[非侵入虚拟化层]：整合以上模块的运行载体，用共享内存通信与本地状态缓存降低通信开销（5.7 节报告虚拟化层平均开销仅 1%）\[作者明确陈述\]\[实验支持\]\[页码：13\]。

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：块级调度的编程模型前提]
  #image("assets/source-crops/img_in_image_box_662_147_1092_362.png", width: 100%)
  #emph[Figure 1. Overview of the GPU programming model.] \
来源：OCR 第 3 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：Kernel由Thread Block网格构成，每Block含多个Warp，每Warp固定32线程，标注blockIdx/threadIdx索引变量。

- #strong[论证关系]：为切片变换用offset+blockIdx重建索引提供硬件前提，支撑块级调度可通用非侵入实现的核心洞见。

- #strong[适用范围]：仅为通用编程模型示意，未可视化调度顺序不确定这一性质，不含具体内核实例数值。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：Tally客户端-服务端整体架构]
  #image("assets/source-crops/img_in_image_box_659_144_1093_544.png", width: 100%)
  #emph[Figure 2. Tally architecture.] \
来源：OCR 第 5 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：三类client经拦截层进入Server，内部Kernel Transformer→Profiler→Scheduler依次处理后连接GPU。

- #strong[论证关系]：可视化印证非侵入虚拟化层机制，三组件与4.1–4.3节模块一一对应。

- #strong[适用范围]：图中JAX图标与实际评测框架列表不完全一致，为通用示意非评测实况。
]

#block(breakable: false, inset: 8pt, stroke: 1pt + rgb(25, 79, 95, 35%), radius: 4pt, fill: luma(252))[
  #text(size: 9pt, weight: "bold", fill: rgb(25, 79, 95))[前排论文大图]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[方法流水线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第6节：切片、抢占与统一同步变换机制]
  #image("assets/source-crops/img_in_image_box_105_143_1112_470.png", width: 100%)
  #emph[Figure 3. Kernel transformations: (a) slicing and preemption transformations (b) unified synchronization transformation.] \
来源：OCR 第 6 页。
  #v(4pt)
  #text(weight: "bold")[图组解读]
  - #strong[图组结论]：切片将16块内核拆为4个各4块子内核；抢占内核用2个worker循环领取任务并维护抢占标志；代码显示同步/return被重定向至统一同步块。

- #strong[论证关系]：直接印证切片/抢占可通过设备代码变换实现，统一同步变换是抢占安全生效的前提。

- #strong[适用范围]：为示意性最小化算例，是否代表实际默认参数无法确认，未验证对Cooperative Groups内核的适用性。
]

== 7. 为什么它可能有效
<7-为什么它可能有效>

- 块级调度的粒度足够细（微秒级 turnaround），预期能把高优先级任务的等待时间压到接近其内核本身执行时间的量级，前提是 profiler 给出的配置选择准确 \[基于文中逻辑的推断\]\[页码：4, 8\]。
- 统一同步变换消除同步分歧风险，使抢占可以自动应用于任意内核而非仅限特定代码模式，预期收益是通用性提升，条件是内核不使用跨块协作原语（如 Cooperative Groups）\[基于文中逻辑的推断\]\[页码：7, 13\]。
- Priority-aware 调度器的\"严格让路\"策略预期在低负载下几乎不牺牲吞吐，但在高负载（低 idle）区间会以吞吐换隔离，这一权衡的存在条件是 best-effort 任务数量足够多导致资源竞争 \[基于文中逻辑的推断，实验部分间接支持\]\[页码：10\]。

== 8. 实验与指标：证据是否支撑主张
<8-实验与指标证据是否支撑主张>

=== 8.1 实验问题与判定标准
<81-实验问题与判定标准>
- #strong[效果]：Tally 相对基线能否显著降低高优先级任务尾延迟开销同时保持有竞争力吞吐？对应 Figure 5 端到端对比 \[页码：9-10\]。
- #strong[必要性]：块级内核变换相对于\"仅调度算法\"是否是隔离效果的必要条件？对应 5.5 节性能分解消融 \[页码：12\]。
- #strong[鲁棒性]：隔离能力是否对流量负载、训练任务配对具有稳定性？对应 5.3 节负载敏感性 \[页码：10\]。
- #strong[适用范围]：能否扩展到多个 best-effort 任务？对应 5.4 节可扩展性 \[页码：11\]。
- #strong[参数敏感性]：turnaround latency 阈值如何影响延迟-吞吐权衡？对应 5.6 节 \[页码：12\]。

=== 8.2 数据、任务、对比与运行设置
<82-数据任务对比与运行设置>
- #strong[硬件/环境]：AWS p4d.24xlarge 实例（单张 A100 GPU）\[作者明确陈述\]\[页码：14\]。
- #strong[工作负载]：6 个训练 + 6 个推理基准，覆盖 BERT、Llama-2-7B、ResNet50、YOLOv6M、GPT-Neo-2.7B、Stable Diffusion（推理）及 Whisper、ResNet50、PointNet、Pegasus、GPT2、BERT（训练）\[作者明确陈述\]\[页码：9-14\]。
- #strong[流量模拟]：MAF2（微软生产流量轨迹）驱动的推理请求模拟 \[作者明确陈述\]\[页码：9\]。
- #strong[基线]：Time-Slicing、MPS、MPS-Priority、TGS 四个系统 \[作者明确陈述\]\[页码：14\]。
- #strong[推理引擎/训练框架]：ONNX Runtime/TorchInductor/Hidet（推理）、PyTorch（训练）；架构图（Figure 2）中出现的 JAX 未见于实际评测框架列表 \[基于文中逻辑的推断\]\[页码：8\]。
- #strong[重复次数/统计方式]：文中未说明。
- #strong[超参数]：turnaround latency 阈值默认 0.0316ms，经 5.6 节扫描确定 \[作者明确陈述\]\[页码：8, 12\]。

=== 8.3 指标字典与对应公式
<83-指标字典与对应公式>
- #strong[指标与方向]：P99 延迟（\#mi(\"99^{th}\") percentile latency），测量推理任务响应时间，单位 ms，越低越好。

  - #strong[定义与公式]：来源层级为`无可核验公式`——论文仅说明其为\"评估推理任务性能的主要指标\"，未给出统计计算式（如采样窗口、聚合方式）\[文中未给出公式编号\]\[页码：9\]。
  - #strong[实验用途]：端到端结果（5.2）、负载敏感性（5.3）、性能分解（5.5）。
  - #strong[读数与边界]：Tally 平均开销 7.2% vs. Time-Slicing/MPS/MPS-Priority/TGS 的 252.3%/345.0%/195.5%/188.9% \[实验支持\]\[页码：9-10\]；不能证明该结论在非 A100 硬件上的成立性。

- #strong[指标与方向]：吞吐（Throughput），单位时间处理样本数，越高越好。

  - #strong[定义与公式]：来源层级`无可核验公式`——作者文字定义\"the number of samples processed per unit of time\"，无数学式 \[作者明确陈述\]\[页码：9\]。
  - #strong[实验用途]：各实验的吞吐对比。
  - #strong[读数与边界]：无独立数值，通常与系统吞吐一并报告。

- #strong[指标与方向]：系统吞吐（System Throughput），多并发工作负载整体吞吐，越高越好。

  - #strong[定义与公式]：来源层级`无可核验公式`——作者文字定义为\"各任务归一化吞吐求和\"，未说明归一化基准 \[作者明确陈述\]\[页码：9\]。
  - #strong[实验用途]：5.2/5.3/5.4 系统吞吐对比。
  - #strong[读数与边界]：Tally 达四基线的 105.2%/83.6%/80.6%/80.3% \[实验支持\]\[页码：9\]；10% 空闲时 Tally\=1.19 vs. TGS\=1.65（严格优先级策略牺牲部分吞吐）\[实验支持\]\[页码：10\]。

- #strong[指标与方向]：Turnaround latency（切换延迟），best-effort 内核释放资源所需估计时间，单位 ms/μs，越低越好（隔离更强）。

  - #strong[定义与公式]：通用定义来源层级`无可核验公式`（文字定义，无通用数学式）\[页码：8\]；抢占内核专用估算式来源层级为`原文公式`（4.2 节正文给出，未标注 Eq. 编号）：\#mi(\"turnaround\_latency\=\\dfrac{kernel\_latency\\cdot worker\_blocks}{total\_blocks}\") \[作者明确陈述\]\[页码：8\]。
  - #strong[实验用途]：说明调度粒度对隔离的影响（Table 1）；profiler 选优的核心依据。
  - #strong[读数与边界]：Table 1 实测（BERT vs. Whisper，A100）：迭代级 ≈3s、内核级 ≈10ms、线程块级 ≈304μs、线程级 ≈38μs，BERT 单次推理仅需 3.93ms \[实验支持\]\[页码：4\]；仅一组代表性案例，非系统性扫描。

- #strong[指标与方向]：Turnaround latency 阈值，调度器接受的上限，单位 ms，需权衡（越低隔离越强、吞吐可能下降）。

  - #strong[定义与公式]：来源层级`无可核验公式`——默认值 0.0316ms 为 5.6 节敏感性扫描（0.01ms–10ms 六档）的经验调参结果，非公式推导 \[作者明确陈述\]\[页码：8, 12\]。
  - #strong[实验用途]：4.2 节调度算法参数、5.6 节敏感性分析。
  - #strong[读数与边界]：阈值升高，延迟增加（尤其 Whisper 等长内核）、吞吐仅小幅提升 \[实验支持\]\[页码：12\]；未说明该值随 GPU 型号的迁移性 \[文中未说明\]。

- #strong[指标与方向]：空闲时间/负载（idle time / load），GPU 非服务时间占比，0–100%。

  - #strong[定义与公式]：来源层级`无可核验公式`——文字定义 load 为\"推理服务实际处理请求所占时间百分比\"，idle\=100%−load \[页码：8, 10\]。
  - #strong[实验用途]：5.3 节负载敏感性分析的自变量。
  - #strong[读数与边界]：覆盖 10%–90% 区间 \[实验支持\]\[页码：10\]。

=== 8.4 主结果、消融与证据边界
<84-主结果消融与证据边界>
#strong[比较工作与被批判限制的呼应]

#align(center)[#table(
  columns: 4,
  align: (col, row) => (auto,auto,auto,auto,).at(col),
  inset: 6pt,
  [比较工作/基线], [核心限制或失效条件], [本文对应模块], [直接实验与仍未验证的边界],
  [Time-Slicing / MPS],
  [优先级无关，\"尽量多派发\"导致排队，开销 252.3%/345.0% \[实验支持\]\[页码：9\]],
  [Priority-aware 调度器],
  [Figure 5 已验证；未验证非 A100 硬件],
  [MPS-Priority / TGS],
  [内核级粒度不足，开销 195.5%/188.9%，TGS 延迟退化跨组合波动 15.6%–751.7% \[实验支持\]\[页码：9-10\]],
  [块级调度（切片+抢占）+profile-guided 配置],
  [Figure 5/6 已验证；未验证异构大规模场景],
  [REEF / AntMan / Orion / MIG],
  [分别要求幂等、局限训练场景、需离线 profiling、静态粗粒度分区 \[作者明确陈述\]\[页码：5, 12-14\]],
  [统一同步+抢占变换 / 任务无关设计 / 透明在线 profiler / 动态资源分配],
  [无直接定量对比实验，仅定性讨论 \[无法从当前 OCR 内容确认\]],
)
]

- 比较结果仅说明本文实验设置内的相对表现，不能证明基线方法在其他场景下必然失效。

#strong[主张与证据表]

#align(center)[#table(
  columns: 3,
  align: (col, row) => (auto,auto,auto,).at(col),
  inset: 6pt,
  [主张], [直接证据（实验/表图）], [证据强度与边界],
  [Tally P99 延迟开销均值 7.2%，远低于 TGS 等基线],
  [摘要、5.2 节、Figure 5 \[页码：1, 9-10\]],
  [\[实验支持\]，覆盖 36 种推理×训练组合],
  [块级/线程级调度是亚毫秒隔离的必要条件],
  [Table 1 \[页码：4\]],
  [\[实验支持\]，仅 BERT+Whisper 单一案例，非系统扫描],
  [块级调度对隔离是必要的（相较仅调度算法）],
  [5.5 节，Figure 7b：No-scheduling 最差 30× 延迟放大，仅调度算法在 Whisper/BERT 仍达 10×，完整 Tally 平均 4.0%（最差 6.2%）\[实验支持\]\[页码：12\]],
  [消融实验直接支撑必要性主张],
  [Tally 隔离能力具有鲁棒性],
  [5.3 节，Figure 6a/6b \[页码：10-11\]],
  [仅覆盖 BERT、Llama-2-7B 两个推理代表],
  [可扩展到多个 best-effort 任务],
  [5.4 节，Figure 7a \[页码：11\]],
  [仅用同构 ResNet50 模拟，未验证异构场景 \[基于文中逻辑的推断\]\[页码：11\]],
  [Tally 优于 MIG],
  [第 6 节讨论 \[页码：12-13\]],
  [\[作者明确陈述\]，无实验数值支持，定性论证],
  [虚拟化层开销约 1%],
  [5.7 节 \[页码：13\]],
  [\[实验支持\]，未说明是否分推理/训练拆分 \[文中未说明\]],
)
]

- 关键设置提示：所有主结果均基于单张 A100、固定 50% 负载或指定 idle time 区间，跨硬件/跨负载泛化性未被验证 \[页码：9-12\]。
- Cooperative Groups 类内核未被纳入评测基准，相关适用范围主张缺乏实证 \[作者明确陈述\]\[页码：13\]。

== 9. 图表解读与论证关系
<9-图表解读与论证关系>

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("assets/source-crops/img_in_chart_box_109_149_1115_786.png", width: 100%)
    #emph[Figure 5. Analysis of 99th-percentile latency and system throughput across different high-priority inference and best-effort training workload combinations under various GPU sharing mechanisms.] \
来源：OCR 第 10 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：7.2% vs 188.9%尾延迟主张，系统吞吐80.3%–105.2%]
    - #strong[图组结论]：36种推理×训练组合中Tally柱始终最接近Ideal，明显低于MPS等基线；系统吞吐略低于基线但差距多不大。

- #strong[论证关系]：把粒度论证从单一案例扩展到36种组合的系统性验证，支撑核心贡献主张。

- #strong[适用范围]：无法单独证明块级调度相对纯调度算法的贡献占比，也不能证明A100外硬件的通用性。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0011-041b53eb46e5.png", width: 100%)
    #emph[Figure 6. (a) Latency and throughput for high-priority BERT and Llama2-7B inference co-located with BERT, GPT-2, and Whisper training under Tally and TGS across different traffic loads. (b) Time-series visualization of user traffic, tail latency, and throughput over time for BERT inference co-located with BERT training across different GPU sharing systems.] \
来源：OCR 第 11 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[实验结论]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：Tally隔离能力对负载与训练搭配的鲁棒性]
    - #strong[图组结论]：10%–90% Idle Time区间Tally延迟始终贴近Ideal，TGS显著更高且随训练搭配波动大；系统吞吐差距随Idle Time增大而收窄。

- #strong[论证关系]：支撑隔离鲁棒性主张及\"高负载下以吞吐换隔离\"的调度权衡。

- #strong[适用范围]：仅覆盖BERT、Llama-2-7B两推理代表，未验证PEGASUS、YOLOv6m等组合；部分时序曲线因分辨率限制无法精确辨读。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
#grid(
  columns: (45%, 1fr),
  gutter: 8pt,
  [
    #image("figure-groups/page-0012-28843ab9279e.png", width: 100%)
    #emph[Figure 7. (a) Scalability performance of Tally with respect to number of concurrent workloads. (b) Performance decomposition of Tally for BERT inference. (c) Latency and throughput under different turnaround latency threshold settings.] \
来源：OCR 第 12 页。
  ],
  [
    #text(weight: "bold")[图组解读]
    #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[消融验证]]
    #text(size: 8.5pt, fill: luma(95))[呼应：第8节：块级内核变换是隔离效果的必要条件]
    - #strong[图组结论]：No-scheduling延迟放大最差达30×，仅调度算法在Whisper/BERT仍达10×，完整Tally平均4.0%（最差6.2%）；延迟在1–10个任务间保持稳定，阈值升高使延迟明显上升而吞吐仅小幅提升。

- #strong[论证关系]：直接支撑\"块级调度相较仅调度算法是隔离必要条件\"的机制主张，并佐证可扩展性与阈值权衡。

- #strong[适用范围]：可扩展性仅用同构ResNet50模拟，未验证异构组合；结论未验证非A100硬件可迁移性。
  ],
)
]

#block(breakable: false, inset: 7pt, stroke: luma(215), radius: 3pt)[
  #text(weight: "bold")[表格证据：Table 1. Comparison of BERT inference latency against turn-around latency of different scheduling granularity for Whi...]
  #box(inset: (x: 6pt, y: 2pt), radius: 3pt, fill: rgb(25, 79, 95, 12%))[#text(size: 8.5pt, weight: "bold", fill: rgb(25, 79, 95))[对比基线]]
  #text(size: 8.5pt, fill: luma(95))[呼应：第4节：调度粒度决定隔离上限的核心洞见]
  - #strong[图组结论]：BERT与Whisper训练在A100上对比显示迭代级≈3s、内核级≈10ms、线程块级≈304μs、线程级≈38μs，BERT单次推理仅需3.93ms。

- #strong[论证关系]：证明粗粒度调度的turnaround远超推理延迟需求，是块级/线程级调度成为隔离必要条件的关键量化依据。

- #strong[适用范围]：仅BERT+Whisper单一代表性案例，非系统性扫描，不能证明其他模型组合下的普适性。
  #v(5pt)
  #image("table-groups/page-0004-6654cdb4c95c.png", width: 100%)
]

== 10. 完整因果推理树
<10-完整因果推理树>

- 根问题：生产级 DL 集群 GPU 利用率低（中位数 4.2%），如何在共享 GPU 时同时保证利用率与高优先级任务性能？\[页码：1\]
  - 旧方法限制：集成成本高、粒度粗导致隔离不足（迭代级/内核级 turnaround 达 3s/10ms）、依赖狭窄工作负载特征（幂等/可预测模式）\[页码：4-5\]
  - 核心洞见/假设：块级调度可在不依赖幂等假设的前提下非侵入通用实现，且隔离效果足够 \[页码：3, 5\]
    + 方法模块：切片变换、抢占变换、统一同步变换、透明 Profiler、Priority-aware 调度器、非侵入虚拟化层 \[页码：6-13\]
    + 可验证预测：块级变换可把 turnaround latency 压至微秒级，从而使高优先级延迟接近独立运行水平
      - 指标与实验：P99 延迟、系统吞吐、性能分解消融（5.2/5.5 节）\[页码：9-12\]
      - 图表证据：Figure 5（端到端）、Figure 7b（消融）
      - 结论与适用边界：36 种组合下延迟开销均值 7.2%、必要性获消融支持；但未验证异构大规模、非 A100 硬件及 Cooperative Groups 内核场景 \[实验支持\]\[页码：9-13\]

== 11. 结论、贡献与边界
<11-结论贡献与边界>

- #strong[贡献总结]：提出非侵入式 GPU 共享系统 Tally；提出任务无关的块级内核变换（切片+抢占+统一同步）与 priority-aware 调度器；在多样化工作负载上验证其吞吐可与最优基线持平同时保证强隔离 \[作者明确陈述\]\[页码：3\]。
- #strong[证据充分的结论]：Tally 在本文测试的 36 种推理-训练组合下显著优于四个非侵入基线的尾延迟开销（7.2% vs. 188.9%起），且块级变换对隔离是消融验证过的必要因素 \[实验支持\]\[页码：9-12\]。
- #strong[尚属推断的意义]：块级调度\"足够好\"（相对线程级调度）为经验判断，未有严格定量证明 \[基于文中逻辑的推断\]\[页码：5\]。
- #strong[适用条件]：面向\"一个高优先级任务 + 多个 best-effort 任务\"场景，多高优先级任务并发竞争的情形未讨论 \[作者明确陈述\]\[页码：5\]。
- #strong[局限与下一步验证]：与 MIG/REEF/AntMan/Orion 缺乏统一定量对比；核心指标缺精确公式；Cooperative Groups 内核未实测；异构大规模 best-effort 扩展性未验证；阈值 0.0316ms 跨硬件迁移性未讨论 \[页码：9-14\]。

#strong[审稿式风险检查]：

- 贡献新意：块级调度思路借鉴 EffiSha/GPES 等已有工作，本文创新点在于非侵入实现（拦截设备代码而非源码）及统一同步变换，新意主要体现在工程实现层面而非全新调度原语 \[基于文中逻辑的推断\]\[页码：5, 14\]。
- 写作/可复现性：代码/数据集链接文中未说明，复现依赖细节（如统计口径、重复次数）未披露 \[文中未说明\]\[页码：9\]。
- 效果大小：主结果建立在单一硬件（A100）与固定基准套件上，效果量级是否随硬件/规模变化，当前证据未显示该风险已被评估。
- 实验覆盖：与多个关键基线（MIG、REEF、AntMan、Orion）缺乏定量对比，是本文证据链中最明显的覆盖缺口 \[页码：12-14\]。
- 方法设计：隐含假设\"内核代码可安全拦截并重编译\"未讨论失效边界（如加密/混淆内核），当前证据未显示该假设已被压力测试 \[基于文中逻辑的推断\]\[页码：13\]。

== 12. 术语与第一性原理学习路径
<12-术语与第一性原理学习路径>

=== 12.1 核心术语
<121-核心术语>
- #strong[术语]：线程块（Thread Block）——GPU 内核中可独立调度、彼此不依赖的最小执行单元集合。

  - #strong[第一性原理角色]：受 GPU 编程模型约束——同一内核内的线程块执行顺序不确定、相互独立，这是块级调度能非侵入通用实现的物理前提。
  - #strong[本文位置]：切片变换通过 `offset+blockIdx` 操作线程块索引实现拆分 \[页码：3, 6\]。

- #strong[术语]：Turnaround latency（切换延迟）——best-effort 内核释放已占用 GPU 资源所需的估计时间。

  - #strong[第一性原理角色]：受调度粒度约束——粒度越粗，turnaround 越长，直接决定隔离上限。
  - #strong[本文位置]：Table 1 用于论证粒度选择；Profiler 用其估算式选择调度配置 \[页码：4, 8\]。

- #strong[术语]：切片（Slicing）——把一个大内核拆分为多个可独立启动的小子内核。

  - #strong[第一性原理角色]：通过增加内核启动次数换取更细的抢占插入点，受\"内核启动开销\"这一资源约束。
  - #strong[本文位置]：模块一，4.1 节 \[页码：6\]。

- #strong[术语]：抢占（Preemption）——允许正在执行的内核被中断并在之后恢复。

  - #strong[第一性原理角色]：通过引入循环控制流和状态标志，把\"任务能否被打断\"从内核启动边界下沉到迭代边界，受同步安全性约束（需配合统一同步变换）。
  - #strong[本文位置]：模块二，4.1 节 \[页码：6-7\]。

- #strong[术语]：统一同步变换（Unified Synchronization Transformation）——将内核中所有同步点和返回点重定向到单一检查点的代码变换。

  - #strong[第一性原理角色]：解决\"同步分歧\"这一 GPU 编程模型下的未定义行为约束，是抢占变换安全生效的前提条件。
  - #strong[本文位置]：模块三，4.1 节 \[页码：7\]。

- #strong[术语]：Profile-guided 调度配置——通过运行时实测/估算为每个内核选择最优调度原语与参数。

  - #strong[第一性原理角色]：在\"隔离强度\"与\"best-effort 吞吐\"两个约束目标之间做权衡搜索。
  - #strong[本文位置]：模块四，4.2 节 \[页码：7-8\]。

- #strong[术语]：非侵入（Non-intrusive）——不需修改用户代码/框架即可生效的系统设计属性。

  - #strong[第一性原理角色]：约束来自生产集群\"对运行中工作负载语义无感知\"的现实条件，决定了系统只能在设备代码/API 层面介入。
  - #strong[本文位置]：整体设计目标之一，贯穿第 4 节 \[页码：2, 5, 13\]。

- #strong[术语]：P99 延迟——第 99 百分位响应时间，衡量最坏情况用户体验。

  - #strong[第一性原理角色]：连接\"任务调度延迟\"与\"服务质量（SLA）达标\"两个基本量。
  - #strong[本文位置]：核心评估指标，贯穿第 5 节 \[页码：9\]。

=== 12.2 学习路径
<122-学习路径>
+ GPU 的 SM/线程/warp/线程块/网格层级结构——理解\"哪一级别可被独立调度\"是理解块级调度可行性的基础 \[页码：3\]。
+ GPU 共享与性能隔离的基本目标——理解\"为什么要在同一 GPU 上跑多个任务却互不拖累\"，类比多辆车共用一条车道但要保证急救车优先 \[页码：1-2\]。
+ 调度粒度与切换延迟的关系——理解\"粒度越粗、切换等待越久\"这一因果链，是 Table 1 论证的基础 \[页码：4\]。
+ GPU 内核编译中间表示（PTX）与设备代码拦截机制——理解 Tally 如何在不接触源码的情况下修改内核行为 \[页码：13\]。
+ 优先级调度与 reactive 策略——理解\"高优先级优先、必要时抢占\"的调度决策逻辑，是理解 Priority-aware 调度器权衡的前提 \[页码：8-9\]。
