# 图片批次 2

## 图片 1：Figure 3. Kernel transformations: (a) slicing and preemption transformations (b) unified synchronization transformation.

![Figure 3. Kernel transformations: (a) slicing and preemption transformations (b) unified synchronization transformation.](../assets/imgs/img_in_image_box_105_143_1112_470.jpg)

*来源：OCR 第 6 页。*

### 解读

1. **论文角色与验证问题**：该图对应 Figure 3，是论文方法核心机制图，用于解释 4.1 节"内核变换（Kernel Transformations）"如何在设备代码层面实现切片（slicing）、抢占（preemption）与统一同步（unified synchronization）三个变换,即模块一、二、三的具体实现细节。其证据类型为**机制（mechanism）**：不是展示实验数据，而是解释"块级调度为何能以非侵入方式对任意内核通用适用"这一核心洞见（核心洞见 2、4）背后的具体代码变换逻辑 [正文支持]。
   - **图表角色**：方法流水线。
   - **上文呼应**：对应 4.1 节"Kernel Transformations"，呼应第 5 节"核心洞见"中"切片与抢占原语可通过设备代码变换实现"的主张，以及"统一同步变换"作为抢占变换的前置安全保障这一设计动机。

2. **图像类型与布局**：左侧为示意图（Figure 3a），右侧为伪代码/编译中间表示对照图（Figure 3b）。左侧分三部分：原始内核（16 个编号方块 0–15，4×4 网格）、切片后的 4 个子内核（各标注 Block Offset 与局部块编号 0–3）、以及抢占式内核（含 Worker 1/Worker 2 两个彩色 worker 方块、一个循环箭头、"Next block"计数器和"Preempt Flag"状态框，以及底部"pointers passed in by scheduler"说明）。右侧分左右两栏对照"Original Kernel"与"Transformed Kernel"的设备代码片段（含 `$BB1`/`$BB2`/`$BB_SYNC` 等基本块标签、`bar.sync`、`ret`、`mov.pred`、`branchtargets` 等指令），并配三个右侧文字说明框解释每个变换动作的含义（标记同步位置、标记返回状态、检查线程是否都已到达同步/返回状态）。

3. **如何阅读**：左侧应按"原始内核 → 切片（向右上箭头）→ 4 个子内核"和"原始内核 → 抢占（向右下箭头）→ 抢占式内核"两条路径分别读取，对比子内核如何用 Block Offset 复原原始块编号、抢占内核如何用固定数量 worker 循环领取 "Next block" 编号并检查 "Preempt Flag"。右侧应逐行对照 Original 与 Transformed 两栏代码，配合虚线箭头指向的蓝色/黑色说明文字（"transform for every sync instruction"、"transform for every return instruction"、"postponed for every kernel"）理解每条原始指令被替换/新增为何种指令，以及最右侧三个文字框对应统一同步变换的判断逻辑。

4. **直接可见的结论**：
   - 切片将 16 块的原始内核拆为 4 个各含 4 块的子内核，每个子内核标注不同的 Block Offset（0、4、8、12）[图像直接可见]。
   - 抢占式内核仅显示 2 个 worker（Worker 1、Worker 2），通过一个循环箭头和"Next block"计数器动态领取任务，并维护一个布尔型"Preempt Flag"状态 [图像直接可见]。
   - 右侧代码对照显示：原始的 `bar.sync 0` 被替换为设置 `is_sync` 谓词、记录位置索引、跳转到统一同步块 `$BB_SYNC` 的指令序列；原始的 `ret` 被替换为设置不同位置索引后同样跳转到 `$BB_SYNC` 的指令；`$BB_SYNC` 块中新增一条使用 `tally_ts`（分支目标）的分支指令，并含 `bar.or.pred`（线程间"或"归约同步）判断是否所有线程都已置位 `has_sync` [图像直接可见]。
   - 三个说明框表明该统一同步块的作用是：区分"到达同步点"与"到达返回点"两类线程，记录各自位置索引，并通过检查是否存在任何同步调用来决定线程是回退继续执行还是保持等待直至对齐 [图像直接可见]。

5. **它验证的论点与方法设计含义**：本图属于**机制类**证据，直接支撑核心洞见 4（切片/抢占可通过设备代码变换实现,无需框架/硬件改造）与模块三的设计动机（抢占引入的提前 return 会导致同一 block 内线程在不同同步点调用同步指令，产生未定义行为；统一同步变换通过把所有同步/return 指令重定向到单一同步块，检测并强制线程对齐后再统一返回，从而消除该风险）[正文支持]。该图确认了正文文字描述的两个具体机制点：(1) 切片通过 `offset + blockIdx` 重建原始块索引这一说法在图中以"Block Offset"标注体现；(2) 统一同步变换的判断逻辑（"是否存在同步调用→回退 vs 全部返回"）与正文" redirecting them to a unified synchronization point that checks whether all threads have reached a return state"一致。该图**不能**证明这些变换在实际内核上的运行时开销大小，也不能证明变换对功能正确性的普适性覆盖了所有内核类型（如 Cooperative Groups 内核，正文已说明这类内核被排除在块级调度之外）——这些量化结论需依赖 5.5/5.7 节实验数据。

6. **适用范围与证据缺口**：本图展示的是论文示意性质的代码变换示例（16 块→4 子内核、2-worker 抢占的最小化示例），用于解释设计原理，并非某个具体基准工作负载（如 BERT/Whisper）的真实反汇编代码或真实参数配置。左侧示意图中的具体数值（4 个子内核、2 个 worker）是否代表 Tally 实际运行时的默认参数,正文与图注均未说明，无法从当前图像内容确认。除此之外无额外证据缺口。

---

## 图片 2：Figure 5. Analysis of 99th-percentile latency and system throughput across different high-priority inference and best-effort training workload combinations under various GPU sharing mechanisms.

![Figure 5. Analysis of 99th-percentile latency and system throughput across different high-priority inference and best-effort training workload combinations under various GPU sharing mechanisms.](../assets/imgs/img_in_chart_box_109_149_1115_786.jpg)

*来源：OCR 第 10 页。*

### 解读

1. **论文角色与验证问题**：该图对应 Figure 5,是 5.2 节"端到端结果"的核心实验证据,证据类型为**效果（effect）**并同时承担**对比基线**角色。它试图验证论文摘要与引言的核心量化主张——"Tally 相比 Time-Slicing/MPS/MPS-Priority/TGS 四个非侵入基线,能把高优先级推理任务的 P99 延迟开销压到接近理想（Ideal 独立运行）水平，同时保持有竞争力的系统吞吐"，具体检验的是第 3 节批判的"旧方法缺乏性能隔离保证"这一限制在真实多样化工作负载组合下是否成立、以及块级调度（Tally）能否克服该限制 [正文支持]。
   - **图表角色**：实验结论 / 对比基线。
   - **上文呼应**：5.2 节"End-to-end Results"，呼应摘要中"7.2% vs 188.9%"、"105.2%/83.6%/80.6%/80.3% 系统吞吐"等主张。

2. **图像类型与布局**：多子图分组柱状图，共 6 个推理任务面板（BERT、Llama-2-7B、ResNet50、YOLOv6M、GPT-Neo-2.7B、Stable Diffusion），每个面板内又分上下两行子图（P99 Latency (ms) 在上、System Throughput 在下）。每个子图 x 轴为 6 种配对的 best-effort 训练工作负载（Whisper、ResNet50、PointNet、Pegasus、GPT2、BERT），每个 x 位置有 6 根并排彩色柱：Ideal（蓝）、Time-Slicing（橙）、MPS（红）、MPS-Priority（绿）、TGS（黄绿）、Tally（紫），顶部统一图例标注六种颜色对应系统。

3. **如何阅读**：应先按推理任务（6 个面板）分组阅读，每个面板内先看上方 P99 延迟柱状图——比较 Tally（紫）与 Ideal（蓝）柱高是否接近，以及与其余四个基线（尤其 MPS 红色柱)柱高差距;再看下方系统吞吐柱状图——比较 Tally 紫柱相对其余基线柱的相对高度。x 轴的 6 个配对训练任务代表不同的协同执行场景，需要逐个比较而非只看单一配对。纵轴单位与量程因面板而异（如 Llama-2-7B 面板纵轴到 6000+ms，GPT-Neo-2.7B 到 40000ms），跨面板不可直接比较绝对值,只能比较各面板内部相对差异。

4. **直接可见的结论**：
   - 在全部 6 个推理任务、6 种训练配对组合中，紫色 Tally 柱在 P99 延迟子图里始终最接近蓝色 Ideal 柱，明显低于红色 MPS 柱（MPS 在多数面板中柱高最突出，例如 BERT 面板与 Whisper 配对时远高于其余柱）[图像直接可见]。
   - 系统吞吐子图中，Tally（紫）柱高度总体低于 Time-Slicing/MPS/MPS-Priority/TGS 等基线柱，但差距幅度在多数配对组合下不大（视觉上多在同一量级）[图像直接可见]。
   - GPT-Neo-2.7B 面板中 Time-Slicing（橙）在 Whisper、PointNet 配对下的 P99 延迟柱显著高出该面板其余柱（视觉上突出的极端值）[图像直接可见]。
   - 不同推理任务面板间,MPS（红）柱相对 Ideal 的倍数差异有可见的大小变化（例如 ResNet50、Whisper 配对时 MPS 柱视觉上比 Ideal 高出较多倍），但具体倍数需依赖正文数值,图像本身无法精确读出准确比值 [基于视觉的谨慎推断]。

5. **它验证的论点与方法设计含义**：该图（连同正文数值 7.2% vs 188.9%–345.0%，系统吞吐 80.3%–105.2%）以**效果类**证据支撑"Tally 在保证性能隔离的同时不显著牺牲吞吐"这一核心贡献主张，并同时是**对比基线**类证据：Time-Slicing/MPS 柱普遍偏高说明其"优先级无关设计"（第 3 节批判点）在广泛工作负载组合下普遍导致高优先级任务排队延迟增大；MPS-Priority/TGS 柱虽低于 MPS/Time-Slicing 但仍显著高于 Tally，印证"内核级调度粒度不足以应对协同执行干扰"（Table 1 粒度论证的推广验证）。该图把第 3 节的粒度论证（仅 BERT+Whisper 单一案例）扩展到 6 推理×6 训练=36 种组合的系统性验证，属于对"块级调度是否在多样化场景下普遍有效"这一必要性/普适性主张的实证支持。该图**不能**单独证明块级调度本身（相对于仅有调度算法无变换）的贡献占比——这是 5.5 节 Figure 7(b) 消融实验的任务；也不能证明 Tally 在非 A100/非本文基准套件之外的通用性。

6. **适用范围与证据缺口**：本图覆盖论文报告的实验设置——AWS p4d.24xlarge 实例、单张 A100 GPU、MAF2 轨迹模拟的推理流量、固定 50% 负载、六种训练×六种推理的全部组合 [正文支持]。图中各子图具体数值（如某一配对组合下 Tally 与 Ideal 的精确延迟数值、各系统的精确吞吐比值）无法从当前图像像素精确读出，只能依赖正文给出的平均值（7.2%、188.9%等）；图像本身未标注具体数值标签,因此无法在图中独立核实正文"70% 组合延迟退化 10% 以内、最差 ResNet50 23%"这一细粒度分布性结论具体对应柱状图中的哪些位置。
