# 图片批次 3

## 图片 1：Figure 6. (a) Latency and throughput for high-priority BERT and Llama2-7B inference co-located with BERT, GPT-2, and Whisper training under Tally and TGS across different traffic loads. (b) Time-series visualization of user traffic, tail latency, and throughput over time for BERT inference co-located with BERT training across different GPU sharing systems.

![Figure 6. (a) Latency and throughput for high-priority BERT and Llama2-7B inference co-located with BERT, GPT-2, and Whisper training under Tally and TGS across different traffic loads. (b) Time-series visualization of user traffic, tail latency, and throughput over time for BERT inference co-located with BERT training across different GPU sharing systems.](../figure-groups/page-0011-041b53eb46e5.png)

*来源：OCR 第 11 页。*

### 解读

1. **论文角色与验证问题**：本组图对应 5.3 节"流量负载敏感性分析"与其时序案例说明，证据类型为**鲁棒性（robustness）**与**效果（effect）**。正文明确陈述：作者需要证明 Tally 的隔离能力"不受流量负载高低、也不受配对训练任务特征影响"，并进一步用一段真实流量轨迹的时序回放展示 Tally 对波动流量的"自适应"能力 [正文支持][页码：10-11]。
   - **图表角色**：实验结论 / 鲁棒性验证。
   - **上文呼应**：5.3 节"Traffic Load Sensitivity Analysis"（Figure 6a）与该节末尾时序案例（Figure 6b），对应主张地图中"Tally 的隔离能力对不同流量负载、不同训练任务配对具有鲁棒性"一条。

2. **图像类型与布局**：整图为 Figure 6 的完整拼版，由两部分构成：Figure 6a 为 4 个折线图面板（Panel2–Panel5，共享 Panel1 图例），Figure 6b 为一组纵向堆叠的三个时序折线图（Panel6 内的 (1)(2)(3)）。Panel1 图例标注 BERT/GPT2/Whisper 分别配 TGS（虚线）与 Tally（实线）两种线型，以及 Ideal（紫色虚线）。Panel2「(1) BERT」与 Panel3「(2) Llama-2-7B」为 P99 延迟 vs Idle Time 折线图；Panel4「(3)」与 Panel5「(4)」为系统吞吐 vs Idle Time 折线图，分别对应 BERT、Llama-2-7B 作为高优先级推理任务的场景。Panel6 三个子图依次为"请求数随时间变化"、"高优先级 P99 延迟随时间变化（六种方法对比）"、"best-effort 训练吞吐随时间变化"。

3. **如何阅读**：Panel2/3 横轴为 Idle Time（10%–90%，即 100%−负载），纵轴为 P99 延迟（ms）；应对比同一训练搭配下 TGS（虚线）与 Tally（实线）在各 idle time 点的高度差，以及与 Ideal 虚线的贴合程度。Panel4/5 横轴同为 Idle Time，纵轴为系统吞吐（无量纲/归一化值），应比较 Tally 与 TGS 曲线的相对高度及其随 idle time 增大的收敛趋势。Panel6 三个子图共享横轴（时间戳，秒），分别读请求量峰值与"Server Capacity"虚线的关系、六条方法曲线相对 Ideal 基线的抬升幅度、以及 Tally 训练吞吐相对 Ideal 训练吞吐的贴合度。

4. **直接可见的结论**：
   - Panel2、Panel3 中，无论训练搭配（BERT/GPT2/Whisper）如何，Tally 实线始终紧贴 Ideal 虚线、且在 10%–90% Idle Time 区间内几乎水平不变；而 TGS 虚线整体显著更高（BERT 场景约 15–23ms，Llama 场景约 3300–4400ms），且不同训练搭配之间 TGS 的高度差异明显（Whisper 搭配最高）[图像直接可见]。
   - Panel4、Panel5 中，Tally（实线）与 TGS（虚线）的系统吞吐都随 Idle Time 增大而上升；在低 Idle Time（10%）处两者差距最大，Tally 明显低于 TGS，随 Idle Time 增大差距逐渐收窄，至 90% 时两者曲线接近重合 [图像直接可见]。
   - Panel6 中，请求量子图显示流量在 Server Capacity 虚线附近剧烈波动；高优先级延迟子图中多条基线方法曲线出现明显尖峰式抬升，而 Tally 与 Ideal 对应曲线维持在低位且相对平稳；best-effort 吞吐子图显示 Tally 的训练吞吐曲线随时间起伏，其波动形态与 Ideal（独立运行）吞吐曲线大致同步、但整体水平在部分时段略低 [基于视觉的谨慎推断，因线条颜色在小图上不易逐一精确区分]。

5. **它验证的论点与方法设计含义**：本组图直接支持主张地图中"Tally 的隔离能力对不同流量负载、不同训练任务配对具有鲁棒性"这一鲁棒性主张——Panel2/3 显示无论 idle time 高低或训练任务类型如何变化，Tally 延迟始终贴近 Ideal，印证正文"BERT 最高 5.8×、Llama-2-7B 最高 2.3× 延迟放大发生在 TGS 而非 Tally"的陈述 [正文支持][页码：10]。Panel4/5 验证了效果类主张中"Tally 在低负载（高 idle）区间吞吐收敛于 TGS 水平，但在高负载（低 idle）区间因严格优先级策略牺牲部分吞吐"，对应文中"10% idle time 时 Tally=1.19 vs TGS=1.65"的具体陈述，说明 Priority-aware 调度器设计中"reactive、严格让路"策略在高负载下的吞吐代价 [正文支持][页码：10]。Panel6 作为案例验证，支持"Tally 能自适应波动流量、同时保留 best-effort 训练吞吐 68% 以上"的效果主张 [正文支持][页码：11]。该图不能证明 Tally 在此两个模型之外的其余训练/推理组合（如 PEGASUS、YOLOv6m 等）下是否同样鲁棒，也不能证明该策略在超过 90% 高负载或更极端流量突发下的表现。

6. **适用范围与证据缺口**：本证据覆盖论文报告的 AWS p4d.24xlarge（A100 GPU）上，BERT 与 Llama-2-7B 两个推理代表任务分别与 BERT/GPT2/Whisper 三种训练任务搭配、MAF2 流量轨迹模拟下 10%–90% Idle Time 的测试范围 [正文支持][页码：10]。Panel6 时序子图的具体纵轴刻度、Tally 与其余基线曲线的逐条颜色对应关系因图像分辨率限制无法完全精确辨读，属于图像裁剪/像素分辨率导致的真实缺口。

---

## 图片 2：Figure 7. (a) Scalability performance of Tally with respect to number of concurrent workloads. (b) Performance decomposition of Tally for BERT inference. (c) Latency and throughput under different turnaround latency threshold settings.

![Figure 7. (a) Scalability performance of Tally with respect to number of concurrent workloads. (b) Performance decomposition of Tally for BERT inference. (c) Latency and throughput under different turnaround latency threshold settings.](../figure-groups/page-0012-28843ab9279e.png)

*来源：OCR 第 12 页。*

### 解读

1. **论文角色与验证问题**：本组图对应 5.4 节"可扩展性"与 5.5 节"性能分解"、5.6 节"Turnaround Latency 分析"三项实验，证据类型分别为**适用范围（scope）**（Panel1）、**必要性（necessity）/机制（mechanism）**（Panel2）、以及**效果（effect）/参数敏感性**（Panel3、4）。作者需要依次验证：Tally 能否在 best-effort 任务数量增多时仍保持高优先级延迟稳定；块级内核变换相对于"仅调度算法"是否是隔离效果的必要因素；turnaround latency 阈值参数如何在延迟与吞吐之间权衡 [正文支持][页码：11-12]。
   - **图表角色**：适用范围验证（Panel1）+ 消融验证（Panel2）+ 实验结论/参数敏感性（Panel3、4）。
   - **上文呼应**：5.4 节"Scalability with Number of Workloads"（Figure 7a）、5.5 节"Performance Decomposition"（Figure 7b）、5.6 节"Turnaround Latency Analysis"（Figure 7c）。

2. **图像类型与布局**：整图为 Figure 7 的完整拼版，含四个子面板。Panel1「(a)」为双纵轴折线图：左轴 High Priority Latency（蓝色圆点线），右轴 System Throughput（橙色圆点线），横轴为 best-effort 工作负载数（1–10）。Panel2「(b)」为分组柱状图（y 轴对数刻度），横轴为六个训练工作负载名称（Whisper、ResNet50、PointNet、Pegasus、GPT2、BERT），每组含四色柱：Ideal（蓝）、No Scheduling（橙）、Scheduling w/o Transformations（红）、Scheduling + Transformations/Tally（绿）。Panel3「(c-i)」为 P99 Latency vs Turnaround Latency Threshold 的折线图（横轴对数刻度），六条彩色曲线对应六个推理/训练模型（Whisper、BERT、Pegasus、ResNet50、PointNet、GPT2）。Panel4「(c-ii)」为对应的 Norm Throughput vs Turnaround Latency Threshold 折线图，同一组六条曲线。

3. **如何阅读**：Panel1 应分别读左轴蓝线（是否随负载数增加而抬升）与右轴橙线（是否持续上升或趋于饱和平台）。Panel2 应在同一训练负载分组内纵向比较四色柱高度差异（对数轴意味着柱高差异是数量级差异），横向比较不同训练负载间"No Scheduling"与"w/o Transformations"柱的高度变化。Panel3/4 应沿横轴（阈值从约 0.01ms 增至约 3ms）观察六条曲线纵轴取值的变化趋势，并比较不同模型曲线的斜率差异。

4. **直接可见的结论**：
   - Panel1 中，蓝色 High Priority Latency 曲线在 best-effort 任务数从 1 增至 10 的过程中基本保持水平（约 1.5–1.6ms 附近无明显抬升）；橙色 System Throughput 曲线随任务数增加持续上升，大致在任务数达到 7–8 附近后增速明显放缓、趋于平台 [图像直接可见]。
   - Panel2 中，六组训练负载的 No Scheduling（橙）柱普遍显著高于 Ideal（蓝）柱，其中 Whisper、PointNet、Pegasus 对应的橙柱在对数轴上抬升幅度尤为突出；Scheduling w/o Transformations（红）柱相对 No Scheduling 有所降低，但在 Whisper、Pegasus、PointNet 等负载上仍明显高于 Ideal；Scheduling + Transformations（绿）柱在六组负载中均紧贴 Ideal 蓝柱高度 [图像直接可见]。
   - Panel3 中，六条曲线在低阈值区间（约 <0.3ms）普遍聚集在 4–5ms 附近且彼此接近；随阈值增大到约 1–3ms 区间，Whisper（蓝色）曲线陡峭上升至约 8.7ms，PointNet（紫色）也有一定幅度抬升，其余曲线（BERT、Pegasus、ResNet50、GPT2）抬升幅度较小 [图像直接可见]。
   - Panel4 中，六条归一化吞吐曲线随阈值增大整体呈缓慢上升趋势，各曲线之间存在明显的水平层级差异（如蓝色曲线整体最高、红色曲线整体最低），但整体斜率远小于 Panel3 中延迟曲线的抬升幅度 [图像直接可见]。

5. **它验证的论点与方法设计含义**：Panel1 支持主张地图中"Tally 可扩展到多个 best-effort 任务而不损害高优先级任务性能"这一适用范围主张，直接印证正文"延迟在 1–10 个任务间保持一致、吞吐持续上升直至约 8 个任务时 GPU 饱和"的陈述 [正文支持][页码：11]。Panel2 是本文核心机制主张"块级调度对性能隔离是必要的"的关键消融证据：No-scheduling 缺乏优先级机制导致的严重延迟放大（最差 Whisper 场景约 30×）说明"仅有调度算法而无内核变换"仍不足以应对长内核工作负载干扰（对应正文 ResNet50/GPT2 8.0%/9.8% 但 Whisper/BERT 达 10× 的陈述），只有加入切片+抢占的完整 Tally 才能把延迟放大压到平均 4.0%（最差 6.2%）——这直接支撑"块级内核变换是隔离效果的必要条件，而非调度算法单独可实现"的机制类主张 [正文支持][页码：12]。Panel3/4 支持"turnaround latency 阈值需要权衡延迟与吞吐"的效果类主张：阈值升高总体导致延迟增加（尤其对长内核 Whisper 影响最大）而吞吐仅小幅提升，为默认阈值 0.0316ms 的经验选择提供依据 [正文支持][页码：12]。该图不能证明这一阈值在其他 GPU 型号或非 A100 硬件下的最优性，也不能证明可扩展性结论可推广到异构 best-effort 任务组合（Panel1 仅用同构 ResNet50 推理任务模拟）。

6. **适用范围与证据缺口**：Panel1 覆盖的是 1–10 个同构 ResNet50 推理任务模拟 best-effort 负载的场景，并非异构任务组合 [正文支持][页码：11]。Panel2 覆盖 BERT 高优先级推理与六个训练工作负载（Whisper、ResNet50、PointNet、Pegasus、GPT2、BERT）的消融对比 [正文支持][页码：12]。Panel3/4 覆盖六个推理/训练模型在 0.01ms–10ms 六档阈值下的敏感性扫描 [正文支持][页码：12]。柱状图（Panel2）对数轴上部分较矮柱体（如 Ideal 与 Tally 柱）因刻度压缩导致具体数值差异不易精确读出，属于图像本身刻度精度导致的真实缺口；除此以外无额外证据缺口。
