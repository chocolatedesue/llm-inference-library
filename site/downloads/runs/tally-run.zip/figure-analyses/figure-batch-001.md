# 图片批次 1

## 图片 1：Figure 1. Overview of the GPU programming model.

![Figure 1. Overview of the GPU programming model.](../assets/imgs/img_in_image_box_662_147_1092_362.jpg)

*来源：OCR 第 3 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 2 节 "GPU architecture and programming model"，用于讲解 GPU 编程模型的层级结构（kernel→thread block→warp→thread），为后文核心洞见 2（"线程块彼此独立执行、调度顺序不确定，因而块级调度可对所有内核通用适用"）提供概念基础 [正文支持][页码：3, 5]。
   - **图表角色**：方法流水线（作为切片/抢占变换设计的前置概念铺垫，非实验数据图）。
   - **上文呼应**：第 2 节背景介绍；核心洞见 2（页码 3, 5）。

2. **图像类型与布局**：概念示意图（嵌套层级放大图）。左侧为整体 Kernel 区域，内含多个蓝色 "B" 方块（Thread Block）按网格排列，标注 gridDim: (x1, y1, z1)、blockDim: (x2, y2, z2)；虚线引出右侧放大的单个 "Thread Block" 框，内含多个橙色 "W" 方块（Warp），标注 blockIdx；再由虚线引出右上角放大的单个 "Warp" 框，内含 "32 Threads" 标注和 threadIdx。

3. **如何阅读**：按从左到右的层级放大顺序阅读——整体 Kernel（多个 Thread Block 组成的网格）→ 单个 Thread Block（内含多个 Warp）→ 单个 Warp（固定 32 个 Thread）。图中无数值坐标轴，标注的是结构性变量名（gridDim、blockDim、blockIdx、threadIdx），用于识别各层级的索引方式。

4. **直接可见的结论**：Kernel 由多个 Thread Block 排列成网格结构；每个 Thread Block 内部包含多个 Warp；每个 Warp 固定含 32 个 Thread；blockIdx 标识 Block 在 grid 中的位置，threadIdx 标识 Thread 在 Warp/Block 中的位置 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图不含实验数据，属于机制/背景说明类证据，用于让读者建立"线程块是可独立调度的基本单位"这一编程模型认知，从而支撑正文核心洞见 2——"线程块彼此独立执行、调度顺序不确定，使块级调度可以对所有内核通用适用（不依赖幂等性假设）" [正文支持][页码：3, 5]。图中显式标注的 blockIdx 变量，直接对应 4.1 节切片变换"用 offset + 原 blockIdx 重建原始块索引"的技术前提。该图不能用于证明任何效果、必要性或对比类实验主张，仅提供概念铺垫。

6. **适用范围与证据缺口**：本图为通用 GPU 编程模型的结构示意，不针对特定 GPU 型号或具体 kernel 实例，不含具体数值。图中未直接可视化"线程块调度顺序不确定"这一性质（该论断为正文文字陈述），但正文已明确说明（"thread blocks... can be scheduled and executed independently in any order"[页码：3]），图仅承担结构可视化角色，不构成第 6 条定义下的真实缺口。无额外证据缺口。

---

## 图片 2：Figure 2. Tally architecture.

![Figure 2. Tally architecture.](../assets/imgs/img_in_image_box_659_144_1093_544.jpg)

*来源：OCR 第 5 页。*

### 解读

1. **论文角色与验证问题**：该图对应第 4 节 "TALLY: SYSTEM DESIGN" 引言段，图注为 "Figure 2. Tally architecture."，用于呈现 Tally 的整体客户端-服务端架构，解释非侵入虚拟化层如何拦截应用调用并交由服务端统一调度 [正文支持][页码：5]。
   - **图表角色**：方法流水线。
   - **上文呼应**：第 4 节系统设计总览（页码 5）；对应贡献 2（非侵入细粒度块级调度 + priority-aware 调度器，页码 3）与模块六（非侵入虚拟化层，页码 13）。

2. **图像类型与布局**：分层架构/流程图。顶部 "Tally Client Interception" 区域内三个应用/框架图标：ONNX Runtime（红色标注 "High-priority Inference"）、PyTorch（绿色标注 "Best-effort Training"）、JAX（绿色标注 "Best-effort Inference"），各有箭头向下指向服务端。下方大框 "Tally Virtualization Server" 内纵向排列三行：Kernel Transformer（输入 "Low-level Device Code" → 输出 "Sliced & Preemptive Kernel"）、Transparent Profiler（输入 "Kernel Ptr & Grid Size" → 输出 "Estimated Turnaround Latency"）、Priority-aware Scheduler（输入 "Client Task Queues" → 输出 "Kernel to dispatch & Launch Configuration"），左列为青色输入框、右列为紫色输出框，行间有交叉箭头连接。最底部为 "GPU" 框，与 Server 之间有箭头相连。

3. **如何阅读**：自上而下阅读：顶部三个图标代表不同优先级/角色的 client 进程（红色=高优先级、绿色=best-effort），箭头表示它们统一经拦截层进入 Tally Virtualization Server；Server 内部左列（输入）→右列（输出）为每个组件的处理内容，行间交叉箭头表示组件间的数据依赖（例如 Kernel Transformer 的输出信息被下方 Profiler/Scheduler 使用）；最底部 GPU 与 Server 的箭头表示最终执行调度关系。

4. **直接可见的结论**：三类 client（ONNX Runtime=高优先级推理·红色，PyTorch=best-effort 训练·绿色，JAX=best-effort 推理·绿色）均先经过 "Tally Client Interception" 层再进入 "Tally Virtualization Server"；Server 内部按顺序包含 Kernel Transformer、Transparent Profiler、Priority-aware Scheduler 三个模块，各自具有独立的输入/输出标注，且模块间存在交叉箭头连接；Server 最终与 GPU 相连 [图像直接可见]。

5. **它验证的论点与方法设计含义**：该图属方法流水线类证据，直观呈现"非侵入虚拟化层 + 客户端-服务端架构"整体设计（对应模块六及贡献 1、2）[正文支持][页码：5, 13]。图中通过颜色区分高优先级与 best-effort 角色，可视化印证正文所述"client library 拦截设备代码/API 调用并转发给 server，server 负责实际设备执行与资源调度"的机制描述 [正文支持][页码：5]；图中三个 server 组件与正文 4.1–4.3 节三个子模块一一对应，其输入输出关系（如 Kernel Transformer 输出 "Sliced & Preemptive Kernel" 被下游 Profiler 和 Scheduler 使用）佐证了正文"transparent profiler 对变换后 kernel 在不同 launch 配置下 profile"以及"scheduler 整合前两者能力做出调度决策"这一流水线顺序 [正文支持][页码：5]。该图不含任何实验数值，不能用于验证效果类主张（如 7.2% 延迟开销）或消融/对比类结论，仅说明架构机制本身。

6. **适用范围与证据缺口**：本图展示 Tally 的通用架构示意，图中列出的三类框架（ONNX Runtime/PyTorch/JAX）用于说明架构对不同框架的兼容性；需注意实际评测中使用的推理引擎为 ONNX Runtime/TorchInductor/Hidet、训练框架为 PyTorch，5.1 节未提及使用 JAX 进行评测 [基于文中逻辑的推断，依据：5.1 节列出的实际评测框架与图中 JAX 图标不完全一致][页码：8]。图中箭头线条清晰、无像素遮挡，架构关系可完整辨认。无额外证据缺口。
